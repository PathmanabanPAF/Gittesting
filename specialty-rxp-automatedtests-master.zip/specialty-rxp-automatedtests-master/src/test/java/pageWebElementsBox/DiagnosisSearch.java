package pageWebElementsBox;

import org.openqa.selenium.By;

public class DiagnosisSearch {
	
	public static By lableDiagnosis = By.xpath("//*[contains(@class, 'dataLabelForWrite flex flex-row ')]");

}
