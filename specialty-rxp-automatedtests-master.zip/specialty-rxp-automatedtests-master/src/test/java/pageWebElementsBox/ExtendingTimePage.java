package pageWebElementsBox;

public class ExtendingTimePage {

	
	public static String xpathFavoriteOptions = "//following-sibling::*//*[@role='menu' and not(contains(@style,'none'))]";

	
	
	
}
