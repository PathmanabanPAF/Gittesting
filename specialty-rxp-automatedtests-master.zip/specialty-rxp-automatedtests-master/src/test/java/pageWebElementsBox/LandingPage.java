package pageWebElementsBox;

import org.openqa.selenium.By;

public class LandingPage {

	public static String xpathMenuNamePart1 = "//i[contains(@class,'avatar')]//*[.='";
	public static String xpathMenuNamePart2 = "']";

	public static String xpathLandingPageHeaderPart1 = "//*[contains(@class,'accredoportallabel')]//*[normalize-space(text())='";
	public static String xpathLandingPageHeaderPart2 = "']";
	
	public static By xpathTRCValue = By.xpath("//*[text()='TRC Name:']//*[text()]");
	
	public static By xpathAccredoLogo = By.xpath("//*[contains(@src,'accredo_logo_header')]");
	
	public static By xpathWorkBaskets = By.xpath("//*[@node_name='DashBoardProcessCount']//button[contains(@class,'Accredo') and not(contains(@class,'disabled'))]");
	
	public static String dynamicXpathWIPCountPart1 = "//button[normalize-space(.)='";
	public static String dynamicXpathWIPCountPart2 = "' and not(ancestor::*[contains(@style,'none')])]/ancestor::*[@string_type='field']/following-sibling::*//span[contains(@class,'operator')]";

	public static String dynamicXpathWorkBasketCount1 ="//button[normalize-space(.)='";
	public static String dynamicXpathWorkBasketCount2 ="']/ancestor::*[contains(@class,'dataValue')]/following-sibling::*//*[@class='accredooperatorname']";
	
	public static String xpathMyLockCasesPart1 = "//*[text()='";
	public static String xpathMyLockCasesPart2 = "']";
	
	public static By xpathWordOrderId = By.xpath("//*[@class='work_identifier']");
	public static By xpathPatientName = By.xpath("//*[text()='Name:']/ancestor-or-self::*[contains(@class, 'dataLabelFor')]/following-sibling::*//span");
	public static By xpathuserLoggedIn = By.xpath("//i[@class='pi pi-user']/ancestor-or-self::*[contains(@class, 'RxP_Header_nav')]");
	public static By xpathLockedCasestable = By.xpath("//*[@id='bodyTbl_right']//tr");
	public static String xpathLockedCasedetailspart1 ="//*[@id='bodyTbl_right']//tr[";
	public static String xpathLockedCasedetailspart2= "]/td[";
	public static String xpathLockedCasedetailspart3= "]";
	
	
	
	
}
