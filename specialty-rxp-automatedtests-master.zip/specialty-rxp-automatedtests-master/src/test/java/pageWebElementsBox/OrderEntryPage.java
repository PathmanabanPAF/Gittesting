package pageWebElementsBox;

import org.openqa.selenium.By;

public class OrderEntryPage {
	
	public static By xpathColumnHeaders = By.xpath("//*[normalize-space(text())='Payer']/ancestor-or-self::*[contains(@class, 'standardlabel')]/following-sibling::*//th[@role='columnheader']//*[normalize-space(@class)='cellIn']");

	public static By xpathReferralCaseId = By.xpath("//*[@class='work_identifier']");
	
	public static String dynamicXpathReferralCaseIdPart1 = "//*[@class='work_identifier' and text()='";
	public static String dynamicXpathReferralCaseIdPart2 = "']";

	public static By xpathEmptyWorkBaksetMessage  = By.xpath("//*[@class='harnessContent']//*[contains(@node_name,'NoAssignments')]//*[contains(@class,'dataLabe')]//*[text()]");
	
	public static By xpathLastWorkOrderError = By.xpath("//*[@class='errorText' and not(ancestor::*[contains(@style,'none')])]//*[text()]");
	
	
	public static String dynamicXpathAgeNotificationPart1 = "//*[normalize-space(text())= '";
	public static String dynamicXpathAgeNotificationPart2 = "']/ancestor-or-self::*[contains(@class,'dataLabelFor')]/following-sibling::*";
    public static String dynamicXpathAgeNotificationPart3 = "//*[normalize-space(text())='";
	public static String dynamicXpathAgeNotificationPart4 = "']/ancestor-or-self::*[@string_type='field']/following-sibling::*//*[contains(@class,'dataLabelRead')]";
	
	public static By xpathAdditionalInformationTab = By.xpath("//a[normalize-space(.)='Additional Information']//*[text()='Additional Information']");

	
}
