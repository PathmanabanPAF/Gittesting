package pageWebElementsBox;

import org.openqa.selenium.By;

public class GraphViewPage {
	public static By graphView = By.xpath("//*[@class='fusioncharts-container']");
	public static By xAxis = By.xpath("//*[contains(@id,'raphael-paper')]//*[@class='fusioncharts-xaxis-0-title']//*[text()]");
	public static By yAxis = By.xpath("//*[contains(@id,'raphael-paper')]//*[@class='fusioncharts-yaxis-0-title']//*[text()]");
	public static By caseCountByTherapy = By.xpath("//label[@class='field-caption dataLabelForWrite']");
	
}
