package pageWebElementsBox;

import org.openqa.selenium.By;

public class SearchPage {

	
	public static String dynamicXpathModalButtons1 = "//*[normalize-space(text())='";
	public static String dynamicXpathModalButtons2 = "']/ancestor::*[@id='modalWrapper']//button[@type='button' and not(@class='container-close')]";

	public static By showMore = By.xpath("//*[text()='Show More']");
	public static By closeSearchLookup = By.xpath(CommonWebElements.dynamicXpathClosePopup);

	public static By drugResultsLocator = By.xpath("//table[contains(@pl_prop,'SearchResults') and not(ancestor::*[contains(@style,'none')])]/tbody");
	public static By druglocInd = By.xpath(".//*[text()]");

	public static By xpathSearchResultsTable = By.xpath("//table[contains(@pl_prop,'SearchResults') and not(ancestor::*[contains(@style,'none')])]");
	
	public static By xpathSearchResultsText = By.xpath("//*[contains(@node_name,'SearchResults') and not(ancestor::*[contains(@style,'none')])]//*[@class='header-title']");

	public static String xpathHeaders = "//table[@id='bodyTbl_right']//th[@role='columnheader']//*[normalize-space(@class)='cellIn']";

	//public static By cancelSearchLookup = By.xpath("//button[normalize-space(text()) = 'Cancel' and not(ancestor::*[contains(@style,'none')]) and contains(@class,'Accredo')]");
	public static By cancelSearchLookup = By.xpath("//button[normalize-space(text()) = 'Cancel']");
	public static By submitSearchLookup = By.xpath("//button[@id='ModalButtonSubmit']");
	public static By tablePrescriber = By.xpath("//table[@pl_prop='ProviderList.pxResults']/tbody");


	public static String dynamicXpathRadioButtonPart1 = "//table[contains(@pl_prop,'SearchResults') and not(ancestor::*[contains(@style,'none')])]//tr[";
	public static String dynamicXpathRadioButtonPart2 = "]//input[@type='radio']";
	
	public static String dynamicXpathColumnValuePart1 = "//table[contains(@pl_prop,'SearchResults') and not(ancestor::*[contains(@style,'none')])]//tr[";
	public static String dynamicXpathColumnValuePart2 = "]/td[";
	public static String dynamicXpathColumnValuePart3 = "]//*[text()]";
	
	public static String dynamicXpathNextPageButton3 = "//button[.='>' and not(contains(@class,'disabled'))]";
	
	public static String dynamicXpathColumnValues1 = "//table[@id='bodyTbl_right']//td[";
	public static String dynamicXpathColumnValues2 = "]//*[text()]";
	
	public static String dynamicXpathPhoneNumberColumn3 = "//table[@id='bodyTbl_right']//tr[";
	public static String dynamicXpathPhoneNumberColumn4 = "]";
	
	public static String xpathRowCount = "//table[@id='bodyTbl_right']//tr";
	
	public static String xpathDiagnosisSearch1 = "//*[@pl_prop='DiagnosisSearchResults.pxResults']//following-sibling::*//tr[";
	public static String xpathDiagnosisSearch2= "]//input[@type='checkbox']";
	
	public static By xpathICDSearchResutlTbl = By.xpath("//*[@pl_prop='DiagnosisSearchResults.pxResults']/tbody");
	
	public static By xpathDiagnosisCodesTbl = By.xpath("//*[@pl_prop= '.DiagnosisHC']//tbody");
	
	public static String xpathDeleteIcon1 = "//*[@pl_prop= '.DiagnosisHC']//tbody//tr[";
	
	public static String xpathDeleteIcon2 = "]/td[4]//a[@class = 'iconDelete']";

	public static String xpathSelectAdditionalDetailsTbl = "//table[contains(@id,'bodyTbl') and not(ancestor::*[contains(@style,'none')])]/tbody";
	

}
