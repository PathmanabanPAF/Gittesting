package pageWebElementsBox;

import org.openqa.selenium.By;

public class TaskTimeOutPage {

	public static By xpathTaskTimeOutText = By.xpath("//*[@class='dialogHeaderLabel']");
	
}
