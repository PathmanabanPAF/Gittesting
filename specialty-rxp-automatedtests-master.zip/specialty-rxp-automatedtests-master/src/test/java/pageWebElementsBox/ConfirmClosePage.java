package pageWebElementsBox;

public class ConfirmClosePage {

	public static String dynamicXpathPopUpMessagePart1 = "//*[normalize-space(text())='";
	public static String dynamicXpathPopUpMessagePart2 =  "' and not(ancestor::*[contains(@style,'none')])]/ancestor::*[contains(@id,'modaldialog')]/following-sibling::*//*[contains(@class,'modaldialog') and not(ancestor::*[contains(@style,'none')])]";
	

	
}
