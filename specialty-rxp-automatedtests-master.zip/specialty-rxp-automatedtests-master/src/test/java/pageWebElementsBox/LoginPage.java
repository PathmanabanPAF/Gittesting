package pageWebElementsBox;

import org.openqa.selenium.By;

public class LoginPage {
	
	public static By iDUsername = By.id("txtUserID");
	
	public static By iDPassword = By.id("txtPassword");
	
	public static By idSubmitButton = By.id("sub");
	
	public static By xpathMenuUserName = By.xpath("//*[@class='RxP_Header_nav' and descendant::*[contains(@class,'user')]]");

	public static By xpathLoginErrorMessage = By.xpath("//*[@class='errorMessage']");
	
	public static By idTimeoutModalWindow = By.id("modaldialog_hd_title");
	
	public static By xpathTimeOutOkButton = By.xpath("//button[@class='buttonTimeout' and text()='Ok']");
	
	public static String dynamicXpathFooterValue1 = "//footer//*[contains(.,'"; 
	public static String dynamicXpathFooterValue2 = "')]"; 
	
}
