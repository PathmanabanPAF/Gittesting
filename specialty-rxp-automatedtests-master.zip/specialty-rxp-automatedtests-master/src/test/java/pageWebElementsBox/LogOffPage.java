package pageWebElementsBox;

public class LogOffPage {
	
	public static String dynamicXpathLogOffPart1 = "//*[@class='menu-item-title'and text()='";
	public static String dynamicXpathLogOffPart2 = "']";

}
