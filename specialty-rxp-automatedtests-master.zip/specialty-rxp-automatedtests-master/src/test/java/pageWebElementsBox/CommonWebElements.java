package pageWebElementsBox;

public class CommonWebElements {
	
	public static String dynamicXpathButtonPart1 = "//button[normalize-space(.)='";
	public static String dynamicXpathButtonPart2 = "' and not(ancestor::*[contains(@style,'none')])]";

	public static String dynamicXpathLinkPart1 = "//a[normalize-space(.)='";
	public static String dynamicXpathLinkPart2 = "' and not(ancestor::*[contains(@style,'none')])]";
	
	public static String dynamicXpathGeneric1 = "//*[normalize-space(text()) = '";
	public static String dynamicXpathGeneric2 = "']/ancestor-or-self::*[contains(@class,'dataLabelFor')]/following-sibling::*";
	
	public static String dynamicXpathSearchHeader1= "//*[normalize-space(text()) = '";
	public static String dynamicXpathSearchHeader2 = "']/ancestor::*[@id ='modaldialog_hd']/following-sibling::*";
	    
	public static String dynamicXpathHostName1 = "//*[contains(@class, 'dataLabelForRead')]";
	public static String dynamicXpathHostName2 = "/following-sibling::*//*[@class = 'accredooperatorname']";
		
	public static String dynamicXpathErrorPart4 = "/following-sibling::*//*[contains(@class, 'iconError')]";
    public static String dynamicXpathCalendarImagePart4 = "/following-sibling::img";
    
	public static String dynamicXpathCalendar3 = "//*[normalize-space(text())='";
	public static String dynamicXpathCalendar4 = "' and not(ancestor::*[contains(@style,'none')])]/ancestor-or-self::*[contains(@class, 'dataLabelFor')]/following-sibling::*//input";
	public static String dynamicXpathCalendarPart4 = "/following-sibling::*"; 

    public static String dynamicXpathTextBox3 = "//*[normalize-space(text())='";
	public static String dynamicXpathTextBox4 = "' and not(ancestor::*[contains(@style,'none')])]/ancestor-or-self::*[contains(@class, 'dataLabelFor')]/following-sibling::*//input";
	public static String dynamicXpathSearchlookup = "/ancestor::*[contains(@class,'content-field')]/following-sibling::*//img";
	public static String dynamicXpathClosePopup = "//button[@id='container_close' and not(ancestor::*[contains(@style,'none')])] "; 
	
	public static String dynamicXpathReadOnly3 = "//*[normalize-space(text())='";
	public static String dynamicXpathReadOnly4 = "' and not(ancestor::*[contains(@style,'none')])]/ancestor-or-self::*[contains(@class, 'dataLabelFor')]/following-sibling::*//*[text()]";

	public static String dynamicXpathTextArea3 = "//*[normalize-space(text())= '";
	public static String dynamicXpathTextArea4 = "' and not(ancestor::*[contains(@style,'none')])]/ancestor-or-self::*[contains(@class, 'dataLabelFor')]/following-sibling::*//textarea";

	public static String dynamicXpathDropDown3 = "//*[normalize-space(text())='";
	public static String dynamicXpathDropDown4 = "' and not(ancestor::*[contains(@style,'none')])]/ancestor-or-self::*[contains(@class, 'dataLabelFor')]/following-sibling::*//select";

	public static String dynamicXpathTextPart1 = "//*[normalize-space(text())='";
	public static String dynamicXpathTextPart2 = "' and not(ancestor::*[contains(@style,'none')])]";

	public static String dynamicXpathHeaderPart1 = "//*[@class='header-title' and not(ancestor::*[contains(@style,'none')]) and normalize-space(text())='";
    public static String dynamicXpathHeaderPart2 = "']/ancestor::*[@role='heading']/following-sibling::*"; 
    
    public static String dynamicXpathCollapsibleHeaderPart1 = "//*[@class='header-title' and not(ancestor::*[contains(@style,'none')]) and normalize-space(text())='";
    public static String dynamicXpathCollapsibleHeaderPart2 = "']/ancestor::*[contains(@class,'collapsible')]/following-sibling::*"; 

    public static String dynamicXpathStatusPart3 = "//*[@class='ellipsis']";
    
    public static String dynamicXpathDropDownField1 = "//*[normalize-space(text()) = '";
	public static String dynamicXpathDropDownField2 = "']/ancestor-or-self::*[contains(@class,'dataLabelFor')]/following-sibling::*";
    public static String dynamicXpathDropDownField3 = "//*[normalize-space(text())='";
	public static String dynamicXpathDropDownField4 = "']/ancestor-or-self::*[@string_type='field']/following-sibling::*//select";
	
	public static String dynamicXpathColumnName1 = "//*[text()='";
	public static String dynamicXpathColumnName2 = "']/following-sibling::*[@aria-live]";
	
	public static String dynamicXpathColName1 = "//*[normalize-space(text())='";
	public static String dynamicXpathColName2 = "']";
	
	public static String dynamicXpathSearchIconPart3 = "//img[not(ancestor::*[contains(@style,'none')])]";

	public static String dynamicXpathNonEditableOnly3 = "//*[normalize-space(text())='";
	public static String dynamicXpathNonEditableOnly4 = "' and not(ancestor::*[contains(@style,'none')])]/ancestor-or-self::*[contains(@class,'dataLabelFor')]/following-sibling::*//input[@disabled]";   
}
