package pageWebElementsBox;

import org.openqa.selenium.By;

public class ManualCaseCreatePage {
	
	
	public static By createLink = By.linkText("Create");
	
	public static By xpathMenuReferral = By.xpath("//*[normalize-space(text())='Referral' and contains(@class,'menu-item')]");
	
	public static By xpathResolveCase = By.xpath("//button[normalize-space(.)='Submit' and not(ancestor::*[contains(@style,'none')])]");
	
	public static String dynamicXpathCaseSummary1 = "//*[@class='header-content']/*[normalize-space(.)='";
	public static String dynamicXpathCaseSummary2 = "']";
	public static String dynamicXpathCaseSummary3 = "/ancestor::*[contains(@class,'collapsible')]/following-sibling::*//*[normalize-space(text())='";
	public static String dynamicXpathCaseSummary4 = "']/ancestor-or-self::*[contains(@class,'dataLabelForRead')]/following-sibling::*//*[normalize-space(text())='";
	public static String dynamicXpathCaseSummary5 = "']";
}
