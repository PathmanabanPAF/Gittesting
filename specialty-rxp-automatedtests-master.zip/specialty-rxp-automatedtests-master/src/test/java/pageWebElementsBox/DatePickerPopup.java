package pageWebElementsBox;

import org.openqa.selenium.By;

public class DatePickerPopup {
	public static By defaultDate = By.xpath("//*[@id='Pega_Cal_Cont']//*[@id='controlCalBody']//td[@class='calcell today selected']//a");
	public static By defaultMonth = By.xpath("//*[@id='Pega_Cal_Cont']//*[@id='calMonthCell']");
	public static By defaultYear = By.xpath("//*[@id='Pega_Cal_Cont']//*[@id='calYearCell']");
	public static By nextYearButton = By.xpath("//*[@id='Pega_Cal_Cont']//*[@id='nextYear']//a");
	public static By previousYearButton = By.xpath("//*[@id='Pega_Cal_Cont']//*[@id='previousYear']//a");
	public static By nextMonthButton = By.xpath("//*[@id='Pega_Cal_Cont']//*[@id='nextMonth']//a");
	public static By previousMonthButton = By.xpath("//*[@id='Pega_Cal_Cont']//*[@id='previousMonth']//a");
	public static String pickDateString1 = "//*[@id='Pega_Cal_Cont']//*[@id='controlCalBody']//a[text()='";
	public static String pickDateString2 = "']";
	public static By datepickerIcon=By.xpath("//*[normalize-space(text()) ='Date Written:']/ancestor-or-self::*[contains(@class,'dataLabelFor')]/following-sibling::*//img");
	
}
