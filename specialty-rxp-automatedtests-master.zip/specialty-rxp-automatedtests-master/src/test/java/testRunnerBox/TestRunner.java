package testRunnerBox;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import globalBox.BrowserMethods;
import globalBox.CommonMethods;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

import cucumber.api.CucumberOptions;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;

@RunWith(ExtendedCucumber.class)

@ExtendedCucumberOptions(jsonReport = "target/cucumber-json-report.json",  
usageReport = true, 
detailedReport = true, 
detailedAggregatedReport = true, 
overviewReport = true, 
toPDF = true, 
outputFolder = "src/test/resources/TestRun-Reports")

@CucumberOptions(features = { "BusinessRequirementsBox/Release_1/Sprint_17.11/test.feature"} 
,monochrome = true 
,glue = { "stepDefinitionBox" } 
,plugin = {"pretty", "html:target/cucumber-html-report","json:target/cucumber-json-report.json"}
,tags ={"@test"}
,dryRun= false)	

public class TestRunner { 

	@BeforeClass
	public static void initialSetup()
	
	{
		
		 String parentPath="src/test/resources/jresources/";
		 String tempString=Thread.currentThread().getStackTrace()[1].getClassName();
		 List<String>extractedList = Arrays.asList(tempString.split("\\."));
		 
		// or we can use this code tempString.substring(tempString.indexOf(".")+1);
		 String testRunnerClassName= extractedList.get(extractedList.size()-1);
		//Create  and set test run folder
		CommonMethods.TestRunnerfolderWithPath=parentPath+testRunnerClassName+CommonMethods.getTimeStamp();

		File directory=new File(CommonMethods.TestRunnerfolderWithPath);
		if(!directory.exists())//Create feature file directory
		{
			directory.mkdir();
			
		}

	}
	
	@AfterClass
public static void releaseResources()
	
	{
		String browserName=CommonMethods.readPropertiesFile("browser");
		switch(browserName)
		{
			case "ie": 
					if(BrowserMethods.ieService1RunningFlag==true)
						{
							BrowserMethods.ieDriverService1.stop();
							BrowserMethods.ieService1RunningFlag=false;
						}
					if(BrowserMethods.ieService2RunningFlag==true)
					{
						BrowserMethods.ieDriverService2.stop();
						BrowserMethods.ieService2RunningFlag=false;
					}
					break;
			case "chrome": 
				//Empty template
			case "ff": 
				//Empty template
				break;
			case "phantomjs": 
				//Empty template
				
				break;
			 default:
				break;
						
		}
	}

}
