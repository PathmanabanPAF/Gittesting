package globalBox;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ClickMethods {

   /*
    * This method is used to click on a element in web page
	* Input parameters :- driver of the the browser instance, explicit wait, locator of the element to be clicked
    * Output:- The element with provided locator will be clicked
    */
	public static void clickElement(WebDriver localdriver, WebDriverWait wait,
			By locator) {
		
		try {
			
			AlertMethods.closeAlertPopup(BrowserMethods.driver1);		
			WaitMethods.waitForElementReady(wait, locator);	
			AlertMethods.closeAlertPopup(BrowserMethods.driver1);
			localdriver.findElement(locator).click();
			
		} catch (Exception e) {
			
			CommonMethods.testStepPassFlag = false;

		}

	}
	/*(1)This method is used to click on a button
	(2)Input parameters :- localdriver as webdriver , wait as WebDriverWait , UIlocator as By
	(3)Output :- The given button is clicked
*/
	public static void clickElement(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime)
		{
			try
				{
					// WaitMethods.waitForElementReady(wait,locator);
					WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
					WaitMethods.syncAndCheckForElementClickable(localdriver, wait, locator, maxWaitTime);
					localdriver.findElement(locator).click();
				} catch (Exception e)
				{
					CommonMethods.testStepPassFlag = false;

				}

		}

	/*
	 * This method is used to click on submit button
     * Input parameters :- driver of the the browser instance, explicit wait, locator of the submit button to be clicked
     * Output :- The given submit button is clicked
	 */
	public static void submitButton(WebDriver localdriver, WebDriverWait wait,
			By locator) {
		
		try {
			
			WaitMethods.waitForElementReady(wait, locator);
			
			localdriver.findElement(locator).submit();
			
		} catch (Exception e) {
			
			CommonMethods.testStepPassFlag = false;

		}
	}
	
	/*
	 * This method is used to press Keyboard Enter key
     * Input parameters :- localdriver as webdriver , wait as WebDriverWait , UIlocator as By
     * Output :- The Enter key is pressed
	 */
	public static void clickElementByEnterKey(WebDriver localdriver,
			WebDriverWait wait, By locator) {
		
		try {
			
			WaitMethods.waitForElementReady(wait, locator);
			
			localdriver.findElement(locator).sendKeys(Keys.ENTER);
			
		} catch (Exception e) {
			
			CommonMethods.testStepPassFlag = false;
			
		}
	}

}
