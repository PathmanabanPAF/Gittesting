package globalBox;

import org.openqa.selenium.By;

public class DynamicXpathCalculation {

	public static By dynamicXpathCreation(String beginnningString,String middleString, String endString)
	{
		
			By localBy;
			localBy=By.xpath(beginnningString+middleString+endString);
			return localBy;
		
	}
}
