package globalBox;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class DateConversionMethods {

	public static Date convertStringToDate(String valueDate,String fromDateFormat,String toDateFormat) throws ParseException{

		DateFormat to   = new SimpleDateFormat(toDateFormat); // wanted format
		DateFormat from = new SimpleDateFormat(fromDateFormat); // current format
		String date = to.format(from.parse(valueDate));
		Date dateConverted = new SimpleDateFormat("M/d/yyyy").parse(date);
		return dateConverted;
	}

	
	
	public static String changeDateFormat(String valueDate,String fromDateFormat,String toDateFormat) throws ParseException{

		DateFormat to   = new SimpleDateFormat(toDateFormat); // wanted format
		DateFormat from = new SimpleDateFormat(fromDateFormat); // current format
		String date = to.format(from.parse(valueDate));
		return date;
	}

	public static void isValidFormat(String format, String value) {
		Date date = null;
		try {

			SimpleDateFormat sdf = new SimpleDateFormat(format);
			date = sdf.parse(value);

			if (!value.equals(sdf.format(date))) {
				CommonMethods.testStepPassFlag = false;
			}
		} catch (ParseException ex) {
			CommonMethods.testStepPassFlag = false;
		}

	}

	public static String getCurrentDateInTimeZones(String dateFormat, String timeZone) {
		SimpleDateFormat format = new SimpleDateFormat(dateFormat);
		format.setTimeZone(TimeZone.getTimeZone(timeZone));
		return format.format(new Date());
	}

	public static String getNextDayDate(String dateFormat, String timeZone) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat(dateFormat);
		format.setTimeZone(TimeZone.getTimeZone(timeZone));
		String dateText = format.format(new Date()); 
		Date date=new SimpleDateFormat(dateFormat).parse(dateText);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, +1);
		String nextDayValue= format.format(cal.getTime());
		return nextDayValue;
	}


	public static String getPreviousDayDate(String dateFormat, String timeZone) throws ParseException {

		SimpleDateFormat format = new SimpleDateFormat(dateFormat);
		format.setTimeZone(TimeZone.getTimeZone(timeZone));
		String dateText = format.format(new Date()); 
		Date date=new SimpleDateFormat(dateFormat).parse(dateText);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, -1);
		String previousDayValue = format.format(cal.getTime());
		return previousDayValue;

	}


	public static String getDate(String dateRequired, String dateFormat, String timeZone) throws ParseException{
		String dateConverted = "";
		switch(dateRequired){
		case "Today":
			dateConverted = getCurrentDateInTimeZones(dateFormat, timeZone);
			break;
		case "Tomorrow":
			dateConverted = getNextDayDate(dateFormat, timeZone);
			break;
		case "Yesterday":
			dateConverted = getPreviousDayDate(dateFormat, timeZone);
			break;
		}
		return dateConverted;
	}


	public static int getDateValueFromDate(String dateValue, String dateFormat) throws ParseException{

		Date dateConverted =new SimpleDateFormat(dateFormat).parse(dateValue);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateConverted);
		int day = cal.get(Calendar.DAY_OF_MONTH);
		
		return day;

	}

	public static int getMonthFromDate(String dateValue, String dateFormat) throws ParseException{

		Date dateRequired =new SimpleDateFormat(dateFormat).parse(dateValue);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateRequired);
		int month = cal.get(Calendar.MONTH);

		return month;

	}

	public static int getYearFromDate(String dateValue, String dateFormat) throws ParseException{

		Date dateConversionValue =new SimpleDateFormat(dateFormat).parse(dateValue);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateConversionValue);
		int year = cal.get(Calendar.YEAR);

		return year;

	}
	
/*	@Test
	public void getDat() throws ParseException{
		
		
		System.out.println("T"+ getDate("Today", "MM/dd/yyyy", "CST"));
		System.out.println("M"+ getDate("Tomorrow" ,"MM/dd/yyyy", "CST"));
		System.out.println("Y"+ getDate("Yesterday" , "MM/dd/yyyy","CST"));
	}*/
}
