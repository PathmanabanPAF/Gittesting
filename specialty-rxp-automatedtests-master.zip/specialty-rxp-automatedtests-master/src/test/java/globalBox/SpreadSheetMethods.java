package globalBox;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

public class SpreadSheetMethods {

	
//get row and col number by matching a text vertically for all the matches. It will start from first col till last col--> returns a list containing row number and col number.
public static List<List<Integer>> getRowColWillCheckAllColsVertically(String workbookPath,String workbookName,
		String workbookSheetName,String text)
	{
	        List<List<Integer>> rowColList=new ArrayList<List<Integer>>();
			try
			{
				        
				      
				       String cellValue=null;
						DataFormatter formatter=new DataFormatter();
						//String filePath=workbookPath; String filename=workbookName;
						File sheetFileName=new File(workbookPath+"/"+workbookName);
						
							FileInputStream fis=new FileInputStream(sheetFileName);
						
						String fileExtension=workbookName.substring(workbookName.indexOf("."));
						Workbook currentWorkbook=null;
						if(fileExtension.equals(".xls"))
						{
							currentWorkbook= new HSSFWorkbook(fis);
						}
						else if(fileExtension.equals(".xlsx"))
						{
							currentWorkbook=new XSSFWorkbook(fis);
						}
						Sheet currentSheet=currentWorkbook.getSheet(workbookSheetName);
						//String sheetName=currentSheet.getSheetName();
						try
						{
							int firstRowNum=currentSheet.getFirstRowNum();
									//getRow(rowNumber);
							int lastRowNum=currentSheet.getLastRowNum();
							
							
							for(int i=firstRowNum;i<=lastRowNum;i++)
							{
								try{
											Row currentRow=currentSheet.getRow(i);
											int firstCellNum=currentRow.getFirstCellNum();
											int lastCellNum=currentRow.getLastCellNum();
											for(int j=firstCellNum;j<=lastCellNum;j++)
											{
												try
												{
													cellValue=formatter.formatCellValue(currentRow.getCell(j));
													if(cellValue.equals(text))
													{
														List<Integer> tempList=new ArrayList<>();
														tempList.add(i);
														tempList.add(j);
														rowColList.add(tempList);
													}
												}
												catch(Exception e)
												{
													//system.out.println(e);
												}
											}
								}catch(Exception e)
								{
									//system.out.println(e);
								}
											
							}
						
						}
						catch(Exception e)
						{
							//system.out.println(e);
						fis.close();
						currentWorkbook.close();
						}
						fis.close();
						currentWorkbook.close();
						
						
				}
			catch(Exception e)
			{
				//system.out.println(e);
			}
			return rowColList;		
	
	}




//get row and col number by matching a text vertically in specified column--> returns a list of row number and col number
public static List<List<Integer>> getRowColWillCheckGivenColVertically(String workbookPath,String workbookName,
		String workbookSheetName,int colNumber,String text)
	{
	        List<List<Integer>> rowColList=new ArrayList<List<Integer>>();
			try
			{
				        
				      
				       String cellValue=null;
						DataFormatter formatter=new DataFormatter();
						//String filePath=workbookPath; String filename=workbookName;
						File sheetFileName=new File(workbookPath+"/"+workbookName);
						
							FileInputStream fis=new FileInputStream(sheetFileName);
						
						String fileExtension=workbookName.substring(workbookName.indexOf("."));
						Workbook currentWorkbook=null;
						if(fileExtension.equals(".xls"))
						{
							currentWorkbook= new HSSFWorkbook(fis);
						}
						else if(fileExtension.equals(".xlsx"))
						{
							currentWorkbook=new XSSFWorkbook(fis);
						}
						Sheet currentSheet=currentWorkbook.getSheet(workbookSheetName);
						//String sheetName=currentSheet.getSheetName();
						try
						{
							int firstRowNum=currentSheet.getFirstRowNum();
									//getRow(rowNumber);
							int lastRowNum=currentSheet.getLastRowNum();
							
							
							for(int i=firstRowNum;i<=lastRowNum;i++)
							{
								try{
											Row currentRow=currentSheet.getRow(i);
//											int firstCellNum=currentRow.getFirstCellNum();
//											int lastCellNum=currentRow.getLastCellNum();
//											for(int j=firstCellNum;j<=lastCellNum;j++)
//											{
												try
												{
													cellValue=formatter.formatCellValue(currentRow.getCell(colNumber));
													if(cellValue.equals(text))
													{
														List<Integer> tempList=new ArrayList<>();
														tempList.add(i);
														tempList.add(colNumber);
														rowColList.add(tempList);
													}
												}
												catch(Exception e)
												{
													//system.out.println(e);
												}
//											}
								}catch(Exception e)
								{
									//system.out.println(e);
								}
											
							}
						
						}
						catch(Exception e)
						{
							//system.out.println(e);
						fis.close();
						currentWorkbook.close();
						}
						fis.close();
						currentWorkbook.close();
						
						
				}
			catch(Exception e)
			{
				//system.out.println(e);
			}
			return rowColList;		
	
	}
	

//get row and col number by matching a text horizontally in specified row--> returns a list of row and col 
public static List<List<Integer>> getRowColWillCheckGivenRowHorizontally(String workbookPath,String workbookName,
		String workbookSheetName,int rowNumber,String text)
	{
	        List<List<Integer>> rowColList=new ArrayList<List<Integer>>();
			try
			{
				        
				      
				       String cellValue=null;
						DataFormatter formatter=new DataFormatter();
						//String filePath=workbookPath; String filename=workbookName;
						File sheetFileName=new File(workbookPath+"/"+workbookName);
						
							FileInputStream fis=new FileInputStream(sheetFileName);
						
						String fileExtension=workbookName.substring(workbookName.indexOf("."));
						Workbook currentWorkbook=null;
						if(fileExtension.equals(".xls"))
						{
							currentWorkbook= new HSSFWorkbook(fis);
						}
						else if(fileExtension.equals(".xlsx"))
						{
							currentWorkbook=new XSSFWorkbook(fis);
						}
						Sheet currentSheet=currentWorkbook.getSheet(workbookSheetName);
						//String sheetName=currentSheet.getSheetName();
						try
						{
							int firstRowNum=currentSheet.getFirstRowNum();
									//getRow(rowNumber);
							int lastRowNum=currentSheet.getLastRowNum();
							
							
//							for(int i=firstRowNum;i<=lastRowNum;i++)
//							{
								try{
											Row currentRow=currentSheet.getRow(rowNumber);
											int firstCellNum=currentRow.getFirstCellNum();
											int lastCellNum=currentRow.getLastCellNum();
											for(int j=firstCellNum;j<=lastCellNum;j++)
											{
												try
												{
													cellValue=formatter.formatCellValue(currentRow.getCell(j));
													if(cellValue.equals(text))
													{
														List<Integer> tempList=new ArrayList<>();
														tempList.add(rowNumber);
														tempList.add(j);
														rowColList.add(tempList);
													}
												}
												catch(Exception e)
												{
													//system.out.println(e);
												}
											}
								}catch(Exception e)
								{
									//system.out.println(e);
								}
											
//							}
						
						}
						catch(Exception e)
						{
							//system.out.println(e);
						fis.close();
						currentWorkbook.close();
						}
						fis.close();
						currentWorkbook.close();
						
						
				}
			catch(Exception e)
			{
				//system.out.println(e);
			}
			return rowColList;		
	
	}
    

//get text at given row and col
public static String getTextAtGivenRowAndCol(String workbookPath,String workbookName,
		String workbookSheetName,int rowNumber,int colNumber)
	{
			String cellValue=null;
			try
			{
				        
				      
				       
						DataFormatter formatter=new DataFormatter();
						//String filePath=workbookPath; String filename=workbookName;
						File sheetFileName=new File(workbookPath+"/"+workbookName);
						
							FileInputStream fis=new FileInputStream(sheetFileName);
						
						String fileExtension=workbookName.substring(workbookName.indexOf("."));
						Workbook currentWorkbook=null;
						if(fileExtension.equals(".xls"))
						{
							currentWorkbook= new HSSFWorkbook(fis);
						}
						else if(fileExtension.equals(".xlsx"))
						{
							currentWorkbook=new XSSFWorkbook(fis);
						}
						Sheet currentSheet=currentWorkbook.getSheet(workbookSheetName);
						//String sheetName=currentSheet.getSheetName();
						try
						{
							
	
								try{
											Row currentRow=currentSheet.getRow(rowNumber);
											cellValue=formatter.formatCellValue(currentRow.getCell(colNumber));
													
												
											
								}catch(Exception e)
								{
									//system.out.println(e);
								}
											
//							}
						
						}
						catch(Exception e)
						{
							//system.out.println(e);
						fis.close();
						currentWorkbook.close();
						}
						fis.close();
						currentWorkbook.close();
						
						
				}
			catch(Exception e)
			{
				//system.out.println(e);
			}
			return cellValue;		
	
	}



//get cell contents in a list for a vertical column specified by row range--> returns a list
//If any cell is blank then it will give null pointer exception and for that empty string is written in the list.
public static List<String> getAllCellValuesForAColInGivenVerticalRange(String workbookPath,String workbookName,
		String workbookSheetName,int colNumber,int startRow,int endRow)
	{
	       List<String> valueList=new ArrayList<>();
			try
			{
				        
				      
				       String cellValue=null;
						DataFormatter formatter=new DataFormatter();
						//String filePath=workbookPath; String filename=workbookName;
						File sheetFileName=new File(workbookPath+"/"+workbookName);
						
							FileInputStream fis=new FileInputStream(sheetFileName);
						
						String fileExtension=workbookName.substring(workbookName.indexOf("."));
						Workbook currentWorkbook=null;
						if(fileExtension.equals(".xls"))
						{
							currentWorkbook= new HSSFWorkbook(fis);
						}
						else if(fileExtension.equals(".xlsx"))
						{
							currentWorkbook=new XSSFWorkbook(fis);
						}
						Sheet currentSheet=currentWorkbook.getSheet(workbookSheetName);
						//String sheetName=currentSheet.getSheetName();
						try
						{
//							int firstRowNum=currentSheet.getFirstRowNum();
//									//getRow(rowNumber);
//							int lastRowNum=currentSheet.getLastRowNum();
							
							
							for(int i=startRow;i<=endRow;i++)
							{
								try{
											Row currentRow=currentSheet.getRow(i);
//											int firstCellNum=currentRow.getFirstCellNum();
//											int lastCellNum=currentRow.getLastCellNum();
//											for(int j=firstCellNum;j<=lastCellNum;j++)
//											{
												try
												{
													cellValue=formatter.formatCellValue(currentRow.getCell(colNumber));
//													if(cellValue.equals(text))
//													{
//														List<Integer> tempList=new ArrayList<>();
//														tempList.add(i);
//														tempList.add(colNumber);
														valueList.add(cellValue);
//													}
												}
												catch(Exception e)
												{
													//system.out.println(e);
													valueList.add("");//this will add empty string to cell which is blank
												}
//											}
								}catch(Exception e)
								{
									//system.out.println(e);
								}
											
							}
						
						}
						catch(Exception e)
						{
							//system.out.println(e);
						fis.close();
						currentWorkbook.close();
						}
						fis.close();
						currentWorkbook.close();
						
						
				}
			catch(Exception e)
			{
				//system.out.println(e);
			}
			return valueList;		
	
	}





//get cell content in a list for a row  specified by col range i.e start col and end col--> returns a list
//If any cell is blank then it will give null pointer exception and for that empty string is written in the list.
public static List<String> getAllCellValuesForARowInGivenHorizontalRange(String workbookPath,String workbookName,
		String workbookSheetName,int rowNumber,int startCol,int endCol)
	{
	       List<String> valueList=new ArrayList<>();
			try
			{
				        
				      
				       String cellValue=null;
						DataFormatter formatter=new DataFormatter();
						//String filePath=workbookPath; String filename=workbookName;
						File sheetFileName=new File(workbookPath+"/"+workbookName);
						
							FileInputStream fis=new FileInputStream(sheetFileName);
						
						String fileExtension=workbookName.substring(workbookName.indexOf("."));
						Workbook currentWorkbook=null;
						if(fileExtension.equals(".xls"))
						{
							currentWorkbook= new HSSFWorkbook(fis);
						}
						else if(fileExtension.equals(".xlsx"))
						{
							currentWorkbook=new XSSFWorkbook(fis);
						}
						Sheet currentSheet=currentWorkbook.getSheet(workbookSheetName);
						//String sheetName=currentSheet.getSheetName();
						try
						{
//							int firstRowNum=currentSheet.getFirstRowNum();
//									//getRow(rowNumber);
//							int lastRowNum=currentSheet.getLastRowNum();
							
//							
//							for(int i=startRow;i<=endRow;i++)
//							{
								try{
											Row currentRow=currentSheet.getRow(rowNumber);
//											int firstCellNum=currentRow.getFirstCellNum();
//											int lastCellNum=currentRow.getLastCellNum();
											for(int j=startCol;j<=endCol;j++)
//											{
												try
												{
													cellValue=formatter.formatCellValue(currentRow.getCell(j));
//													if(cellValue.equals(text))
//													{
//														List<Integer> tempList=new ArrayList<>();
//														tempList.add(i);
//														tempList.add(colNumber);
														valueList.add(cellValue);
//													}
												}
												catch(Exception e)
												{
													//system.out.println(e);
													valueList.add("");//this will add empty string to cell which is blank
												}
//											}
								}catch(Exception e)
								{
									//system.out.println(e);
								}
											
//							}
						
						}
						catch(Exception e)
						{
							//system.out.println(e);
						fis.close();
						currentWorkbook.close();
						}
						fis.close();
						currentWorkbook.close();
						
						
				}
			catch(Exception e)
			{
				//system.out.println(e);
			}
			return valueList;		
	
	}

/**********************wrie methods*****************************************/
//write text at given row and col
public static void writeTextAtGivenRowAndCol(String workbookPath,String workbookName,
		String workbookSheetName,int rowNumber,int colNumber, String textToBeWritten)
	{
			String cellValue=null;
			try
			{
				        
				      
				       
						DataFormatter formatter=new DataFormatter();
						//String filePath=workbookPath; String filename=workbookName;
						File sheetFileName=new File(workbookPath+"/"+workbookName);
						
						
						FileInputStream fis=new FileInputStream(sheetFileName);
						String fileExtension=workbookName.substring(workbookName.indexOf("."));
						Workbook currentWorkbook=null;
						if(fileExtension.equals(".xls"))
						{
							currentWorkbook= new HSSFWorkbook(fis);
						}
						else if(fileExtension.equals(".xlsx"))
						{
							currentWorkbook=new XSSFWorkbook(fis);
						}
						Sheet currentSheet=currentWorkbook.getSheet(workbookSheetName);
						//String sheetName=currentSheet.getSheetName();
						try
						{
							
	
								try{
											Row currentRow=currentSheet.getRow(rowNumber);
										//	cellValue=formatter.formatCellValue(currentRow.getCell(colNumber));
											
											
											
										    Cell cell = currentRow.getCell(colNumber);
										    if (cell == null) {
										        cell = currentRow.createCell(colNumber);
										    }
										    cell.setCellType(CellType.STRING);
										    cell.setCellValue(textToBeWritten);
										
													
												
											
								}catch(Exception e)
								{
									//system.out.println(e);
								}
											
//							}
						
						}
						catch(Exception e)
						{
							//system.out.println(e);
							FileOutputStream fos=new FileOutputStream(sheetFileName);
							
							currentWorkbook.write(fos);	
							fis.close();
						    
						   
					         fos.close();
						    currentWorkbook.close();
						    
						    
						}
						FileOutputStream fos=new FileOutputStream(sheetFileName);
						
						currentWorkbook.write(fos);	
					    
						fis.close();
				         fos.close();
					    currentWorkbook.close();
					    
						
				}
			catch(Exception e)
			{
				//system.out.println(e);
			}
				
	
	}

//compare cell and read  corresponding column cell-->returns arraylist

public static List<List<String>> compareAndReadGivenColumnCell(String workbookPath,String workbookName,
		String workbookSheetName,int comparisonColNumber,int firstTargetColNumber,int startRow,
		int endRow,List<List<String>> dataList)
	{
	      // List<String> valueList=new ArrayList<>();
			try
			{
				        
				      
				       String cellValue=null;
						DataFormatter formatter=new DataFormatter();
						//String filePath=workbookPath; String filename=workbookName;
						File sheetFileName=new File(workbookPath+"/"+workbookName);
						
							FileInputStream fis=new FileInputStream(sheetFileName);
						
						String fileExtension=workbookName.substring(workbookName.indexOf("."));
						Workbook currentWorkbook=null;
						if(fileExtension.equals(".xls"))
						{
							currentWorkbook= new HSSFWorkbook(fis);
						}
						else if(fileExtension.equals(".xlsx"))
						{
							currentWorkbook=new XSSFWorkbook(fis);
						}
						Sheet currentSheet=currentWorkbook.getSheet(workbookSheetName);
						//String sheetName=currentSheet.getSheetName();
						try
						{
//							int firstRowNum=currentSheet.getFirstRowNum();
//									//getRow(rowNumber);
//							int lastRowNum=currentSheet.getLastRowNum();
							boolean matchFound=false;
						for(int a=0;a<dataList.size();a++)
						{
							String compareString=dataList.get(a).get(0);
							
										for(int i=startRow;i<=endRow;i++)
										{
											try{
														matchFound=false;
												        Row currentRow=currentSheet.getRow(i);
			//											int firstCellNum=currentRow.getFirstCellNum();
			//											int lastCellNum=currentRow.getLastCellNum();
			//											for(int j=firstCellNum;j<=lastCellNum;j++)
			//											{
															try
																{
																	cellValue=formatter.formatCellValue(currentRow.getCell(comparisonColNumber));
				  													if(cellValue.equals(compareString))
				 												{
				  														String column1CellValue=formatter.formatCellValue(currentRow.getCell(firstTargetColNumber));
				  														dataList.get(a).add(1,column1CellValue);
				  														matchFound=true;
																		break;
				 												}
															}
															catch(Exception e)
															{
																//system.out.println(e);
																dataList.get(a).add(1,"");//this will add empty string to cell which is blank
															}
			//											}
											}catch(Exception e)
											{
												//system.out.println(e);
											}
														
										}
										
										if(matchFound==false) //write blank if there is no match found vertically
										{
											dataList.get(a).add(1,"");//this will add empty string to cell which is blank
										}
						}
						
						}
						catch(Exception e)
						{
							//system.out.println(e);
						fis.close();
						currentWorkbook.close();
						}
						fis.close();
						currentWorkbook.close();
						
						
				}
			catch(Exception e)
			{
				//system.out.println(e);
			}
			return dataList;		
	
	}




//compare cell and read corresponding two columns--->returns arraylist
public static List<List<String>> compareAndReadGivenTwoColumnsCell(String workbookPath,String workbookName,
		String workbookSheetName,int comparisonColNumber,int firstTargetColNumber,int secondTargetColNumber,int startRow,
		int endRow,List<List<String>> dataList)
	{
	      // List<String> valueList=new ArrayList<>();
			try
			{
				        
				      
				       String cellValue=null;
						DataFormatter formatter=new DataFormatter();
						//String filePath=workbookPath; String filename=workbookName;
						File sheetFileName=new File(workbookPath+"/"+workbookName);
						
							FileInputStream fis=new FileInputStream(sheetFileName);
						
						String fileExtension=workbookName.substring(workbookName.indexOf("."));
						Workbook currentWorkbook=null;
						if(fileExtension.equals(".xls"))
						{
							currentWorkbook= new HSSFWorkbook(fis);
						}
						else if(fileExtension.equals(".xlsx"))
						{
							currentWorkbook=new XSSFWorkbook(fis);
						}
						Sheet currentSheet=currentWorkbook.getSheet(workbookSheetName);
						//String sheetName=currentSheet.getSheetName();
						try
						{
//							int firstRowNum=currentSheet.getFirstRowNum();
//									//getRow(rowNumber);
//							int lastRowNum=currentSheet.getLastRowNum();
							boolean matchFound=false;
						for(int a=0;a<dataList.size();a++)
						{
							String compareString=dataList.get(a).get(0);
							
										for(int i=startRow;i<=endRow;i++)
										{
											try{
														matchFound=false;
												        Row currentRow=currentSheet.getRow(i);
			//											int firstCellNum=currentRow.getFirstCellNum();
			//											int lastCellNum=currentRow.getLastCellNum();
			//											for(int j=firstCellNum;j<=lastCellNum;j++)
			//											{
															try
																{
																	cellValue=formatter.formatCellValue(currentRow.getCell(comparisonColNumber));
				  													if(cellValue.equals(compareString))
				 												{
				  														String column1CellValue=formatter.formatCellValue(currentRow.getCell(firstTargetColNumber));
				  														dataList.get(a).add(1,column1CellValue);
				  														String column2CellValue=formatter.formatCellValue(currentRow.getCell(secondTargetColNumber));
				  														dataList.get(a).add(2,column2CellValue);
				  														matchFound=true;
																		break;
				 												}
															}
															catch(Exception e)
															{
																//system.out.println(e);
																dataList.get(a).add(1,"");//this will add empty string to cell which is blank
																dataList.get(a).add(2,"");//this will add empty string to cell which is blank
															}
			//											}
											}catch(Exception e)
											{
												//system.out.println(e);
											}
														
										}
										
										if(matchFound==false) //write blank if there is no match found vertically
										{
											dataList.get(a).add(1,"");//this will add empty string to cell which is blank
											dataList.get(a).add(2,"");//this will add empty string to cell which is blank
										}
						}
						
						}
						catch(Exception e)
						{
							//system.out.println(e);
						fis.close();
						currentWorkbook.close();
						}
						fis.close();
						currentWorkbook.close();
						
						
				}
			catch(Exception e)
			{
				//system.out.println(e);
			}
			return dataList;		
	
	}
//compare cell and write  corresponding column cell-->returns void

public static void compareAndWriteToGivenColumnCell(String workbookPath,String workbookName,
		String workbookSheetName,int comparisonColNumber,int writeTargetColNumber,int startRow,
		int endRow,List<List<String>> dataList)
	{
	      // List<String> valueList=new ArrayList<>();
			try
			{
				        
				      
				       String cellValue=null;
						DataFormatter formatter=new DataFormatter();
						//String filePath=workbookPath; String filename=workbookName;
						File sheetFileName=new File(workbookPath+"/"+workbookName);
						
							FileInputStream fis=new FileInputStream(sheetFileName);
						
						String fileExtension=workbookName.substring(workbookName.indexOf("."));
						Workbook currentWorkbook=null;
						if(fileExtension.equals(".xls"))
						{
							currentWorkbook= new HSSFWorkbook(fis);
						}
						else if(fileExtension.equals(".xlsx"))
						{
							currentWorkbook=new XSSFWorkbook(fis);
						}
						Sheet currentSheet=currentWorkbook.getSheet(workbookSheetName);
						//String sheetName=currentSheet.getSheetName();
						try
						{
//							int firstRowNum=currentSheet.getFirstRowNum();
//									//getRow(rowNumber);
//							int lastRowNum=currentSheet.getLastRowNum();
							boolean matchFound=false;
						for(int a=0;a<dataList.size();a++)
						{
							String compareString=dataList.get(a).get(0);
							
										for(int i=startRow;i<=endRow;i++)
										{
											try{
														matchFound=false;
												        Row currentRow=currentSheet.getRow(i);
			//											int firstCellNum=currentRow.getFirstCellNum();
			//											int lastCellNum=currentRow.getLastCellNum();
			//											for(int j=firstCellNum;j<=lastCellNum;j++)
			//											{
															try
																{
																	cellValue=formatter.formatCellValue(currentRow.getCell(comparisonColNumber));
				  													if(cellValue.equals(compareString))
				 												{
				  														//write to desired column in the given row
				  														   Cell cell = currentRow.getCell(writeTargetColNumber);
				  														    if (cell == null) {
				  														        cell = currentRow.createCell(writeTargetColNumber);
				  														    }
				  														    cell.setCellType(CellType.STRING);
				  														    String textToBeWritten=dataList.get(a).get(1);
				  														    cell.setCellValue(textToBeWritten);
				  														    matchFound=true;
																			break;
				 												}
															}
															catch(Exception e)
															{
																//system.out.println(e);
																//dataList.get(a).add(1,"");//this will add empty string to cell which is blank
															}
			//											}
											}catch(Exception e)
											{
												//system.out.println(e);
											}
														
										}
										
										if(matchFound==false) //write blank if there is no match found vertically
										{
											//dataList.get(a).add(1,"");//this will add empty string to cell which is blank
											//system.out.println("No match found for string" +compareString);
										}
						}
						
						}
						catch(Exception e)
						{
							//system.out.println(e);
							FileOutputStream fos=new FileOutputStream(sheetFileName);
							
							currentWorkbook.write(fos);	
							fis.close();
						    
						   
					         fos.close();
						    currentWorkbook.close();
						}
						FileOutputStream fos=new FileOutputStream(sheetFileName);
						
						currentWorkbook.write(fos);	
						fis.close();
					    
					   
				         fos.close();
					    currentWorkbook.close();
						
						
				}
			catch(Exception e)
			{
				//system.out.println(e);
			}
				
	
	}


//Update vertical cells with color after comparing the cell content for expected and actual separated by a delimiter
/*Cell content Example :
200<jkSeparator>500
5<jkSeparator>5
00<jkSeparator>
Note : all cells present vertically in the give row and column range is taken and processed
*/

public static void updateColorOfAllCellsPresentInColumnAfterComparingCellContentForExpectedActualSeparatedByDelimiter(String workbookPath,String workbookName,
		String workbookSheetName,String splitTag,int colNumber,int startRow,int endRow)

		
		
	{
	 
	try
	{
		        
		      
		       String cellValue=null;
				DataFormatter formatter=new DataFormatter();
				//String filePath=workbookPath; String filename=workbookName;
				File sheetFileName=new File(workbookPath+"/"+workbookName);
				
					FileInputStream fis=new FileInputStream(sheetFileName);
					 CellStyle styleRED=null ;CellStyle styleGREEN=null;
				String fileExtension=workbookName.substring(workbookName.indexOf("."));
				Workbook currentWorkbook=null;
				if(fileExtension.equals(".xls"))
				{
					currentWorkbook= new HSSFWorkbook(fis);
					
					
					//REDStyle
	                styleRED = currentWorkbook.createCellStyle();
	                styleRED.setFillForegroundColor(IndexedColors.RED.getIndex());
	                styleRED.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	                //REDStylEnd
	                
	              //GREENStyle
	                styleGREEN = currentWorkbook.createCellStyle();
	                styleGREEN.setFillForegroundColor(IndexedColors.GREEN.getIndex());
	                styleGREEN.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	              //GREENStyle END
	                
					
				}
				else if(fileExtension.equals(".xlsx"))
				{
					currentWorkbook=new XSSFWorkbook(fis);
					
					//REDStyle
	                styleRED = currentWorkbook.createCellStyle();
	                styleRED.setFillForegroundColor(IndexedColors.RED.getIndex());
	                styleRED.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	                //REDStylEnd
	                
	              //GREENStyle
	                styleGREEN = currentWorkbook.createCellStyle();
	                styleGREEN.setFillForegroundColor(IndexedColors.GREEN.getIndex());
	                styleGREEN.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	              //GREENStyle END
	                 
				}
				Sheet currentSheet=currentWorkbook.getSheet(workbookSheetName);
				//String sheetName=currentSheet.getSheetName();
				try
				{

					
					for(int i=startRow;i<=endRow;i++)
					{
					
										        Row currentRow=currentSheet.getRow(i);
	//											
													try
														{
															cellValue=formatter.formatCellValue(currentRow.getCell(colNumber));
															List<String> extractedList = Arrays.asList(cellValue.split(splitTag));
															String left=extractedList.get(0);
															String right=extractedList.get(1);
															  try{
																	if(left.equals(right))
																	{
																		 Cell cell = currentRow.getCell(colNumber);
																		 cell.setCellStyle(styleGREEN);
				  														   
																	}
																	else
																	{
																		Cell cell = currentRow.getCell(colNumber);
																		 cell.setCellStyle(styleRED);
																		ScreenshotMethods.logger("Data not matching.Expected node value: "+left+"   Actual value: "+right ); 
																	}
															  }
															  catch(Exception e)
															  {
																  Cell cell = currentRow.getCell(colNumber);
																  cell.setCellStyle(styleRED);
															  }
														}
													catch(Exception e)
													{
														//system.out.println(e);
														//dataList.get(a).add(1,"");//this will add empty string to cell which is blank
													}
				
				}
				
				}
				catch(Exception e)
				{
					//system.out.println(e);
					FileOutputStream fos=new FileOutputStream(sheetFileName);
					
					currentWorkbook.write(fos);	
					fis.close();
				    
				   
			         fos.close();
				    currentWorkbook.close();
				}
				FileOutputStream fos=new FileOutputStream(sheetFileName);
				
				currentWorkbook.write(fos);	
				fis.close();
			    
			   
		         fos.close();
			    currentWorkbook.close();
				
				
		}
	catch(Exception e)
	{
		//system.out.println(e);
	}
	}




public static int getColumnNumber(String testData, String workbookPath,
		String workbookName, String workbookSheetName) {

	int colTestcase = 0;
	try {

		File finalFile = new File(workbookPath + "/" + workbookName);
		FileInputStream file = new FileInputStream(finalFile);
		Workbook inputWorkbook = null;
		String fileExtension = workbookName.substring(workbookName
				.indexOf("."));
		if (fileExtension.equals(".xls")) {
			inputWorkbook = new HSSFWorkbook(file);

		} else if (fileExtension.equals(".xlsx")) {
			inputWorkbook = new XSSFWorkbook(file);
		}
		// Get first sheet from the workbook
		Sheet sheet = inputWorkbook.getSheet(workbookSheetName);
		int noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
		int rowNum = sheet.getLastRowNum() + 1;
		// int colNum = sheet.getRow(0).getLastCellNum();
		for (int i = 1; i < rowNum; i++) {
			Row row = sheet.getRow(i);
			for (int j = 0; j < noOfColumns; j++) {
				Cell cell = row.getCell(j);
				String value = cell.toString();
				if (value.equalsIgnoreCase(testData)) {
					colTestcase = (int) cell.getColumnIndex();
					return colTestcase + 1;
				}
			}
		}
		inputWorkbook.close();
		file.close();
		return colTestcase;

	} catch (Exception e) {
		CommonMethods.testStepPassFlag = false;
		return colTestcase;
	}

}



public static Row getRowObject(String StringRow, String workbookPath,
		String workbookName, String workbookSheetName, int columnNUmber) {

	Row row = null;
	try {

		File finalFile = new File(workbookPath + "/" + workbookName);
		FileInputStream file = new FileInputStream(finalFile);
		Workbook inputWorkbook = null;
		String fileExtension = workbookName.substring(workbookName
				.indexOf("."));
		if (fileExtension.equals(".xls")) {
			inputWorkbook = new HSSFWorkbook(file);

		} else if (fileExtension.equals(".xlsx")) {
			inputWorkbook = new XSSFWorkbook(file);
		}
		// Get first sheet from the workbook
		Sheet sheet = inputWorkbook.getSheet(workbookSheetName);
		Iterator<Row> rowItr = sheet.iterator();
		while (rowItr.hasNext()) {
			row = rowItr.next();


			String rowData = row.getCell(columnNUmber).toString();
			if (rowData.equalsIgnoreCase(StringRow)) {
				return row;
			}
		}

		inputWorkbook.close();
		// If no such row found need to handle NullPointerException for that
		return null;
	} catch (Exception E) {
		CommonMethods.testStepPassFlag = false;
		return null;
	}
}


public static Map<String, String> getAllColumnValuesFromRow(Row RowObject) {

	try {
		DataFormatter formatter = new DataFormatter();
		Map<String, String> rowData = new HashMap<String, String>();
		Iterator<Cell> itr = RowObject.iterator();
		Row headerRow = RowObject.getSheet().getRow(0);
		String cellValue = "";
		int headerCellCount = 1;
		// to avoid first column
		itr.next();

		while (itr.hasNext()) {
			Cell cell = itr.next();
			Cell headerValue = headerRow.getCell(headerCellCount++);
			// CellType p=cell.getCellTypeEnum();
			switch (cell.getCellTypeEnum()) {
			case BOOLEAN:
				cellValue = cell.getBooleanCellValue() + "";
				rowData.put(headerValue.toString(), cellValue);
				break;
			case NUMERIC:
				cellValue = formatter.formatCellValue(cell);
				rowData.put(headerValue.toString(), cellValue);
				break;
			case STRING:
				cellValue = cell.getStringCellValue();
				rowData.put(headerValue.toString(), cellValue);
				break;
			case BLANK:
				cellValue = "";
				rowData.put(headerValue.toString(), cellValue);
				break;
			default:
				break;
			}
		}
		return rowData;
	} catch (Exception E) {
		CommonMethods.testStepPassFlag = false;
		return null;
	}
}




public static List<Integer> getRowNumbers(String testData, String workbookPath,
		String workbookName, String workbookSheetName) {
	int rowTestcase = 0;

	List<Integer> listOfRowNumbers = new ArrayList<Integer>();
	try {

		File finalFile = new File(workbookPath + "/" + workbookName);
		FileInputStream file = new FileInputStream(finalFile);
		Workbook inputWorkbook = null;
		String fileExtension = workbookName.substring(workbookName
				.indexOf("."));
		if (fileExtension.equals(".xls")) {
			inputWorkbook = new HSSFWorkbook(file);

		} else if (fileExtension.equals(".xlsx")) {
			inputWorkbook = new XSSFWorkbook(file);
		}

		Sheet sheet = inputWorkbook.getSheet(workbookSheetName);

		int rowNum = sheet.getLastRowNum() + 1;

		for (int i = 1; i < rowNum; i++) {
			Row row = sheet.getRow(i);
			int j = 0;
			Cell cell = row.getCell(j);
			String value = cell.toString();
			if (!value.isEmpty() && value.equalsIgnoreCase(testData)) {
				rowTestcase = row.getRowNum();
				listOfRowNumbers.add(rowTestcase);

			}
		}
		inputWorkbook.close();
		file.close();
		return listOfRowNumbers;

	} catch (Exception e) {
		CommonMethods.testStepPassFlag = false;
		return listOfRowNumbers;
	}

}


public static List<Row> getMultipleRowObjects(List<Integer> rowNumbers, String workbookPath,
		String workbookName, String workbookSheetName) {

	try {

		List<Row> listOfRows = new ArrayList<Row>();

		Row row = null;

		File finalFile = new File(workbookPath + "/" + workbookName);
		FileInputStream file = new FileInputStream(finalFile);
		Workbook inputWorkbook = null;
		String fileExtension = workbookName.substring(workbookName
				.indexOf("."));
		if (fileExtension.equals(".xls")) {
			inputWorkbook = new HSSFWorkbook(file);

		} else if (fileExtension.equals(".xlsx")) {
			inputWorkbook = new XSSFWorkbook(file);
		}
		Sheet sheet = inputWorkbook.getSheet(workbookSheetName);

		Iterator<Row> rowItr = sheet.iterator();

		while (rowItr.hasNext()) {
			row = rowItr.next();
			for(int number: rowNumbers){

				if(number == row.getRowNum()){
					listOfRows.add(row);
				}

			}

		}

		inputWorkbook.close();

		return listOfRows;

	} catch(Exception exception){

		CommonMethods.testStepPassFlag = false;
		return null;

	}
}



public static Map<String, List<String>> getAllColumnValuesFromMultipleRow(List<Row> ListOfRowObject) {

	try {

		
		Map<String, List<String>> rowData = new HashMap<String, List<String>>();
		Cell headerValue = null;

		for(Row RowObject:ListOfRowObject) {
			DataFormatter formatter = new DataFormatter();

			Iterator<Cell> itr = RowObject.iterator();
			Row headerRow = RowObject.getSheet().getRow(0);
			String cellValue = "";
			int headerCellCount = 1;
			// to avoid first column
			itr.next();
			
			List<String> values = new ArrayList<String>();

			while (itr.hasNext()) {
				List<String> listOfCellValues = new ArrayList<String>();
				Cell cell = itr.next();
				headerValue = headerRow.getCell(headerCellCount++);
				// CellType p=cell.getCellTypeEnum();
				switch (cell.getCellTypeEnum()) {
				case BOOLEAN:
					cellValue = cell.getBooleanCellValue() + "";
					values = rowData.get(headerValue.toString());
					if(values!=null){
						listOfCellValues = values;
					}
					listOfCellValues.add(cellValue);

					rowData.put(headerValue.toString(), listOfCellValues);
					break;
				case NUMERIC:
					cellValue = formatter.formatCellValue(cell);
					values = rowData.get(headerValue.toString());
					if(values!=null){
						listOfCellValues = values;
					}
					listOfCellValues.add(cellValue);

					rowData.put(headerValue.toString(), listOfCellValues);
					break;
				case STRING:
					cellValue = cell.getStringCellValue();

					values = rowData.get(headerValue.toString());
					if(values!=null){
						listOfCellValues = values;
					}
					listOfCellValues.add(cellValue);

					rowData.put(headerValue.toString(), listOfCellValues);
					
					

					break;
				case BLANK:
					cellValue = "";
				
					values = rowData.get(headerValue.toString());
					if(values!=null){
						listOfCellValues = values;
					}
					listOfCellValues.add(cellValue);

					rowData.put(headerValue.toString(), listOfCellValues);
					break;
				default:
					break;
				}


			}


		}

		return rowData;

	} catch (Exception E) {
		CommonMethods.testStepPassFlag = false;
		return null;
	}
}


public static List<String> getListOfColumnData(String pathWorkBook, String nameExcelFile, String nameSheetName, String nameScenario, String nameColumn){
	List<Integer> listOfRowNumbers = new ArrayList<Integer>();
	System.out.println();

	listOfRowNumbers = getRowNumbers(nameScenario, pathWorkBook, nameExcelFile, nameSheetName);		

	List<Row> listOfRowObjects = getMultipleRowObjects(listOfRowNumbers, pathWorkBook, nameExcelFile, nameSheetName);

	Map<String, List<String>> listOfExcelRowData = getAllColumnValuesFromMultipleRow(listOfRowObjects);
	
	List<String> listOfColumnData = listOfExcelRowData.get(nameColumn);


	return listOfColumnData;
}






//TBD-->compare cell and read corresponding columns cell in col range
//TBD-->compare cell and read corresponding rows  cells in row range
//TBD-->compare cell and read corresponding column cell 
//TBD-->compare cell and read corresponding row  cell

//TBD-->compare cell and write corresponding columns cell in col range
//TBD-->compare cell and write corresponding rows  cells in row range
//TBD-->compare cell and write corresponding column cell 
//TBD-->compare cell and write corresponding row  cell


	
}
