package globalBox;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FrameHandlingMethods {
	
	public static void switchToAFrameByNameAfterDefaultContentSwitching(String frameName,WebDriver localDriver,WebDriverWait localwait)
	{
		
			localDriver.switchTo().defaultContent();
			localwait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameName));
		
	}
	
	
	public static void switchToAFrameByNameWithOutDefaultContentSwitching(WebDriver localDriver,WebDriverWait localwait, String frameName)
	{
		
			
			localwait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameName));
			
		
	}
	
	public static void switchToDefaultFrame(WebDriver localDriver,WebDriverWait localwait)
	{
		
			localDriver.switchTo().defaultContent();			
		
	}
	public static void switchToAFrameByXpath(By localBylocator,WebDriverWait localwait)
	{
		
			localwait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(localBylocator));
		
	}
	
	public static String getHighestValueFrameName(WebDriver localDriver,WebDriverWait localwait,By locallocator,String attributeName)
	{ //this takes care of 9 or less frames in a page
		String finalFrameName="";
		
			int indexCount=0;
		
			List<String> listFrames = GetValueMethods.getMultipleElementAttributeList(localDriver, localwait, locallocator, attributeName);
		    
			for(int i=0;i<listFrames.size();i++)
		    {
		    	int extractedInt=Integer.parseInt((listFrames.get(i).substring(10,10)));
		    	if(extractedInt>indexCount)
		    	{
		    		indexCount=extractedInt;
		    	}
		    }
			finalFrameName=listFrames.get(indexCount);
			return finalFrameName;
	
	}
	
	
	/*
	 * This method is useful for situation where there is a frame inside another frame
	 * Here we will not switch to default frame. It directly switches from one frame to another frame
	 */
	public static void switchToFrameByLocatorWithoutDefaultContentSwitching(WebDriverWait localwait, By locator)
	{
		try
			{

				localwait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(locator));

			} catch (Exception e)
			{
				CommonMethods.testStepPassFlag = false;
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", e.toString());
			}
	}

		
	
}
