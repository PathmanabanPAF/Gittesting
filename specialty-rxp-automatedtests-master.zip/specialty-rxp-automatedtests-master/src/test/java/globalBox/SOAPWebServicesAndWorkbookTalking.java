package globalBox;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;






import cucumber.api.DataTable;

public class SOAPWebServicesAndWorkbookTalking 
{

	public static void Set1getTagsFromFeatureFile(DataTable listFromStep,int workbookPathIndexInFeatureFileDataTable,int workbookNameIndexInFeatureFileDataTable,
			int targetSheetNameIndexInFeatureFileDataTable,int xPathColTagIndexInFeatureFileDataTable,int firstTargetColTagIndexInFeatureFileDataTable
			,int requestDataTagIndexInFeatureFileDataTable,int responseDataTagIndexInFeatureFileDataTable,
			int configStartTagIndexInFeatureFileDataTable,int configEndTagIndexInFeatureFileDataTable)
	{
		String tempString;
		List<String> extractedList;
		List<List<String>> stepList = listFromStep.raw();
		SOAPWS.inputWorkbookPath = stepList.get(workbookPathIndexInFeatureFileDataTable).get(1);
		ScreenshotMethods.logger("Workbook path is:  "+SOAPWS.inputWorkbookPath);
		SOAPWS.inputWorkbookName = stepList.get(workbookNameIndexInFeatureFileDataTable).get(1);
		ScreenshotMethods.logger("Workbook name is: "+SOAPWS.inputWorkbookName);
		SOAPWS.targetSheetName = stepList.get(targetSheetNameIndexInFeatureFileDataTable).get(1);
		ScreenshotMethods.logger("Target Sheet name in workbook is :  "+SOAPWS.targetSheetName);
		SOAPWS.XPathColTag = stepList.get(xPathColTagIndexInFeatureFileDataTable).get(1);
		ScreenshotMethods.logger("Xpath tag in input data excel :  "+SOAPWS.XPathColTag);
		SOAPWS.FirstTargetColTag = stepList.get(firstTargetColTagIndexInFeatureFileDataTable).get(1);
		ScreenshotMethods.logger("Target column tag which will specify the column which will act as a source for Request xml nodes:  " +SOAPWS.FirstTargetColTag );
		// Get request tags
		tempString = stepList.get(requestDataTagIndexInFeatureFileDataTable).get(1);
		extractedList = Arrays.asList(tempString.split(";"));
		SOAPWS.RequestDataStartTag= extractedList.get(0);
		ScreenshotMethods.logger("Request Data Start Tag:  "+SOAPWS.RequestDataStartTag);
		SOAPWS.RequestDataEndTag = extractedList.get(1);
		ScreenshotMethods.logger("Request Data End Tag:  " +SOAPWS.RequestDataEndTag );
		// get response tags
		tempString = stepList.get(responseDataTagIndexInFeatureFileDataTable).get(1);
		extractedList = Arrays.asList(tempString.split(";"));
		SOAPWS.ResponseDataStartTag = extractedList.get(0);
		ScreenshotMethods.logger("Response Data Start Tag:  "+SOAPWS.ResponseDataStartTag);
		SOAPWS.ResponseDataEndTag = extractedList.get(1);
		ScreenshotMethods.logger("Response Data End Tag:  "+SOAPWS.ResponseDataEndTag );
		
		//config start and end 
		SOAPWS.configStart=stepList.get(configStartTagIndexInFeatureFileDataTable).get(1);
		SOAPWS.configEnd=stepList.get(configEndTagIndexInFeatureFileDataTable).get(1);
		
		

	}
	
	public static void Set2getTagsFromFeatureFile(DataTable listFromStep,int workbookPathIndexInFeatureFileDataTable,int workbookNameIndexInFeatureFileDataTable,
			int targetSheetNameIndexInFeatureFileDataTable,int xPathColTagIndexInFeatureFileDataTable,int firstTargetColTagIndexInFeatureFileDataTable
			,int requestDataTagIndexInFeatureFileDataTable,int responseDataTagIndexInFeatureFileDataTable,
			int configStartTagIndexInFeatureFileDataTable,int configEndTagIndexInFeatureFileDataTable)
	{
		String tempString;
		List<String> extractedList;
		List<List<String>> stepList = listFromStep.raw();
		SOAPWS.inputWorkbookPath1 = stepList.get(workbookPathIndexInFeatureFileDataTable).get(1);
		ScreenshotMethods.logger("Second Workbook path is:  "+SOAPWS.inputWorkbookPath1);
		SOAPWS.inputWorkbookName1 = stepList.get(workbookNameIndexInFeatureFileDataTable).get(1);
		ScreenshotMethods.logger("Second Workbook name is: "+SOAPWS.inputWorkbookName1);
		SOAPWS.targetSheetName1 = stepList.get(targetSheetNameIndexInFeatureFileDataTable).get(1);
		ScreenshotMethods.logger("Target Sheet name in second workbook is :  "+SOAPWS.targetSheetName1);
		SOAPWS.XPathColTag1 = stepList.get(xPathColTagIndexInFeatureFileDataTable).get(1);
		ScreenshotMethods.logger("Xpath tag in second input data excel :  "+SOAPWS.XPathColTag1);
		SOAPWS.FirstTargetColTag1 = stepList.get(firstTargetColTagIndexInFeatureFileDataTable).get(1);
		ScreenshotMethods.logger("Target column tag which will specify the column which will act as a source for Request xml nodes:  " +SOAPWS.FirstTargetColTag1 );
		// Get request tags
		tempString = stepList.get(requestDataTagIndexInFeatureFileDataTable).get(1);
		extractedList = Arrays.asList(tempString.split(";"));
		SOAPWS.RequestDataStartTag1= extractedList.get(0);
		ScreenshotMethods.logger("Request Data Start Tag for second input data excel file:  "+SOAPWS.RequestDataStartTag1);
		SOAPWS.RequestDataEndTag1 = extractedList.get(1);
		ScreenshotMethods.logger("Request Data End Tag for second input data excel file:  " +SOAPWS.RequestDataEndTag1 );
		// get response tags
		tempString = stepList.get(responseDataTagIndexInFeatureFileDataTable).get(1);
		extractedList = Arrays.asList(tempString.split(";"));
		SOAPWS.ResponseDataStartTag1 = extractedList.get(0);
		ScreenshotMethods.logger("Response Data Start Tag for second input data excel file:  "+SOAPWS.ResponseDataStartTag1);
		SOAPWS.ResponseDataEndTag1 = extractedList.get(1);
		ScreenshotMethods.logger("Response Data End Tag for second input data excel file:  "+SOAPWS.ResponseDataEndTag1 );
		
		//config start and end 
		SOAPWS.configStart1=stepList.get(configStartTagIndexInFeatureFileDataTable).get(1);
		SOAPWS.configEnd1=stepList.get(configEndTagIndexInFeatureFileDataTable).get(1);
		
		

	}
	
	
	public static int getRequestDataStartRowNumber(String workbookPath,String WorkbookName,String targetSheetName,String tag) 
	{
		List<List<Integer>> rowColListForAGivenText;
		int rowNumber=-999;
		// read the request nodes Xpath values from input excel file
		// get "RequestDataStart" tag row and col number
		rowColListForAGivenText = SpreadSheetMethods.getRowColWillCheckAllColsVertically(workbookPath,WorkbookName,targetSheetName,tag);
		if (rowColListForAGivenText.size() == 0) 
		{
			CommonMethods.testStepPassFlag = false;
			
			return rowNumber;
		} else {
			 rowNumber = rowColListForAGivenText.get(0).get(0) + 1;//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
			 return rowNumber;
		}

	}
	
	public static int getResponseDataStartRowNumber(String workbookPath,String WorkbookName,String targetSheetName,String tag) 
	{
		List<List<Integer>> rowColListForAGivenText;
		int rowNumber=-999;
		// read the request nodes Xpath values from input excel file
		// get "RequestDataStart" tag row and col number
		rowColListForAGivenText = SpreadSheetMethods.getRowColWillCheckAllColsVertically(workbookPath,WorkbookName,targetSheetName,tag);
		if (rowColListForAGivenText.size() == 0) 
		{
			CommonMethods.testStepPassFlag = false;
			return rowNumber;
		} else {
			 rowNumber = rowColListForAGivenText.get(0).get(0) + 1;//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
			 return rowNumber;
		}

	}
	
	
	
	public static int getRequestDataEndRowNumber(String workbookPath,String WorkbookName,String targetSheetName,String tag) 
	{
		List<List<Integer>> rowColListForAGivenText;
		int rowNumber=-999;
		//get "RequestDataEnd" tag row and col number
		rowColListForAGivenText = SpreadSheetMethods.getRowColWillCheckAllColsVertically(workbookPath,WorkbookName,targetSheetName,tag);
		if (rowColListForAGivenText.size() == 0) 
		{
			CommonMethods.testStepPassFlag = false;
			return rowNumber;
		} else {
			 rowNumber = rowColListForAGivenText.get(0).get(0) -1;//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
			 return rowNumber;
		}

	}
	
	
	public static int getResponseDataEndRowNumber(String workbookPath,String WorkbookName,String targetSheetName,String tag) 
	{
		List<List<Integer>> rowColListForAGivenText;
		int rowNumber=-999;
		//get "RequestDataEnd" tag row and col number
		rowColListForAGivenText = SpreadSheetMethods.getRowColWillCheckAllColsVertically(workbookPath,WorkbookName,targetSheetName,tag);
		if (rowColListForAGivenText.size() == 0) 
		{
			CommonMethods.testStepPassFlag = false;
			return rowNumber;
		} else {
			 rowNumber = rowColListForAGivenText.get(0).get(0) -1;//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
			 return rowNumber;
		}

	}
	
	public static int getRequestDataColNumber(String workbookPath,String WorkbookName,String targetSheetName,String tag) 
	{
		List<List<Integer>> rowColListForAGivenText;
		int colNumber=-999;
		//Xpath column number
		rowColListForAGivenText = SpreadSheetMethods.getRowColWillCheckAllColsVertically(workbookPath,WorkbookName,targetSheetName,tag);
		if (rowColListForAGivenText.size() == 0) 
		{
			CommonMethods.testStepPassFlag = false;
			return colNumber;
		} else {
			colNumber = rowColListForAGivenText.get(0).get(1);
			 return colNumber;
		}

	}
	
	public static int getResponseDataColNumber(String workbookPath,String WorkbookName,String targetSheetName,String tag) 
	{
		List<List<Integer>> rowColListForAGivenText;
		int colNumber=-999;
		//Xpath column number
		rowColListForAGivenText = SpreadSheetMethods.getRowColWillCheckAllColsVertically(workbookPath,WorkbookName,targetSheetName,tag);
		if (rowColListForAGivenText.size() == 0) 
		{
			CommonMethods.testStepPassFlag = false;
			return colNumber;
		} else {
			colNumber = rowColListForAGivenText.get(0).get(1);
			 return colNumber;
		}

	}
	
					//Get configuration details
					// Get request configuration information from input workbook
					// WebService configuration details search tags from scenario step
							public static void SET1setWebServicesConfigurationDetails(DataTable listFromStep,int WSConfigDataIndexInFeatureFile, List<List<String>> configList,
									String inputWorkbookPath,String inputWorkbookName,String targetSheetName,int baseColNumber,int comparisionColNumber,int configStartrowNumber,
									int configEndRowNumber)
							{
								String tempString;
								List<String> extractedList;
								List<List<String>> stepList = listFromStep.raw();
								tempString = stepList.get(WSConfigDataIndexInFeatureFile).get(1);
								extractedList = Arrays.asList(tempString.split(";"));
								// place the extractedList at the top of configuration tagList
								// wsConfigurationList.add(extractedList);
								for (int i = 0; i < extractedList.size(); i++) {
									List<String> singleTempList = new ArrayList();
									singleTempList.add(extractedList.get(i));
									configList.add(singleTempList);
								}
							
								// Get request configuration information from input workbook
								SpreadSheetMethods.compareAndReadGivenColumnCell(
										inputWorkbookPath, inputWorkbookName,
										targetSheetName, baseColNumber, comparisionColNumber,configStartrowNumber, configEndRowNumber,
										configList);
								// assign configuration values to configuration variables
								SOAPWS.WebServicesURI = SOAPWS.wsConfigurationList.get(0).get(1);
								ScreenshotMethods.logger("Webservice URI is:  "+SOAPWS.WebServicesURI);
								SOAPWS.ContentType = SOAPWS.wsConfigurationList.get(1).get(1);
								ScreenshotMethods.logger("Request Content Type is:  "+SOAPWS.ContentType);
								SOAPWS.UserName = SOAPWS.wsConfigurationList.get(2).get(1);
								ScreenshotMethods.logger("Request User name is:  "+SOAPWS.UserName);
								SOAPWS.Password = SOAPWS.wsConfigurationList.get(3).get(1);
								SOAPWS.HeaderName = SOAPWS.wsConfigurationList.get(4).get(1);
								ScreenshotMethods.logger("Request Header name is:  "+SOAPWS.HeaderName);
								SOAPWS.HeaderValue= SOAPWS.wsConfigurationList.get(5).get(1);
								ScreenshotMethods.logger("Request Header value is:  "+SOAPWS.HeaderValue);
								SOAPWS.RequestFileName = SOAPWS.wsConfigurationList.get(6).get(1);
								ScreenshotMethods.logger("Request XML file name is:  "+SOAPWS.RequestFileName);
								SOAPWS.RequestFilePath = SOAPWS.wsConfigurationList.get(7).get(1);
								ScreenshotMethods.logger("Request XML file path is:  "+SOAPWS.RequestFileName);
								SOAPWS.ResponseFileName = SOAPWS.wsConfigurationList.get(8).get(1);
								ScreenshotMethods.logger("Response XML name is:  "+SOAPWS.ResponseFileName);
								SOAPWS.responseDataSeparatorTag=SOAPWS.wsConfigurationList.get(9).get(1);
								ScreenshotMethods.logger("Separator Tag in request data column in input data excel file:  "+SOAPWS.responseDataSeparatorTag);
							}
					
							
							public static void updateXML(List<String> requestNodeXpath,List<String> requestNodeDataSet,String xmlFilePath,String xmlName )
							{
    				    	
						    	if (!(requestNodeXpath.size()==requestNodeDataSet.size()))
						    	{
						    		CommonMethods.testStepPassFlag = false;
						    		
						    		ScreenshotMethods.logger("Request XML file is not updated becuase there is mismatch in size of requestNodeXpath and requestNodeDataSet ");
						    	}
						    	else//update the xml
						    	{
						    		String xmlFileNameWithPath=xmlFilePath+"/"+xmlName;
						    		
						    		
						    		
						    		for(int i=0;i<requestNodeXpath.size();i++)
						    		{
						    			String xPathOfTargetNode=requestNodeXpath.get(i);
						    			String targetNodeValue=requestNodeDataSet.get(i);
						    			XmlHandlingMethods.updateExistingXMLNode(xmlFileNameWithPath, xPathOfTargetNode, targetNodeValue);
						    			
						    			
						    		}
						    		ScreenshotMethods.logger(" Request XML file:  "+xmlFileNameWithPath+"   is updated");
						    	}
					    	}
	
	
							
		public static void responseDataCollectionFromInputExcel()
		{
			
			
			
			SOAPWS.responseNodeListColNumber=-999;
			SOAPWS.responseNodeListColNumber=SOAPWebServicesAndWorkbookTalking
					.getResponseDataColNumber(SOAPWS.inputWorkbookPath,
							SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
							SOAPWS.RequestDataStartTag);//here RequestDataStartTag has been used and it is assumed that this tag would be available in the sceanrio data  table
			
			SOAPWS.responseDataStartRowNumber = -999;
			SOAPWS.responseDataStartRowNumber = SOAPWebServicesAndWorkbookTalking
					.getResponseDataStartRowNumber(SOAPWS.inputWorkbookPath,
							SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
							SOAPWS.ResponseDataStartTag);
			SOAPWS.responseDataEndRowNumber = -999;
			SOAPWS.responseDataEndRowNumber = SOAPWebServicesAndWorkbookTalking
					.getResponseDataEndRowNumber(SOAPWS.inputWorkbookPath,
							SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
							SOAPWS.ResponseDataEndTag);

			SOAPWS.responseXPATHColNumber = -999;
			SOAPWS.responseXPATHColNumber = SOAPWebServicesAndWorkbookTalking
					.getResponseDataColNumber(SOAPWS.inputWorkbookPath,
							SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
							SOAPWS.XPathColTag);

			SOAPWS.responseXMLComparisonDataColNumber = -999;

			SOAPWS.responseXMLComparisonDataColNumber = SOAPWebServicesAndWorkbookTalking
					.getResponseDataColNumber(SOAPWS.inputWorkbookPath,
							SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
							SOAPWS.FirstTargetColTag);

			SOAPWS.responseNodeList = SpreadSheetMethods
					.getAllCellValuesForAColInGivenVerticalRange(
							SOAPWS.inputWorkbookPath, SOAPWS.inputWorkbookName,
							SOAPWS.targetSheetName, SOAPWS.responseNodeListColNumber,
							SOAPWS.responseDataStartRowNumber, SOAPWS.responseDataEndRowNumber);
			ScreenshotMethods.logger("Response node name list (In input data excel sheet) is:  "+SOAPWS.responseNodeList);
			SOAPWS.responseNodeXpathList = SpreadSheetMethods
					.getAllCellValuesForAColInGivenVerticalRange(
							SOAPWS.inputWorkbookPath, SOAPWS.inputWorkbookName,
							SOAPWS.targetSheetName, SOAPWS.responseXPATHColNumber,
							SOAPWS.responseDataStartRowNumber, SOAPWS.responseDataEndRowNumber);
			ScreenshotMethods.logger("Response node XPath list (In input data excel sheet) is:  "+SOAPWS.responseNodeXpathList);
			SOAPWS.responseNodeDataSetList = SpreadSheetMethods
					.getAllCellValuesForAColInGivenVerticalRange(
							SOAPWS.inputWorkbookPath, SOAPWS.inputWorkbookName,
							SOAPWS.targetSheetName,
							SOAPWS.responseXMLComparisonDataColNumber,
							SOAPWS.responseDataStartRowNumber, SOAPWS.responseDataEndRowNumber);
			ScreenshotMethods.logger("Response node Data list (In input data excel sheet) is:  "+SOAPWS.responseNodeDataSetList);
		
		}
		
		//populate the response node list containing the expected value with the actual value (actual value comes from webservices response) and separated by delimiterTAG.
		
   public static void populateResponseNodeDataSetList()
       {
				//Get all the response data for the given path
				String xmpFileName=ScreenshotMethods.scenarioDirectoryPath+"/"+SOAPWS.ResponseFileName;
				//separate the response node data set list into two lists
				List<String> leftList=new ArrayList<>();List<String> rightList=new ArrayList<>();
				for (int i=0;i<SOAPWS.responseNodeDataSetList.size();i++)
				{
					List<String> extractedList = Arrays.asList(SOAPWS.responseNodeDataSetList.get(i).split(SOAPWS.responseDataSeparatorTag));
					leftList.add(extractedList.get(0));//populate left list
				}
				
				
				//populate right list
				for(int i=0;i<SOAPWS.responseNodeXpathList.size();i++)
				{
					try
					{
						//Call xpath getter method
						
						String nodeValue=XmlHandlingMethods.getXMLNodeValue(xmpFileName, SOAPWS.responseNodeXpathList.get(i));
						rightList.add(i,nodeValue);
					
						
					}catch(Exception e)
					{
						ScreenshotMethods.logger("Xpath not found for the node>>>   "+SOAPWS.responseNodeXpathList.get(i));
						rightList.add(i,e.toString());
					}
				}
					
				
				//Merge the two lists into one
				for(int i=0;i<leftList.size();i++)
				{
					String temp=leftList.get(i)+SOAPWS.responseDataSeparatorTag+rightList.get(i);
					SOAPWS.responseNodeDataSetList.set(i, temp);
					
				}
				ScreenshotMethods.logger("Corresponding response data in Expected and Actual format (Separated by delimiter)"+SOAPWS.responseNodeDataSetList);
       }	

}
