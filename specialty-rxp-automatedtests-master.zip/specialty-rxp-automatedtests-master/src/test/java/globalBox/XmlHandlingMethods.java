package globalBox;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;



public class XmlHandlingMethods {
	
/*	Sample xml:
 * <Request>
        <TestMode>N</TestMode>
        <Channel>IVR</Channel>
        <Direction>I</Direction>
        <Format>XML</Format>
        <OrgId>IVR</OrgId>
        <Role>IVR</Role>
        <UserId>WEBDQA</UserId>
        <OrderCriteria>
                <LineofBusiness>Accredo</LineofBusiness>
                <FilterType>SvRxRef</FilterType>
                <Invoice>
                        <Id></Id>
                        <SubInvoiceId></SubInvoiceId>
                        <FillNbr></FillNbr>
                </Invoice>
                <Prescription>
                        <Id>4250839</Id>
                        <LocationNbr>555</LocationNbr>
                        <RefillNbr>0</RefillNbr>
                </Prescription>
                <Prescription>
                        <Id>4250839</Id> <----------------------------------------------target node whose value we need to change
                        <LocationNbr>555</LocationNbr>
                        <RefillNbr>0</RefillNbr>
                </Prescription>
        </OrderCriteria>
</Request>
 * 
 * 
 * @Test
	public void testMethod()
	{
		String xmlFileNameWithPath="src/test/resources/inputXML/test.xml";
		String xmlTargetNodeXpath="Request/OrderCriteria/Prescription[2]/Id";   <-----------------
		String xmlTargetNodeValue="12345612";
		updateExistingXMLNode(xmlFileNameWithPath,xmlTargetNodeXpath,xmlTargetNodeValue);
		
	}*/
	public static void updateExistingXMLNode(String xmlFileNameWithPath,String xPathOfTargetNode,String targetNodeValue)
	{
		try{
			CommonMethods.testStepPassFlag=true;
			DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder=documentBuilderFactory.newDocumentBuilder();
			Document document=documentBuilder.parse(xmlFileNameWithPath);
			//Writing to the node
			//note that in xml , index starts with 1
			XPath xPath=XPathFactory.newInstance().newXPath();
			Node targetNode=(Node) xPath.compile(xPathOfTargetNode).evaluate(document,XPathConstants.NODE);
			
			if(targetNode!=null)
			{
				targetNode.setTextContent(targetNodeValue);
				System.out.println("Node is updated");
			}
			else
			{
			  System.out.println("Target nodexpath is not correct. Please check..Aborting...");
			  CommonMethods.testStepPassFlag=false;
			}
			
			//write the DOM object to the file
			TransformerFactory transformerFactory=TransformerFactory.newInstance();
			Transformer transformer=transformerFactory.newTransformer();
			DOMSource domSource=new DOMSource(document);
			StreamResult streamResult=new StreamResult(new File(xmlFileNameWithPath));
			transformer.transform(domSource, streamResult);
			
		}catch(Exception e)
		{
			System.out.println(e.toString());
			CommonMethods.testStepPassFlag=false;
		}
	}
	
	
	/*
	 * @Test
	public void testMethod()
	{
		String xmlFileNameWithPath="src/test/resources/inputXML/test.xml";
		String xmlTargetNodeXpath="Request/OrderCriteria/Prescription[2]/Id";
		String outputNodeValue=getXMLNodeValue(xmlFileNameWithPath, xmlTargetNodeXpath);
		System.out.println(outputNodeValue);
	}
	 */
	public static String getXMLNodeValue(String xmlFileNameWithPath,String xPathOfTargetNode)
	{
		String actualNodeText="-999 Some problem";//Incase unable to get node value
		try{
			CommonMethods.testStepPassFlag=true;
			DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder=documentBuilderFactory.newDocumentBuilder();
			Document document=documentBuilder.parse(xmlFileNameWithPath);
			//Writing to the node
			//note that in xml , index starts with 1
			XPath xPath=XPathFactory.newInstance().newXPath();
			Node targetNode=(Node) xPath.compile(xPathOfTargetNode).evaluate(document,XPathConstants.NODE);
			
			if(targetNode!=null)
			{
				actualNodeText=targetNode.getTextContent();
				
				
			}
			else
			{
			  System.out.println("Target nodexpath is not correct. Please check..Aborting...");
			  CommonMethods.testStepPassFlag=false;
			  
			}
			
			//write the DOM object to the file
			TransformerFactory transformerFactory=TransformerFactory.newInstance();
			Transformer transformer=transformerFactory.newTransformer();
			DOMSource domSource=new DOMSource(document);
			StreamResult streamResult=new StreamResult(new File(xmlFileNameWithPath));
			transformer.transform(domSource, streamResult);
			return actualNodeText;
			
		}catch(Exception e)
		{
			System.out.println(e.toString());
			CommonMethods.testStepPassFlag=false;
			return actualNodeText;
		}
	}
	
	
	/*
	 * <Request>
        <TestMode>N</TestMode>
        <Channel>IVR</Channel>
        <Direction>I</Direction>
        <Format>XML</Format>
        <OrgId>IVR</OrgId>
        <Role>IVR</Role>
        <UserId>WEBDQA</UserId>
        <OrderCriteria>
                <LineofBusiness>Accredo</LineofBusiness>
                <FilterType>SvRxRef</FilterType>
                <Invoice>
                        <Id/>
                        <SubInvoiceId/>
                        <FillNbr/>
                </Invoice>
                <Prescription>
                        <Id>4250839</Id>
                        <LocationNbr>555</LocationNbr>
                        <RefillNbr>0</RefillNbr>
                </Prescription>
                <Prescription>
                        <Id>12345612</Id>
                        <LocationNbr>555</LocationNbr>
                        <RefillNbr>0</RefillNbr>  <-----------------------------node to be removed
                </Prescription>
        </OrderCriteria>
</Request>


@Test
	public void testMethod()
	{
		String xmlFileNameWithPath="src/test/resources/inputXML/test.xml";
		String xPathOfParentNode="Request/OrderCriteria/Prescription[2]";
		String childNodeName="RefillNbr"; <------------------------------------------------node to e be removed
		removeExistingXMLNode(xmlFileNameWithPath,xPathOfParentNode,childNodeName);
		
	}
	 */
	public static void removeExistingXMLNode(String xmlFileNameWithPath,String xPathOfParentNode,String childNodeName)
	{
		CommonMethods.testStepPassFlag=true;
		try{
			DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder=documentBuilderFactory.newDocumentBuilder();
			Document document=documentBuilder.parse(xmlFileNameWithPath);
			//Writing to the node
			//note that in xml , index starts with 1
			XPath xPath=XPathFactory.newInstance().newXPath();
			Node parentNode=(Node) xPath.compile(xPathOfParentNode).evaluate(document,XPathConstants.NODE);
			
			if(parentNode!=null)
			{
				String childNodeXpath=xPathOfParentNode+"/"+childNodeName;
				Node childNode=(Node) xPath.compile(childNodeXpath).evaluate(document,XPathConstants.NODE);
				if(childNode!=null)
				{
					parentNode.removeChild(childNode);
					System.out.println("Node is removed");
				}
				else
				{
					System.out.println("Requested child node does not exist.Please check...Aborting...");
					CommonMethods.testStepPassFlag=false;
				}
			}
			else{
				System.out.println("Parent node xpath is not correct. Please check...Aborting...");
				CommonMethods.testStepPassFlag=false;
			}
			
			
			//write the DOM object to the file
			TransformerFactory transformerFactory=TransformerFactory.newInstance();
			Transformer transformer=transformerFactory.newTransformer();
			DOMSource domSource=new DOMSource(document);
			StreamResult streamResult=new StreamResult(new File(xmlFileNameWithPath));
			transformer.transform(domSource, streamResult);
			
			
		}catch(Exception e)
		{
			System.out.println(e.toString());
			CommonMethods.testStepPassFlag=false;
		}
	}
	
	/*
	 * <Request>
        <TestMode>N</TestMode>
        <Channel>IVR</Channel>
        <Direction>I</Direction>
        <Format>XML</Format>
        <OrgId>IVR</OrgId>
        <Role>IVR</Role>
        <UserId>WEBDQA</UserId>
        <OrderCriteria>
                <LineofBusiness>Accredo</LineofBusiness>
                <FilterType>SvRxRef</FilterType>
                <Invoice>
                        <Id/>
                        <SubInvoiceId/>
                        <FillNbr/>
                </Invoice>
                <Prescription>
                        <Id>4250839</Id>
                        <LocationNbr>555</LocationNbr>
                        <RefillNbr>0</RefillNbr>
                </Prescription>
                <Prescription>
                        <Id>12345612</Id>
                        <LocationNbr>555</LocationNbr>
                        <RefillNbr>0</RefillNbr>
                <Country>India</Country>                      <------------This node newly added
                </Prescription>  
        </OrderCriteria>
</Request>

@Test
	public void testMethod()
	{
		String xmlFileNameWithPath="src/test/resources/inputXML/test.xml";
		String xPathOfParentNode="Request/OrderCriteria/Prescription[2]";
		String childNodeName="Country";
		String childNodeValue="India";
        addAnotherNodeInXML(xmlFileNameWithPath,xPathOfParentNode,childNodeName,childNodeValue);
		
	}

	 */
	
	public static void addAnotherNodeInXML(String xmlFileNameWithPath,String xPathOfParentNode,String childNodeName,String childNodeValue)
	{
		try{
			CommonMethods.testStepPassFlag=true;
			DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder=documentBuilderFactory.newDocumentBuilder();
			Document document=documentBuilder.parse(xmlFileNameWithPath);
			//Writing to the node
			//note that in xml , index starts with 1
			XPath xPath=XPathFactory.newInstance().newXPath();
			Node parentNode=(Node) xPath.compile(xPathOfParentNode).evaluate(document,XPathConstants.NODE);
			
			if(parentNode!=null)
			{

				Node newNodeXpathExistence=(Node) xPath.compile(xPathOfParentNode+"/"+childNodeName).evaluate(document,XPathConstants.NODE);
				if(newNodeXpathExistence==null)//node already not present then create a new node
				{
					Element newNode=document.createElement(childNodeName);
					newNode.setTextContent(childNodeValue);
					parentNode.appendChild(newNode);
					System.out.println("node added");
					
				}
				else
				{
					System.out.println("Node to be added already present...Aborting...");
					CommonMethods.testStepPassFlag=false;
					
				}
			}
			else{
				System.out.println("Parent node xpath is not correct. Please check...Aborting...");
				CommonMethods.testStepPassFlag=false;
			}
			
			
			//write the DOM object to the file
			TransformerFactory transformerFactory=TransformerFactory.newInstance();
			Transformer transformer=transformerFactory.newTransformer();
			DOMSource domSource=new DOMSource(document);
			StreamResult streamResult=new StreamResult(new File(xmlFileNameWithPath));
			transformer.transform(domSource, streamResult);
			
			
		}catch(Exception e)
		{
			System.out.println(e.toString());
			CommonMethods.testStepPassFlag=false;
		}
		
	}

}
