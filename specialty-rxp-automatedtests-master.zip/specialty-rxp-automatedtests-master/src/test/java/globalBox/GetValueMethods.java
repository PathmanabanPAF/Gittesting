package globalBox;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;


public class GetValueMethods {

/*	This method is used to get the value of an attribute
	 input parameter -  localBylocator as WebDriver, localwait as WebDriverWait, nameAttribute as a String
*/
		public static String getElementAttributeValue(WebDriver localdriver, WebDriverWait wait, By locator,String nameAttribute,int maxWaitTime) 
		{
		String valueNDC="";
		WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
//			WaitMethods.waitForElementPresence(wait,locator);
			valueNDC = localdriver.findElement(locator).getAttribute(nameAttribute);
		
		return valueNDC;
			}

	/*	This method is used to get the value of attributes  of elements under a locator  in the web page in a string list
		input parameter -  localBylocator as WebDriver, localwait as WebDriverWait, nameAttribute as a String
		output -It lists the various attribute values under the common locator*/

		public static List<String> getMultipleElementAttributeList(WebDriver localdriver, WebDriverWait wait, By locator, String nameAttribute, int maxWaitTime)
			{

				List<String> listText = new ArrayList<String>();
				WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
				// WaitMethods.waitForElementPresence(wait,locator);
				int sizeElements = localdriver.findElements(locator).size();
				for (int i = 0; i < sizeElements; i++)
					{
						listText.add(localdriver.findElements(locator).get(i).getAttribute(nameAttribute));

					}
				return listText;

			}

	/*	This method is used to get the text value of an element
		input parameter -  localBylocator as WebDriver, localwait as WebDriverWait, nameAttribute as a String
		output -It returns the text value of the  element.
*/
		public static String getTextValue(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime)
			{
				WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
				// WaitMethods.waitForElementReady(wait,locator);
				String UIText = localdriver.findElement(locator).getText();
				return UIText;

			}

	/*	This method is used to get the text value of  elements under a locator  in the web page in a string list
		input parameter -  localBylocator as WebDriver, localwait as WebDriverWait, nameAttribute as a String
		output -It returns the text values of elements values under the common locator
*/
		public static List<String> getMultipleTextValues(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime)
			{
				List<String> listTextValues = new ArrayList<String>();

				String valueElement = "";
				WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
				// WaitMethods.waitForElementReady(wait,locator);
				int numberOfTextValues = localdriver.findElements(locator).size();
				for (int i = 0; i < numberOfTextValues; i++)
					{
						valueElement = localdriver.findElements(locator).get(i).getText();
						listTextValues.add(valueElement);
					}
				return listTextValues;

			}
		public static String getElementAttributeValue(WebDriver localdriver, WebDriverWait wait, By locator, String nameAttribute) 
		{

			String valueNDC="";
				WaitMethods.waitForElementPresence(wait,locator);
				valueNDC = localdriver.findElement(locator).getAttribute(nameAttribute);
			
			return valueNDC;

		}
		
		public static List<String> getMultipleElementAttributeList(WebDriver localdriver, WebDriverWait wait, By locator, String nameAttribute) 
		{
		
			List<String> listText =new ArrayList<String>();
			    WaitMethods.waitForElementPresence(wait,locator);
				int sizeElements = localdriver.findElements(locator).size();
				for(int i=0;i<sizeElements;i++){
					listText.add(localdriver.findElements(locator).get(i).getAttribute(nameAttribute));
					
				}
				return listText;
		
		}
		
		
		public static String getTextValue(WebDriver localdriver, WebDriverWait wait, By locator)
		{
			
				WaitMethods.waitForElementReady(wait,locator);
				String UIText=localdriver.findElement(locator).getText();
				return UIText;
			
		}
		
		
		public static String getElementPresentTextValue(WebDriver localdriver, WebDriverWait wait, By locator)
		{
			
				WaitMethods.waitForElementPresence(wait, locator);
				String UIText=localdriver.findElement(locator).getText();
				return UIText;
			
		}
		
		public static List<String> getMultipleTextValues(WebDriver localdriver, WebDriverWait wait, By locator)
		{
			List<String> listTextValues = new ArrayList<String>();
			
				String valueElement ="";
				WaitMethods.waitForElementReady(wait,locator);
				int numberOfTextValues = localdriver.findElements(locator).size();
				for(int i=0; i < numberOfTextValues; i++)
				{
					valueElement=localdriver.findElements(locator).get(i).getText();
					listTextValues.add(valueElement);	
				}
				return listTextValues;			
			
				
		}

	}
