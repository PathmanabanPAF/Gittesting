package globalBox;

import javax.net.ssl.SSLContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.*;
import org.apache.http.entity.FileEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

//Must use SOAPStepDef.java in stepDefinitionBox package
public class SOAPWS {
//********************************for first request ***********************************************************
	public static String inputWorkbookName;
	public static String inputWorkbookPath;
	public static String targetSheetName;
	public static String WebServicesURI;
	public static String ContentType;
	public static String UserName;
	public static String Password;
	public static String HeaderName;
	public static String HeaderValue;
	public static String RequestFileName;
	public static String RequestFilePath;
	public static String ResponseFileName;
	public static String RequestDataStartTag;
	public static String RequestDataEndTag;
	public static String ResponseDataStartTag;
	public static String ResponseDataEndTag;
	public static String XPathColTag;
	public static String FirstTargetColTag;
	public static String responseDataSeparatorTag;
	public static String configStart;
	public static String configEnd;
	public static List<List<String>> wsConfigurationList=new ArrayList<List<String>>();
	public static List<String> requestNodeList=new ArrayList<>();
	public static List<String> requestNodeXpath=new ArrayList<>();
	public static List<String> requestNodeDataSet=new ArrayList<>();
	public static List<String> responseNodeList=new ArrayList<>();
	public static List<String> responseNodeXpathList=new ArrayList<>();
	public static List<String> responseNodeDataSetList=new ArrayList<>();
	
	//**************Response parameters*************************************
	public static int responseNodeListColNumber;	
	public static int responseDataStartRowNumber;	
	public static int responseDataEndRowNumber;
	public static int responseXPATHColNumber;
	public static int responseXMLComparisonDataColNumber;
	
	//*************Second Input sheet data**************************************
	public static String inputWorkbookPath1;
	public static String inputWorkbookName1;
	public static String targetSheetName1;
	public static String XPathColTag1;
	public static String FirstTargetColTag1;
	public static String RequestDataStartTag1;
	public static String RequestDataEndTag1;
	public static String ResponseDataStartTag1;
	public static String ResponseDataEndTag1;
	public static String configStart1;
	public static String configEnd1;
	
	public static List<String> requestNodeList1=new ArrayList<>();
	public static List<String> requestNodeXpathList1=new ArrayList<>();
	public static List<String> requestNodeDataSetList1=new ArrayList<>();
	
	
	
	

	public static void soapWSRequest(String strRequestXMLNameAndPath,String WebServiceURI,String contentType,String userName,String password,
			String headerName,String headerValue,String saveResponseXMLAtPathAndFileName)	  throws Exception 
	{
			     SSLContext sslContext = new SSLContextBuilder()
			          .loadTrustMaterial(null, (certificate, authType) -> true).build();

				     String strRequestPath = strRequestXMLNameAndPath;
				     String strURL  =WebServiceURI;
	              
				     File input = new File(strRequestPath);
	              
				     
				     
				     HttpEntity entity = new FileEntity(input, contentType);
				     /**
				      * When a server sends a document to a user agent (eg. a browser) it also sends information in the Content-Type field of the accompanying HTTP header about what type of data format this is.
				      * It is very important to always label Web documents explicitly. HTTP 1.1 says that the default charset is ISO-8859-1. But there are too many unlabeled documents in other encodings, so browsers use the reader's preferred encoding when there is no explicit charset parameter.
                      * The line in the HTTP header typically looks like this:Content-Type: text/html; charset=utf-8
				      */
				  
	                
			               
					    CredentialsProvider provider= new BasicCredentialsProvider();
					    UsernamePasswordCredentials credentials =new UsernamePasswordCredentials(userName,password);
					    provider.setCredentials(AuthScope.ANY, credentials);
					    
					    
			    
			    
			    
			    
			    CloseableHttpClient client = HttpClients.custom()
			      .setSSLContext(sslContext)
			      .setSSLHostnameVerifier(new NoopHostnameVerifier())
			      .setDefaultCredentialsProvider(provider)
			      .build();
			   
			   // HttpGet httpGet = new HttpGet(strURL);
			    HttpPost post1 = new HttpPost(strURL); 
			    post1.setEntity(entity);
			    post1.setHeader(headerName, headerValue);
			    
			
			    HttpResponse response = client.execute(post1);
			    String responseString = new BasicResponseHandler().handleResponse(response);
			    ScreenshotMethods.logger("Response data is:  " +responseString);
			   /* The below lines of code are also used to get the response as string. But the problem with this is that when you consume response 
			    * data once using  HttpEntity entitytest=response.getEntity();  then response buffer is freed and there is no content in it.
			    * 
			    * HttpEntity entitytest=response.getEntity(); 
			    String testString=EntityUtils.toString(entitytest);*/
			    
			    
			    //******************************reading the response node
			    // Parse the response using DocumentBuilder so you can get at elements easily
//			    DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
//			    DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
//			    Document doc = docBuilder.parse(response);
//			    Element root = doc.getDocumentElement();
//			    
			    //write the response to xml file
			    stringToDom(responseString,saveResponseXMLAtPathAndFileName);
			    
			    post1.releaseConnection();
			}
	
	public static void stringToDom(String xmlSource,String fileNameWithPath) 
            throws IOException
			{
					        /*java.io.FileWriter fw = new java.io.FileWriter(fileNameWithPath);
					        fw.write(xmlSource);
					        fw.close();*/
					
			        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			        
			        DocumentBuilder builder;
			        try
			        {
			            builder = factory.newDocumentBuilder();
			 
			            // Use String reader
			            Document document = builder.parse( new InputSource(
			                    new StringReader( xmlSource ) ) );
			 
			            TransformerFactory tranFactory = TransformerFactory.newInstance();
			            Transformer aTransformer = tranFactory.newTransformer();
			            aTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
			            aTransformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			            Source src = new DOMSource( document );
			            Result dest = new StreamResult( new File( fileNameWithPath ) );
			            aTransformer.transform( src, dest );
			        } catch (Exception e)
			        {
			            // TODO Auto-generated catch block
			        	ScreenshotMethods.logger("Exception encountered  in writing string xml to DOM. Please check...:  "+e.toString());	
			            e.printStackTrace();
			        }
	 }
	

    
}