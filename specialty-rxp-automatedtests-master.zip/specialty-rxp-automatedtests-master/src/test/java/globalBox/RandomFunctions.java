package globalBox;

import java.util.Random;

public class RandomFunctions {
	public static String rand_strng ()
	{
	     String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890ABCDEFGHIJKLMNOEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	        StringBuilder salt = new StringBuilder();
	        Random rnd = new Random();
	        while (salt.length() <15) { // length of the random string.
	            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
	            salt.append("Pega"+SALTCHARS.charAt(index));
	        }
	        String saltStr = salt.toString();
	        return saltStr;

	}

}
