package globalBox;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ListSelectionMethods {
	
	public static void clickCheckboxOfFilterList(By locator,String localtext,WebDriver localdriver,WebDriverWait wait)
	{
		
			WebElement table=localdriver.findElement(locator);
			List<WebElement> filterListTR=table.findElements(By.xpath("./tr"));
			//Get the required TR By comparison with text "localtext"
			boolean listItemFound=false;
			for(int i=1;i<filterListTR.size();i++)
			{
				List<WebElement> filterListTD=filterListTR.get(i).findElements(By.xpath("./td"));
				//for(int j=0;j<filterListTD.size();j++)
				//{
					WebElement TDTextElement=filterListTD.get(1).findElement(By.xpath(".//a"));
					String TRListText=TDTextElement.getText();
					if(TRListText.equals(localtext))
					{
						listItemFound=true;
						//click on the first TD
						WebElement checkboxElement=filterListTD.get(0).findElement(By.xpath(".//input[@type='checkbox']"));
						checkboxElement.click();		
					}
			
				if(listItemFound==false)
					{continue;}
				else 
				{
					break;
				}
				
			}
		
	}
	
	//for review later
	public static List<String> getTableColumnData(WebDriver localdriver,WebDriverWait wait,By locator,int columnNumber)
	{
		
		    List<String> dataTable = new ArrayList<String>();
		    
		    WaitMethods.waitForElementReady(wait, locator);
		    
			WebElement table=wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			List<WebElement> filterListTR =wait.until(ExpectedConditions.visibilityOfAllElements(table.findElements(By.xpath("./tr"))));
			 

			for(int i=1;i<filterListTR.size();i++)
			{				
				List<WebElement> filterListTD= wait.until(ExpectedConditions.visibilityOfAllElements(filterListTR.get(i).findElements(By.xpath("./td"))));
				
				WebElement TDTextElement= wait.until(ExpectedConditions.visibilityOf(filterListTD.get(columnNumber).findElement(By.xpath(".//*[text()]"))));
				
				String valueName = TDTextElement.getText();
				
				dataTable.add(valueName);
				
			}
			
		return dataTable;
	}

}
