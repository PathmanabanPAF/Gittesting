package globalBox;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseMethods {

	public DatabaseMethods() {
	}

	public static Connection getSqlConnection(String nameHost,
			String nameService, int numberPort, String userName,
			String userPassword) throws SQLException, ClassNotFoundException {
		
				Class.forName("oracle.jdbc.OracleDriver");
				String connectionString = "jdbc:oracle:thin:" + userName + "/"
						+ userPassword + "@" + nameHost + ":" + numberPort + "/"
						+ nameService;
				return DriverManager.getConnection(connectionString);
			
				
	}

	public static Connection getSqlConnection(String nameHost,
			String nameService, int numberPort) throws SQLException,
			ClassNotFoundException {
		
		        Class.forName("oracle.jdbc.OracleDriver");
				String connectionString = "jdbc:oracle:thin" + nameHost + ":"
						+ numberPort + "/" + nameService;
				return DriverManager.getConnection(connectionString);
		   
	}
	public static Connection getSqlConnection(String url, String userName,
			String userPassword) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		 
	
	            // Make the database connection
	            String dbClass = "oracle.jdbc.OracleDriver";
	            System.out.println("Connecting to database");
	            Class.forName(dbClass).newInstance();
	            // Get connection to DB
	            return DriverManager.getConnection(url, userName, userPassword);
	            // Statement object to send the SQL statement to the Database
		
	     
	}
	public static void closeConnection(Connection connectionObj) throws SQLException {
				
				connectionObj.close();
		
	}

	public static ResultSet executeDatabaseQuery(Connection connectionObj,
			String querySQL) throws SQLException {
		Statement statementObj=null;
		
			String strSqlQuery = querySQL;
				if (querySQL.endsWith(";"))
				{
					strSqlQuery = querySQL.substring(0, querySQL.length() - 2);
				}
				 statementObj = connectionObj.createStatement();
				return statementObj.executeQuery(strSqlQuery);
		
	}

	public static String getColumnValues(ResultSet results, String nameKey)
			throws SQLException 
			{
					String valueColumn = "";
					int countSetItems = 0;
					while (results.next()) 
					{
						++countSetItems;
						String tempValue = results.getString(nameKey).trim();
						if (countSetItems > 1) {

							valueColumn = valueColumn + "," + tempValue;
						} else {
								valueColumn = tempValue;
								}
					}
					return valueColumn;
			}


}
