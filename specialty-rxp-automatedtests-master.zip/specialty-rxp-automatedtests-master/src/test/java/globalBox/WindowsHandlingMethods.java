package globalBox;

import java.util.Iterator;

import org.openqa.selenium.WebDriver;

public class WindowsHandlingMethods {

	public static String winHandleBefore = "";

	public static void switchwindow(WebDriver localdriver, String titleWindow) {

		try {
			WebDriver popup = null;
			winHandleBefore = localdriver.getWindowHandle();

			Iterator<String> windowIterator = localdriver.getWindowHandles().iterator();

			while (windowIterator.hasNext()) {
				String windowHandle = windowIterator.next();
				popup = localdriver.switchTo().window(windowHandle);
				String title = popup.getTitle();
				if (title.contains(titleWindow)) {
					break;
				}
			}

		} catch (Exception e) {

		}
	}

	public static void switchwindowBack(WebDriver localdriver) {
		try {
			localdriver.close();

			localdriver.switchTo().window(winHandleBefore);

		} catch (Exception e) {

		}
	}
}
