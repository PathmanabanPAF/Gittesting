package globalBox;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;




import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;


public class ScreenshotMethods {
	private static XWPFDocument doc; 
	private static XWPFRun r;
	private static Document document;
	public static String screenshotFileName="";
	public static String featureFileDirectoryPath="";//contains current feature folder name with path
	public static String scenarioDirectoryPath="";//contains current scenario folder name with path
	

	
	public static void initializeScreenshot(String nameDocument) throws IOException, InterruptedException{
	
		
				Thread.sleep(1000);
				
				doc = new XWPFDocument();
			    XWPFParagraph p = doc.createParagraph();
			    r = p.createRun();
			    
			    
			   
				document = new Document();
			
				try {
							screenshotFileName=nameDocument;
							String parentPath=CommonMethods.TestRunnerfolderWithPath+"/";
							String directoryName=CommonMethods.featureName;
							if(CommonMethods.featureName.length()>30)
							{
								directoryName=CommonMethods.featureName.substring(0,30);
							}
							
							String directoryAndPath=parentPath+directoryName;
								
									File directory=new File(directoryAndPath);
									if(!directory.exists())//Create feature file directory
									{
										directory.mkdir();
										featureFileDirectoryPath=directoryAndPath;
									}
					
									featureFileDirectoryPath=directoryAndPath;
									
									
									//scenario folder creation with timestamp
									String scenarioFolderNameWithPath=featureFileDirectoryPath+"/"+nameDocument;
									
										File ScenarioFolder=new File(scenarioFolderNameWithPath);
										
										if(!ScenarioFolder.exists())//Create feature file directory
										{
											ScenarioFolder.mkdir();
											scenarioDirectoryPath=scenarioFolderNameWithPath;
										}
										scenarioDirectoryPath=scenarioFolderNameWithPath;
									
									
							       // PdfWriter.getInstance(document, new FileOutputStream("Image.pdf"));
									PdfWriter.getInstance(document, new FileOutputStream(scenarioDirectoryPath+"/"+ nameDocument +".pdf"));
									document.open();
									
				
						 
							        
				
			      
			    }
				catch(Exception e)
				{
					
				}
	
		
	}
	

	
	
	//public static void takeScreenshot(WebDriver localdriver,String nameScreenshot,String stepDescription) throws IOException, InterruptedException, InvalidFormatException{
	
	//commented all the lines to check for taking screenshot in a folder. just remove // at the begining of each line
	public static void takeScreenshot(WebDriver localdriver,String nameScreenshot,String stepDescription){
		try
		{
			
			File testFile1= ((TakesScreenshot)localdriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(testFile1, new File("src/test/resources/jresources/"+ nameScreenshot +".png"));
	        /*
			String imgFile = "src/test/resources/jresources/"+ nameScreenshot +".jpg";
		    int format =XWPFDocument.PICTURE_TYPE_JPEG;
		    r.setText(stepDescription);
	        r.addBreak();
	        r.addBreak();
	        r.addPicture(new FileInputStream(imgFile), format, imgFile, Units.toEMU(500), Units.toEMU(600)); // 200x200 pixels
	        r.addBreak(BreakType.PAGE);  
	        */
			document.add(new Paragraph(stepDescription));
	        Image image1 = Image.getInstance("src/test/resources/jresources/"+ nameScreenshot +".png");
	       image1.scalePercent(100f, 70f);
	       // image1.scalePercent(70f);
	       image1.scaleToFit(500, 600);
	       // image1.setAbsolutePosition(0, 0);
	        document.add(image1);	
		   document.newPage();
		
		}
		
		catch(Exception e){
			CommonMethods.testStepPassFlag=false;
			
		}
	}  
	
	
	
	
	public static void takeAllPageScreenshots(WebDriver localdriver,String nameScreenshot,String stepDescription){
		try
		{
			//to be implemented later dont use this
			takeScreenshot(BrowserMethods.driver1,"tempJPEGFilePlaceHolder", "stepDescription");
			//float totalheight=document.getPageSize().getHeight();
			Toolkit toolkit=Toolkit.getDefaultToolkit();
			Dimension screenSize=toolkit.getScreenSize();
			Robot robot =new Robot();
			Rectangle rectangle=new Rectangle (0,0,screenSize.width,screenSize.height);
			BufferedImage image=robot.createScreenCapture(rectangle);
			ImageIO.write(image, "png",new File("src/test/resources/jresources/"+ nameScreenshot +".png"));
			 Image image1 = Image.getInstance("src/test/resources/jresources/"+ nameScreenshot +".png");
		       // image1.scalePercent(70f);
		        image1.scaleToFit(500, 600);
		       // image1.setAbsolutePosition(0, 0);
		        document.add(image1);	
		        JavascriptExecutor jse=(JavascriptExecutor)localdriver;
		       jse.executeScript("window.scrollBy(0,100)","");
//		        robot.delay(2000);
//			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
//			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
			Thread.sleep(2000);
			 image=robot.createScreenCapture(rectangle);
			 ImageIO.write(image, "png",new File("src/test/resources/jresources/"+ nameScreenshot +".png"));
			 image1 = Image.getInstance("src/test/resources/jresources/"+ nameScreenshot +".png");
		       // image1.scalePercent(70f);
		        image1.scaleToFit(500, 600);
		       // image1.setAbsolutePosition(0, 0);
		        document.add(image1);	
			//takeScreenshot(BrowserMethods.driver1,"tempJPEGFilePlaceHolder", "");
			
					}
		
		catch(Exception e){
			CommonMethods.testStepPassFlag=false;
			
		}
	} 
	
//	public static void takeScreenshot(WebDriver localdriver,String nameScreenshot,String stepDescription){
//		try
//		{
//			
//			File testFile1= ((TakesScreenshot)localdriver).getScreenshotAs(OutputType.FILE);
//			FileUtils.copyFile(testFile1, new File("src/test/resources/jresources/"+screenshotFileName+"/"+ CommonMethods.getTimeStamp() +".png"));
//	        /*
//			String imgFile = "src/test/resources/jresources/"+ nameScreenshot +".jpg";
//		    int format =XWPFDocument.PICTURE_TYPE_JPEG;
//		    r.setText(stepDescription);
//	        r.addBreak();
//	        r.addBreak();
//	        r.addPicture(new FileInputStream(imgFile), format, imgFile, Units.toEMU(500), Units.toEMU(600)); // 200x200 pixels
//	        r.addBreak(BreakType.PAGE);  
//	        */
//			document.add(new Paragraph(stepDescription));
//	        Image image1 = Image.getInstance("src/test/resources/jresources/"+ nameScreenshot +".png");
//	        image1.scalePercent(30f);
//	        document.add(image1);	
//		
//		
//		}
//		
//		catch(Exception e){
//			CommonMethods.testStepPassFlag=false;
//			
//		}
//	}
	
	public static void logger(String logDetails)
	{ 
			/*
				r.setText(logDetails);
		        r.addBreak();
		        r.addBreak();
		        */ 
		        
		       
				try {
					document.add(new Paragraph(logDetails));
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
	}
	
	public static void finalizeScreenshotDocument() throws IOException{
		
		/*
		  FileOutputStream out = new FileOutputStream("src/test/resources/jresources/"+ nameDocument +".docx");
		  doc.write(out);
		  out.close();
		  
		  */
		try{
		  
		  
		  document.close();
		}catch(Exception e)
		{
		System.out.println(e);
		}
	    
	}
}
