package globalBox;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TextBoxMethods {
	
	
	/*	This method is used to wait till a particular text field is identified by the web driver using 
	WaitMethods.waitForElementReady and then it clears any text present in the text box using  clear and then  it enters the value in the text box.
	(2)input parameters - localdriver,wait,locator, inputText
	(3)output - desired text is entered into the text box.
*/
	public static void inputText(WebDriver localdriver,WebDriverWait wait,By locator, String inputText,int maxWaitTime)
	{
		
//			WaitMethods.waitForElementReady(wait, locator);
		WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
			localdriver.findElement(locator).clear();
			localdriver.findElement(locator).sendKeys(inputText);
			
		
	}

	public static void inputTextWithClearAndWait(WebDriver localdriver, WebDriverWait wait, By locator, String inputText, int maxWaitTime)
		{

			// WaitMethods.waitForElementReady(wait, locator);
			// WaitMethods.syncWait(localdriver, wait, locator,
			// maxWaitTime);
			WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
			localdriver.findElement(locator).clear();
			WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
			// WaitMethods.syncWait(localdriver, wait, locator,
			// maxWaitTime);
			/*
			 * try { Thread.sleep(sleepTime); } catch (InterruptedException
			 * e) { // TODO Auto-generated catch block e.printStackTrace();
			 * }
			 */
			localdriver.findElement(locator).sendKeys(inputText);

		}
	
	public static void setElementAttributeValue(WebDriver localdriver, WebDriverWait wait, By locator, String nameAttribute, String valueAttribute, int maxWaitTime)
	{
		// WaitMethods.waitForElementPresence(wait, locator);
		WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
		WebElement element = localdriver.findElement(locator);
		((JavascriptExecutor) localdriver).executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", new Object[] { element, nameAttribute, valueAttribute });

	}


	public static void clearText(WebDriver localdriver, WebDriverWait wait, By locator, String inputText, int maxWaitTime)
	{

		// WaitMethods.waitForElementReady(wait, locator);
		WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
		localdriver.findElement(locator).clear();
	}
		
	public static void inputText(WebDriver localdriver,WebDriverWait wait,By locator, String inputText)
	{
		
			WaitMethods.waitForElementReady(wait, locator);

			localdriver.findElement(locator).clear();

			localdriver.findElement(locator).sendKeys(inputText);

		
	}
	public static void setElementAttributeValue(WebDriver localdriver, WebDriverWait wait, By locator,String nameAttribute, String valueAttribute) 
	{
		    WaitMethods.waitForElementPresence(wait, locator);

			WebElement element = localdriver.findElement(locator);

			((JavascriptExecutor)localdriver).executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", new Object[]{element, nameAttribute, valueAttribute});


	}
	
	
	public static void clearText(WebDriver localdriver,WebDriverWait wait,By locator)
	{
		
			WaitMethods.waitForElementReady(wait, locator);
			localdriver.findElement(locator).clear();
	}
	
	public static void inputTextWithoutVisibility(WebDriver localdriver,WebDriverWait wait,By locator, String inputText)
	{
		
			//WaitMethods.waitForElementPresence(wait, locator);
			localdriver.findElement(locator).clear();
			localdriver.findElement(locator).sendKeys(inputText);
		
	}
	
	
	public static void retryInputText(WebDriver localdriver,WebDriverWait wait,By locator, String inputText) throws InterruptedException
	{
		
		
		int attempts = 0;
		while(attempts < 5) {
			try {
				WaitMethods.waitForElementReady(wait, locator);

				localdriver.findElement(locator).clear();

				localdriver.findElement(locator).sendKeys(inputText);
				break;
			} catch(StaleElementReferenceException e) {
			}
			attempts++;
		}
		
			

		
	}
}
