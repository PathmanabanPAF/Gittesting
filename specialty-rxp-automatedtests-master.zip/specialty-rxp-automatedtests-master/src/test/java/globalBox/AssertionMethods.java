package globalBox;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AssertionMethods {

	public static int alreadyWaitedTime = 500;
	/*
	 * Verify Expected and actual Strings: method is used to compare two strings
	 * Input parameters :- Field name, expected value, actual value in form of  string
	 * Output :-If the strings matches it will return true, else it returns false.
	 */
	public static void expectedActualTest(
			String expectedValue, String actualValue) {
		if (!expectedValue.equals(actualValue)) {
			CommonMethods.testStepPassFlag = false;	
		} 
	}

/*	Verify Expected and actual Strings: method is used to compare two strings
	(1)Input parameters :- Field name, expected value, actual value in form of  string
	(2)Output :-If the strings matches it will return true else false.
	(3)It takes screen shot for the output page using ScreenshotMethods.takeScreenshot.

			 */
			public static void expectedActualTest(String fieldName, String expectedValue, String actualValue)
			{
				if (!expectedValue.equals(actualValue)) {
					CommonMethods.testStepPassFlag = false;	
				} 
			}
			
	/*
	 * Verify Expected and actual Strings: method is used to compare two strings
	 * Input parameters :- Field name, expected value, actual value in form of  string
	 * Output :-If the strings matches it will return true, else it returns false.
	 */
	public static void equalIgnoreExpectedActualTest(
			String expectedValue, String actualValue) {
		if (!expectedValue.equalsIgnoreCase(actualValue)) {
			CommonMethods.testStepPassFlag = false;	
		} 
	}
	/*
	Verify Expected and actual Integers: method is used to compare two Numbers
	(1)Input parameters :- Field name, expected value, actual value in form of Integer
	(2)Output :-If the numbers match it will return true else false.
	(3)It takes screen shot for the output page using ScreenshotMethods.takeScreenshot.

			 */
	
	public static void expectedActualIntegerTest(String fieldName, int expectedValue, int actualValue)
	{

		if (expectedValue == actualValue)
			{
				// System.out.println("Validation of "+ fieldName
				// +": Expected value is equal to Actual value");
				// System.out.println("Expected value:" + expectedValue
				// +
				// "\t Actual value:" + actualValue + "\n \n");
				String result = "";
				result = "++++++Validation of " + fieldName + ": Expected value is equal to Actual value" + "\n \n" + "Expected value:" + expectedValue + "\t Actual value:" + actualValue + "\n \n---------";
				System.out.println(result);
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", result);

			} else
			{
				// System.out.println("Validation of "+ fieldName
				// +": Expected value is not equal to Actual value");
				// System.out.println("Expected value:" + expectedValue
				// +
				// "\t Actual value:" + actualValue + "\n \n");
				String result = "";
				result = "++++++Validation of " + fieldName + ": Expected value is equal to Actual value" + "\n \n" + "Expected value:" + expectedValue + "\t Actual value:" + actualValue + "\n \n---------";
				System.out.println(result);
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", result);
				CommonMethods.testStepPassFlag = false;
			}

	}

	
	
	/*
	 * Input parameters :- Field name, responseNodePath value in the form of String ,localdriver as webdriver , wait as WebDriverWait , UIlocator as By
	 * Output :- If the UI and WebService data matches it will return true, else it returns false.
	 * It is using RestWebservicesMethods.getNodeValue to get the node value.
	 * It is using GetValueMethods.getTextValue to get the UItext value. 
	 * It is using AssertionMethods.expectedActualTest to compare node value and UI text value.
	 */
	public static void verifyResponseDatawithUI(String fieldName,
			WebDriver localdriver, WebDriverWait wait, String responseNodePath,
			By UIlocator) {

		String WSResponsevalue = RestWebservicesMethods
				.getNodeValue(responseNodePath);

		String textInUI = GetValueMethods.getTextValue(localdriver, wait,
				UIlocator);

		AssertionMethods.expectedActualTest(WSResponsevalue,
				textInUI);

	}
	
	
	/*
(1)Input parameters :- Field name, responseNodePath value in the form of String ,localdriver as webdriver , wait as WebDriverWait , UIlocator as By
(2)Output :-
(3)It is using RestWebservicesMethods.getNodeValue to get the node value
(4)It is using GetValueMethods.getTextValue to get the UItext value 
(5)It is using AssertionMethods.expectedActualTest to compare node value and UI text value

		 */

		public static void verifyResponseDatawithUI(String fieldName, WebDriver localdriver, WebDriverWait wait, String responseNodePath, By UIlocator, int maxWaitTime)
			{

				String WSResponsevalue = RestWebservicesMethods.getNodeValue(responseNodePath);
				String textInUI = GetValueMethods.getTextValue(localdriver, wait, UIlocator, maxWaitTime);
				AssertionMethods.expectedActualTest(fieldName, WSResponsevalue, textInUI);

			}

	/*
	 * This method verifies whether element exists or not.
	 * Input parameters :- Field name in the form of String , wait as WebDriverWait , locator as By
	 * Output :- Driver will wait for the field name until the given time using WebDriverWait method ,if element returns within the given time it will return true else returns false.
	 */
	public static boolean verifyElementExists(WebDriverWait wait, By locator) {

		WebElement testElement = null;
		try {

			testElement = wait.until(ExpectedConditions
					.visibilityOfElementLocated(locator));

			return testElement.isDisplayed();

		} catch (Exception e) {
			CommonMethods.testStepPassFlag = false;
			return false;

		}


	}

	/*
	 * This method is used to verify whether an element is visible or not
	 * Inputs: Wait, locator of the element
	 * Output: This method return the visibility of element in the form of boolean
	 * 
	 */
	public static boolean getElementInvisiblity(WebDriverWait wait, By locator) {
		boolean isElementInvisible =false;
		try {

			isElementInvisible = wait.until(ExpectedConditions
					.invisibilityOfElementLocated(locator));


		} catch (Exception e) {
			CommonMethods.testStepPassFlag =false;

		}

		return isElementInvisible;
	}

//	Verify element does not exist.
	public static void verifyElementInvisiblity(WebDriverWait wait, By locator)
		{

			try
				{

					boolean isElementInvisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
					if (!isElementInvisible)
						{
							CommonMethods.testStepPassFlag = false;
						}

				} catch (Exception e)
				{
					CommonMethods.testStepPassFlag = false;

				}

		}

	public static boolean sleepAndgetElementInvisiblity(WebDriverWait wait, By locator, int sleepTime)
	{
		boolean isElementInvisible = false;
		try
			{
				Thread.sleep(sleepTime);
				isElementInvisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));

			} catch (Exception e)
			{
				isElementInvisible = false;

			}

		return isElementInvisible;
	}
	

	public static boolean syncWaitAndgetElementInvisiblity(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime)
		{
			boolean isElementInvisible = false;
			try
				{
					Thread.sleep(alreadyWaitedTime);

					isElementInvisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));

				} catch (Exception e)
				{
					if (alreadyWaitedTime < maxWaitTime)
						{
							alreadyWaitedTime = alreadyWaitedTime + 500;
							syncWaitAndgetElementInvisiblity(localdriver, wait, locator, maxWaitTime);
						} else
						{
							isElementInvisible = false;
						}

				}
			return isElementInvisible;
		}
	
	/*
	 * This method is used to verify whether an element is present or not
	 * This method will not check the visibility of element
	 * Inputs: Wait, locator of the element
	 * Output: This method return the presence of element in the form of boolean
	 */
	public static boolean verifyElementPresence(WebDriverWait wait, By locator,
			String fieldName) {

		WebElement testElement = null;
		try {

			testElement = wait.until(ExpectedConditions
					.presenceOfElementLocated(locator));
			return testElement.isDisplayed();
		} catch (Exception e) {
			CommonMethods.testStepPassFlag = false;
			return false;

		}

	}

	/*
	 * This method compares two list of strings.
	 * Input parameters :- expectedList and actualList in the form of String List.
	 * Output :- If size of both lists is not equal it will return false else 
	 * it will compare each and every value in both the lists in sequence. If both the value matches, it will return true else false.
	 */
	public static boolean compareLists(List<String> expectedList,
			List<String> actualList) {

		if (expectedList.size() != actualList.size()) {
			System.out
			.println("Expected List size is not equal to Actual List");

			CommonMethods.testStepPassFlag = false;

			return false;

		} else {
			for (int i = 0; i < expectedList.size(); i++) {

				if (!expectedList.get(i).equals(actualList.get(i).trim())) {

					System.out.println("Expected List value["
							+ expectedList.get(i)
							+ "] is not equal to Actual List value["
							+ actualList.get(i) + "]");

					CommonMethods.testStepPassFlag = false;

					return false;

				} else {

					System.out.println("Expected List value["
							+ expectedList.get(i)
							+ "] is equal to Actual List value["
							+ actualList.get(i) + "]");

				}
			}
		}
		return true;

	}


	public static void verifyListMatchesText(String valueToMatch, List<String> listValues) {
		for(String eachValue : listValues) {
			if(!eachValue.equals(valueToMatch)){
				CommonMethods.testStepPassFlag = false;
			}
		}
	}

	public static void verifyListContainsText(String valueToContain, List<String> listValues){
		for(String eachValue : listValues) {
			if(!eachValue.contains(valueToContain)){
				CommonMethods.testStepPassFlag = false;
			}
		}

	}

	public static void verifyListStartsWithText(String valueToStartWith, List<String> listValues){
		for(String eachValue : listValues) {
			if(!eachValue.startsWith(valueToStartWith)){
				CommonMethods.testStepPassFlag = false;
			}
		}
	}
	
	
	public static void verifyListNotContainsText(String valueToContain, List<String> listValues){
		for(String eachValue : listValues) {
			if(eachValue.contains(valueToContain)){
				CommonMethods.testStepPassFlag = false;
			}
		}

	}
}
