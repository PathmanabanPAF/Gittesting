package globalBox;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverService;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;


/*
 */
public class BrowserMethods {
	public static boolean ieService1RunningFlag=false;
	public static boolean ieService2RunningFlag=false;
	public static boolean chromeServiceRunningFlag=false;//need to update for this as well - future scope
	public static boolean htmlUnitServiceRunningFlag=false;
	public static int numberOfDriverInitialized=0;

	public static WebDriver driver1;
	public static WebDriver driver2;

	public static InternetExplorerDriverService  ieDriverService1;
	public static InternetExplorerDriverService  ieDriverService2;
	public static ChromeDriverService chromeDriverService;
   
/*
 * 
  This Method is used to initialize the web browser 
  This method contains switch case statements and each case statement is assigned to various web browsers
 
  For Chrome and IE browser initial boolean value is given as false and it will run the condition in if statement. 
  i.e; it will open a new web browser using startChromeService,startIEService method which contains set property .exe file.
  next condition will come out of if statement where desired capabilities are set and extensions are disabled using initializeChromeDriver1 and initializeIEDriver1.
  
  For Firefox and PhantomJS browser desired capabilities are set and extensions are disabled using initializePhantomjsDriver1(), initializeFirefoxDriver1() ;

 */
	public static  void initializeBrowserDriver1() {
		
		    numberOfDriverInitialized=0;
			//String browserName=CommonMethods.readPropertiesFile("browser");
		    String browserName = CommonMethods.readPropertiesFile("inputdata.properties","browser");

			switch(browserName)
			{
			case "chrome" : 
				// we need to implement 
				if(chromeServiceRunningFlag==false)
				{
					startChromeService();
				}
				
					initializeChromeDriver1();
				
				
				break;
			       
			case "firefox":
				  initializeFFDriver1();
				 
				break;
			case "ie":
				if(ieService1RunningFlag==false)
				{
					startIEService1();
				}
				
					initializeIEDriver1();
				
				
				break;
			
			case "phantomjs":
				
				
				
				{
					initializePhantomjsDriver1();
				}
				
				
				
				break;
			default: //lets take ie as default
				if(ieService1RunningFlag==false)
				{
					startIEService1();
				}
				
					initializeIEDriver1();
				
				break;
			}
			  
			
	}
	/*
	 *   This method is invoked for parallel execution to open another window
	  This Method is used to initialize the web browser 
	  This method contains switch case statements and each case statement is assigned to various web browsers
	 
	  For Chrome and IE browser initial boolean value is given as false and it will run the condition in if statement. 
	  i.e; it will open a new web browser using startChromeService,startIEService method which contains set property .exe file.
	  next condition will come out of if statement where desired capabilities are set and extensions are disabled using initializeChromeDriver1 and initializeIEDriver1.
	  
	  For Firefox and PhantomJS browser desired capabilities are set and extensions are disabled using initializePhantomjsDriver1(), initializeFirefoxDriver1() ;

	 */
	
	public static  void initializeBrowserDriver2() {
		
		
		//String browserName=CommonMethods.readPropertiesFile("browser");
		String browserName = CommonMethods.readPropertiesFile("inputdata.properties","browser");

		
		switch(browserName)
		{
		case "chrome" : 
			// we need to im
			if(chromeServiceRunningFlag==false)
			{
				startChromeService();
			}
			
				initializeChromeDriver2();
			
		       break;
		case "firefox":
			initializeFFDriver2();
			break;
		case "ie":
			if(ieService2RunningFlag==false)
			{
				startIEService2();
			}
			
				initializeIEDriver2();
			
			
			break;
		
		case "phantomjs":
			
			
			
				initializePhantomjsDriver2();
			
			break;
		default: //lets take ie as default
			if(ieService2RunningFlag==false)
			{
				startIEService2();
			}
			
				initializeIEDriver2();
			
			break;
		}
		  
		
}
	/*
	 * This Method is used to set the properties for the IE browser 
If it cannot start the browser it will throw an exception and will print it in log file using ScreenshotMethods.logger

	 */
	
	public static void startIEService1()
	{
		try{
			
		
				ieDriverService1=new InternetExplorerDriverService.Builder()
		        .usingDriverExecutable(new File("src/test/resources/IEBrowserResource/IEDriverServer.exe"))
		        .usingAnyFreePort()
		        .build();
				ieDriverService1.start();
				ieService1RunningFlag=true;
		}
		catch(Exception e)
		{
			ScreenshotMethods.logger(e.toString());
			ieService1RunningFlag=false;
		}
	}
	
	public static void startIEService2()
	{
		try{
			
		
				ieDriverService2=new InternetExplorerDriverService.Builder()
		        .usingDriverExecutable(new File("src/test/resources/IEBrowserResource/IEDriverServer.exe"))
		        .usingAnyFreePort()
		        .build();
				ieDriverService2.start();
				ieService2RunningFlag=true;
		}
		catch(Exception e)
		{
			ScreenshotMethods.logger(e.toString());
			ieService2RunningFlag=false;
		}
	}
	
	/*
	 *  This Method is used to set the properties for the Chrome browser If it cannot start the browser it will throw an exception and will print it in log file using ScreenshotMethods.logger 
	 */
	public static void startChromeService()
	{
		try{
			
		
				chromeDriverService=new ChromeDriverService.Builder()
		        .usingDriverExecutable(new File("path/of/chrome/exe/file"))
		        .usingAnyFreePort()
		        .build();
				chromeDriverService.start();
				chromeServiceRunningFlag=true;
		}
		catch(Exception e)
		{
			ScreenshotMethods.logger(e.toString());
			chromeServiceRunningFlag=false;
		}
	}
	//This Method is used to initialize the firefox browser 
	public static void initializeFFDriver1()
	{
		DesiredCapabilities ffCap=DesiredCapabilities.firefox();
		
		ffCap.setCapability(CapabilityType.ACCEPT_SSL_CERTS,true);
		ffCap.setCapability(CapabilityType.ENABLE_PERSISTENT_HOVERING,true);
		ffCap.setCapability(CapabilityType.ENABLE_PROFILING_CAPABILITY,true);
		ffCap.setCapability(CapabilityType.SUPPORTS_ALERTS,true);
		ffCap.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT,true);
		ffCap.setCapability(CapabilityType.SUPPORTS_LOCATION_CONTEXT,true);
		ffCap.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,true);
		ffCap.setJavascriptEnabled(true); 
		
		driver1 = new FirefoxDriver(ffCap);
		driver1.manage().window().maximize();
		numberOfDriverInitialized++;
		WaitMethods.waitInitializatonFordriver1();
		 
		driver1= new FirefoxDriver();
	}
	//This Method is used to initialize the firefox browser 
	public static void initializeFFDriver2()
	{
		DesiredCapabilities ffCap=DesiredCapabilities.firefox();
		
		ffCap.setCapability(CapabilityType.ACCEPT_SSL_CERTS,true);
		ffCap.setCapability(CapabilityType.ENABLE_PERSISTENT_HOVERING,true);
		ffCap.setCapability(CapabilityType.ENABLE_PROFILING_CAPABILITY,true);
		ffCap.setCapability(CapabilityType.SUPPORTS_ALERTS,true);
		ffCap.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT,true);
		ffCap.setCapability(CapabilityType.SUPPORTS_LOCATION_CONTEXT,true);
		ffCap.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,true);
		ffCap.setJavascriptEnabled(true); 
		
		driver2 = new FirefoxDriver(ffCap);
		driver2.manage().window().maximize();
		numberOfDriverInitialized++;
		WaitMethods.waitInitializatonFordriver2();
		 
		driver2= new FirefoxDriver();
	}
	// This Method is used to initialize the Phantomjs browser 
	public static void initializePhantomjsDriver1()
	{
		
			
			ArrayList<String> cliArgsCap = new ArrayList<String>();
	           DesiredCapabilities capabilities = new DesiredCapabilities();

			capabilities = DesiredCapabilities.phantomjs();
         
			cliArgsCap.add("--web-security=false");
			cliArgsCap.add("--ssl-protocol=any");
			cliArgsCap.add("--ignore-ssl-errors=true");
			capabilities.setCapability("takesScreenshot", true);
			capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_CLI_ARGS, cliArgsCap);
			capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_GHOSTDRIVER_CLI_ARGS,new String[] { "--logLevel=2" });
        
			String path="src/test/resources/PhantomJSResources/phantomjs.exe";
			File file=new File(path);
			System.setProperty("phantomjs.binary.path",file.getAbsolutePath() );
			numberOfDriverInitialized++;
			driver1= new PhantomJSDriver(capabilities);
	
	}
	
	//This Method is used to initialize the Phantomjs browser 
	public static void initializePhantomjsDriver2()
	{
		
			ArrayList<String> cliArgsCap = new ArrayList<String>();
	        DesiredCapabilities capabilities = new DesiredCapabilities();
	        capabilities = DesiredCapabilities.phantomjs();
	        cliArgsCap.add("--web-security=false");
			cliArgsCap.add("--ssl-protocol=any");
			cliArgsCap.add("--ignore-ssl-errors=true");
			capabilities.setCapability("takesScreenshot", true);
			capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_CLI_ARGS, cliArgsCap);
			capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_GHOSTDRIVER_CLI_ARGS,new String[] { "--logLevel=2" });
     
			String path="src/test/resources/PhantomJSResources/phantomjs.exe";
			File file=new File(path);
			System.setProperty("phantomjs.binary.path",file.getAbsolutePath() );
			numberOfDriverInitialized++;
			driver2= new PhantomJSDriver(capabilities);
			
		
	
		
	}
	
	
	//This Method is used to initialize the IE browser 
	public static void initializeIEDriver1()
	{
		
			DesiredCapabilities ieCap = DesiredCapabilities.internetExplorer();
					
					ieCap.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING,
							false);
					ieCap.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, true);
					ieCap.setCapability(InternetExplorerDriver.UNEXPECTED_ALERT_BEHAVIOR,
							UnexpectedAlertBehaviour.DISMISS);
					ieCap.setCapability(InternetExplorerDriver.ENABLE_ELEMENT_CACHE_CLEANUP,
							true);
					ieCap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION,
							true);
					ieCap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
					ieCap.setCapability(
							InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
							true);
					ieCap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
					ieCap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
				
					ieCap.setJavascriptEnabled(true);
			
					driver1 = new InternetExplorerDriver(ieDriverService1, ieCap);
					driver1.manage().window().maximize();
					numberOfDriverInitialized++;
					WaitMethods.waitInitializatonFordriver1();
	
	}
	// This Method is used to initialize the Chrome browser 
	public static void initializeChromeDriver1()
	{
		
		//Setting chrome options
		    ChromeOptions options =new ChromeOptions();
		   
		   
		    options.addArguments("--disable-extensions");
		    options.addArguments(Arrays.asList("--start-maximized",
		    									"--test-type", 
		    									"--ignore-certificate-errors",
		    									"--disable-popup-blocking", 
		    									"--allow-running-insecure-content", 
		    									"--disable-translate", 
		    									"--always-authorize-plugins",
		    									"--disable-extensions"));
		    
		    
			DesiredCapabilities chromeCap=DesiredCapabilities.chrome();
			chromeCap.setCapability(ChromeOptions.CAPABILITY,options);
			chromeCap.setCapability(CapabilityType.ACCEPT_SSL_CERTS,true);
			chromeCap.setCapability(CapabilityType.SUPPORTS_ALERTS,true);
			chromeCap.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT,true);
			chromeCap.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,false);
			chromeCap.setJavascriptEnabled(true); 
			driver1 = new ChromeDriver(chromeDriverService,chromeCap);
			
			numberOfDriverInitialized++;
			WaitMethods.waitInitializatonFordriver1();

	}
	// This Method is used to initialize the Chrome browser 
	public static void initializeChromeDriver2()
	{
		
		//Setting chrome options
		    ChromeOptions options =new ChromeOptions();
		   
		   
		    options.addArguments("--disable-extensions");
		    options.addArguments(Arrays.asList("--start-maximized",
		    									"--test-type", 
		    									"--ignore-certificate-errors",
		    									"--disable-popup-blocking", 
		    									"--allow-running-insecure-content", 
		    									"--disable-translate", 
		    									"--always-authorize-plugins",
		    									"--disable-extensions"));
		    
		    
			DesiredCapabilities chromeCap=DesiredCapabilities.chrome();
			chromeCap.setCapability(ChromeOptions.CAPABILITY,options);
			chromeCap.setCapability(CapabilityType.ACCEPT_SSL_CERTS,true);
			chromeCap.setCapability(CapabilityType.SUPPORTS_ALERTS,true);
			chromeCap.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT,true);
			chromeCap.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,false);
			chromeCap.setJavascriptEnabled(true); 
			driver2 = new ChromeDriver(chromeDriverService,chromeCap);
			
			numberOfDriverInitialized++;
			WaitMethods.waitInitializatonFordriver2();

	}
	//This Method is used to initialize the IE browser 
	public static void initializeIEDriver2()
	{
		DesiredCapabilities ieCap = DesiredCapabilities.internetExplorer();
		
		ieCap.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING,
				false);
		ieCap.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, true);
		ieCap.setCapability(InternetExplorerDriver.UNEXPECTED_ALERT_BEHAVIOR,
				UnexpectedAlertBehaviour.DISMISS);
		ieCap.setCapability(InternetExplorerDriver.ENABLE_ELEMENT_CACHE_CLEANUP,
				true);
		ieCap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION,
				true);
		ieCap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		ieCap.setCapability(
				InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
				true);
		ieCap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		ieCap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
			
			ieCap.setJavascriptEnabled(true); 
			
			driver2 = new InternetExplorerDriver(ieDriverService2,ieCap);
			driver2.manage().window().maximize();
			numberOfDriverInitialized++;
			WaitMethods.waitInitializatonFordriver2();

	}
	
	public static void initializeHtmlUnitDriver(WebDriver driverName)
	{
		
			DesiredCapabilities htmlCap=DesiredCapabilities.htmlUnit();
			htmlCap.setCapability(HtmlUnitDriver.INVALIDSELECTIONERROR,true);
			htmlCap.setCapability(HtmlUnitDriver.INVALIDXPATHERROR,true);
		
			htmlCap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			
			htmlCap.setJavascriptEnabled(true);
		    driverName = new HtmlUnitDriver(htmlCap);
					
			driverName.manage().window().maximize();
			numberOfDriverInitialized++;
			
	}
	
	
	
	
//        This method is used to open a URL
	public static void getURL(WebDriver localdriver, String url) {
		localdriver.get(url);
	}

	public static void closeDrivers()
	{
		try
		{
		
			if(numberOfDriverInitialized>1)
			{
				
				driver2.quit();
				driver1.quit();
				
				
			}
			else{
				
				driver1.quit();
			}
			
			
			
		}
		catch(Exception e)
		{
			CommonMethods.testStepPassFlag=false;
			
		}
	}
	
}