package globalBox;

import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;

public class EncryptDecryptMethods {

	static PooledPBEStringEncryptor encryptor = null;
	static {
		encryptor = new PooledPBEStringEncryptor();
		encryptor.setPoolSize(4);
		// There are various approaches to pull this configuration via system
		// level properties.
		encryptor.setPassword("parashar");
		encryptor.setAlgorithm("PBEWITHMD5ANDDES");

	}

	public static String encrypt(String input) {
		return encryptor.encrypt(input);
	}

	public static String decrypt(String encryptedMessage) {
		return encryptor.decrypt(encryptedMessage);
	}

	public static String performEncryptDecrypt(String propertyNamePassword,
			String propertyNameEncryptDecrypt) {

		String password = CommonMethods
				.readPropertiesFile("inputdata.properties", propertyNamePassword);

		boolean encrptPassword = Boolean.parseBoolean(CommonMethods
				.readPropertiesFile("inputdata.properties", propertyNameEncryptDecrypt));

		if (encrptPassword) {

			password = EncryptDecryptMethods.decrypt(password);

		} else {

			String encryptedText = EncryptDecryptMethods.encrypt(password);

			CommonMethods.replacePropertiesFileValue(propertyNamePassword,
					encryptedText);

			CommonMethods.replacePropertiesFileValue(
					propertyNameEncryptDecrypt, "true");

		}

		return password;
	}

}
