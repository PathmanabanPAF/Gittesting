package globalBox;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;


public class CommonMethods {

	public static boolean testStepPassFlag = true;

	public static String scenarioOutputFileName="";

	public static String scenarioID="";
	public static String featureName="";
	public static String LastScenarioOutputFileName="";
	public static String TestRunnerfolderWithPath="";

	/*
	 * This method returns the current date & time as string in
	 * dd-MMM-yyyy-hh-mm-ss format.
	 */
	public static String getTimeStamp() {
		try {

			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"-dd-MMM-yyyy-hh-mm-ss");

			Date curDate = new Date();

			String dateString = dateFormat.format(curDate);

			return dateString;

		} catch (Exception e) {

			CommonMethods.testStepPassFlag = false;

			return e.toString();
		}
	}

	/*
	 * This method reads properties file and get the value of given input key
	 * from properties file. input parameters - nameOfKey from
	 * inputData.properties as a string Output - returns value of the key from
	 * inputData.properties
	 */
	public static String readPropertiesFile(String nameFile, String inputKey) {
		String value = "";
		try {

			File file = new File(nameFile);
			FileInputStream fileInput = new FileInputStream(file);

			Properties properties = new Properties();
			properties.load(fileInput);

			fileInput.close();

			value = properties.getProperty(inputKey);

			return value;

		} catch (Exception e) {

			CommonMethods.testStepPassFlag = false;

			return e.toString();

		}

	}
	public static String readPropertiesFile(String inputKey)
	{
		String value ="";
		 try{
				File file = new File("inputdata.properties");
				FileInputStream fileInput = new FileInputStream(file);
				Properties properties = new Properties();
				properties.load(fileInput);
				fileInput.close();

				//Enumeration enuKeys = properties.keys();
				//while (enuKeys.hasMoreElements()) {
					//String key = (String) enuKeys.nextElement();
					value = properties.getProperty(inputKey);
					//System.out.println(inputKey + ": " + value);
				//}
			return value;
		 } catch(Exception e)
		 {
			 
			 CommonMethods.testStepPassFlag=false;
			 return e.toString();
			 
		 }
	
	}

	/*
	 * This method is used to set the value for input key in properties file.
	 * input parameters - nameOfKey as a string and valueOfKey as a string
	 * Output - It will set the value to the provided key and save the
	 * properties file.
	 */
	public static void replacePropertiesFileValue(String inputKey,
			String inputValue) {
		try {

			PropertiesConfiguration config = new PropertiesConfiguration(
					inputValue);

			config.setProperty(inputKey, inputValue);

			config.save();

		} catch (Exception e) {

			CommonMethods.testStepPassFlag = false;

		}

	}

	/*
	 * This method is used to create a folder at given path . input parameters -
	 * path where the folder need to be created output - new folder is created
	 * at given path along with the given folder name.
	 */
	public static void createFolderAtGivenPath(
			String pathOfFolderIncludingFolderName) {

		File directory = new File(pathOfFolderIncludingFolderName);

		directory.mkdir();

	}

	/*
	 * This method is used to open a url in the requested browser using driver 1
	 * . This method uses BrowserMethods.initializeBrowserDriver1() to
	 * initialize a browser and BrowserMethods.getURL to launch the url input
	 * parameters - url to be navigated output - url is launched in the given
	 * browser using driver 1.
	 */
	public static void getUrlUsingDriver1(String applicationUrl) {

		BrowserMethods.initializeBrowserDriver1();

		BrowserMethods.getURL(BrowserMethods.driver1, applicationUrl);

	}

	/*
	 * This method should be used only when driver1 is running and we need to
	 * use another driver
	 */
	public static void getUrlUsingDriver2() {
		// This method should beused only when driver1 is running and we need to
		// use another driver
		BrowserMethods.initializeBrowserDriver2();

	}

	//For driver2 only initialization will take place.No need to pass url during initialization.
		public static void initialization(String driverName,String scenarioOutputFolderAsWellASFileName,String url)
		   {
		
		    CommonMethods.scenarioOutputFileName=scenarioOutputFolderAsWellASFileName;
			//String ExistingscenarioFolderName=ScreenshotMethods.screenshotFileName
					//getModularCopayData_Jitendra-06-Aug-2017-12-34-33
			if(driverName.equals("driver1"))
			{
	            CommonMethods.getUrlUsingDriver1(CommonMethods.readPropertiesFile(url));
			}
			else if(driverName.equals("driver2"))
			{
				BrowserMethods.initializeBrowserDriver2();
			}
			try {
				//ScreenshotMethods.initializeScreenshot();
				if(!(CommonMethods.LastScenarioOutputFileName.equals(scenarioOutputFolderAsWellASFileName)))
				{	
					ScreenshotMethods.initializeScreenshot(CommonMethods.scenarioOutputFileName+CommonMethods.getTimeStamp());
					CommonMethods.LastScenarioOutputFileName=scenarioOutputFolderAsWellASFileName;
					
				}
			} catch (Exception e) {
			  CommonMethods.testStepPassFlag=false;
			}
			
		   }
		public static void initializationForWebservices(String scenarioOutputFolderAsWellASFileName)
		   {
		
		    CommonMethods.scenarioOutputFileName=scenarioOutputFolderAsWellASFileName;
			
		  try {
			  if(!(CommonMethods.LastScenarioOutputFileName.equals(scenarioOutputFolderAsWellASFileName)))
				{	
					ScreenshotMethods.initializeScreenshot(CommonMethods.scenarioOutputFileName+CommonMethods.getTimeStamp());
					CommonMethods.LastScenarioOutputFileName=scenarioOutputFolderAsWellASFileName;
					ScreenshotMethods.logger("Initialization of resources for webservice complete.");
					
				}
				
			} catch (Exception e) {
			  CommonMethods.testStepPassFlag=false;
			  ScreenshotMethods.logger(e.toString());
			}
			
		   }
	
	//Check if required
	public static void initializeBrowser(String driverName, String url) {

		if (driverName.equals("driver1")) {
			CommonMethods.getUrlUsingDriver1(CommonMethods
					.readPropertiesFile("inputdata.properties",url));
		} else if (driverName.equals("driver2")) {
			CommonMethods.getUrlUsingDriver1(CommonMethods
					.readPropertiesFile("inputdata.properties",url));
		}
		

	}

	/*
	 * This method is used to take a screenshot for particular driver with file
	 * name as screenshotFileMessage and current time stamp and logs the file
	 * message .This method uses ScreenshotMethods.logger to get the message in
	 * log file and input parameters - driverName,cucumberReportMessage, output
	 * - screen shot is taken with name as current date an time and is saved in
	 * the given path. It will close the browsers once screenshot is taken, if
	 * it does not take any screen shot it will throw an exception error.
	 */
	public static void closure(String driverName, String cucumberReportMessage,
			String screenshotFileMessage, String stepDescription) {

		// ScreenshotMethods.logger(screenshotFileMessage);
		if (driverName.equals("driver1")) {
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", stepDescription);
		} else if (driverName.equals("driver2")) {
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver2,
					"tempJPEGFilePlaceHolder", stepDescription);
		}

		try {
			// ScreenshotMethods.finalizeScreenshotDocument(CommonMethods.scenarioOutputFileName+CommonMethods.getTimeStamp());
			ScreenshotMethods.finalizeScreenshotDocument();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BrowserMethods.closeDrivers();

	}

	public static void closeAllBrowsers() {

		BrowserMethods.closeDrivers();
	}
	/*
	 * This method is used to enter the username and password in the text box
	 * using TextBoxMethods.inputText and then submitting it using
	 * ButtonMethods.clickElement input parameters - locatorUserName,
	 * locatorPassword output - Username and Password are entered and logs into
	 * the application.
	 */
	public static void loginApplication(WebDriver localdriver,
			WebDriverWait wait, By locatorUserName, By locatorPassword,
			By locatorSubmit, String userName, String password) {

		TextBoxMethods.inputText(localdriver, wait, locatorUserName, userName);

		TextBoxMethods.inputText(localdriver, wait, locatorPassword, password);

		ClickMethods.clickElement(localdriver, wait, locatorSubmit);

	}

	public static void loginApplicationWithSync(WebDriver localdriver,
			WebDriverWait wait, By locatorUserName, By locatorPassword,
			By locatorSubmit, String userName, String password) {

		boolean encrptPassword = Boolean.parseBoolean(CommonMethods
				.readPropertiesFile("statepasswordencryption"));
		
		if (encrptPassword) {
			password = EncryptDecryptMethods.decrypt(password);
		} else {
			String encryptedText = EncryptDecryptMethods.encrypt(password);
			CommonMethods.replacePropertiesFileValue("password", encryptedText);
			CommonMethods.replacePropertiesFileValue("statepasswordencryption",
					"true");
		}
		TextBoxMethods.inputTextWithClearAndWait(localdriver, wait, locatorUserName, userName, 6000);
		TextBoxMethods.inputTextWithClearAndWait(localdriver, wait, locatorPassword, password, 6000);
		ClickMethods.clickElement(localdriver, wait, locatorSubmit,6000);

	}
	
	public static void webservicesClosure()
	{
	
		try {
				
				ScreenshotMethods.finalizeScreenshotDocument();
			} catch (Exception e) {
					// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
	
	}
	
	public static void copyFileWhenThereIsNoSuchFileInDestination(String sourceFileNameWithPath,String DestinationFileNameWithPath)
	{

		File destinationFileWithPath=new File(DestinationFileNameWithPath);
		File sourceFileWithPath=new File(sourceFileNameWithPath);
		
		if(!destinationFileWithPath.exists())//Create feature file directory
		{
			try {
				FileUtils.copyFile(sourceFileWithPath,destinationFileWithPath);
				ScreenshotMethods.logger("File is copied to: "+DestinationFileNameWithPath);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				
				CommonMethods.testStepPassFlag=false;
				ScreenshotMethods.logger("Unable to copy file at :  "+DestinationFileNameWithPath+"    Because of following exception:    "+e.toString());
			}
		}
	}
	
	
	

}
