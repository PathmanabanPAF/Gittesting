package globalBox;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TableAndPageHandlingMethods {

	
/*	Note: This class methods uses following arguments.Valid only when table contains td's inside various tr  i.e tr-->td. It will not work in the case
	 * if table has tr-->th structure.
	 * See the methods : columnTextFromAllPages  and firstFewMatchingRecordsAndExitLoop which call submethods.
	 * Arguments description in order:
	 * (1)WebDriver (2)WebDriverWait (3)By paginationBlockXpath -->xpath of pagination table. Example- paginationTable=By.xpath("//*[@id='grid-desktop-paginator']/tbody")
	 * (4)int targetTRNumberInPagination: tr number which contains all the pagination td's  example: 0
	 * (5)int targetTDNumberForMaxPage: td number of "Maximum page entry in pagination" . Expected value :any integer value starting from 0
	   (6)By searchResultTableXpath:xpath ,including tbody , for search result table.
	   (7)int targetTRNumberForCurrentPage: tr number where current page td resides. Example-> Any valid value starting from 0
	   (8)int targetTDNumberForCurrentPage: td number of "Current page" field in pagination. Expected value--> any integer valuer starting from 0
	   (9)By currentPageTextBoxLocator: locator of current page text box. Example: By.xpath(".//input")
	   (10)int tableTRStartNumberExcludingHeader:First row in the table from where , calculation would start. If we need to exclude table column header row then give 1
	                                              else give 0
	   (11)int targetTDNumber:It is the td number for particular column.Example--> Any value starting from 0. Be cautious in giving td number corresponding to a column.
	   (12)By resultTDLocator:Locator inside td element. Example:By.xpath(".//span")
	   (13)String comparisonString : String value to be used in comparison for match with column records.

	*/
	
	//Get max page number
	public static int getMaxPagenumber(WebDriver localDriver,WebDriverWait localwait,By paginationBlockXpath,int targetTRNumber ,int targetTDNumberForMaxPage)
	{
		//This method assumes that the pagination block will contain page details and buttons in first "tr", we can pass tr index using argument targetTRNumber
			
		WebElement table=localDriver.findElement(paginationBlockXpath);
		List<WebElement> trList=table.findElements(By.xpath("./tr"));
		//get all td's of requested TR
		List<WebElement> tdList=trList.get(targetTRNumber).findElements(By.xpath("./td"));
		String x=tdList.get(targetTDNumberForMaxPage).getText(); 
		return Integer.parseInt(x);
			
	}
	//Get current page number
	public static int  getCurrentPagenumber(WebDriver localDriver,WebDriverWait localwait,By paginationBlockXpath,int targetTRNumber ,int targetTDNumberforCurrentPage)
	{
			WebElement table=localDriver.findElement(paginationBlockXpath);
			List<WebElement> trList=table.findElements(By.xpath("./tr"));
			//get all td's of requested TR
			List<WebElement> tdList=trList.get(targetTRNumber).findElements(By.xpath("./td"));
			
			
		     String x=tdList.get(targetTDNumberforCurrentPage).findElement(By.xpath(".//input")).getAttribute("value");
		     return Integer.parseInt(x);
		
		
	}
	
	//navigate to next page
	public static boolean navigateToNextPage(WebDriver localDriver,WebDriverWait localwait,By paginationBlockXpath,int targetTRNumberForCurrentPage, int targetTDNumberForCurrentPage,
											By currentPageTextBoxLocator,int maxPageNumber) throws InterruptedException
	{
	int currentPageNumber=getCurrentPagenumber(localDriver,localwait,paginationBlockXpath,targetTRNumberForCurrentPage,targetTDNumberForCurrentPage);
		if(currentPageNumber<maxPageNumber)
		{
			
			WebElement table=localDriver.findElement(paginationBlockXpath);
			List<WebElement> trList=table.findElements(By.xpath("./tr"));
			//get all td's of requested TR
			List<WebElement> tdList=trList.get(targetTRNumberForCurrentPage).findElements(By.xpath("./td"));
			
			Actions action=new Actions(localDriver);
						
			WebElement pageNumberEditbox=tdList.get(targetTDNumberForCurrentPage).findElement(currentPageTextBoxLocator);
			pageNumberEditbox.clear();
			Thread.sleep(1000);
			String nextPageNumber=String.valueOf(currentPageNumber+1);
			pageNumberEditbox.sendKeys(nextPageNumber);
			action.sendKeys(Keys.TAB).sendKeys(Keys.RETURN).build().perform();
			
			WaitMethods.waitForPageLoad(BrowserMethods.driver1, WaitMethods.wait20driver1);
			return true;
		}
		else {
			System.out.println("Already at last page");
			return false;
		}
		
	}
	
  //  Update WebElement list  with matching tr's 
	public static int getAllMatchingTrsInTable(WebDriver localDriver,WebDriverWait localWait,By tableLocator,int startTRNumber,
			                                      int targetTDNumber,By locatorInTD,String comparisonString,List<WebElement> resultTRList)
    {
		WebElement table=localDriver.findElement(tableLocator);
		List<WebElement> trList=table.findElements(By.xpath("./tr"));
		//Loop for each tr
		//get all td's of requested TR
		
	   int foundItemCount=0;
		for(int i=startTRNumber;i<trList.size();i++)
		{
				List<WebElement> filterListTD=trList.get(i).findElements(By.xpath("./td"));
			
				WebElement TDElementtext=filterListTD.get(targetTDNumber).findElement(locatorInTD);
				String actualText=TDElementtext.getText();
				if(actualText.equals(comparisonString))
				{
					resultTRList.add(trList.get(i));
					foundItemCount++;
					//click on the first TD
						
				}
		
		
			
		}
		return foundItemCount;
  	  
    }
	
	 //  Update WebElement list  with matching tr's  present in current page . It verifies with multiple column search criteria
		public static int getAllMatchingTrsUsingTDComparisonTable(WebDriver localDriver,WebDriverWait localWait,By tableLocator,int startTRNumber,
				                                      By locatorInTD,List<List<String>> tdComparisonList,List<WebElement> resultTRList)
	    {
			WebElement table=localDriver.findElement(tableLocator);
			List<WebElement> trList=table.findElements(By.xpath("./tr"));
			//Loop for each tr
			//get all td's of requested TR
			
		   int foundItemCount=0;
			for(int i=startTRNumber;i<trList.size();i++)
			{
					List<WebElement> filterListTD=trList.get(i).findElements(By.xpath("./td"));
				    boolean allColumnsMatching=true;
					for(int j=0;j<tdComparisonList.size();j++)
					{
						 int targetTDNumber=Integer.parseInt(tdComparisonList.get(j).get(0));
						 String comparisonString=tdComparisonList.get(j).get(1);
								WebElement TDElementtext=filterListTD.get(targetTDNumber).findElement(locatorInTD);
								String actualText=TDElementtext.getText();
								if(actualText.equals(comparisonString))
								{
									
									continue;
									
								}
								else{allColumnsMatching=false;
									break;}
								
											
					}
					
					if(allColumnsMatching==true)
					{
						resultTRList.add(trList.get(i));
						foundItemCount++;
					}
				
			}
			return foundItemCount;
	  	  
	    }
	  //Returns list of string of column text from  single  page 
			public static List<String> getAllColumnTextInTable(WebDriver localDriver,WebDriverWait localWait,By tableLocator,int startTRNumber,
		            int targetTDNumber,By locatorInTD)
				{
						List<String> columnTextResultList = new ArrayList<String>();
						WebElement table=localDriver.findElement(tableLocator);
						List<WebElement> trList=table.findElements(By.xpath("./tr"));
						
						for(int i=startTRNumber;i<trList.size();i++)
						{
							List<WebElement> filterListTD=trList.get(i).findElements(By.xpath("./td"));
							
							WebElement TDElementtext=filterListTD.get(targetTDNumber).findElement(locatorInTD);
							String columnText=TDElementtext.getText();
							
							columnTextResultList.add(columnText);
							
						
						}
			
						return   columnTextResultList;
				}
		
	
	
	
				//get all required TR's from  current table view. exclude the header
				public static int getAllTrsInTable(WebDriver localDriver,WebDriverWait localWait,By tableLocator,int startTRNumber,
			                                       List<WebElement> resultTRList) throws InterruptedException
				{
						WebElement table=localDriver.findElement(tableLocator);
						List<WebElement> trList=table.findElements(By.xpath("./tr"));
						for (int i=0;i<startTRNumber;i++)
						{
							trList.remove(0);
							Thread.sleep(2000);
							
						}
					resultTRList.addAll(trList);
						
						return trList.size();
			
				}
				
				/*Give list of string which contains text value of a column from all the pages.
				 * 
				 * Note: This method is valid only when table contains td's inside various tr  i.e tr-->td. It will not work in the case
				 * if table has tr-->th structure.
				 * Arguments description in order:
				 * (1)WebDriver (2)WebDriverWait (3)By paginationBlockXpath -->xpath of pagination table. Example- paginationTable=By.xpath("//*[@id='grid-desktop-paginator']/tbody")
				 * (4)int targetTRNumberInPagination: tr number which contains all the pagination td's  example: 0
				 * (5)int targetTDNumberForMaxPage: td number of "Maximum page entry in pagination" . Expected value :any integer value starting from 0
				   (6)By searchResultTableXpath:xpath ,including tbody , for search result table.
				   (7)int targetTRNumberForCurrentPage: tr number where current page td resides. Example-> Any valid value starting from 0
				   (8)int targetTDNumberForCurrentPage: td number of "Current page" field in pagination. Expected value--> any integer valuer starting from 0
				   (9)By currentPageTextBoxLocator: locator of current page text box. Example: By.xpath(".//input")
				   (10)int tableTRStartNumberExcludingHeader:First row in the table from where , calculation would start. If we need to exclude table column header row then give 1
				                                              else give 0
				   (11)int targetTDNumber:It is the td number for particular column.Example--> Any value starting from 0. Be cautious in giving td number corresponding to a column.
				   (12)By resultTDLocator:Locator inside td element. Example:By.xpath(".//span")
				   (13)String comparisonString : String value to be used in comparison for match with column records.
				 * 
				 * 
				 
				*/
				
				public static List<String> columnTextFromAllPages(WebDriver localDriver,WebDriverWait localwait,
						By paginationBlockXpath,int targetTRNumberInPagination ,int targetTDNumberForMaxPage,
						By searchResultTableXpath,int targetTRNumberForCurrentPage, int targetTDNumberForCurrentPage,
						By currentPageTextBoxLocator
						,int tableTRStartNumberExcludingHeader, int targetTDNumber,By resultTDLocator)	
				 {
				 
				 int maxPageCount= TableAndPageHandlingMethods.getMaxPagenumber(localDriver, localwait, paginationBlockXpath,targetTRNumberInPagination,targetTDNumberForMaxPage);
				 List<String> resultTRList=new ArrayList<String>();
				 for (int i=1;i<=maxPageCount;i++)
				 {
					 
					 //get all matching Tr's presnet in current view of the table

					 try{
						 
					 
					 
						TableAndPageHandlingMethods.getAllColumnTextInTable(localDriver, localwait, searchResultTableXpath, 
								 tableTRStartNumberExcludingHeader,targetTDNumber, resultTDLocator);
					//navigate to next page starting from first page
						TableAndPageHandlingMethods.navigateToNextPage(localDriver,localwait, paginationBlockXpath,
							 targetTRNumberForCurrentPage, targetTDNumberForCurrentPage,currentPageTextBoxLocator, maxPageCount);
					 //wait for 3 seconds minimum and  20 seconds maximum for table content to get loaded
					 WaitMethods.waitForPegaPageLoad(WaitMethods.wait3driver1, WaitMethods.wait20driver1);
				 }catch(Exception e)
					 {
					 System.out.println(e.toString());
					 CommonMethods.testStepPassFlag=false; 
					 }
					 
					 
				 } 
				 return resultTRList;
				 }
			
			
/*		It is not required. Resultant arraylist can't be used as when we move to the last page then the reference of 
 *      previous page table elements are lost as they are no more attached to DOM.
 *      	
 * public static List<WebElement> allMatchingRecordsFromAllPages(WebDriver localDriver,WebDriverWait localwait,
					By paginationBlockXpath,int targetTRNumberInPagination ,int targetTDNumberForMaxPage,
					By searchResultTableXpath,int targetTRNumberForCurrentPage, int targetTDNumberForCurrentPage,
					By currentPageTextBoxLocator
					,int tableTRStartNumberExcludingHeader, int targetTDNumber,By resultTDLocator,String comparisonString)
					
			{
				int maxPageCount= TableAndPageHandlingMethods.getMaxPagenumber(localDriver, localwait, paginationBlockXpath,targetTRNumberInPagination,targetTDNumberForMaxPage);
				 List<WebElement> resultTRList=new ArrayList();
				 for (int i=1;i<=maxPageCount;i++)
				 {
					try{
					 //get all matching Tr's presnet in current view of the table
					 int noOfRecords=TableAndPageHandlingMethods.getAllMatchingTrsInTable(localDriver, localwait, searchResultTableXpath, 
							 tableTRStartNumberExcludingHeader,targetTDNumber, resultTDLocator,comparisonString, resultTRList);
					 //navigate to next page starting from first page
					 TableAndPageHandlingMethods.navigateToNextPage(localDriver,localwait, paginationBlockXpath,
							 targetTRNumberForCurrentPage, targetTDNumberForCurrentPage,currentPageTextBoxLocator, maxPageCount);
					 //wait for 3 seconds minimum and  20 seconds maximum for table content to get loaded
					 WaitMethods.waitForPegaPageLoad(WaitMethods.wait3driver1, WaitMethods.wait20driver1);
					 
					}catch(Exception e)
					{
						System.out.println(e.toString());
						CommonMethods.testStepPassFlag=false; 
						
					}
				 }
				 return resultTRList;
			}*/
				
				
				/*This method returns list of matching tr WebElements.It will search for matching text in specified column in all the Pages.
				 * If in a particular page, if finds match then it will STOP CHECKING and return the list of WebElement. First item, i.e item 0 of the
				 * returned list would contain the tr of first match. The required webelement can be further processed to take action like click on 
				 * td or get text of td  etc.
				 * 
				 * Note: This method is valid only when table contains td's inside various tr  i.e tr-->td. It will not work in the case
				 * if table has tr-->th structure.
				 * Arguments description in order:
				 * (1)WebDriver (2)WebDriverWait (3)By paginationBlockXpath -->xpath of pagination table. Example- paginationTable=By.xpath("//*[@id='grid-desktop-paginator']/tbody")
				 * (4)int targetTRNumberInPagination: tr number which contains all the pagination td's  example: 0
				 * (5)int targetTDNumberForMaxPage: td number of "Maximum page entry in pagination" . Expected value :any integer value starting from 0
				   (6)By searchResultTableXpath:xpath ,including tbody , for search result table.
				   (7)int targetTRNumberForCurrentPage: tr number where current page td resides. Example-> Any valid value starting from 0
				   (8)int targetTDNumberForCurrentPage: td number of "Current page" field in pagination. Expected value--> any integer valuer starting from 0
				   (9)By currentPageTextBoxLocator: locator of current page text box. Example: By.xpath(".//input")
				   (10)int tableTRStartNumberExcludingHeader:First row in the table from where , calculation would start. If we need to exclude table column header row then give 1
				                                              else give 0
				   (11)int targetTDNumber:It is the td number for particular column.Example--> Any value starting from 0. Be cautious in giving td number corresponding to a column.
				   (12)By resultTDLocator:Locator inside td element. Example:By.xpath(".//span")
				   (13)String comparisonString : String value to be used in comparison for match with column records.
				 * 
				 * 
				 
				*/
			public static List<WebElement> firstFewMatchingRecordsAndExitLoop(WebDriver localDriver,WebDriverWait localwait,
					By paginationBlockXpath,int targetTRNumberInPagination ,int targetTDNumberForMaxPage,
					By searchResultTableXpath,int targetTRNumberForCurrentPage, int targetTDNumberForCurrentPage,
					By currentPageTextBoxLocator
					,int tableTRStartNumberExcludingHeader, int targetTDNumber,By resultTDLocator,String comparisonString)	
					{
							 //get list of matching record and exit the loop
							int maxPageCount= TableAndPageHandlingMethods.getMaxPagenumber(localDriver, localwait, paginationBlockXpath,targetTRNumberInPagination,targetTDNumberForMaxPage);
							 List<WebElement> resultTRList=new ArrayList<WebElement>();
							
							 for (int i=1;i<=maxPageCount;i++)
							 {
								 try{	 
										 //get all matching Tr's presnet in current view of the table
										 int noOfRecords=TableAndPageHandlingMethods.getAllMatchingTrsInTable(localDriver, localwait, searchResultTableXpath, 
												 tableTRStartNumberExcludingHeader,targetTDNumber, resultTDLocator,comparisonString, resultTRList);
										 if(noOfRecords>0)
										 {break;}
										 //navigate to next page starting from first page
										 TableAndPageHandlingMethods.navigateToNextPage(localDriver,localwait, paginationBlockXpath,
												 targetTRNumberForCurrentPage, targetTDNumberForCurrentPage,currentPageTextBoxLocator, maxPageCount);
										 //wait for 3 seconds minimum and  20 seconds maximum for table content to get loaded
										 WaitMethods.waitForPegaPageLoad(WaitMethods.wait3driver1, WaitMethods.wait20driver1);
										 
								}catch(Exception e)
								{
									System.out.println(e.toString());
									CommonMethods.testStepPassFlag=false; 
									
								}
							 }
							 return resultTRList;
					}
			
			/*This method returns list of matching tr WebElements . Columns list with expected matching text is passed.
          * If in a particular page, if finds match then it will STOP CHECKING and return the list of WebElement. First item, i.e item 0 of the
             * returned list would contain the tr of first match. The required webelement can be further processed to take action like click on 
              * td or get text of td  etc.
             * 
              * Note: This method is valid only when table contains td's inside various tr  i.e tr-->td. It will not work in the case
             * if table has tr-->th structure.
             * Arguments description in order:
(1)WebDriver (2)WebDriverWait (3)By paginationBlockXpath -->xpath of pagination table. Example- paginationTable=By.xpath("//*[@id='grid-desktop-  paginator']/tbody")
             * (4)int targetTRNumberInPagination: tr number which contains all the pagination td's  example: 0
             * (5)int targetTDNumberForMaxPage: td number of "Maximum page entry in pagination" . Expected value :any integer value starting from 0
                (6)By searchResultTableXpath:xpath ,including tbody , for search result table.
                (7)int targetTRNumberForCurrentPage: tr number where current page td resides. Example-> Any valid value starting from 0
                (8)int targetTDNumberForCurrentPage: td number of "Current page" field in pagination. Expected value--> any integer valuer starting from 0
                (9)By currentPageTextBoxLocator: locator of current page text box. Example: By.xpath(".//input")
                (10)int tableTRStartNumberExcludingHeader:First row in the table from where , calculation would start. If we need to exclude table column header row then give 1
                                                           else give 0
                (11)By resultTDLocator:Locator inside td element. Example:By.xpath(".//span")
                (12) Two dimensional list of string.
             * 
              * Example: Given Admin user has searched for "a" assessment name "editQuestionName"
|0|Comprehensive Assessment for Diabetes|
|1|Diabetes_Comprehensive_Assessment|
|2|PegaCareTemplates|
              Get the above list in tdList:
ArrayList<ArrayList<String>> comparisonList=new ArrayList<ArrayList<String>>();
		List<List<String>> tdList=inputtdList.raw();
Pass tdList as argument to the method
             
	

*/

			
			public static List<WebElement> firstFewMatchingRecordsInMultipleColumnsAndExitLoop(WebDriver localDriver,WebDriverWait localwait,
					By paginationBlockXpath,int targetTRNumberInPagination ,int targetTDNumberForMaxPage,
					By searchResultTableXpath,int targetTRNumberForCurrentPage, int targetTDNumberForCurrentPage,
					By currentPageTextBoxLocator
					,int tableTRStartNumberExcludingHeader,By resultTDLocator,List<List<String>> comparisonTDList)	
					{
							 //get list of matching record and exit the loop
							int maxPageCount= TableAndPageHandlingMethods.getMaxPagenumber(localDriver, localwait, paginationBlockXpath,targetTRNumberInPagination,targetTDNumberForMaxPage);
							 List<WebElement> resultTRList=new ArrayList<WebElement>();
							
							 for (int i=1;i<=maxPageCount;i++)
							 {
								 try{	 
										 //get all matching Tr's presnet in current view of the table
										 int noOfRecords=TableAndPageHandlingMethods.getAllMatchingTrsUsingTDComparisonTable(localDriver, localwait, searchResultTableXpath, 
												 tableTRStartNumberExcludingHeader,resultTDLocator,comparisonTDList, resultTRList);
										 if(noOfRecords>0)
										 {break;}
										 //navigate to next page starting from first page
										 TableAndPageHandlingMethods.navigateToNextPage(localDriver,localwait, paginationBlockXpath,
												 targetTRNumberForCurrentPage, targetTDNumberForCurrentPage,currentPageTextBoxLocator, maxPageCount);
										 //wait for 3 seconds minimum and  20 seconds maximum for table content to get loaded
										 WaitMethods.waitForPegaPageLoad(WaitMethods.wait3driver1, WaitMethods.wait20driver1);
										 
								}catch(Exception e)
								{
									System.out.println(e.toString());
									CommonMethods.testStepPassFlag=false; 
									
								}
							 }
							 return resultTRList;
					}
			//This method is used to return row count of given table
			public static int getRowCount(WebDriver localDriver,WebDriverWait wait, By tableLocator)
			{
				WaitMethods.waitForElementReady(wait, tableLocator);
				WebElement table = localDriver.findElement(tableLocator);
				List<WebElement> rows = table.findElements(By.xpath("./tr"));
				return rows.size();
			}
			// This method is used to return row and column number with an cell text presented in the table
			// columnXpath = By.xpath("/td//label")
			// columnXpath = By.xpath("/td//span")
			public static String getRowColWithCellText(WebDriver localDriver, By tableLocator, String cellText, By locatorInTD, boolean useLocatorINTD)
			{
				 int row_num,col_num;	
				 String rowColNumber = null;
				 String getCellText ="";
				 row_num = 1;
				 col_num = 1;
				 int rowIncrement = 0;
				 boolean blnFlag = false;				 
				 WebElement table_element = localDriver.findElement(tableLocator);
				 List<WebElement> tr_collection = table_element.findElements(By.xpath("./tr"));
				 for(int i=0; i< tr_collection.size();i++)
				 {
					 if(rowIncrement >= 1)
					 {
						 List<WebElement> td_collection = tr_collection.get(i).findElements(By.xpath("./td"));
						 for(int j=0; j< td_collection.size(); j++)
						 {
								if(useLocatorINTD){ 
									try{
										getCellText = td_collection.get(j).findElement(locatorInTD).getText();
									   }catch(Exception e){}}
								else{ getCellText = td_collection.get(j).getText();}							 
							 if( cellText.toLowerCase().trim().equals(getCellText.trim().toLowerCase()))
							 { 
								 rowColNumber =  row_num + "|" + col_num;
								 blnFlag = true;
								 break;
							 }	
							 col_num++;
						 }
						 if (blnFlag){break;}
					 }
					 row_num++; 
					 rowIncrement++;
				 }
				return rowColNumber;
			}
			
			// This method is used to get the cell column number when you pass the column header name
			public static int getColNumber(WebDriver localDriver,WebDriverWait wait, By tableLocator, String headerName, By locatorInTD, boolean useLocatorINTD)
			{
				int col_num;
				int colNumber = 0;
				String getCellText ="";
				WaitMethods.waitForElementReady(wait, tableLocator);
				WebElement table_element = localDriver.findElement(tableLocator);
				List<WebElement> tr_collection = table_element.findElements(By.xpath("./tr"));
				List<WebElement> td_collection = tr_collection.get(0).findElements(By.xpath("./th"));
				col_num = 1;
				for(int i = 0; i< td_collection.size();i++)
				{	
					
					if(useLocatorINTD){
						try{
						getCellText  = td_collection.get(i).findElement(locatorInTD).getText();
						}catch(Exception e){}
						}
					else{ getCellText  = td_collection.get(i).getText();}
					 if( headerName.toLowerCase().trim().equals(getCellText.trim().toLowerCase()))
					 { 
						 colNumber = col_num;
						 break;
					 }						
					col_num++;
				}
				return colNumber;
			}
			
			// This method is used to get the cell text based on the row and column number 
			// By locatorID =By.xpath( "./*[text()]");
			public static String getCellText(WebDriver localDriver, By tableLocator, int rowNum,int colNum,By locatorInTD,boolean useLocatorINTD)			
			{
				String getCellTxt="";
				WebElement table_element = localDriver.findElement(tableLocator);
				List<WebElement> tr_collection = table_element.findElements(By.xpath("./tr"));
				List<WebElement> td_collection = tr_collection.get(rowNum).findElements(By.xpath("./td"));
				if (useLocatorINTD){
						try{
						WebElement td_Element = td_collection.get(colNum).findElement(locatorInTD);
						getCellTxt	= td_Element.getText();
						}
						catch(Exception e){}}
				else {	getCellTxt = td_collection.get(colNum).getText();}
				return getCellTxt;
			}
}

























