package globalBox;

import org.openqa.selenium.WebDriver;

public class AlertMethods {
	
	public static void closeAlertPopup(WebDriver localdriver){
		try{
			localdriver.switchTo().alert().accept();
		}catch(Exception e){
			
		}
	}

}
