package globalBox;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitMethods
	{
	
	public static WebDriverWait wait60driver1;
		public static WebDriverWait wait3driver1;
		public static WebDriverWait wait5driver1;
		public static WebDriverWait wait10driver1;
		public static WebDriverWait wait15driver1;
		public static WebDriverWait wait20driver1;

		public static WebDriverWait wait60driver2;
		public static WebDriverWait wait3driver2;
		public static WebDriverWait wait5driver2;
		public static WebDriverWait wait10driver2;
		public static WebDriverWait wait15driver2;
		public static WebDriverWait wait20driver2;

		public static int alreadyWaitedTime = 1000;

		public static void waitInitializatonFordriver1()
			{

				// Creation of wait instances
			    wait60driver1 = new WebDriverWait(BrowserMethods.driver1, 60);
				wait3driver1 = new WebDriverWait(BrowserMethods.driver1, 3);
				wait5driver1 = new WebDriverWait(BrowserMethods.driver1, 5);
				wait10driver1 = new WebDriverWait(BrowserMethods.driver1, 10);
				wait15driver1 = new WebDriverWait(BrowserMethods.driver1, 15);
				wait20driver1 = new WebDriverWait(BrowserMethods.driver1, 20);

			}

		public static void waitInitializatonFordriver2()
			{

				// Creation of wait instances
			    wait60driver2 = new WebDriverWait(BrowserMethods.driver2, 60);
				wait3driver2 = new WebDriverWait(BrowserMethods.driver2, 3);
				wait5driver2 = new WebDriverWait(BrowserMethods.driver2, 5);
				wait10driver2 = new WebDriverWait(BrowserMethods.driver2, 10);
				wait15driver2 = new WebDriverWait(BrowserMethods.driver2, 15);
				wait20driver2 = new WebDriverWait(BrowserMethods.driver2, 20);

			}

		/*
		 * public static void waitForElementReady(WebDriverWait wait, By
		 * locator) { try { WebElement testElement = null; try { //
		 * WaitMethods.syncWait(localdriver, wait, locator, maxWaitTime);
		 * 
		 * testElement =
		 * wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		 * 
		 * } catch (Exception e) { try { testElement =
		 * wait.until(ExpectedConditions .elementToBeClickable(locator)); }
		 * catch (Exception e1) { CommonMethods.testStepPassFlag = false;
		 * 
		 * } }
		 * 
		 * // WebElement testElement = setExplicitWait(wait, locator);
		 * 
		 * if (!testElement.isDisplayed()) { try { Thread.sleep(2000); } catch
		 * (InterruptedException e) { CommonMethods.testStepPassFlag = false;
		 * 
		 * } }
		 * 
		 * if (!testElement.isEnabled()) { try { Thread.sleep(2000); } catch
		 * (InterruptedException e) { CommonMethods.testStepPassFlag = false;
		 * 
		 * } } } catch (Exception e) { CommonMethods.testStepPassFlag = false;
		 * 
		 * }
		 * 
		 * }
		 * 
		 * public static void sleepAndWaitForElementReady(WebDriver localdriver,
		 * WebDriverWait wait, By locator, int maxWaitTime) { try {
		 * 
		 * WebElement testElement = null; try { // testElement =
		 * wait.until(ExpectedConditions.presenceOfElementLocated(locator)); //
		 * (locator)); WaitMethods.syncWait(localdriver, wait, locator,
		 * maxWaitTime); } catch (Exception e) { // try { // testElement =
		 * wait.until(ExpectedConditions // .elementToBeClickable(locator)); //
		 * } catch (Exception e1) { // CommonMethods.testStepPassFlag = false;
		 * // // } // }
		 * 
		 * // WebElement testElement = setExplicitWait(wait, locator);
		 * 
		 * if (!testElement.isDisplayed()) { WaitMethods.syncWait(localdriver,
		 * wait, locator, maxWaitTime); }
		 * 
		 * if (!testElement.isEnabled()) { WaitMethods.syncWait(localdriver,
		 * wait, locator, maxWaitTime); } } catch (Exception e) {
		 * CommonMethods.testStepPassFlag = false;
		 * 
		 * }
		 * 
		 * } public static WebElement setExplicitWait(WebDriverWait wait, By
		 * locator) { // it is a test method. dont use this WebElement
		 * testElement = wait.until(ExpectedConditions
		 * .visibilityOfElementLocated(locator));
		 * 
		 * return testElement; }
		 */
		/*
		 * This method is useful for converting String which exists in one
		 * format to a Date existing in another format Here From and To date
		 * formats can be same or different
		 */
		/*
		 * This method is useful for waiting for an element with a particular
		 * text in the element attribute("value")
		 */
		/*
		 * public static void waitForTextToBePresentInElementValue(WebDriverWait
		 * wait, By locator, String textToBePresent) {
		 * 
		 * try { wait.until(ExpectedConditions.textToBePresentInElementValue(
		 * locator, textToBePresent)); } catch (Exception e) {
		 * CommonMethods.testStepPassFlag = false; } }
		 */
		/*
		 * This method is useful for only Pega applications Call this method
		 * when we are navigating from one page to another page. This method
		 * waits until the page is loaded at the browser level
		 */
		
		public static void waitForElementReady(WebDriverWait wait, By locator) {
			try {
				WebElement testElement = null;

				try {
					testElement = wait.until(ExpectedConditions
							.visibilityOfElementLocated(locator));
		
				} catch (Exception e) {
					try {
						testElement = wait.until(ExpectedConditions
								.elementToBeClickable(locator));

					} catch (Exception e1) {
						CommonMethods.testStepPassFlag = false;

					}
				}

				// WebElement testElement = setExplicitWait(wait, locator);

				if (!testElement.isDisplayed()) {
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						CommonMethods.testStepPassFlag = false;

					}
				}

				if (!testElement.isEnabled()) {
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						CommonMethods.testStepPassFlag = false;

					}
				}

			} catch (Exception e) {
				CommonMethods.testStepPassFlag = false;

			}

		}

		public static WebElement setExplicitWait(WebDriverWait wait, By locator) {
			// it is a test method. dont use this
			WebElement testElement = wait.until(ExpectedConditions
					.visibilityOfElementLocated(locator));

			return testElement;
		}
		/*
		 * This method is useful for converting String which exists in one format to a Date existing in another format
		 * Here From and To date formats can be same or different
		 */
		/*
		 * This method is useful for waiting for an element with a particular text in the element attribute("value")
		 */
		public static void waitForTextToBePresentInElementValue(WebDriverWait wait,
				By locator, String textToBePresent) {

			try {
				wait.until(ExpectedConditions.textToBePresentInElementValue(
						locator, textToBePresent));
			} catch (Exception e) {
				CommonMethods.testStepPassFlag = false;
			}
		}

		
//		This method is used to wait till the page load is complete
		public static void waitForPageLoad(WebDriver driver, WebDriverWait wait)
			{

				ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
					public Boolean apply(WebDriver driver)
						{
							return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
						}
				};
				wait.until(pageLoadCondition);

			}




		/*
		 * public static void waitForElementReady(WebDriverWait wait, By
		 * locator) { try { WebElement testElement = null; try { //
		 * WaitMethods.syncWait(localdriver, wait, locator, maxWaitTime);
		 * 
		 * testElement =
		 * wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		 * 
		 * } catch (Exception e) { try { testElement =
		 * wait.until(ExpectedConditions .elementToBeClickable(locator)); }
		 * catch (Exception e1) { CommonMethods.testStepPassFlag = false;
		 * 
		 * } }
		 * 
		 * // WebElement testElement = setExplicitWait(wait, locator);
		 * 
		 * if (!testElement.isDisplayed()) { try { Thread.sleep(2000); } catch
		 * (InterruptedException e) { CommonMethods.testStepPassFlag = false;
		 * 
		 * } }
		 * 
		 * if (!testElement.isEnabled()) { try { Thread.sleep(2000); } catch
		 * (InterruptedException e) { CommonMethods.testStepPassFlag = false;
		 * 
		 * } } } catch (Exception e) { CommonMethods.testStepPassFlag = false;
=======
		/*
		 * This method is useful for only Pega applications Call this method
		 * when Pega specific page load icon is visible on the screen This
		 * method waits until the Pega page load icon is disappeared This method
		 * also supports when of Pega page load icon is inconsistent Example
		 * scenario, after clicking on "Submit" or "Next" button, page load icon
		 * will be displayed on the top of pega screen
		 */
		public static void waitForPegaPageLoad(WebDriverWait waitForVisibility, WebDriverWait waitForInVisibitlity)
			{
				try
					{

						waitForVisibility.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='pega_ui_load']")));
						waitForInVisibitlity.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//*[@id='pega_ui_load']")));

					} catch (Exception e)
					{
						/*
						 * waitForInVisibitlity.until(ExpectedConditions
						 * .invisibilityOfElementLocated(By
						 * .xpath("//*[@id='pega_ui_load']")));
						 */
					}
			}

		/*
		 * This method is useful when an element is not visible but present in
		 * the UI Example: Inorder to set attribute value in Calendar, we use
		 * input tag but input tag is not visible in the DOM
		 */
		/*
		 * public static void waitForElementPresence(WebDriverWait wait, By
		 * locator) { try { WebElement testElement = null; testElement =
		 * wait.until(ExpectedConditions .presenceOfElementLocated(locator));
		 * 
		 * } catch (Exception e) { CommonMethods.testStepPassFlag = false;
>>>>>>> 1adf7494d716b88857fc6cdb3067603bb7da1fe1
		 * 
		 * }
		 * 
		 * }
<<<<<<< HEAD
		 * 
		 * public static void sleepAndWaitForElementReady(WebDriver localdriver,
		 * WebDriverWait wait, By locator, int maxWaitTime) { try {
		 * 
		 * WebElement testElement = null; try { // testElement =
		 * wait.until(ExpectedConditions.presenceOfElementLocated(locator)); //
		 * (locator)); WaitMethods.syncWait(localdriver, wait, locator,
		 * maxWaitTime); } catch (Exception e) { // try { // testElement =
		 * wait.until(ExpectedConditions // .elementToBeClickable(locator)); //
		 * } catch (Exception e1) { // CommonMethods.testStepPassFlag = false;
		 * // // } // }
		 * 
		 * // WebElement testElement = setExplicitWait(wait, locator);
		 * 
		 * if (!testElement.isDisplayed()) { WaitMethods.syncWait(localdriver,
		 * wait, locator, maxWaitTime); }
		 * 
		 * if (!testElement.isEnabled()) { WaitMethods.syncWait(localdriver,
		 * wait, locator, maxWaitTime); } } catch (Exception e) {
		 * CommonMethods.testStepPassFlag = false;
		 * 
		 * }
		 * 
		 * } public static WebElement setExplicitWait(WebDriverWait wait, By
		 * locator) { // it is a test method. dont use this WebElement
		 * testElement = wait.until(ExpectedConditions
		 * .visibilityOfElementLocated(locator));
		 * 
		 * return testElement; }
		 */
		/*
		 * This method is useful for converting String which exists in one
		 * format to a Date existing in another format Here From and To date
		 * formats can be same or different
		 */
		/*
		 * This method is useful for waiting for an element with a particular
		 * text in the element attribute("value")
		 */
		/*
		 * public static void waitForTextToBePresentInElementValue(WebDriverWait
		 * wait, By locator, String textToBePresent) {
		 * 
		 * try { wait.until(ExpectedConditions.textToBePresentInElementValue(
		 * locator, textToBePresent)); } catch (Exception e) {
		 * CommonMethods.testStepPassFlag = false; } }
		 */
		/*
		 * This method is useful for only Pega applications Call this method
		 * when we are navigating from one page to another page. This method
		 * waits until the page is loaded at the browser level
		 */
		

		/*
		 * This method is useful when an element is not visible but present in
		 * the UI Example: Inorder to set attribute value in Calendar, we use
		 * input tag but input tag is not visible in the DOM
		 */
		/*
		 * public static void waitForElementPresence(WebDriverWait wait, By
		 * locator) { try { WebElement testElement = null; testElement =
		 * wait.until(ExpectedConditions .presenceOfElementLocated(locator));
		 * 
		 * } catch (Exception e) { CommonMethods.testStepPassFlag = false;
		 * 
		 * }
		 * 
		 * }
		 */

	
	/*
	 * This method is useful when an element is not visible but present in the UI
	 * Example: Inorder to set attribute value in Calendar, we use input tag but input tag is not visible in the DOM
	 */
	/*public static void waitForElementPresence(WebDriverWait wait, By locator) {
		try {
			WebElement testElement = null;
			testElement = wait.until(ExpectedConditions
					.presenceOfElementLocated(locator));

		} catch (Exception e) {
			CommonMethods.testStepPassFlag = false;

		}

	}*/
	
		public static void waitForElementPresence(WebDriverWait wait, By locator) {
			try {

				 wait.until(ExpectedConditions
						.presenceOfElementLocated(locator));


			} catch (Exception e) {
				CommonMethods.testStepPassFlag = false;

			}

		}
		

		public static void waitForElementInvisibility(WebDriverWait wait, By locator) {
			try {

				 wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));

			} catch (Exception e) {
				CommonMethods.testStepPassFlag = false;

			}

		}
		 
//		This method is used to check for presence of element repeatedly after waiting for short interval of time till the total wait time exceeds the maxWaitTime 
		public static void syncAndCheckForPresenceOfElement(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime)
			{
				try
					{
						Thread.sleep(alreadyWaitedTime);
						// WebElement testElement = null;
						wait.until(ExpectedConditions.presenceOfElementLocated(locator));

					} catch (Exception e)
					{
						if (alreadyWaitedTime < maxWaitTime)
							{
								alreadyWaitedTime = alreadyWaitedTime + 100;
								syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
							} else
							{

								CommonMethods.testStepPassFlag = false;

							}

					}

			}

//		This method is used to verify element is clickable repeatedly after waiting for short interval of time till the total wait time exceeds the maxWaitTime 
		public static void syncAndCheckForElementClickable(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime)
			{
				try
					{
						Thread.sleep(alreadyWaitedTime);
						// WebElement testElement = null;
						wait.until(ExpectedConditions.elementToBeClickable(locator));

					} catch (Exception e)
					{
						if (alreadyWaitedTime < maxWaitTime)
							{
								alreadyWaitedTime = alreadyWaitedTime + 100;
								syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
							} else
							{

								CommonMethods.testStepPassFlag = false;

							}

					}

			}

//		This method is used to verify element is visible repeatedly after waiting for short interval of time till the total wait time exceeds the maxWaitTime 
		public static void syncAndCheckForElementVisibility(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime)
			{
				try
					{
						Thread.sleep(alreadyWaitedTime);
						// WebElement testElement = null;
						wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

					} catch (Exception e)
					{
						if (alreadyWaitedTime < maxWaitTime)
							{
								alreadyWaitedTime = alreadyWaitedTime + 100;
								syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
							} else
							{

								CommonMethods.testStepPassFlag = false;

							}
					}
			}

//		This method is used to verify element has some text repeatedly after waiting for short interval of time till the total wait time exceeds the maxWaitTime 
		public static void syncAndCheckForTextToBePresentInElementValue(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime, String textToBePresent)
			{
				try
					{
						Thread.sleep(alreadyWaitedTime);
						// WebElement testElement = null;
						wait.until(ExpectedConditions.textToBePresentInElementValue(locator, textToBePresent));

					} catch (Exception e)
					{
						if (alreadyWaitedTime < maxWaitTime)
							{
								alreadyWaitedTime = alreadyWaitedTime + 100;
								syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
							} else
							{

								CommonMethods.testStepPassFlag = false;
							}

					}
			}
		
//		This method is used to verify element is displayed repeatedly after waiting for short interval of time till the total wait time exceeds the maxWaitTime 
		public static void syncAndCheckForElementDisplayed(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime)
			{
				try
					{
						Thread.sleep(alreadyWaitedTime);
						// WebElement testElement = null;
						wait.until(ExpectedConditions.presenceOfElementLocated(locator));
						if (BrowserMethods.driver1.findElement(locator).isDisplayed())
							{
								System.out.println("Element is displayed");
							} else
							{
								if (alreadyWaitedTime >= maxWaitTime)

									{
										CommonMethods.testStepPassFlag = false;

									} else
									{
										alreadyWaitedTime = alreadyWaitedTime + 100;
										syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
									}
							}
					} catch (Exception e)
					{
						if (alreadyWaitedTime < maxWaitTime)
							{
								alreadyWaitedTime = alreadyWaitedTime + 100;

								syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);

							} else
							{
								CommonMethods.testStepPassFlag = false;

							}

					}
			}
		
//		This method is used to verify element is enabled repeatedly after waiting for short interval of time till the total wait time exceeds the maxWaitTime 
		public static void syncAndCheckForElementEnabled(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime)
			{
				try
					{
						Thread.sleep(alreadyWaitedTime);
						// WebElement testElement = null;
						wait.until(ExpectedConditions.presenceOfElementLocated(locator));

						if (BrowserMethods.driver1.findElement(locator).isEnabled())
							{
								System.out.println("Element is Enabled");
							} else
							{
								if (alreadyWaitedTime >= maxWaitTime)

									{
										CommonMethods.testStepPassFlag = false;

									} else
									{
										alreadyWaitedTime = alreadyWaitedTime + 100;
										syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
									}

							}
					} catch (Exception e)
					{
						if (alreadyWaitedTime < maxWaitTime)
							{
								alreadyWaitedTime = alreadyWaitedTime + 100;

								syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);

							} else
							{

								CommonMethods.testStepPassFlag = false;

							}

					}

			}

	}
