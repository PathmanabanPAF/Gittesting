package globalBox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CountMethods {
	
	public static int getElementsNumber(WebDriver localdriver, WebDriverWait wait, By locator) 
	{
		int sizeElements=0;
		try {
			WaitMethods.waitForElementReady(wait,locator);
			sizeElements = localdriver.findElements(locator).size();
			return sizeElements;
		} catch(Exception ex){
			System.out.println(ex);
			return sizeElements;
		}
		
	}
	
	public static int getNumberOfWebElementsWithoutFailure(WebDriver localdriver, WebDriverWait wait, By locator) 
	{
		int sizeElements=0;
		try {
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(locator));
			sizeElements = localdriver.findElements(locator).size();
			return sizeElements;
		} catch(Exception ex){
			System.out.println(ex);
			return sizeElements;
		}
		
	}
}
