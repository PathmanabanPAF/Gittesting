package globalBox;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class KeyboardActions {

	public static void performTabAction(WebDriver localdriver, WebDriverWait wait, By locator) throws InterruptedException 
	{		
		int attempts = 0;
		while(attempts < 5) {
			try 
			{
				WaitMethods.waitForElementPresence(wait,locator);
				localdriver.findElement(locator).sendKeys(Keys.TAB);
				break;
			} catch(StaleElementReferenceException e) {
			}
			attempts++;
		}
	}


	public static void performMultipleTabs(WebDriver localdriver, WebDriverWait wait, By locator,int numberOfTabs) throws InterruptedException 
	{	
		int attempts = 0;
		while(attempts < 5) {

			localdriver.findElement(locator).sendKeys(Keys.TAB);
			attempts++;
		}
	}
	
    public static void performArrowUp(WebDriver localdriver, WebDriverWait wait, By locator) throws InterruptedException 
    {            
        int attempts = 0;
        while(attempts < 5) 
        {
               try 
               {
                     WaitMethods.waitForElementPresence(wait,locator);
                     localdriver.findElement(locator).sendKeys(Keys.ARROW_UP);
                     break;
               } catch(StaleElementReferenceException e) {
               }
               attempts++;
        }
    }
 
    public static void performArrowDown(WebDriver localdriver, WebDriverWait wait, By locator) throws InterruptedException 
    {            
        int attempts = 0;
        while(attempts < 5)
        {
               try 
               {
                     WaitMethods.waitForElementPresence(wait,locator);
                     localdriver.findElement(locator).sendKeys(Keys.ARROW_DOWN);                     
                     break;
               } catch(StaleElementReferenceException e) {
               }
               attempts++;
        }
    }
    public static void performNumPad0(WebDriver localdriver, WebDriverWait wait, By locator) throws InterruptedException 
    {            
        int attempts = 0;
        while(attempts < 5)
        {
               try 
               {
                     WaitMethods.waitForElementPresence(wait,locator);
                     localdriver.findElement(locator).sendKeys(Keys.NUMPAD0);                     
                     break;
               } catch(StaleElementReferenceException e) {
               }
               attempts++;
        }
    }	
    public static void performNumPad1(WebDriver localdriver, WebDriverWait wait, By locator) throws InterruptedException 
    {            
        int attempts = 0;
        while(attempts < 5)
        {
               try 
               {
                     WaitMethods.waitForElementPresence(wait,locator);
                     localdriver.findElement(locator).sendKeys(Keys.NUMPAD1);                     
                     break;
               } catch(StaleElementReferenceException e) {
               }
               attempts++;
        }
    }	
    public static void performNumPad2(WebDriver localdriver, WebDriverWait wait, By locator) throws InterruptedException 
    {            
        int attempts = 0;
        while(attempts < 5)
        {
               try 
               {
                     WaitMethods.waitForElementPresence(wait,locator);
                     localdriver.findElement(locator).sendKeys(Keys.NUMPAD2);                     
                     break;
               } catch(StaleElementReferenceException e) {
               }
               attempts++;
        }
    }	
}
