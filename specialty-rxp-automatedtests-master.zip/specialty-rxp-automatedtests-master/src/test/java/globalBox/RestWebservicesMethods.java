package globalBox;

import static io.restassured.RestAssured.*;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

import com.jayway.restassured.path.json.JsonPath;

public class RestWebservicesMethods {
	public static Response resJSON;
	public static Response resXML;
	public static JsonPath jsonpath;

	

	/*
	 * This method is used to send REST POST request in xml form. Input-- A
	 * saved xml request file. Entire xml is posted in request
	 */
	public static void PostXML(String url1, String nameFile, String nameHeader,
			String valueHeader) {
		try {

			String myRequest = GenerateStringFromResource("src/test/resources/inputXML/"
					+ nameFile + ".xml");

			resXML = given().contentType("application/xml")
															
					.relaxedHTTPSValidation()
					
					.header(nameHeader, valueHeader)
					.body(myRequest).when()
					.get(url1).peek();

		} catch (Exception e) {
			CommonMethods.testStepPassFlag = false;
		}

	}
	
	public static void PostXMLWithCredenials(String url1, String nameFile, String nameHeader,
			String valueHeader,String userName,String password) {
		try {
			// String url1="https://soaqa.medco.com:11056/order/detail/get";
			String myRequest = "";

			// myRequest =
			// GenerateStringFromResource("/CICDAutomation/src/test/resources/jresources/test.xml");
			myRequest = GenerateStringFromResource("src/test/resources/inputXML/"
					+ nameFile + ".xml");

			resXML = given().contentType("application/xml")// This line is for
															// sending request
															// in xml form
					.auth().basic(userName, password)
					.relaxedHTTPSValidation()// .keyStore(new File
												// ("C:/Program Files/Java/jdk1.8.0_121/jre/lib/security/esi/ssl"),
												// "changeit")
					// Above line is used to ignore all SSL client/server
					// certification exceptions
					// .header("Authorization","Basic V0VCRFFBOlViYUBSaFNoUQ==")
					.header(nameHeader, valueHeader)// Check header value in
													// header section of SOAP
													// UI.
					.body(myRequest).when()
					// .post(url1).andReturn().asString();
					.post(url1).peek();

	
			
		} catch (Exception e) {
			CommonMethods.testStepPassFlag = false;
		}

	}

	public static void PostXMLWithCredenialsWithoutHeaders(String url1, String nameFile, String userName,String password) {
		try {
			// String url1="https://soaqa.medco.com:11056/order/detail/get";
			String myRequest = "";

			// myRequest =
			// GenerateStringFromResource("/CICDAutomation/src/test/resources/jresources/test.xml");
			myRequest = GenerateStringFromResource("src/test/resources/inputXML/"
					+ nameFile + ".xml");

			resXML = given().contentType("application/xml")// This line is for
															// sending request
															// in xml form
					.auth().basic(userName, password)
					.relaxedHTTPSValidation()// .keyStore(new File
												// ("C:/Program Files/Java/jdk1.8.0_121/jre/lib/security/esi/ssl"),
												// "changeit")
					// Above line is used to ignore all SSL client/server
					// certification exceptions
					// .header("Authorization","Basic V0VCRFFBOlViYUBSaFNoUQ==")
					//.header(nameHeader, valueHeader)// Check header value in
													// header section of SOAP
													// UI.
					.body(myRequest).when()
					// .post(url1).andReturn().asString();
					.post(url1).peek();

	
			
		} catch (Exception e) {
			CommonMethods.testStepPassFlag = false;
		}

	}

	public static String getNodeValue(String xpathNode) {

		XmlPath xmlPath = resXML.xmlPath();
		String valueNode = xmlPath.getString(xpathNode);
		return valueNode;

	}

	public static int getNodesCount(String xpathNode) {

		XmlPath xmlPath = resXML.xmlPath();

		int totalItems = xmlPath.getList(xpathNode).size();

		return totalItems;

	}

	public static String GenerateStringFromResource(String path)
			throws IOException {

		return new String(Files.readAllBytes(Paths.get(path)));

	}

	/* 
	 * This method is used to invoke Rest Web service and get response in JSON format.
	 * Request need to pass in JSON format
	 * The request JSON content need to be placed in .txt file in the location(src/test/resources/inputJSON)
	 * Pass the .txt file name as parameter to this method
	 * Pass URI, header key, header value of web service as parameters
	 */
	public static void  PostJSON(String url1, String headerKey,
			String headerValue,
			String nameFile) throws IOException {
		
		String myRequest = GenerateStringFromResource("src/test/resources/inputXML/"
				+ nameFile + ".txt");
		
		resJSON = given()
				.contentType(ContentType.JSON)
				.body(myRequest)
				.relaxedHTTPSValidation()
				.keyStore(
						new File(
								"C:/Program Files/Java/jdk1.8.0_121/jre/lib/security/esi/ssl"),
						"changeit").header(headerKey, headerValue).when()
				.post(url1).peek();

	}

	// GET JSON Methods
	public static Response responseGetJson;

	/* 
	 * This method is useful to call the GETJson Web Service
	 * This need to be called only once and get use getNodeValueGetJson method any number of times
	 * Pass Uri and header information
	 * Create Map<String, String> parameters with parameter values
	 * Map<String, String> parameters = new HashMap<String, String>();
		 parameters.put("patient", "11176828");
		 parameters.put("address", "10");
     * Then pass 'parameters' as an argument to callGetJson method
	 */
	public static void callGetJson(String urlGetJson, String nameHeader, String valueHeader, Map<String, String>  parameters) {

		responseGetJson = given()
				.header(nameHeader, valueHeader).pathParams(parameters)
				.relaxedHTTPSValidation()
				.keyStore(
						new File(
								"C:/Program Files/Java/jdk1.8.0_121/jre/lib/security/esi/ssl"),
						"changeit")
						.header("accept", "application/json")
						.contentType(ContentType.JSON).get(urlGetJson).peek();

	}

	/* 
	 * This method is useful to get the particular node value in the JSON response
	 * Pass the Node path of the JSON response
	 */
	public static String getNodeValueGetJson(String nodePath){
		String initialString=JsonPath.from(responseGetJson.getBody().asString()).getString(nodePath);
		
		initialString=initialString.replaceAll("\\[",""); 
		
	    String finalString= initialString.replaceAll("\\]",""); 
		return finalString;
	}
	
	/* 
	 * This method is useful to get the number of particular node available in the JSON response
	 * Pass the Node path of the JSON response
	 */
	public static int getCountGetJsonNodes(String nodePath) {
		
		return  JsonPath.from(responseGetJson.getBody().asString()).getList(nodePath).size();
		
	}

	
	// GET XML Methods
	public static Response responseGetXml;
	
	public static void callGetXML(String url1, String Header, String HeaderValue, Map<String, String>  parameters) {
	
		responseGetXml = given()
				.header(Header, HeaderValue).params(parameters)
				.relaxedHTTPSValidation()
				.keyStore(
						new File(
								"C:/Program Files/Java/jdk1.8.0_121/jre/lib/security/esi/ssl"),
						"changeit").header("accept", "application/xml")
                .contentType(ContentType.XML).when()
				.get(url1).peek();

	}

	public static String getNodeValueGetXml(String xpathNode) {

		XmlPath xmlPath = responseGetXml.xmlPath();
		String valueNode = xmlPath.getString(xpathNode);
		return valueNode;

	}

	public static int getNodesCountGetXml(String xpathNode) {

		XmlPath xmlPath = responseGetXml.xmlPath();

		int totalItems = xmlPath.getList(xpathNode).size();

		return totalItems;

	}
}
