package globalBox;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DropdownMethods {

	public static void selectValueByValueFromDropdown(WebDriver localdriver,WebDriverWait wait, By loctaor, String textValue) 
	{

		WaitMethods.waitForElementReady(wait,loctaor);
		Select selectbox = new Select(localdriver.findElement(loctaor));
		selectbox.selectByVisibleText(textValue);

	}

	public static String getSelectedValueFromDropdown(WebDriver localdriver,WebDriverWait wait, By loctaor) 
	{

		WaitMethods.waitForElementReady(wait,loctaor);
		Select selectbox = new Select(localdriver.findElement(loctaor));
		return selectbox.getFirstSelectedOption().getText();		
	}	

	public static List<String> getListDropdownValues(WebDriver localdriver,WebDriverWait wait, By loctaor) 
	{
		List<String> listDropdownOptions = new ArrayList<String>();

		WaitMethods.waitForElementReady(wait,loctaor);
		Select selectbox = new Select(localdriver.findElement(loctaor));
		List<WebElement> listWebElements = selectbox.getOptions();

		for(WebElement element:listWebElements){
			listDropdownOptions.add(element.getText());
		}
		return listDropdownOptions;

	}

	/*This method is used to select a value from the drop down list by visible text in the list 
	(2)input parameters - localdriver as WebDriver ,wait as WebDriverWait , textValue as String 
	(3)output - It selects the value from the drop down list.
*/
	public static void selectValueByValueFromDropdown(WebDriver localdriver, WebDriverWait wait, By locator, String textValue, int maxWaitTime)
		{

			// WaitMethods.waitForElementReady(wait,loctaor);
			WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
			Select selectbox = new Select(localdriver.findElement(locator));
			selectbox.selectByVisibleText(textValue);

		}

	//This method is used to get the value of first selected option in dropdown
	public static String getSelectedValueFromDropdown(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime)
		{

			// WaitMethods.waitForElementReady(wait,loctaor);
			WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);
			Select selectbox = new Select(localdriver.findElement(locator));
			return selectbox.getFirstSelectedOption().getText();
		}

/*		This method is used to get all the available values from the drop down list 
	It stores the values from drop down list in a string list using listDropdownOptions
	(2)input parameters - local driver as WebDriver ,wait as WebDriverWait  
	(3)output - It returns drop down values in a list
*/
	public static List<String> getListDropdownValues(WebDriver localdriver, WebDriverWait wait, By locator, int maxWaitTime)
		{
			List<String> listDropdownOptions = new ArrayList<String>();

			// WaitMethods.waitForElementReady(wait,loctaor);
			WaitMethods.syncAndCheckForPresenceOfElement(localdriver, wait, locator, maxWaitTime);

			Select selectbox = new Select(localdriver.findElement(locator));

			List<WebElement> listWebElements = selectbox.getOptions();

			for (WebElement element : listWebElements)
				{
					listDropdownOptions.add(element.getText());
				}
			return listDropdownOptions;

		}


	public static void retryingSelectValueFromDropdown(WebDriver localdriver,WebDriverWait wait, By loctaor, String textValue) {
	
		int attempts = 0;
		while(attempts < 5) {
			try {
				WaitMethods.waitForElementReady(wait,loctaor);
				Select selectbox = new Select(localdriver.findElement(loctaor));
				selectbox.selectByVisibleText(textValue);
				break;
			} catch(StaleElementReferenceException e) {
			}
			attempts++;
		}

	}


}
