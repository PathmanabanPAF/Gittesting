package globalBox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HoveringMethods {

	
	public static void hoverOnElementAndClickOtherElement(WebDriver localdriver, WebDriverWait wait, By locatorToHover, By locatorToClick) throws InterruptedException {
		
		WaitMethods.waitForElementReady(wait,locatorToHover);
		
		Actions builder = new Actions(localdriver);
		
		WebElement elementToHover = wait.until(ExpectedConditions
				.visibilityOfElementLocated(locatorToHover));
		
		builder.moveToElement(elementToHover).build().perform();
		
		builder.moveToElement(wait.until(ExpectedConditions
				.visibilityOfElementLocated(locatorToClick))).build().perform();
		
		builder.click().build().perform();

	}
	
	
	public static void hoverOnElement(WebDriver localdriver, WebDriverWait wait, By locatorToHover) throws InterruptedException 
	{
			
			WaitMethods.waitForElementReady(wait,locatorToHover);
			
			Actions builder = new Actions(localdriver);
			
			WebElement elementToHover = wait.until(ExpectedConditions
					.visibilityOfElementLocated(locatorToHover));
			
			builder.moveToElement(elementToHover).build().perform();
	
	}
	public static void hoverAndClickOnElement(WebDriver localdriver, WebDriverWait wait, By locatorToHover) throws InterruptedException 
	{
		
		WaitMethods.waitForElementReady(wait,locatorToHover);
		
		Actions builder = new Actions(localdriver);
		
		WebElement elementToHover = wait.until(ExpectedConditions
				.visibilityOfElementLocated(locatorToHover));
		
		builder.moveToElement(elementToHover).build().perform();
		builder.moveToElement(elementToHover).click();
	}
}
