package stepDefinitionBox;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.GetValueMethods;
import globalBox.RandomFunctions;
import globalBox.SOAPWS;
import globalBox.ScreenshotMethods;
import globalBox.SpreadSheetMethods;
import globalBox.WaitMethods;
import globalBox.SOAPWebServicesAndWorkbookTalking;
import globalBox.XmlHandlingMethods;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

public class SOAPStepDef {

	// It gets feature file name and scenario name
	@Before
	public void before(Scenario scenario) {

		CommonMethods.scenarioID = scenario.getId().toString();
		List<String> extractedList = Arrays.asList(CommonMethods.scenarioID
				.split(";"));
		CommonMethods.featureName = extractedList.get(0);

	}

	@Given("^SOAP-Update request XML file with the node data specified in input excel file  ----> Result output folder and screenshot file name is \"(.*?)\"$")
	public void soap_Update_request_XML_file_with_the_node_data_specified_in_input_excel_file_Result_output_folder_and_screenshot_file_name_is(
			String fileAndFolderName, DataTable listFromStep) throws Throwable {

		// *****************Folder creation and initialization for
		// Webservices*******************
		// Create a separate folder to place all the scenario related
		// resources***************************************************
		CommonMethods.testStepPassFlag = true;
		CommonMethods.initializationForWebservices(fileAndFolderName);

		// ************************************************************************************************************************

		List<String> extractedList;
		List<List<String>> stepList = listFromStep.raw();

		try {

			// get different tags from the feature file
			SOAPWebServicesAndWorkbookTalking.Set1getTagsFromFeatureFile(
					listFromStep, 0, 1, 2, 5, 6, 3, 4, 8, 9);
			List<List<Integer>> rowColListForAGivenText;

			ScreenshotMethods.logger("Collected different tags from feature file scenario");
			// *************copy input excel file to output
			// folder********************
			String destinationFileWithPath = ScreenshotMethods.scenarioDirectoryPath
					+ "/" + SOAPWS.inputWorkbookName;
			String sourceFileWithPath = SOAPWS.inputWorkbookPath + "/"
					+ SOAPWS.inputWorkbookName;
			CommonMethods.copyFileWhenThereIsNoSuchFileInDestination(
					sourceFileWithPath, destinationFileWithPath);
			ScreenshotMethods.logger("Destination folder is:  "+ScreenshotMethods.scenarioDirectoryPath);
			ScreenshotMethods.logger("Copied input data excel file to "+ScreenshotMethods.scenarioDirectoryPath
					+ "/" + SOAPWS.inputWorkbookName );
			// Set the path of inputWorkbookPath1
			// ************IMPORTANT********************************************
			SOAPWS.inputWorkbookPath = ScreenshotMethods.scenarioDirectoryPath;
			
			ScreenshotMethods.logger("SOAPWS.inputWorkbookPath path is updated to output result folder:  "+ScreenshotMethods.scenarioDirectoryPath);
			
			// ******************Request data
			// collection***************************************************
			int requestNodeListColNumber = 0;
			int requestDataStartRowNumber = -999;

			requestDataStartRowNumber = SOAPWebServicesAndWorkbookTalking
					.getRequestDataStartRowNumber(SOAPWS.inputWorkbookPath,
							SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
							SOAPWS.RequestDataStartTag);
			ScreenshotMethods.logger("Request data start row number:  "+requestDataStartRowNumber);
			
			int requestDataEndRowNumber = -999;
			requestDataEndRowNumber = SOAPWebServicesAndWorkbookTalking
					.getRequestDataEndRowNumber(SOAPWS.inputWorkbookPath,
							SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
							SOAPWS.RequestDataEndTag);
			ScreenshotMethods.logger("Request data end row number:  "+requestDataEndRowNumber);
			int XPATHColNumber = -999;
			XPATHColNumber = SOAPWebServicesAndWorkbookTalking
					.getRequestDataColNumber(SOAPWS.inputWorkbookPath,
							SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
							SOAPWS.XPathColTag);
			ScreenshotMethods.logger("Request data XML Path column number:  "+XPATHColNumber);
			
			
			int requstXMLInputDataColNumber = -999;

			requstXMLInputDataColNumber = SOAPWebServicesAndWorkbookTalking
					.getRequestDataColNumber(SOAPWS.inputWorkbookPath,
							SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
							SOAPWS.FirstTargetColTag);
			ScreenshotMethods.logger("Column number which will be filled in request xml nodes in input data exchel file"+requstXMLInputDataColNumber);
			
			SOAPWS.requestNodeList = SpreadSheetMethods
					.getAllCellValuesForAColInGivenVerticalRange(
							SOAPWS.inputWorkbookPath, SOAPWS.inputWorkbookName,
							SOAPWS.targetSheetName, requestNodeListColNumber,
							requestDataStartRowNumber, requestDataEndRowNumber);
			ScreenshotMethods.logger("Node list in input data excel file:  "+SOAPWS.requestNodeList);

			SOAPWS.requestNodeXpath = SpreadSheetMethods
					.getAllCellValuesForAColInGivenVerticalRange(
							SOAPWS.inputWorkbookPath, SOAPWS.inputWorkbookName,
							SOAPWS.targetSheetName, XPATHColNumber,
							requestDataStartRowNumber, requestDataEndRowNumber);
			ScreenshotMethods.logger("XMLpath list in input data excel file:  "+SOAPWS.requestNodeXpath);
			SOAPWS.requestNodeDataSet = SpreadSheetMethods
					.getAllCellValuesForAColInGivenVerticalRange(
							SOAPWS.inputWorkbookPath, SOAPWS.inputWorkbookName,
							SOAPWS.targetSheetName,
							requstXMLInputDataColNumber,
							requestDataStartRowNumber, requestDataEndRowNumber);
			ScreenshotMethods.logger("Request Node value list in input data excel file:  "+SOAPWS.requestNodeDataSet);

			int configStartIndex = -999;

			configStartIndex = SOAPWebServicesAndWorkbookTalking
					.getRequestDataStartRowNumber(SOAPWS.inputWorkbookPath,
							SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
							SOAPWS.configStart);
			ScreenshotMethods.logger("Start index of configuration Tag in input data excel file:  "+configStartIndex);
			int configEndIndex = -999;

			configEndIndex = SOAPWebServicesAndWorkbookTalking
					.getRequestDataEndRowNumber(SOAPWS.inputWorkbookPath,
							SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
							SOAPWS.configEnd);
			ScreenshotMethods.logger("End index of configuration Tag in input data excel file:  "+configEndIndex);

			// ******************************Request data collection
			// ends***************************

			// Get configuration details******************
			// Get request configuration information from input
			// workbook*******************
			// WebService configuration details search tags from scenario
			// step************

			SOAPWS.wsConfigurationList.clear();
			SOAPWebServicesAndWorkbookTalking
					.SET1setWebServicesConfigurationDetails(listFromStep, 7,
							SOAPWS.wsConfigurationList,
							SOAPWS.inputWorkbookPath, SOAPWS.inputWorkbookName,
							SOAPWS.targetSheetName, 0, 1, configStartIndex,
							configEndIndex);
			// *************copy request XML file to output
			// folder********************
			String dest = ScreenshotMethods.scenarioDirectoryPath + "/"
					+ SOAPWS.RequestFileName;
			String src = SOAPWS.RequestFilePath + "/" + SOAPWS.RequestFileName;
			CommonMethods.copyFileWhenThereIsNoSuchFileInDestination(src, dest);
			

			// *********************************************************************

			// update request xml with the required values mentioned in input

			SOAPWebServicesAndWorkbookTalking.updateXML(
					SOAPWS.requestNodeXpath, SOAPWS.requestNodeDataSet,
					SOAPWS.RequestFilePath, SOAPWS.RequestFileName);

			if (CommonMethods.testStepPassFlag == false) {

				ScreenshotMethods.logger("This step failed as the testStepPassFlag is false");
				CommonMethods.webservicesClosure();
				Assert.fail("TestStepPassFlag  is false");
			}
		} catch (Exception e) {

			ScreenshotMethods.logger("Unable to proceed due to the below exception.Please check...  "+e.toString());
			CommonMethods.webservicesClosure();
			
			Assert.fail(e.toString());

		}

	}

	@Given("^SOAP-Invoke WebService and save the response file$")
	public void soap_Invoke_WebService_and_save_the_response_file()
			throws Throwable {

		try {
			CommonMethods.testStepPassFlag = true;

			String responseSaveDestination = ScreenshotMethods.scenarioDirectoryPath
					+ "/" + SOAPWS.ResponseFileName;

			String strRequestXMLNameAndPath = SOAPWS.RequestFilePath + "/"
					+ SOAPWS.RequestFileName;

			SOAPWS.soapWSRequest(strRequestXMLNameAndPath,
					SOAPWS.WebServicesURI, SOAPWS.ContentType, SOAPWS.UserName,
					SOAPWS.Password, SOAPWS.HeaderName, SOAPWS.HeaderValue,
					responseSaveDestination);

			//ScreenshotMethods.logger("All done......");
			if (CommonMethods.testStepPassFlag == false) {

				ScreenshotMethods.logger("This step failed as the testStepPassFlag is false");
				CommonMethods.webservicesClosure();
				Assert.fail("TestStepPassFlag  is false");
			}
		} catch (Exception e) {

			ScreenshotMethods.logger("Unable to proceed due to the below exception.Please check...  "+e.toString());
			CommonMethods.webservicesClosure();
			
			Assert.fail(e.toString());

		}

	}

	@Given("^SOAP-Close and release all resources$")
	public void soap_Close_and_release_all_resources() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		CommonMethods.testStepPassFlag = true;
		try {

			CommonMethods.webservicesClosure();
			

		} catch (Exception e) {
			ScreenshotMethods.logger("Unable to proceed due to the below exception.Please check...  "+e.toString());
			CommonMethods.webservicesClosure();
			
			Assert.fail(e.toString());

		}
	}

	@Given("^SOAP-write  response XML  nodes in RESPONSE column tag \"(.*?)\" to input excel file present in result output folder$")
	public void soap_write_response_XML_nodes_in_RESPONSE_column_tag_to_input_excel_file_present_in_result_output_folder(
			String colTag) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			// inputsheetName

			// Responsetagname and get the response row range

			String responseXMLFileNameInOutputResultFolder = SOAPWS.ResponseFileName;

			// ******************Response data collection from excel
			// sheet***************************************************
			SOAPWebServicesAndWorkbookTalking
					.responseDataCollectionFromInputExcel();

			// ******************************Response data collection from excel
			// sheet ends***************************

			// Populate response node list
			SOAPWebServicesAndWorkbookTalking.populateResponseNodeDataSetList();

			// Create list of list to be used to call
			// compareAndWriteToGivenColumnCell
			List<List<String>> xpathPlusValueList = new ArrayList<List<String>>();
			for (int i = 0; i < SOAPWS.responseNodeXpathList.size(); i++) {
				List<String> tempList = new ArrayList<String>();
				tempList.add(0, SOAPWS.responseNodeXpathList.get(i));
				tempList.add(1, SOAPWS.responseNodeDataSetList.get(i));
				xpathPlusValueList.add(tempList);
			}

			SpreadSheetMethods.compareAndWriteToGivenColumnCell(
					SOAPWS.inputWorkbookPath, SOAPWS.inputWorkbookName,
					SOAPWS.targetSheetName, SOAPWS.responseXPATHColNumber,
					SOAPWS.responseXMLComparisonDataColNumber,
					SOAPWS.responseDataStartRowNumber,
					SOAPWS.responseDataEndRowNumber, xpathPlusValueList);

			// Color with RED (expcted and actual does not matches) or GREEN (If
			// they matches)

			SpreadSheetMethods
					.updateColorOfAllCellsPresentInColumnAfterComparingCellContentForExpectedActualSeparatedByDelimiter(
							SOAPWS.inputWorkbookPath, SOAPWS.inputWorkbookName,
							SOAPWS.targetSheetName,
							SOAPWS.responseDataSeparatorTag,
							SOAPWS.responseXMLComparisonDataColNumber,
							SOAPWS.responseDataStartRowNumber,
							SOAPWS.responseDataEndRowNumber);

			if (CommonMethods.testStepPassFlag == false) {

				ScreenshotMethods.logger("This step failed as the testStepPassFlag is false");
				CommonMethods.webservicesClosure();
				Assert.fail("TestStepPassFlag  is false");
			}
		} catch (Exception e) {

			ScreenshotMethods.logger("Unable to proceed due to the below exception.Please check...  "+e.toString());
			CommonMethods.webservicesClosure();
			
			Assert.fail(e.toString());

		}

	}

	@Given("^SOAP-Update NEXT REQUEST input data excel sheet$")
	public void soap_Update_NEXT_REQUEST_input_data_excel_sheet(
			DataTable listFromStep) throws Throwable {

		CommonMethods.testStepPassFlag = true;
		try {
			// read request start tag
			// read request end tag
			// read requset xpath node
			// re

			SOAPWebServicesAndWorkbookTalking.Set2getTagsFromFeatureFile(
					listFromStep, 0, 1, 2, 5, 6, 3, 4, 8, 9);

			// ******************Request 2 data
			// collection***************************************************
			int requestNodeListColNumber1 = 0;
			int requestDataStartRowNumber1 = -999;

			requestDataStartRowNumber1 = SOAPWebServicesAndWorkbookTalking
					.getRequestDataStartRowNumber(SOAPWS.inputWorkbookPath1,
							SOAPWS.inputWorkbookName1, SOAPWS.targetSheetName1,
							SOAPWS.RequestDataStartTag1);
			int requestDataEndRowNumber1 = -999;
			requestDataEndRowNumber1 = SOAPWebServicesAndWorkbookTalking
					.getRequestDataEndRowNumber(SOAPWS.inputWorkbookPath1,
							SOAPWS.inputWorkbookName1, SOAPWS.targetSheetName1,
							SOAPWS.RequestDataEndTag1);

			int XPATHColNumber1 = -999;
			XPATHColNumber1 = SOAPWebServicesAndWorkbookTalking
					.getRequestDataColNumber(SOAPWS.inputWorkbookPath1,
							SOAPWS.inputWorkbookName1, SOAPWS.targetSheetName1,
							SOAPWS.XPathColTag1);

			int requstXMLInputDataColNumber1 = -999;

			requstXMLInputDataColNumber1 = SOAPWebServicesAndWorkbookTalking
					.getRequestDataColNumber(SOAPWS.inputWorkbookPath1,
							SOAPWS.inputWorkbookName1, SOAPWS.targetSheetName1,
							SOAPWS.FirstTargetColTag1);

			SOAPWS.requestNodeList1 = SpreadSheetMethods// This is required on
														// second time
					.getAllCellValuesForAColInGivenVerticalRange(
							SOAPWS.inputWorkbookPath1,
							SOAPWS.inputWorkbookName1, SOAPWS.targetSheetName1,
							requestNodeListColNumber1,
							requestDataStartRowNumber1,
							requestDataEndRowNumber1);

			SOAPWS.requestNodeXpathList1 = SpreadSheetMethods
					.getAllCellValuesForAColInGivenVerticalRange(
							SOAPWS.inputWorkbookPath1,
							SOAPWS.inputWorkbookName1, SOAPWS.targetSheetName1,
							XPATHColNumber1, requestDataStartRowNumber1,
							requestDataEndRowNumber1);
			SOAPWS.requestNodeDataSetList1 = SpreadSheetMethods
					.getAllCellValuesForAColInGivenVerticalRange(
							SOAPWS.inputWorkbookPath1,
							SOAPWS.inputWorkbookName1, SOAPWS.targetSheetName1,
							requstXMLInputDataColNumber1,
							requestDataStartRowNumber1,
							requestDataEndRowNumber1);

			/*
			 * int configStartIndex = -999;
			 * 
			 * configStartIndex = WebServicesAndWorkbookTalking
			 * .getRequestDataStartRowNumber(SOAPWS.inputWorkbookPath,
			 * SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
			 * SOAPWS.configStart); int configEndIndex = -999;
			 * 
			 * configEndIndex = WebServicesAndWorkbookTalking
			 * .getRequestDataEndRowNumber(SOAPWS.inputWorkbookPath,
			 * SOAPWS.inputWorkbookName, SOAPWS.targetSheetName,
			 * SOAPWS.configEnd);
			 */

			// ******************************Request 2 data collection
			// ends***************************

			// Populate requestNodeDataSet1 List

			// Get all the response data for the given path
			String xmpFileName = ScreenshotMethods.scenarioDirectoryPath + "/"
					+ SOAPWS.ResponseFileName;
			// separate the response node data set list into two lists
			List<String> responseValueList = new ArrayList<>();
			// populate right list
			for (int i = 0; i < SOAPWS.requestNodeXpathList1.size(); i++) {
				try {
					// Call xpath getter method

					String nodeValue = XmlHandlingMethods.getXMLNodeValue(
							xmpFileName, SOAPWS.requestNodeXpathList1.get(i));
					responseValueList.add(i, nodeValue);

				} catch (Exception e) {
					ScreenshotMethods
							.logger("Xpath not found for the node>>>   "
									+ SOAPWS.requestNodeXpathList1.get(i));
					responseValueList.add(i, e.toString());
				}
			}

			// Create list of list to be used to call
			// compareAndWriteToGivenColumnCell
			List<List<String>> xpathPlusValueList = new ArrayList<List<String>>();
			for (int i = 0; i < SOAPWS.requestNodeXpathList1.size(); i++) {
				List<String> tempList = new ArrayList<String>();
				tempList.add(0, SOAPWS.requestNodeXpathList1.get(i));
				tempList.add(1, responseValueList.get(i));
				xpathPlusValueList.add(tempList);
			}

			SpreadSheetMethods.compareAndWriteToGivenColumnCell(
					SOAPWS.inputWorkbookPath1, SOAPWS.inputWorkbookName1,
					SOAPWS.targetSheetName1, XPATHColNumber1,
					requstXMLInputDataColNumber1, requestDataStartRowNumber1,
					requestDataEndRowNumber1, xpathPlusValueList);
			ScreenshotMethods.logger("Current response node data is updated to corresponding Request node data set in the next input data excel sheet.Details are below :");
			ScreenshotMethods.logger("Workbook path: "+SOAPWS.inputWorkbookPath1);
			ScreenshotMethods.logger("Workbook name: "+SOAPWS.inputWorkbookName1);
			ScreenshotMethods.logger("Workbook target sheet name: "+SOAPWS.targetSheetName1);
			ScreenshotMethods.logger("Xpath column number: "+XPATHColNumber1);
			ScreenshotMethods.logger("Xpath plus node value list: "+xpathPlusValueList);
			
			
			

			if (CommonMethods.testStepPassFlag == false) {

				ScreenshotMethods.logger("This step failed as the testStepPassFlag is false");
				CommonMethods.webservicesClosure();
				Assert.fail("TestStepPassFlag  is false");
			}
		} catch (Exception e) {

			ScreenshotMethods.logger("Unable to proceed due to the below exception.Please check...  "+e.toString());
			CommonMethods.webservicesClosure();
			
			Assert.fail(e.toString());

		}

	}

}
