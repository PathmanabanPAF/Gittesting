package stepDefinitionBox;


import java.util.List;

import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;


import projectBox.ConfirmCloseMethods;
import projectBox.RxCommonMethods;
import projectBox.TryCatchTemp;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ReturningToLandingPage_StepDef {

	@Then("^User has following message in \"(.*?)\" pop up$")
	public void user_has_following_message_in_pop_up(String nameOfPopUp, List<String> listOfPopUpMessages) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);

			ConfirmCloseMethods.verifyConfirmClosePopUpMessage(nameOfPopUp, listOfPopUpMessages.get(0));

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User has proper message in " + nameOfPopUp + " pop up");

			TryCatchTemp.checkFlagClosure("driver1", "User has proper message in " + nameOfPopUp + " pop up");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User has proper message in " + nameOfPopUp + " pop up", exception);
		}
	}

	@When("^User creates \"(.*?)\" work orders$")
	public void user_creates_work_orders(String number) throws Throwable {

		for(int i=0;i<Integer.parseInt(number); i++) {

			FrameHandlingMethods.switchToDefaultFrame( BrowserMethods.driver1, WaitMethods.wait20driver1);
			RxCommonMethods.clickLink("Create");
			RxCommonMethods.clickLink("Referral");	          
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
			RxCommonMethods.clickButton("Close");	          
			WaitMethods.waitForPageLoad(BrowserMethods.driver1, WaitMethods.wait20driver1);
			WaitMethods.waitForPegaPageLoad(WaitMethods.wait5driver1, WaitMethods.wait20driver1);
		}
	}


}
