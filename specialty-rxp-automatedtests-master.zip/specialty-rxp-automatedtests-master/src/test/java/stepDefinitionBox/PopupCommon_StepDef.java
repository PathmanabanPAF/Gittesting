package stepDefinitionBox;

import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.ScreenshotMethods;

import projectBox.RxCommonMethods;
import projectBox.TryCatchTemp;
import cucumber.api.java.en.When;

public class PopupCommon_StepDef {


	@When("^User selects \"(.*?)\" option in \"(.*?)\" pop up$")
	public void user_selects_option_in_pop_up(String nameOfButton, String nameOfPopUp) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			RxCommonMethods.clickButton(nameOfButton);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User selects " + nameOfButton + " option in " + nameOfPopUp + " pop up>> has failed dut to testStepPassFlag false value");

			TryCatchTemp.checkFlagClosure("driver1", "User selects " + nameOfButton + " option in " + nameOfPopUp + " pop up>> has failed dut to testStepPassFlag false value");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User selects " + nameOfButton + " option in " + nameOfPopUp + " pop up>> has failed dut to testStepPassFlag false value", exception);
		}

	}

}
