package stepDefinitionBox;

import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;

import projectBox.DatePicker;
import projectBox.RxCommonMethods;
import projectBox.TryCatchTemp;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PrescriptionWritten_StepDef {

	@When("^User has following shadow values in \"(.*?)\" section$")
	public void user_has_following_shadow_values_in_section(String nameSection, DataTable tableOfFields) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
			RxCommonMethods.verifyPlaceHolderValues(BrowserMethods.driver1, WaitMethods.wait20driver1, 
					nameSection, tableOfFields, "placeholder");

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User has following shadow values in " + nameSection + " section for Prescription Writtent date");
			TryCatchTemp.checkFlagClosure("driver1", "User has following shadow values in " + nameSection + " section for Prescription Writtent date");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User has following shadow values in " + nameSection + " section for Prescription Writtent date", exception);
		}

	}

	@When("^User selects \"(.*?)\" icon in \"(.*?)\" section$")
	public void user_selects_icon_in_section(String iconName, String nameSection, DataTable tableOfFields) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			DatePicker.clickCalenderICON(BrowserMethods.driver1, WaitMethods.wait20driver1, 
					nameSection, tableOfFields);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User select " + iconName+ " in " + nameSection + " section");

			TryCatchTemp.checkFlagClosure("driver1", "User select " + iconName+ " in " + nameSection + " section");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User select " + iconName+ " in " + nameSection + " section", exception);
		}
	}

	@Then("^\"(.*?)\" date is selected by default$")
	public void date_is_selected_by_default(String dateValue) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			DatePicker.checkDefaultDateInPicker(dateValue);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "Default selected date value in Calendar");

			TryCatchTemp.checkFlagClosure("driver1", "Default selected date value in Calendar");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "Default selected date value in Calendar", exception);
		}
	}

	@Then("^User should not receive following notifications for mandatory fields in \"(.*?)\" section$")
	public void user_should_not_receive_following_notifications_for_mandatory_fields_in_section(String nameSection, DataTable tableOfFields) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);

			RxCommonMethods.verifyFieldValidationErrorMessages(BrowserMethods.driver1,
					WaitMethods.wait20driver1, nameSection, tableOfFields, "Submit",false);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User should not receive notifications for the mandatory fields in " + nameSection + " section");

			TryCatchTemp.checkFlagClosure("driver1", "User should not receive notifications for the mandatory fields in " + nameSection + " section");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User should not receive notifications for the mandatory fields in " + nameSection + " section", exception);
		}
	}

	@Then("^User should receive following notifications for mandatory fields in \"(.*?)\" section$")
	public void user_should_receive_following_notifications_for_mandatory_fields_in_section(String nameSection, DataTable tableOfFields) throws Throwable 
	{
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);

			RxCommonMethods.verifyFieldValidationErrorMessages(BrowserMethods.driver1,
					WaitMethods.wait20driver1, nameSection, tableOfFields, "Submit",true);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User should receive notifications for the mandatory fields in " + nameSection + " section");

			TryCatchTemp.checkFlagClosure("driver1", "User should receive notifications for the mandatory fields in " + nameSection + " section");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User should receive notifications for the mandatory fields in " + nameSection + " section", exception);
		}
	}
	@Then("^User is able to verify future dates are disabled in calendar$")
	public void user_is_able_to_verify_future_dates_are_disabled_in_calendar() throws Throwable 
	{
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);

			boolean blnFlag =true;
			if(blnFlag )
			{
				CommonMethods.testStepPassFlag = false;
			}

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User is able to verify future dates are disabled in calendar");

			TryCatchTemp.checkFlagClosure("driver1", "User is able to verify future dates are disabled in calendar");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User is able to verify future dates are disabled in calendar", exception);
		}
	}
	
}
