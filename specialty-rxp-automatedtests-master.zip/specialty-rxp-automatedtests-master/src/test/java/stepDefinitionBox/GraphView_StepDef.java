package stepDefinitionBox;

//import org.openqa.selenium.By;

import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
//import globalBox.TableAndPageHandlingMethods;
import globalBox.WaitMethods;
import projectBox.GraphViewMethods;
import projectBox.TryCatchTemp;
import cucumber.api.java.en.Then;

public class GraphView_StepDef {

	@Then("^User is able to see the graph with header as \"(.*?)\" and xAxis as \"(.*?)\" and yAxis as \"(.*?)\"$")
	public void user_is_able_to_see_the_graph_with_header_as_and_xAxis_as_and_yAxis_as(String lblTextInGraph, String XAxisValue, String YAxisValue) throws Throwable {		
		CommonMethods.testStepPassFlag = true;
		try {
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
			GraphViewMethods.GraphExistence();
			GraphViewMethods.checklabelTextInGraph(lblTextInGraph);
			GraphViewMethods.checkXAxisValue(XAxisValue);
			GraphViewMethods.checkYAxisValue(YAxisValue);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User is able to see the graph with header as "+ lblTextInGraph +" and xAxis as " + XAxisValue + " and yAxis as " + YAxisValue);
			
			TryCatchTemp.checkFlagClosure("driver1", "User is able to see the graph with header as "+ lblTextInGraph +" and xAxis as " + XAxisValue + " and yAxis as " + YAxisValue);

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User is able to see the graph with header as "+ lblTextInGraph +" and xAxis as " + XAxisValue + " and yAxis as " + YAxisValue, exception);

		}
	}
	/*
	@Then("^user is abel to test table methods$") // Test for table methods implementation
	public void user_is_abel_to_test_table_methods() throws Throwable {
		//By table = By.xpath("//*[@pl_prop='MyWorkLocks.pxResults']/tbody");
		//By locatorID =By.xpath( "./*[text()]");
		//By locatorID =By.xpath( ".//label]");		
		FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
		//'String cellText = "";
		SearchMethods.verifyNoSearchResultsInTable("Search Provider");

		String cellValue1 = TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, table, 1, 1, locatorID);
		System.out.println("Cell Text" +cellValue1 );
		String cellValue2 = TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, table, 1, 2, locatorID);
		System.out.println("Cell Text" +cellValue2 );
		int colNumber = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, table, "Case ID", locatorID);
		System.out.println("Get Col Number" + colNumber );
		
		//String getColNum = TableAndPageHandlingMethods.getRowColWithCellText(BrowserMethods.driver1, table, cellText, locatorID,false);
		//String getColNum1 = TableAndPageHandlingMethods.getRowColWithCellText(BrowserMethods.driver1, table, "RxP Generic User Technician", locatorID,true);
		//String getColNum2 = TableAndPageHandlingMethods.getRowColWithCellText(BrowserMethods.driver1, table, "7/13/17 4:51 AM", locatorID,true);
		//String getColNum3 = TableAndPageHandlingMethods.getRowColWithCellText(BrowserMethods.driver1, table, "Tom, M, Smith ,Jr", locatorID,false);
		//System.out.println("Get Col Number" + getColNum );
		//System.out.println("Get Col Number" + getColNum1 );
		//System.out.println("Get Col Number" + getColNum2 );
		//System.out.println("Get Col Number" + getColNum3 );
		
		}*/

}



