package stepDefinitionBox;

import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;

import java.util.List;

import projectBox.ActionsPerform;
import projectBox.TryCatchTemp;
import projectBox.ValueCommonMethods;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class DAW_StepDef 
{
	@Then("^User has below defaulted value selected in \"(.*?)\" field in \"(.*?)\" section$")
	public void user_has_below_defaulted_value_selected_in_field_in_section(String nameField, String nameSection, List<String> listOfFields) throws Throwable
	{
		String ReportMessage = "Defaulted Value selected in " + nameField + "in" + nameSection +" Section ";
		CommonMethods.testStepPassFlag = true;
		try 
		{	
			ValueCommonMethods.verifyDefaultedValueinDropDown(nameField, nameSection, listOfFields);
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
			TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
		}
		catch (Exception exception)
		{
			TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
		}		
	}

	@Then("^User selects \"(.*?)\" code using mouse click in \"(.*?)\" Section$")
	public void user_selects_code_using_mouse_click_in_Section(String nameField, String nameSection) throws Throwable
	{
		
		String ReportMessage = "User select the "+ nameField + "code using Mouse Click";
		CommonMethods.testStepPassFlag = true;
		try 
		{
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
			ActionsPerform.performMouseActions(nameField, nameSection);
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage);
			TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
		}
		catch (Exception exception)
		{
			TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
		}						
	}
		

	@Then("^User selects \"(.*?)\" code using below Keyboard strokes in \"(.*?)\" Section$")
	public void user_selects_code_using_below_Keyboard_strokes_in_Section(String nameField, String nameSection, DataTable tableValues) throws Throwable
	{
		String ReportMessage = "User select the DAW code using Key Strokes";
		CommonMethods.testStepPassFlag = true;
		try 
		{	
			ActionsPerform.performKeyBoardActions(nameField, nameSection, tableValues);
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage);
			TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
		}
		catch (Exception exception)
		{
			TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
		}				
	}
	

	@Then("^User selects the \"(.*?)\" code by keying the below numeric value in \"(.*?)\" Section$")
	public void user_selects_the_code_by_keying_the_below_numeric_value_in_Section(String nameField, String nameSection, DataTable tableValues) throws Throwable
	{
		String ReportMessage = "User select the DAW code using Numeric Value";
		CommonMethods.testStepPassFlag = true;
		try 
		{	
			ActionsPerform.performKeyBoardActions(nameField, nameSection, tableValues);
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage);
			TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
		}
		catch (Exception exception)
		{
			TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
		}							
	}	

}
