package stepDefinitionBox;

import projectBox.ManualCaseCreationMethods;
import projectBox.TryCatchTemp;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;
import cucumber.api.java.en.Then;


public class ManualCaseCreation_StepDef {

	@Then("^Case is \"(.*?)\" with \"(.*?)\" as \"(.*?)\" in \"(.*?)\" section$")
	public void case_is_with_as_in_section(String caseAction, String nameField, String nameFieldValue, String nameHeader) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			ManualCaseCreationMethods.caseSummaryCheck(caseAction, nameField, nameFieldValue, nameHeader);


			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "Case is " + caseAction + " with "+nameField+" as "+nameFieldValue+" in "+nameFieldValue+" section");

			TryCatchTemp.checkFlagClosure("driver1", "Case is " + caseAction + " with "+nameField+" as "+nameFieldValue+" in "+nameFieldValue+" section");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "Case is " + caseAction + " with "+nameField+" as "+nameFieldValue+" in "+nameFieldValue+" section", exception);

		}
	}
}
