package stepDefinitionBox;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;

import java.util.List;
import org.openqa.selenium.By;

import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.OrderEntryPage;
import projectBox.OrderEntry;
import projectBox.RxCommonMethods;
import projectBox.TryCatchTemp;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class MissingHighlightInfo_StepDef {


	@Then("^User has following notifications for mandatory fields in \"(.*?)\" section$")
	public void user_has_following_notifications_for_the_mandatory_fields_in_section(String nameSection, DataTable tableOfFields) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
			
			RxCommonMethods.verifyBlankFieldValidationErrorMessages(BrowserMethods.driver1, WaitMethods.wait20driver1, nameSection, tableOfFields, "Submit", true);

			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User has following notifications for the mandatory fields in " + nameSection + " section");

			TryCatchTemp.checkFlagClosure("driver1", "User has following notifications for the mandatory fields in " + nameSection + " section");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User has following notifications for the mandatory fields in " + nameSection + " section", exception);

		}
	}


	@Then("^User has following notifications for \"(.*?)\" fields in \"(.*?)\" section$")
	public void user_has_following_notifications_for_condition_fields_in_section(String typeFields,String nameSection, DataTable tableOfFields) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);			

			RxCommonMethods.verifyFieldValidationErrorMessages(BrowserMethods.driver1, WaitMethods.wait20driver1, nameSection, tableOfFields, "Search", true);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User has following notifications for " + typeFields + " fields in " + nameSection + " section");

			TryCatchTemp.checkFlagClosure("driver1", "User has following notifications for " + typeFields + " fields in " + nameSection + " section");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User has following notifications for " + typeFields + " fields in " + nameSection + " section", exception);

		}
	}


	@Then("^User has following notification in \"(.*?)\" page without providing mandatory inputs$")
	public void user_has_following_notification_in_page_without_providing_mandatory_inputs(String namePage, List<String> errorMessage) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			AssertionMethods.verifyElementExists(WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathTextPart1 + errorMessage.get(0) +CommonWebElements.dynamicXpathTextPart2));

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User has following notification in " + namePage + " page without providing mandatory inputs");

			TryCatchTemp.checkFlagClosure("driver1", "User has following notification in " + namePage + " page without providing mandatory inputs");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User has following notification in " + namePage + " page without providing mandatory inputs", exception);

		}
	}


	@Then("^User is able to submit the order$")
	public void user_is_able_to_submit_the_order() throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			AssertionMethods.verifyElementExists(WaitMethods.wait20driver1, OrderEntryPage.xpathLastWorkOrderError);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User is able to submit the order");

			TryCatchTemp.checkFlagClosure("driver1", "User is able to submit the order");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User is able to submit the order", exception);

		}
	}


	@Then("^User receives below notification if \"(.*?)\" is less than \"(.*?)\" years in \"(.*?)\" section$")
	public void user_receives_below_notification_if_is_less_than_years_in_section(String nameField, String minimumYears, String nameSection, List<String> expectedErrormessage) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);

			OrderEntry.verifyAgeNotification(nameField, minimumYears, nameSection, expectedErrormessage.get(0));

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User receives below notification if " + nameField + " is less than " + minimumYears + " years in " + nameSection + " section");

			TryCatchTemp.checkFlagClosure("driver1", "User receives below notification if " + nameField + " is less than " + minimumYears + " years in " + nameSection + " section");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User receives below notification if " + nameField + " is less than " + minimumYears + " years in " + nameSection + " section", exception);

		}
	}
}
