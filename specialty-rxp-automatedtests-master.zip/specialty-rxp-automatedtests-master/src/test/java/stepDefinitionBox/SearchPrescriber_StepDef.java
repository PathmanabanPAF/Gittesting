package stepDefinitionBox;

import java.util.List;

import org.openqa.selenium.By;

import projectBox.RxCommonMethods;
import projectBox.SearchMethods;
import projectBox.TryCatchTemp;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class SearchPrescriber_StepDef {
	
	@When("^User selects \"(.*?)\" search look up in \"(.*?)\" section$")
		public void user_selects_search_look_up_in_section(String nameField, String nameSection) throws Throwable
		{
			String ReportMessage = "Select Search Look up of " + nameField + "in" + nameSection +" Section ";
			CommonMethods.testStepPassFlag = true;
			try {
				FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
				SearchMethods.clickSearchLookup(nameField, nameSection);
				Thread.sleep(5000);
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}
		}
	@Then("^User close the \"(.*?)\" search look up$")
		public void user_close_the_search_look_up(String nameSection) throws Throwable
		{
			String ReportMessage = "' " + nameSection + " ' look up close";
			CommonMethods.testStepPassFlag = true;
			try {
				SearchMethods.closeSearchLookup(nameSection);
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	    
		}

	@Then("^User selects \"(.*?)\" link in \"(.*?)\"$")
		public void user_selects_link_in(String nameField, String nameSection) throws Throwable
		{	
		String ReportMessage = "' " + nameSection + " ' select show more link ";
		CommonMethods.testStepPassFlag = true;
		try {
				SearchMethods.clickShowMore();
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	 		
		}
	@Then("^User receive following error message when \"(.*?)\" selected without any search criteria$")
	public void user_receive_following_error_message_when_selected_without_any_search_criteria(String nameOfButton, List<String> expectedErrorMsg) throws Throwable 
	{
		String ReportMessage = "' " + nameOfButton + " ' is selected without any search criteria ";
		CommonMethods.testStepPassFlag = true;
		try {
				SearchMethods.verifyErrorMessageOnNoCriteria(nameOfButton,expectedErrorMsg);
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	 			
	
	}
	
	@When("^User selects the \"(.*?)\" in \"(.*?)\" Screen$")
	public void user_selects_the_in_Screen(String nameButton, String nameSection) throws Throwable
	{
		FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
		String ReportMessage = "User select the " + nameButton + "' button in " + nameSection + "Screen";
		CommonMethods.testStepPassFlag = true;
		try {
				RxCommonMethods.clickButton("Clear");
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	 			
	}
	@When("^User has following notifications for search fields in \"(.*?)\" section$")
	public void user_has_following_notifications_for_search_fields_in_section(String nameSection, DataTable tableFields) throws Throwable
	{
		String ReportMessage = "Validation of "+ nameSection +" fields presented in the look up scrren";
		CommonMethods.testStepPassFlag = true;
		try {
				SearchMethods.validationOfSearchFields(nameSection, tableFields);
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	 			
	}
	
	@When("^User is able to select only one result based on the below values$")
	public void user_is_able_to_select_only_one_result_based_on_the_below_values(DataTable tableFields) throws Throwable {
		String ReportMessage = "User is able to select only one record from the result table";
		CommonMethods.testStepPassFlag = true;
		try {
				//SearchMethods.selectSearchLookupSubmit();
				//RxCommonMethods.clickButton("Clear");
				RxCommonMethods.clickButton("Search");
				List<List<String>> listFields = tableFields.raw();
				//SearchMethods.selectOneRecordFromTable(listFields);
				SearchMethods.selectSingleRecordFromTbl(listFields, By.xpath("./*[text()]"), false);
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	 					
	}

	@When("^User clicks on submit the prescriber details$")
	public void user_clicks_on_submit_the_prescriber_details() throws Throwable 
	{
		String ReportMessage = "User is able to sumbit the selected search results";
		CommonMethods.testStepPassFlag = true;
		try {
				SearchMethods.selectSearchLookupSubmit();
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	 					
	}

	@Then("^User is able to verify below \"(.*?)\" details populated from look up screen$")
	public void user_is_able_to_verify_below_details_populated_from_look_up_screen(String nameSection, DataTable tableFields) throws Throwable 
	{
		String ReportMessage = "Populated values from " + nameSection  +" search look up into Order Entry Page ";
		CommonMethods.testStepPassFlag = true;
		try {
				List<List<String>> listFields = tableFields.raw();
				SearchMethods.verifyInformationOfField(nameSection, listFields);
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	 					
	}
	
	@Then("^User has defaulted values for below fields on \"(.*?)\" section when \"(.*?)\" look up Cancelled$")
	public void user_has_defaulted_values_for_below_fields_on_section_when_look_up_Cancelled(String nameSection, String nameSearchlookup, List<String> listFields) throws Throwable 			
	{
		String ReportMessage = "User Cancel the search look up and verify the default values of " + nameSection + "Section";
		CommonMethods.testStepPassFlag = true;
		try {
				SearchMethods.verifyDefaultValuesOnCancelSearch(nameSection, nameSearchlookup, listFields);
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	 					
	}
	@When("^User noted the default values for below fields in \"(.*?)\" Section on \"(.*?)\" page$")
	public void user_noted_the_default_values_for_below_fields_in_Section_on_page(String nameSection, String namePage, List<String> listFields) throws Throwable 
	{
		String ReportMessage = "User noted the default values on "+nameSection+ "Section";
		CommonMethods.testStepPassFlag = true;
		try {
				FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
				SearchMethods.noteDefaultValues(nameSection, listFields);
				//FrameHandlingMethods.switchToDefaultFrame(BrowserMethods.driver1, WaitMethods.wait20driver1);
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	 							
	}
	@Then("^search results displayed below values in \"(.*?)\"$")
	public void search_results_displayed_below_values_in(String nameSection, DataTable tableFields) throws Throwable 
	{
		String ReportMessage = "search results displayed in  " + nameSection + "Table" ;
		CommonMethods.testStepPassFlag = true;
		try {				
				RxCommonMethods.clickButton("Search");
				SearchMethods.verifySearchResultsInTable(nameSection,tableFields);				
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	 							
	}
	@Then("^system should display no results found message in \"(.*?)\"$")
	public void system_should_display_no_results_found_message_in(String nameSection) throws Throwable 
	{
		String ReportMessage = "No search results displayed in  " + nameSection + "Table" ;
		CommonMethods.testStepPassFlag = true;
		try {
				FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
				RxCommonMethods.clickButton("Search");
				SearchMethods.verifyNoSearchResultsInTable(nameSection);				
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
			}	    	 							
	}

	
}
