package stepDefinitionBox;


import java.util.List;

import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;

import projectBox.HostnameMethods;
import projectBox.TryCatchTemp;
import cucumber.api.java.en.Then;

public class Hostname_StepDef {
	
	@Then("^User can find the below \"(.*?)\" details in the footer$")
	public void user_can_find_the_below_details_in_the_footer(String footerField, List<String> dataValue) throws Throwable {
		
		CommonMethods.testStepPassFlag = true;
		try {
			
			HostnameMethods.verifyFooterValue(footerField, dataValue.get(0));
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User can find the below " + footerField + " details in the footer" + dataValue.get(0));
			
			TryCatchTemp.checkFlagClosure("driver1", "User can find the below " + footerField + " details in the footer" + dataValue.get(0));

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User can find the below " + footerField + " details in the footer" + dataValue.get(0), exception);

		}
	  
	}

	@Then("^User can find the below \"(.*?)\" details at the footer in \"(.*?)\" page$")
	public void user_can_find_the_below_details_at_the_footer_in_page(String nameOfHost, String nameOfPage, List<String> dataValue) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			
			FrameHandlingMethods.switchToDefaultFrame(BrowserMethods.driver1, WaitMethods.wait20driver1);
			
			HostnameMethods.verifyHostName(dataValue.get(0));
						
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User can find "+ nameOfHost +" details in "+ nameOfPage +" page" + dataValue.get(0));
			
			TryCatchTemp.checkFlagClosure("driver1", "User can find "+ nameOfHost +" details in "+ nameOfPage +" page" + dataValue.get(0));

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User can find "+ nameOfHost +" details in "+ nameOfPage +" page" + dataValue.get(0), exception);

		}
	 
	}



}
