package stepDefinitionBox;

import java.util.List;

import org.openqa.selenium.By;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.CommonMethods;
import globalBox.DynamicXpathCalculation;
import globalBox.FrameHandlingMethods;
import globalBox.GetValueMethods;
import globalBox.ScreenshotMethods;
import globalBox.SpreadSheetMethods;
import globalBox.WaitMethods;
import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.DiagnosisSearch;
import projectBox.AdditionalOE;
import projectBox.RxCommonMethods;
import projectBox.TryCatchTemp;

public class AdditionalOE_StepDef {

	@Then("^User clicks on \"(.*?)\" link in \"(.*?)\" screen$")
	public void user_clicks_on_link_in_screen(String nameLink, String nameScreen) throws Throwable {

		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);

			By linkXpath = By.xpath(CommonWebElements.dynamicXpathLinkPart1 + nameLink + CommonWebElements.dynamicXpathLinkPart2);

			ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, linkXpath);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User clicked on " +nameLink+ "in "+nameScreen );


			TryCatchTemp.checkFlagClosure("driver1", "User clicked on " +nameLink+ "in "+nameScreen);

		} catch (Exception exception){

			TryCatchTemp.exceptionClosure("driver1", "User clicked on " +nameLink+ "in "+nameScreen, exception);

		}

	}


	/*	@Then("^system will display a message label on top of the ICD-(\\d+) search section$")
	public void system_will_display_a_message_label_on_top_of_the_ICD_search_section(int ICD, String diagnosisSearchLabel) throws Throwable {

		CommonMethods.testStepPassFlag = true;
		String actualdiagnosisSearchLabel = "";
		try {

			actualdiagnosisSearchLabel = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, DiagnosisSearch.lableDiagnosis);

			AssertionMethods.expectedActualTest(diagnosisSearchLabel, actualdiagnosisSearchLabel);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "Diagnosis Search label " + actualdiagnosisSearchLabel + "is displayed in Diagnosis Search screen" );


			TryCatchTemp.checkFlagClosure("driver1", "Diagnosis Search label " + actualdiagnosisSearchLabel + "is displayed in Diagnosis Search screen");

		} catch (Exception exception){

			TryCatchTemp.exceptionClosure("driver1", "Diagnosis Search label " + actualdiagnosisSearchLabel + "is displayed in Diagnosis Search screen", exception);

		}

	}*/

	@Then("^system will display a message label on top of the Diagnosis search section$")
	public void system_will_display_a_message_label_on_top_of_the_Diagnosis_search_section(List<String> diagnosisSearchLabel) throws Throwable {

		CommonMethods.testStepPassFlag = true;

		String actualdiagnosisSearchLabel = "";
		try {

			actualdiagnosisSearchLabel = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, DiagnosisSearch.lableDiagnosis);

			AssertionMethods.expectedActualTest(diagnosisSearchLabel.get(0), actualdiagnosisSearchLabel);

			AssertionMethods.verifyElementExists(WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathTextPart1 + diagnosisSearchLabel.get(0) +CommonWebElements.dynamicXpathTextPart2));

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "Diagnosis Search label " + actualdiagnosisSearchLabel + "is displayed in Diagnosis Search screen" );


			TryCatchTemp.checkFlagClosure("driver1", "Diagnosis Search label " + actualdiagnosisSearchLabel + "is displayed in Diagnosis Search screen");

		} catch (Exception exception){

			TryCatchTemp.exceptionClosure("driver1", "Diagnosis Search label " + actualdiagnosisSearchLabel + "is displayed in Diagnosis Search screen", exception);

		}

	}

	@Then("^User has following elements in \"(.*?)\" section$")
	public void user_has_following_elements_in_section(String nameHeader, DataTable tableFields) throws Throwable {

		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);

			AdditionalOE.fieldValidationDiagnosisSearch(WaitMethods.wait20driver1, tableFields);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User has following elements in "+nameHeader+" section of Diagnosis Search page");

			TryCatchTemp.checkFlagClosure("driver1", "User has following elements in "+nameHeader+" section of Diagnosis Search page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User has following elements in "+nameHeader+" section of Diagnosis Search page", exception);

		} 


	}


	@Then("^User Selects \"(.*?)\" from \"(.*?)\"$")
	public void user_Selects_from(String childElement, String ParentElement) throws Throwable
	{
		String ReportMessage = "Select <<<  " + childElement + " >>> From <<<" +ParentElement+ ">>> section" ;
		CommonMethods.testStepPassFlag = true;
		try 
		{
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);
			RxCommonMethods.clickButton(ParentElement);
			AdditionalOE.clickMenuOptions(childElement);
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );	
			TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
		} catch (Exception exception) {
			TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);}			
	}

	@Then("^User has below options to indicate the \"(.*?)\" in \"(.*?)\" section$")
	public void user_has_below_options_to_indicate_the_in_section(String nameField, String nameSection, List<String> listOfValues) throws Throwable 
	{
		String ReportMessage = "Verfication of <<< " + nameField +" >>> in the <<< " + nameSection + " >>>" ;			
		CommonMethods.testStepPassFlag = true;
		try 
		{
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);
			AdditionalOE.verifyReasonforOEField(nameField, nameSection, listOfValues);
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );	
			TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
		} catch (Exception exception) {
			TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);}
	}

	/*		@Then("^User is able to enter below comments in \"(.*?)\" field under \"(.*?)\" section$")
		public void user_is_able_to_enter_below_comments_in_field_under_section(String nameField, String nameSection, List<String> listOfValues) throws Throwable 
		{
			String ReportMessage = "Entering the text in <<< " + nameField +" >>> in the <<< " + nameSection + " >>>" ;			
			CommonMethods.testStepPassFlag = true;
			try 
			{
				ValueCommonMethods.setFieldValue(BrowserMethods.driver1, WaitMethods.wait20driver1, nameSection, nameField, "Text area", listOfValues.get(0));
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );	
				TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
			} catch (Exception exception) {
				TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);}			
		}*/

	@Then("^User is able to Withdrawn or cancelled the Order entry task$")
	public void user_is_able_to_Withdrawn_or_cancelled_the_Order_entry_task() throws Throwable 
	{
		String ReportMessage = "User is able to withdrawn or cancelled the Order entry task" ;			
		CommonMethods.testStepPassFlag = true;
		try 
		{
			RxCommonMethods.clickButton("Submit");
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );	
			TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
		} catch (Exception exception) {
			TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);}		
	}


	@Then("^User selects \"(.*?)\" Results with below Columns$")
	public void user_selects_Results_with_below_Columns(String nameSearch, List<String> nameColumn) throws Throwable {

		//String icdCode  =  SearchTransactionData.geticdCode1();
		List<String> listOfColumnData = SpreadSheetMethods.getListOfColumnData(CommonMethods.readPropertiesFile("inputdata.properties", "workBookPath"),"SearchTestData.xlsx", "Diagnosis Search", "valid search", "ICD Code");
		String icdCode  =  listOfColumnData.get(0);
		CommonMethods.testStepPassFlag = true;

		try {

			AdditionalOE.selectColumnContainedValues(nameSearch, nameColumn.get(0), icdCode);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User selects the records from the search results");

			TryCatchTemp.checkFlagClosure("driver1", "User selects the records from the search results");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User selects the records from the search results", exception);

		} 	

	}

	@Then("^User receives the selected records under \"(.*?)\" section in  \"(.*?)\"	screen$")
	public void user_receives_the_selected_records_under_section_in_screen(String nameSection, String nameScreen) throws Throwable {

		CommonMethods.testStepPassFlag = true;
		
		try {

			AdditionalOE.verifySelectedValues();

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User selects the records from the search results");

			TryCatchTemp.checkFlagClosure("driver1", "User selects the records from the search results");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User selects the records from the search results", exception);

		} 

	}


	@Then("^user deletes the added records under \"(.*?)\" section in \"(.*?)\" screen$")
	public void user_deletes_the_added_records_under_section_in_screen(String arg1, String arg2) throws Throwable {

		CommonMethods.testStepPassFlag = true;
		
		try {

			AdditionalOE.deleteSelectedValues();

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User deletes the selected records under Diagnosis codes section in Additional OE screen");

			TryCatchTemp.checkFlagClosure("driver1", "User deletes the selected records under Diagnosis codes section in Additional OE screen");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User deletes the selected records under Diagnosis codes section in Additional OE screen", exception);

		} 
	}

	

	
	
	@Then("^User navigates back to \"(.*?)\" page$")
	public void user_navigates_back_to_page(String namePage) throws Throwable {
		
		CommonMethods.testStepPassFlag = true;
		
		try {
			

			By xpathLink = DynamicXpathCalculation.dynamicXpathCreation(
					CommonWebElements.dynamicXpathLinkPart1, namePage,
					CommonWebElements.dynamicXpathLinkPart2);
			
			AssertionMethods.verifyElementExists(WaitMethods.wait20driver1, xpathLink);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User navigated back to " +namePage+ " page");

			TryCatchTemp.checkFlagClosure("driver1", "User navigated back to " +namePage+ " page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User navigated back to " +namePage+ " page", exception);

		} 

	}
	
	
}	



