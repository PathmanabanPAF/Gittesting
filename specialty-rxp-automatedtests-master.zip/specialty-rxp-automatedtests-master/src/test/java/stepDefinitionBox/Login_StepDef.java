package stepDefinitionBox;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import pageWebElementsBox.LoginPage;
import projectBox.LoginMethods;
import projectBox.TransactionData;
import projectBox.TryCatchTemp;
import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login_StepDef {
	@Given("^User has navigated to login screen of RxProcessing application \"(.*?)\"$")
	public void user_has_navigated_to_login_screen_of_Rx_Processing_application(
			String nameScenario) throws Throwable {
	System.setProperty("webdriver.chrome.driver", "C:\\specialty-rxp-automatedtests-master\\target\\test-classes\\chromedriver.exe");
	//WebDriver driver = new InternetExplorerDriver();
	WebDriver driver = new ChromeDriver();
	
	driver.get("google.com");
	}
	/*@Given("^User has navigated to login screen of RxProcessing application \"(.*?)\"$")
	public void user_has_navigated_to_login_screen_of_Rx_Processing_application(
			String nameScenario) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {
			LoginMethods.navigateToUrl(nameScenario);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,"tempJPEGFilePlaceHolder","User has navigated to login screen of RxProcessing application");

			TryCatchTemp.checkFlagClosure("driver1", "User has navigated to login screen of RxProcessing application");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User has navigated to login screen of RxProcessing application", exception);

		}

	}

	@When("^User provides valid \"([^\"]*)\" credentials and submit$")
	public void user_provides_valid_Technician_credentials(String userRole)
			throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			LoginMethods.loginApplication(BrowserMethods.driver1, WaitMethods.wait20driver1, LoginPage.iDUsername, LoginPage.iDPassword, LoginPage.idSubmitButton, userRole);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User logins and navigates to landing page after submitting valid credentials");

			TryCatchTemp.checkFlagClosure("driver1", "User logins and navigates to landing page after submitting valid credentials");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User logins and navigates to landing page after submitting valid credentials", exception);

		}

	}

	@Then("^User logs into the application as \"([^\"]*)\"$")
	public void user_logs_into_the_application(String userRole)
			throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			LoginMethods.verifyApplicationMenuName(userRole);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User logs into the application as <"+ userRole + ">");

			TryCatchTemp.checkFlagClosure("driver1", "User logs into the application as <"+ userRole + ">");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User logs into the application as <"+ userRole + ">", exception);

		}
	}

	@Then("^User is able to close browser$")
	public void user_is_able_to_close_browser() throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			CommonMethods.closure("driver1", "", "screenshotFileMessage",
					"Close all Browsers in the final Step");

			TryCatchTemp.checkFlagClosure("driver1", "User is able to close browser");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User is able to close browser", exception);

		}
	}
	
	
	@Then("^User closes the browser$")
	public void user_closes_close_browser() throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			CommonMethods.closeAllBrowsers();

			TryCatchTemp.checkFlagClosure("driver1", "User closes the browser");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User closes the browser", exception);

		}
	}

	@When("^User provides invalid \"(.*?)\" and \"(.*?)\"$")
	public void user_provides_invalid_and(String userName, String password)
			throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			LoginMethods.enterInvalidCredentials(userName, password);

			TryCatchTemp.checkFlagClosure("driver1", "User provides invalid  " + userName + " and "+ password + "credetials");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User provides invalid  " + userName + " and "+ password + "credetials", exception);

		}
	}

	@Then("^following login error message displayed$")
	public void following_error_message_displayed(
			List<String> listOfErrorMessages) throws Throwable {

		CommonMethods.testStepPassFlag = true;

		try {

			LoginMethods.verifyLoginErrorMessage(listOfErrorMessages.get(0));
			
			TryCatchTemp.checkFlagClosure("driver1", "following login error message displayed" + listOfErrorMessages.get(0));

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "following login error message displayed" + listOfErrorMessages.get(0), exception);

		}
	}

	@Then("^User logs into the application as \"(.*?)\" within \"(.*?)\" seconds$")
	public void user_logs_into_the_application_as_within_seconds(
			String userRole, String expectedLoginTime) throws Throwable {

		CommonMethods.testStepPassFlag = true;

		try {

			LoginMethods.verifyLoginTime(userRole, expectedLoginTime);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User logs into the application as " + userRole + " within " + expectedLoginTime + " seconds");

			TryCatchTemp.checkFlagClosure("driver1", "User has navigated to login screen of RxProcessing application");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User has navigated to login screen of RxProcessing application", exception);

		}
	}

	@When("^User is inactive for \"(.*?)\" minutes in landing page$")
	public void user_is_inactive_for_minutes_in_landing_page(String waitTime)
			throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			LoginMethods.inactiveWait(waitTime);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User is inactive for " + waitTime + " minutes in landing page");
			
			TryCatchTemp.checkFlagClosure("driver1", "User is inactive for " + waitTime + " minutes in landing page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User is inactive for " + waitTime + " minutes in landing page", exception);

		}
	}

	@Then("^User \"(.*?)\" the time out pop up in landing page$")
	public void user_the_time_out_pop_up_in_landing_page(String actionOfUser)
			throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {
			
			LoginMethods.userTimeOutAction(actionOfUser);
			
		
			TryCatchTemp.checkFlagClosure("driver1", "User " + actionOfUser + " the time out pop up in landing page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User " + actionOfUser + " the time out pop up in landing page", exception);

		}
	}

	@Then("^User gets logged out of the application$")
	public void user_gets_logged_out_of_the_application() throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {
			
			AssertionMethods.verifyElementExists(WaitMethods.wait20driver1, LoginPage.iDUsername);

			ScreenshotMethods
			.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User gets logged out of the application");
			
			TryCatchTemp.checkFlagClosure("driver1", "User gets logged out of the application");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User gets logged out of the application", exception);

		}
	}
	
	
	
	@Then("^User stays back in landing page$")
	public void user_stays_back_in_landing_page() throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {
			
			LoginMethods.verifyApplicationMenuName(TransactionData.getUserRole());

			ScreenshotMethods
			.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User stays back in landing page");
			
			TryCatchTemp.checkFlagClosure("driver1", "User stays back in landing page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User stays back in landing page", exception);

		}
	}
	*/

}
