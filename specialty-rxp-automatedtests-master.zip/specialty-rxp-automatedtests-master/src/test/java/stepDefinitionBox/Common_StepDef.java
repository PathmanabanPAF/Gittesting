package stepDefinitionBox;

import org.openqa.selenium.By;

import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.HoveringMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;
import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.LoginPage;
import projectBox.LoginMethods;
import projectBox.RxCommonMethods;
import projectBox.TryCatchTemp;
import projectBox.verifyCommonMethods;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Common_StepDef {

	@Given("^User \"(.*?)\" to the RxProcessing application as \"(.*?)\" \"(.*?)\"$")
	public void user_to_the_Rx_Processing_application_as(String nameAction, String userRole, String nameScenario) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			LoginMethods.navigateToUrl(nameScenario);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "Navigate to Rx Processing Application URL");

			LoginMethods.loginApplication(BrowserMethods.driver1,WaitMethods.wait20driver1, LoginPage.iDUsername, LoginPage.iDPassword, LoginPage.idSubmitButton, userRole);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User "+ nameAction +" to the Rx Processing application as <"+ userRole +">");

			TryCatchTemp.checkFlagClosure("driver1", "User "+ nameAction +" to the Rx Processing application as <"+ userRole +">");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User "+ nameAction +" to the Rx Processing application as <"+ userRole +">", exception);

		}
	}



	@Then("^User has following elements in \"(.*?)\" section of \"(.*?)\" page$")
	public void user_has_following_elements_in_section_of_page(String nameHeader, String namePage, DataTable tableFields) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			switch(nameHeader) {
			case "Patient":
				FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
				break;
			case "Prescription":
			case "Supervising Prescriber":
			case "Prescriber":
			case "Drug Search":
			case "Drug":
			case "Diagnosis Search":{
				FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
				break;
			}
			default:

				break;
			}

			verifyCommonMethods.fieldValidation(WaitMethods.wait20driver1, nameHeader, tableFields);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User has following elements in "+nameHeader+" section of "+namePage+" page");

			TryCatchTemp.checkFlagClosure("driver1", "User has following elements in "+nameHeader+" section of "+namePage+" page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User has following elements in "+nameHeader+" section of "+namePage+" page", exception);

		} 
	}




	@Then("^User enter following fields in \"(.*?)\" section of \"(.*?)\" page$")
	public void user_enter_following_fields_in_section(String nameSection, String nameScreen, DataTable tableFieldDetails) throws Throwable {

		CommonMethods.testStepPassFlag = true;
		try {

			switch(nameSection) {
			case "Settings":
			case "Patient":
			case "Prescription":
			case "Prescriber":
			case "Drug":
			case "Drug Search":{
				FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
				break;
			}
			default:

				break;
			}

			RxCommonMethods.enterFieldValues(tableFieldDetails.raw(), nameSection);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,"tempJPEGFilePlaceHolder", "User enter following fields in " + nameSection + " section of " + nameScreen + " page");

			TryCatchTemp.checkFlagClosure("driver1", "User enter following fields in " + nameSection + " section of " + nameScreen + " page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User enter following fields in " + nameSection + " section of " + nameScreen + " page", exception);

		} 
	}


	@And("^User has following field values in \"(.*?)\" section$")
	public void user_has_following_field_values_in_section(String nameHeader, DataTable tableValues) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			switch(nameHeader) {

			case "Patient":
			case "Prescription":
			case "Drug":
			case "Prescriber":
			case "Diagnosis":{
				FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
				break;
			}
			default:

				break;
			}

			RxCommonMethods.verifyFieldValues(BrowserMethods.driver1, WaitMethods.wait20driver1, nameHeader, tableValues);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,"tempJPEGFilePlaceHolder", "User has following field values in " + nameHeader + " section");

			TryCatchTemp.checkFlagClosure("driver1", "User has following field values in " + nameHeader + " section");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User has following field values in " + nameHeader + " section", exception);

		} 
	}




	@When("^User \"(.*?)\" the \"(.*?)\" in \"(.*?)\" page$")
	public void user_the_order_in_Page(String nameAction, String nameObject, String namePage) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			if("Refresh".equals(nameAction)) {

				FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			} else {

				FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			}


			RxCommonMethods.clickButton(nameAction);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User " + nameAction + " the " + nameObject + " in " + namePage + " page");

			TryCatchTemp.checkFlagClosure("driver1", "User " + nameAction + " the " + nameObject + " in " + namePage + " page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User " + nameAction + " the " + nameObject + " in " + namePage + " page", exception);

		}
	}

	
	@When("^User performs below operation in given fields in \"(.*?)\" section of \"(.*?)\" page$")
	public void user_performs_below_operation_in_given_fields_in_section_of_page(String nameSection, String namePage, DataTable tabelFieldDetails) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			RxCommonMethods.performAction(nameSection, tabelFieldDetails);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User performs below operation in given fields in " + nameSection + " section of " + namePage + " page");

			TryCatchTemp.checkFlagClosure("driver1", "User performs below operation in given fields in " + nameSection + " section of " + namePage + " page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User performs below operation in given fields in " + nameSection + " section of " + namePage + " page", exception);

		}
	}
	
	
	
	@Then("^User performs \"(.*?)\" by using mouse click$")
	public void user_performs_by_using_mouse_click(String nameButton) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			
			By xpathHoveringButton = By.xpath(CommonWebElements.dynamicXpathButtonPart1 + nameButton + CommonWebElements.dynamicXpathButtonPart2);

			HoveringMethods.hoverOnElementAndClickOtherElement(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathHoveringButton, xpathHoveringButton);
			
			WaitMethods.waitForPegaPageLoad(WaitMethods.wait5driver1,
					WaitMethods.wait20driver1);

			WaitMethods.waitForPageLoad(BrowserMethods.driver1,
					WaitMethods.wait20driver1);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User performs " + nameButton + " by using mouse click");

			TryCatchTemp.checkFlagClosure("driver1", "User performs " + nameButton + " by using mouse click");

			
		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User performs " + nameButton + " by using mouse click", exception);

		}
	}
	
	
	@When("^User performs \"(.*?)\" by navigating using tab key starting from below field$")
	public void user_performs_by_navigating_using_tab_keys(String nameButton, DataTable tabDetails) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			
			

			TryCatchTemp.checkFlagClosure("driver1", "User performs " + nameButton + " by navigating using tab key starting from below field");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User performs " + nameButton + " by navigating using tab key starting from below field", exception);

		}
	}
}
