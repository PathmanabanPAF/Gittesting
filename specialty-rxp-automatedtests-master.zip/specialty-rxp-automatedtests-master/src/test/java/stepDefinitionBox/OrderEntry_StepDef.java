package stepDefinitionBox;

import java.util.List;

import projectBox.OrderEntry;
import projectBox.TransactionData;
import projectBox.TryCatchTemp;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class OrderEntry_StepDef {


	@Then("^User has following columns in \"(.*?)\" section of \"(.*?)\" page$")
	public void user_has_following_columns_in_section_of_page(String nameSection, String nameScreen, List<String> listOfExpectedColumns) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			OrderEntry.verifyColumns(listOfExpectedColumns);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User has following columns in " + nameSection + " section of " + nameScreen + " page");


			TryCatchTemp.checkFlagClosure("driver1", "User has following columns in " + nameSection + " section of " + nameScreen + " page");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User has following columns in " + nameSection + " section of " + nameScreen + " page", exception);
		}
	}


	@Then("^User receives following message when no orders are present in \"(.*?)\" work basket$")
	public void user_receives_following_message_when_no_orders_are_present_in_work_basket(String nameWorkBasket, List<String> listEmptyGetWorkMessage) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			OrderEntry.verifyEmptyWorkBassketMessage(listEmptyGetWorkMessage.get(0));

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User receives following message when no orders are present in "+ nameWorkBasket +" work basket");

			TryCatchTemp.checkFlagClosure("driver1", "User receives following message when no orders are present in "+ nameWorkBasket +" work basket");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User receives following message when no orders are present in "+ nameWorkBasket +" work basket", exception);
		}
	}

	@Then("^Work order count is \"(.*?)\" by \"(.*?)\" of \"(.*?)\" work basket$")
	public void work_order_count_is_increased_by_of_work_basket(String nameOfFluctuation, String expectedWorkOrderCount, String nameOfWorkBasket) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			int countOfDifference = Integer.parseInt(expectedWorkOrderCount);

			if("increased".equalsIgnoreCase(nameOfFluctuation)){


				expectedWorkOrderCount = Integer.toString(TransactionData.getWorkOrdersCount() + countOfDifference);

			} else {

				expectedWorkOrderCount = Integer.toString(TransactionData.getWorkOrdersCount() - countOfDifference);

			}


			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			OrderEntry.verifyWorkOrderCount(expectedWorkOrderCount, nameOfWorkBasket);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "Work order count is "+ nameOfFluctuation +" by " + expectedWorkOrderCount + " of " +  nameOfWorkBasket + " work basket");


			TryCatchTemp.checkFlagClosure("driver1", "Work order count is "+ nameOfFluctuation +" by " + expectedWorkOrderCount + " of " +  nameOfWorkBasket + " work basket");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "Work order count is "+ nameOfFluctuation +" by " + expectedWorkOrderCount + " of " +  nameOfWorkBasket + " work basket", exception);
		}
	}



	@Given("^User has Work Order count of \"(.*?)\" work basket in landing page$")
	public void user_has_Work_Order_count_of_work_basket_in_landing_page(String nameOfWorkBasket) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			OrderEntry.setWorkOrderCount(nameOfWorkBasket);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User has Work Order count of "+ nameOfWorkBasket +" work basket in landing page");
			TryCatchTemp.checkFlagClosure("driver1", "User has Work Order count of "+ nameOfWorkBasket +" work basket in landing page");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User has Work Order count of "+ nameOfWorkBasket +" work basket in landing page", exception);
		}
	}

	@Then("^User receives below error message after all orders are submitted$")
	public void user_receives_below_error_message(List<String> listLastOrderErrorMessages) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			OrderEntry.verifyLastWorkOrderError(listLastOrderErrorMessages.get(0));

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User receives below error message after all orders are submitted");
			TryCatchTemp.checkFlagClosure("driver1", "User receives below error message after all orders are submitted");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User receives below error message after all orders are submitted", exception);
		}
	}


	@Then("^User can view the \"(.*?)\" of work order as \"(.*?)\" in \"(.*?)\" section$")
	public void user_can_view_the_of_work_order_as_in_section(String nameField, String valueField, String nameSection) throws Throwable {

		CommonMethods.testStepPassFlag = true;

		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			OrderEntry.verifyWorkOrderStatus(nameField, valueField, nameSection);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User can view the " + nameField + " of work order as " + valueField + " in " + nameSection + " section");

			TryCatchTemp.checkFlagClosure("driver1", "User can view the " + nameField + " of work order as " + valueField + " in " + nameSection + " section");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User can view the " + nameField + " of work order as " + valueField + " in " + nameSection + " section", exception);
		}
	}

}
