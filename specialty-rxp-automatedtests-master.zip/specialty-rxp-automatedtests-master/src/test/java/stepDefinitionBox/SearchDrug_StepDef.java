package stepDefinitionBox;

import java.util.List;

import org.openqa.selenium.By;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;
import pageWebElementsBox.CommonWebElements;
import projectBox.LoadTransactionData;
import projectBox.RxCommonMethods;
import projectBox.SearchMethods;
import projectBox.SearchResultsMethods;
import projectBox.SearchTransactionData;
import projectBox.SortingMethods;
import projectBox.TryCatchTemp;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SearchDrug_StepDef {
	
	@Then("^User has following actions to perform in \"(.*?)\" screen$")
	public void user_has_following_actions_to_perform_in_screen(String nameScreen, List<String> listOfExpectedButtons) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
			
			RxCommonMethods.verifyButtons(nameScreen, listOfExpectedButtons);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User has following actions to perform in " + nameScreen + " screen"+ listOfExpectedButtons);


			TryCatchTemp.checkFlagClosure("driver1", "User has following actions to perform in " + nameScreen + " screen");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User has following actions to perform in " + nameScreen + " screen", exception);
		}
	}
	
	
	@Then("^System displays below message for \"(.*?)\" in \"(.*?)\" screen$")
	public void system_displays_below_message_for_invalid_search_in_screen(String searchReason, String nameScreen, List<String> errorMessage) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			AssertionMethods.verifyElementExists(WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathTextPart1 + errorMessage.get(0) +CommonWebElements.dynamicXpathTextPart2));

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System displays below message for " + searchReason + " in " + nameScreen + " screen");

			TryCatchTemp.checkFlagClosure("driver1", "System displays below message for " + searchReason + " in " + nameScreen + " screen");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "System displays below message for " + searchReason + " in " + nameScreen + " screen", exception);

		}
	}

	
	@Then("^User can view \"(.*?)\" search results in current search results page$")
	public void user_can_view_search_results_in_current_search_results_page(String numberOfSearchResults) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			SearchResultsMethods.verifySearchResultsCount(Integer.parseInt(numberOfSearchResults));
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User can view " + numberOfSearchResults + " search results in current search results page");

			TryCatchTemp.checkFlagClosure("driver1", "User can view " + numberOfSearchResults + " search results in current search results page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User can view " + numberOfSearchResults + " search results in current search results page", exception);

		}
	}
	
	
	@Then("^User enters below field values with \"(.*?)\" in \"(.*?)\" screen$")
	public void user_enters_below_field_values_with_in_Search_screen(String numberOfResults, String nameScreen, List<String> listOfFields) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			
			LoadTransactionData.loadDrugSearchTestData(numberOfResults);
			
			
			SearchMethods.inputSearchFields(nameScreen, listOfFields);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User enters below field values with " + numberOfResults + " in " + nameScreen + " Search screen");

			TryCatchTemp.checkFlagClosure("driver1", "User enters below field values with " + numberOfResults + " in " + nameScreen + " Search screen");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User enters below field values with " + numberOfResults + " in " + nameScreen + " Search screen", exception);

		}
	}
	
	
	@Then("^System displays message as \"(.*?)\" for below fields in \"(.*?)\" screen for \"(.*?)\" criteria$")
	public void system_displays_message_as_for_below_fields(String searchText, String nameSearch, String nameScenario, List<String> listFieldNames) throws Throwable {
		
		CommonMethods.testStepPassFlag = true;
		try {
			
			SearchMethods.verifySearchResultsTextMessage(searchText, nameSearch, nameScenario, listFieldNames);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System displays message as " + searchText + " for below fields" + listFieldNames);

			TryCatchTemp.checkFlagClosure("driver1", "System displays message as " + searchText + " for below fields" + listFieldNames);

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "System displays message as " + searchText + " for below fields" + listFieldNames, exception);

		}
	    
	}
	
	
	@Then("^System displays \"(.*?)\" results in below columns$")
	public void system_displays_results_in_below_columns(String nameSearchResults, List<String> listOfColumns) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			
			SearchMethods.verifyTableHeaders(nameSearchResults,listOfColumns);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System displays " + nameSearchResults + " results in below columns" + listOfColumns);

			TryCatchTemp.checkFlagClosure("driver1", "System displays " + nameSearchResults + " results in below columns" + listOfColumns);

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "System displays " + nameSearchResults + " results in below columns" + listOfColumns, exception);

		}
	}

	@Then("^User sorts the results by \"(.*?)\" column$")
	public void user_sorts_the_results_by_column(String colName) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			//FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
			
			SortingMethods.columnSort(colName);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User is able to sort the results by column: "+colName);


			TryCatchTemp.checkFlagClosure("driver1", "User is able to sort the results by column: "+colName);

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User is able to sort the results by column: "+colName, exception);
		}
	}
	
	@Then("^System displays the Search results with all drugs that have the \"(.*?)\" entered for the search$")
	public void system_displays_the_Search_results_with_all_drugs_that_have_the_entered_for_the_search(String colName) throws Throwable {

		String NDC = "" ;
		
		CommonMethods.testStepPassFlag = true;
		try {
			
			NDC = SearchTransactionData.getDrugNdc();
		
			SearchMethods.verifySearchResultsNDC(NDC,colName);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System displayed all the results for the searched Ndc: "+NDC);

			TryCatchTemp.checkFlagClosure("driver1", "System displayed all the results for the searched Ndc: "+NDC);

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "System displayed all the results for the searched Ndc: "+ NDC, exception);

		}
	    
	}
	
	@Then("^System displays all the search criteria even after the \"(.*?)\" results are displayed$")
	public void system_displays_all_the_search_criteria_even_after_the_results_are_displayed(String nameScreen) throws Throwable {

		String NDC = "" ;
		
		String DrugName = "";
		
		CommonMethods.testStepPassFlag = true;
		try {
			
			NDC = SearchTransactionData.getDrugNdc();
			
			DrugName = SearchTransactionData.getDrugName();
			
			SearchMethods.verifySearchCriteriaNDC(NDC, DrugName, nameScreen);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System displayed all the search criteria even after the results are displayed");

			TryCatchTemp.checkFlagClosure("driver1", "System displayed all the search criteria even after the results are displayed");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "System displayed all the search criteria even after the results are displayed", exception);

		}
		
		
	}

/*	@Then("^User initiates another \"(.*?)\" by keying new NDC$")
	public void user_initiates_another_by_keying_new_NDC(String nameScreen) throws Throwable {


		String NDC = "" ;
		
		String DrugName = "";
		
		CommonMethods.testStepPassFlag = true;
		try {
			
			NDC = SearchTransactionData.getDrugNdc();
			
			DrugName = SearchTransactionData.getDrugName();
			
	

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System displayed all the results for the searched Ndc: "+NDC);

			TryCatchTemp.checkFlagClosure("driver1", "System displayed all the results for the searched Ndc: "+NDC);

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "System displayed all the results for the searched Ndc: "+ NDC, exception);

		}
	}*/
		


	@When("^User can \"(.*?)\" a result with below Columns from the \"(.*?)\" Results$")
	public void user_can_a_result_from_the_Results(String nameButton, String typeOfSearch,List<String> listOfColumns) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			SearchMethods.selectSearchResultsRow(typeOfSearch, listOfColumns);
			
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User " + nameButton + " a result from the " + typeOfSearch + " Results");


			TryCatchTemp.checkFlagClosure("driver1", "User can " + nameButton + " a result from the " + typeOfSearch + " Results");

		} catch (Exception exception){
			
			TryCatchTemp.exceptionClosure("driver1", "User can " + nameButton + " a result from the " + typeOfSearch + " Results", exception);
		}
	}

	@Then("^User has correct populated below drug details in \"(.*?)\" section of \"(.*?)\" screen$")
	public void user_has_correct_populated_below_drug_details_in_section_of_screen(String nameSection, String nameScreen, List<String> listOfFields) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			SearchMethods.verifyDrugValue(nameSection, listOfFields.get(0), "Text Box");
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User has correct populated below drug details in " + nameSection + " section of " + nameScreen + " screen");


			TryCatchTemp.checkFlagClosure("driver1", "User has correct populated below drug details in " + nameSection + " section of " + nameScreen + " screen");

		} catch (Exception exception){
			
			TryCatchTemp.exceptionClosure("driver1", "User has correct populated below drug details in " + nameSection + " section of " + nameScreen + " screen", exception);
		}
	}
	
	@Then("^User receives the \"(.*?)\" results based on \"(.*?)\" in below columns$")
	public void user_receives_the_results_based_on_in_below_columns(String typeOfResults, String functionToBeChecked, DataTable tableColumnData) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			List<List<String>> listOfColumnData = tableColumnData.raw();
			
			SearchMethods.verifyColumnStartswithValues(typeOfResults, listOfColumnData.get(0).get(0), listOfColumnData.get(0).get(1));
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User receives the " + typeOfResults + " results based on " + functionToBeChecked + "in below columns");


			TryCatchTemp.checkFlagClosure("driver1", "User receives the " + typeOfResults + " results based on " + functionToBeChecked + "in below columns");

		} catch (Exception exception){
			
			TryCatchTemp.exceptionClosure("driver1", "User receives the " + typeOfResults + " results based on " + functionToBeChecked + "in below columns", exception);
		}
	}
	
	
}

