package stepDefinitionBox;

import java.util.List;

import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.ScreenshotMethods;
import projectBox.ExcelDataMethods;
import projectBox.TryCatchTemp;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ExcelData_StepDef

{

	@When("^User enters below field values in \"(.*?)\" section for \"(.*?)\" criteria$")
	public void user_enters_below_field_values_in_section_for_criteria(String nameSection, String nameScenario, DataTable tableFieldData) throws Throwable 
	{
		CommonMethods.testStepPassFlag = true;
		try {

			ExcelDataMethods.enterExcelData(nameSection, nameScenario, tableFieldData);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User enters below field values in " + nameSection + " section for " + nameScenario + " criteria");

			TryCatchTemp.checkFlagClosure("driver1", "User enters below field values in " + nameSection + " section for " + nameScenario + " criteria");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User enters below field values in " + nameSection + " section for " + nameScenario + " criteria", exception);

		}

	}
	
	@Then("^User receives below \"(.*?)\" column values in \"(.*?)\" results for \"(.*?)\" criteria$")
	public void user_receives_below_column_values_in_results_for_criteria(String typeResults, String nameSearch, String nameScenario, List<String> listOfColumnNames) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			ExcelDataMethods.verifySearchresultsColumnsData(nameSearch,nameScenario, typeResults, listOfColumnNames);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User receives below " + typeResults + " column values in " + nameSearch+ " results for " + nameScenario + " criteria");

			TryCatchTemp.checkFlagClosure("driver1", "User receives below " + typeResults + " column values in " + nameSearch+ " results for " + nameScenario + " criteria");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User receives below " + typeResults + " column values in " + nameSearch+ " results for " + nameScenario + " criteria", exception);

		}
		
	   
	}
	
	
	@Then("^User gets below \"(.*?)\" column values in \"(.*?)\" results for \"(.*?)\" criteria$")
	public void user_gets_below_column_values_in_results_for_criteria(String typeResults, String nameSearch, String nameScenario, List<String> listOfColumnNames) throws Throwable {
	   
		CommonMethods.testStepPassFlag = true;
		
		try {

			ExcelDataMethods.verifyPhoneNumberSearchResults(nameSearch,nameScenario, typeResults, listOfColumnNames);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User gets below " + typeResults + " column values in " + nameSearch+ " results for " + nameScenario + " criteria");

			TryCatchTemp.checkFlagClosure("driver1", "User gets below " + typeResults + " column values in " + nameSearch+ " results for " + nameScenario + " criteria");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User gets below " + typeResults + " column values in " + nameSearch+ " results for " + nameScenario + " criteria", exception);

		}
	}
	
	
	@Then("^User receives below \"(.*?)\" column values with pagination in \"(.*?)\" results for \"(.*?)\" criteria$")
	public void user_receives_below_column_values_with_pagination_in_results_for_criteria(String typeResults, String nameSearch, String nameScenario, List<String> listOfColumnNames) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User receives below " + typeResults + " column values with pagination in " + nameSearch+ " results for " + nameScenario + " criteria");

			TryCatchTemp.checkFlagClosure("driver1", "User receives below " + typeResults + " column values with pagination in " + nameSearch+ " results for " + nameScenario + " criteria");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User receives below " + typeResults + " column values with pagination in " + nameSearch+ " results for " + nameScenario + " criteria", exception);

		}
	}
	

}
