package stepDefinitionBox;

import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;

import java.util.List;

import org.openqa.selenium.By;

import pageWebElementsBox.CommonWebElements;
import projectBox.ReviewPatientInfoMethods;
import projectBox.RxCommonMethods;
import projectBox.SearchMethods;
import projectBox.TryCatchTemp;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ReviewPatientInfo_StepDef {

	@Then("^User has following field values in \"(.*?)\" section received from API$")
	public void user_has_following_field_values_section_obtained_from_API(String nameSection, List<String> ListOfFields) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

				FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
				switch(nameSection.toUpperCase()){
					case "PATIENT":
						ReviewPatientInfoMethods.verifyPatientInfoWithAPI(nameSection, ListOfFields);
						break;
					case "DRUG":
						break;
					case "PRESCRIBER":
						SearchMethods.verifyPrescriberInfoWithAPI(nameSection, ListOfFields);
						break;
				}
				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
						"tempJPEGFilePlaceHolder", "User has following field values in " + nameSection + " section received from API");
			TryCatchTemp.checkFlagClosure("driver1", "User has following field values in " + nameSection + " section received from API");

			} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User has following field values in " + nameSection + " section received from API", exception);
		}
	}



	@Then("^User has correct \"(.*?)\" in \"(.*?)\" format based on \"(.*?)\" in \"(.*?)\" section$")
	public void user_has_correct_in_format_based_on_in_section(String nameField, String format, String dependField, String nameSection) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			ReviewPatientInfoMethods.verifyPatientAge(nameField, format, dependField, nameSection);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User has correct " + nameField + " in " + format + " format based on " + dependField + " in " + nameSection + " section");
			TryCatchTemp.checkFlagClosure("driver1", "User has correct " + nameField + " in " + format + " format based on " + dependField + " in " + nameSection + " section");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User has correct " + nameField + " in " + format + " format based on " + dependField + " in " + nameSection + " section", exception);
		}


	}

	@Then("^User has following \"(.*?)\" received from \"(.*?)\" API$")
	public void user_has_following_received_from_API(String nameSubSection, String nameAPI, List<String> listOfAdditionalAddressFields) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);

			ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, By.xpath(CommonWebElements.dynamicXpathTextPart1 + nameSubSection + CommonWebElements.dynamicXpathTextPart2));

			ReviewPatientInfoMethods.verifyPatientInfoWithAPI(nameSubSection, listOfAdditionalAddressFields);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User has following " + nameSubSection + " received from " + nameAPI + " API");
			TryCatchTemp.checkFlagClosure("driver1", "User has following " + nameSubSection + " received from " + nameAPI + " API");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User has following " + nameSubSection + " received from " + nameAPI + " API", exception);
		}
	}

	@When("^User selects \"(.*?)\" unit as \"(.*?)\" in \"(.*?)\" section of \"(.*?)\" page$")
	public void user_selects_unit_as_in_section_of_page(String nameField, String valueWeightUnit, String nameSection, String namePage) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
	
			ReviewPatientInfoMethods.selectFieldValueFromDropDown(nameField, valueWeightUnit, nameSection);
			
			WaitMethods.waitForPageLoad(BrowserMethods.driver1, WaitMethods.wait20driver1);

			WaitMethods.waitForPegaPageLoad(WaitMethods.wait5driver1, WaitMethods.wait20driver1);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User selects " + nameField + " unit as " + valueWeightUnit + " in " + nameSection + " section of " + namePage + " page");
			TryCatchTemp.checkFlagClosure("driver1", "User selects " + nameField + " unit as " + valueWeightUnit + " in " + nameSection + " section of " + namePage + " page");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User selects " + nameField + " unit as " + valueWeightUnit + " in " + nameSection + " section of " + namePage + " page", exception);
		}
	}

	@Then("^User can view converted \"(.*?)\" value \"(.*?)\" in \"(.*?)\" in \"(.*?)\" section of \"(.*?)\" page$")
	public void user_gets_converted_value_in_in_section_of_page(String nameField, String valueToBeConverted, String nameWeightUnit, String nameSection, String namePage) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			ReviewPatientInfoMethods.verifyConvertedWeightValues(nameField, valueToBeConverted, nameWeightUnit, nameSection);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User can view converted " + nameField + " value " + valueToBeConverted +" in " + nameWeightUnit + " in " + nameSection + " section of " + namePage + " page");

			TryCatchTemp.checkFlagClosure("driver1", "User can view converted " + nameField + " value " + valueToBeConverted +" in " + nameWeightUnit + " in " + nameSection + " section of " + namePage + " page");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User can view converted " + nameField + " value " + valueToBeConverted +" in " + nameWeightUnit + " in " + nameSection + " section of " + namePage + " page", exception);
		}
	}

	@Then("^User does not have following fields in \"(.*?)\" section of \"(.*?)\" page$")
	public void user_does_not_have_following_fields_in_section_of_page(String nameSection, String namePage, DataTable tableReportedTime) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
			
			RxCommonMethods.verifyFieldNonExistance(nameSection, tableReportedTime);
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User does not have following fields in  "+nameSection+" section of "+namePage+" page");

			TryCatchTemp.checkFlagClosure("driver1", "User does not have following fields in  "+nameSection+" section of "+namePage+" page");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User does not have following fields in  "+nameSection+" section of "+namePage+" page", exception);
		}

	}
	
	
	@When("^User enters \"(.*?)\" value as \"(.*?)\" in \"(.*?)\" section of \"(.*?)\" page$")
	public void user_enters_unit_as_in_section_of_page(String nameField, String valueWeight, String nameSection, String namePage) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
	
			ReviewPatientInfoMethods.inputTextValue(nameField, valueWeight, nameSection);
			
			WaitMethods.waitForPageLoad(BrowserMethods.driver1, WaitMethods.wait20driver1);

			WaitMethods.waitForPegaPageLoad(WaitMethods.wait5driver1, WaitMethods.wait20driver1);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User enters " + nameField + " value as " + valueWeight + " in " + nameSection + " section of " + namePage + " page");
			TryCatchTemp.checkFlagClosure("driver1", "User enters " + nameField + " value as " + valueWeight + " in " + nameSection + " section of " + namePage + " page");

		} catch (Exception exception){
			TryCatchTemp.exceptionClosure("driver1", "User enters " + nameField + " value as " + valueWeight + " in " + nameSection + " section of " + namePage + " page", exception);
		}
	}


}
