package stepDefinitionBox;

import projectBox.OrderEntry;
import projectBox.RxCommonMethods;
import projectBox.TryCatchTemp;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;
import cucumber.api.java.en.Then;

public class GetWork_StepDef {
	

	@Then("^System retrieves work order in First In First Out sequence from \"(.*?)\" work basket$")
	public void system_retrieves_work_order_in_First_In_First_Out_sequence_from_work_basket(String nameWorkbasket) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
				
			OrderEntry.verifyWorkOrderFifoSequence(nameWorkbasket);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System retrieves work order in First In First Out sequence from " + nameWorkbasket + " work basket");

			
			TryCatchTemp.checkFlagClosure("driver1", "System retrieves work order in First In First Out sequence from " + nameWorkbasket + " work basket");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "System retrieves work order in First In First Out sequence from " + nameWorkbasket + " work basket", exception);

		}
	}


	@Then("^System creates a new referral case$")
	public void system_creates_a_new_referral_case() throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);
			
			OrderEntry.verifyFirstCaseCreation();
			
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System creates a new referral case");
			
			TryCatchTemp.checkFlagClosure("driver1", "System creates a new referral case");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "System creates a new referral case", exception);

		}
	}

	@Then("^System creates another referral case$")
	public void system_creates_another_new_referral_case() throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			OrderEntry.verifySecondCaseCreation();
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System creates a second work order");
			
			TryCatchTemp.checkFlagClosure("driver1", "System creates a second work order");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "System creates a second work order", exception);

		}
	}
	
	
	
	@Then("^System retrieves first Work Order from work basket$")
	public void system_retrieves_first_Work_Order_from_work_basket() throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
	
			
			OrderEntry.verifyGetWorkFirstOrder();
			
			OrderEntry.patientName();
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System retrieves first Work Order from work basket");
			
			TryCatchTemp.checkFlagClosure("driver1", "System retrieves first Work Order from work basket");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "System retrieves first Work Order from work basket", exception);

		}
	}


	@Then("^User \"(.*?)\" the Order$")
	public void user_the_Order(String nameButton) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			
			RxCommonMethods.clickButton(nameButton);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User " + nameButton + " the Order");
			
			TryCatchTemp.checkFlagClosure("driver1", "User " + nameButton + " the Order");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User " + nameButton + " the Order", exception);

		}
	}

	@Then("^System retrieves second Work Order from work basket$")
	public void system_retrieves_second_Work_Order_from_work_basket() throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			
			OrderEntry.verifyGetWorkSecondOrder();
			
			TryCatchTemp.checkFlagClosure("driver1", "System retrieves second Work Order from work basket");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "System retrieves second Work Order from work basket", exception);

		}
	}
}
