package stepDefinitionBox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import cucumber.api.java.en.Given;

public class test {
	@Given("^User login$")
	public void user_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		
		//System.setProperty("webdriver.ie.driver", "C:\\specialty-rxp-automatedtests-master\\target\\test-classes\\IEBrowserResource\\IE\\IEDriverServer.exe");
			
		//Firefox Browser
		System.setProperty("webdriver.gecko.driver", "C:\\Working Drivers\\geckodriver.exe");
		//It create firefox profile
		ProfilesIni prof=new ProfilesIni();
		FirefoxProfile profile=prof.getProfile("seleniumprofile");
		// This will set the true value
		profile.setAcceptUntrustedCertificates(true);
		profile.setAssumeUntrustedCertificateIssuer(false);
		WebDriver driver=new FirefoxDriver(profile);
		//webdriver.gecko.driver*/
		
		//Chrome Browser
		/*System.setProperty("webdriver.chrome.driver", "C:\\Working Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();*/
	
		/*System.setProperty("webdriver.ie.driver", "C:\\Working Drivers\\IEDriverServer.exe");
		Thread.sleep(7000);
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	
	
		WebDriver driver = new InternetExplorerDriver(capabilities);*/
		
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.get("https://www.google.com");
		Thread.sleep(7000);
		//driver.get("http://thehub.express-scripts.com/default.aspx");
		driver.quit();
	}


}
