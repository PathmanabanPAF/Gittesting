package stepDefinitionBox;

import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;
import projectBox.OrderEntry;
import projectBox.TryCatchTemp;
import cucumber.api.DataTable;
import cucumber.api.java.en.When;

public class ReviewDrugAPI_StepDef {

	@When("^User has following field values in \"(.*?)\" section prepopulated from \"(.*?)\" API$")
	public void user_has_following_field_values_in_section_prepopulated_from_API(String nameHeader, String nameAPI, DataTable tableValues) throws Throwable {

			CommonMethods.testStepPassFlag = true;

			try {
			
				FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);
				
				switch(nameHeader){
				
				case "Drug" :

					OrderEntry.verifyDrugAPIValues(nameHeader, tableValues);
					
					break;
				
				case "Prescription" :

					OrderEntry.verifyPrescriptionAPIValues(nameHeader, tableValues);
					
					break;

				}

				ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User has following field values in " + nameHeader + " section prepopulated from " + nameAPI+ " API");

				TryCatchTemp.checkFlagClosure("driver1", "User has following field values in " + nameHeader + " section prepopulated from " + nameAPI+ " API");

			} catch (Exception exception) {

				TryCatchTemp.exceptionClosure("driver1", "User has following field values in " + nameHeader + " section prepopulated from " + nameAPI+ " API", exception);

			}
		
	}

}
