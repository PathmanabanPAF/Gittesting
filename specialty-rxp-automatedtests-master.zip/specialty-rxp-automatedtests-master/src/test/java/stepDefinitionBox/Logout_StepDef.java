package stepDefinitionBox;

import pageWebElementsBox.LoginPage;
import projectBox.GetWorkMethods;
import projectBox.LogOffMethods;
import projectBox.TryCatchTemp;
import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Logout_StepDef {

	@When("^User can \"(.*?)\" from the application$")
	public void user_can_from_the_application(String userAction) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			LogOffMethods.performLogOut(userAction);

			WaitMethods.waitForPageLoad(BrowserMethods.driver1, WaitMethods.wait20driver1);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User can " + userAction + " from the application");
			
			TryCatchTemp.checkFlagClosure("driver1", "User can " + userAction + " from the application");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User can " + userAction + " from the application", exception);

		}
	}

	
	@When("^User is navigated to RxProcessing login page$")
	public void user_is_navigated_to_RxProcessing_login_page() throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			AssertionMethods.verifyElementExists(WaitMethods.wait20driver1, LoginPage.iDUsername);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User is navigated to RxProcessing login page");

			TryCatchTemp.checkFlagClosure("driver1", "User is navigated to RxProcessing login page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User is navigated to RxProcessing login page", exception);

		}
	}
	
	
	
	@Then("^User can \"(.*?)\" from the application \"(.*?)\" saving data$")
	public void user_can_from_the_application_saving_data(String userAction, String without) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			LogOffMethods.performLogOut(userAction);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User can " + userAction + " from the application " + without + " saving data");
			
			TryCatchTemp.checkFlagClosure("driver1", "User can " + userAction + " from the application " + without + " saving data");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User can " + userAction + " from the application " + without + " saving data", exception);

		}
	}




	@Given("^User has no work orders in \"(.*?)\" work basket$")
	public void user_has_no_work_orders_in_work_basket(String workBasketname) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			
			GetWorkMethods.previousWorkClearance(workBasketname);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User has no work orders in " + workBasketname + " work basket");
			
			TryCatchTemp.checkFlagClosure("driver1", "User has no work orders in " + workBasketname + " work basket");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User has no work orders in " + workBasketname + " work basket", exception);

		}
	}


	

}




