package stepDefinitionBox;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;


import java.util.List;


import pageWebElementsBox.LandingPage;
import projectBox.LandingMethods;
import projectBox.RxCommonMethods;
import projectBox.TryCatchTemp;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Landing_StepDef {

	@When("^User is navigated to \"(.*?)\"$")
	public void user_is_navigated_to(String nameScreen) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {
		
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);
			
			AssertionMethods.verifyElementExists( WaitMethods.wait10driver1,
					LandingPage.xpathTRCValue);

			/*FrameHandlingMethods.switchToDefaultFrame(BrowserMethods.driver1, WaitMethods.wait20driver1);
			 By xpathPortalheader = DynamicXpathCalculation.dynamicXpathCreation(LandingPage.xpathLandingPageHeaderPart1, nameScreen, LandingPage.xpathLandingPageHeaderPart2);

			AssertionMethods.verifyElementExists(WaitMethods.wait20driver1, xpathPortalheader);*/

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User is navigated to "+ nameScreen);

			TryCatchTemp.checkFlagClosure("driver1", "User is navigated to "+ nameScreen);

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User is navigated to "+ nameScreen, exception);

		}
	}



	@When("^User selects \"(.*?)\" from \"(.*?)\" options in landing page$")
	public void user_selects_from_options_in_landing_page(String nameOption, String nameLink) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			LandingMethods.createOption(nameLink, nameOption);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User selects "+nameOption+" from "+nameLink+" options in landing page");

			TryCatchTemp.checkFlagClosure("driver1", "User selects "+ nameOption +" from "+nameLink+" options in landing page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User selects "+ nameOption +" from "+nameLink+" options in landing page", exception);

		}

	}


	@Then("^User is able to view following TRC values that they are assigned to$")
	public void user_is_able_to_view_the_TRC_value_that_they_are_assigned_to(
			List<String> expectedTrcValues) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			LandingMethods.verifyTRCValues(expectedTrcValues);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User is able to view following TRC values that they are assigned to");

			TryCatchTemp.checkFlagClosure("driver1", "User is able to view following TRC values that they are assigned to");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User is able to view following TRC values that they are assigned to", exception);

		}
	}

	@Then("^User is able to view following Work baskets for assigned TRCs$")
	public void user_is_able_to_view_following_Work_baskets_for_assigned_TRCs(
			List<String> expectedWorkBaskets) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			LandingMethods.verifyWorkBaskets(expectedWorkBaskets);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User is able to view following Work baskets for assigned TRCs"+ expectedWorkBaskets.get(0));

			TryCatchTemp.checkFlagClosure("driver1", "User is able to view following Work baskets for assigned TRCs"+ expectedWorkBaskets.get(0));

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User is able to view following Work baskets for assigned TRCs"+ expectedWorkBaskets.get(0), exception);

		}
	}

	@Then("^User is able to view count of Work in Progress for following Work baskets$")
	public void user_is_able_to_view_count_of_Work_in_Progress_for_below_Workbaskets(
			List<String> listWorkBaskets) throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {

			LandingMethods.verifyWIPCountView(listWorkBaskets);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User is able to view count of Work in Progress for following Work baskets"+ listWorkBaskets);

			TryCatchTemp.checkFlagClosure("driver1", "User is able to view count of Work in Progress for following Work baskets");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User is able to view count of Work in Progress for following Work baskets", exception);

		}
	}

	@Then("^User is able to view the Accredo logo$")
	public void user_is_able_to_view_the_Accredo_logo() throws Throwable {
		CommonMethods.testStepPassFlag = true;

		try {
			FrameHandlingMethods.switchToDefaultFrame(BrowserMethods.driver1, WaitMethods.wait20driver1);
			AssertionMethods.verifyElementExists(WaitMethods.wait20driver1, LandingPage.xpathAccredoLogo);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User is able to view the Accredo logo");

			TryCatchTemp.checkFlagClosure("driver1", "User is able to view count of Work in Progress for following Work baskets");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User is able to view count of Work in Progress for following Work baskets", exception);

		}
	}



	@When("^User selects the \"(.*?)\" work basket in Landing page$")
	public void user_selects_the_work_basket_in_Landing_page(String nameWorkbasket) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			RxCommonMethods.clickButton(nameWorkbasket);			
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User selects the "+ nameWorkbasket +" work basket in Landing page");

			TryCatchTemp.checkFlagClosure("driver1", "User selects the "+ nameWorkbasket +" work basket in Landing page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User selects the "+ nameWorkbasket +" work basket in Landing page", exception);

		}
	}


	@When("^User has navigated to login screen of RxProcessing application$")
	public void user_has_navigated_to_login_screen_of_RxProcessing_application() throws Throwable {

		CommonMethods.testStepPassFlag = true;

		try {

			CommonMethods.initializeBrowser("driver1", "url");

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,"tempJPEGFilePlaceHolder",
					"User has navigated to login screen of RxProcessing application");

			TryCatchTemp.checkFlagClosure("driver1", "User has navigated to login screen of RxProcessing application");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User has navigated to login screen of RxProcessing application", exception);

		}

	}


	@Then("^User gets the below details in \"(.*?)\"$")
	public void user_gets_the_below_details_in(String nameColumn, List<String> FieldNames) throws Throwable {

		CommonMethods.testStepPassFlag=true; 
		try{  
			LandingMethods.updatedBy();

			LandingMethods.VerifyLockedCaseDetails(nameColumn,  FieldNames);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User gets the locked orders below details in " + nameColumn);


			TryCatchTemp.checkFlagClosure("driver1", "User gets the locked orders below details in " + nameColumn);

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User gets the locked orders below details in " + nameColumn, exception);

		}
	}


	@Then("^User will not be able to view the last created case Id in \"(.*?)\" list$")
	public void user_will_not_be_able_to_view_the_last_created_case_Id_in_list(String mylockedCases) throws Throwable {
		CommonMethods.testStepPassFlag =true;
		try{  

			LandingMethods.verifyMylockedCaseExistence();	

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User will not be able to view the last created case Id in " + mylockedCases + " list");

			TryCatchTemp.checkFlagClosure("driver1", "User will not be able to view the last created case Id in " + mylockedCases + " list");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User will not be able to view the last created case Id in " + mylockedCases + " list", exception);

		}
	}
}
