package stepDefinitionBox;

import org.openqa.selenium.By;

import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.HoveringMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;
import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.OrderEntryPage;
import projectBox.ExcelDataMethods;
import projectBox.RxCommonMethods;
import projectBox.TryCatchTemp;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SupervisingPrescriberSearch_StepDef {
	
	@When("^User navigates to \"(.*?)\" tab in \"(.*?)\" page$")
	public void user_navigates_to_tab_in_page(String nameTab, String namePage) throws Throwable {	
		
		CommonMethods.testStepPassFlag = true;
		 
		try {
			
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);
			
			HoveringMethods.hoverOnElement(BrowserMethods.driver1, WaitMethods.wait10driver1, OrderEntryPage.xpathReferralCaseId);
			
			RxCommonMethods.clickLink(nameTab);
			

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User navigates to " + nameTab + " tab in " + namePage + " page");

			TryCatchTemp.checkFlagClosure("driver1", "User navigates to " + nameTab + " tab in " + namePage + " page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User navigates to " + nameTab + " tab in " + namePage + " page", exception);

		}
	}
	
	
	
	@Then("^User selects \"(.*?)\" search look up in \"(.*?)\" page$")
	public void user_selects_search_look_up_in_page(String nameSearch, String namePage) throws Throwable {
		
		CommonMethods.testStepPassFlag = true;
		
		try {
			String xpathHeader = RxCommonMethods.getHeaderXpath(nameSearch);
			By xpathSearchLookUp = By.xpath(xpathHeader + CommonWebElements.dynamicXpathSearchIconPart3);
			
			ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathSearchLookUp);
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User selects " + nameSearch + " search look up in " + namePage + " page");

			TryCatchTemp.checkFlagClosure("driver1", "User selects " + nameSearch + " search look up in " + namePage + " page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User selects " + nameSearch + " search look up in " + namePage + " page", exception);

		}
	}



	@When("^User selects single record based on below values in \"(.*?)\" section for \"(.*?)\" criteria$")
	public void user_selects_single_record_based_on_below_values_in_section_for_criteria(String nameSection, String nameScenario, DataTable tableFieldData) throws Throwable 
	{
		String ReportMessage = "User is able to select single result in Supervising the Prescriber search";
		CommonMethods.testStepPassFlag = true;
		try {
			//FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
			RxCommonMethods.clickButton("Search");
			ExcelDataMethods.selectSignleRecord(nameSection, nameScenario, tableFieldData);
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
			TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
		} catch (Exception exception) {
			TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
		}	
	}
	@Then("^User is able to verify below \"(.*?)\" details selected in \"(.*?)\" for \"(.*?)\" criteria$")
	public void user_is_able_to_verify_below_details_selected_in_for_criteria(String nameSection, String nameSheet, String nameScenario, DataTable tableFieldData) throws Throwable 	
	{
		String ReportMessage = "User is able to select single result in Supervising the Prescriber search";
		CommonMethods.testStepPassFlag = true;
		try {
			//FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
			ExcelDataMethods.verifyFieldValues(nameSection,nameSheet, nameScenario, tableFieldData);
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", ReportMessage );
			TryCatchTemp.checkFlagClosure("driver1", ReportMessage);
		} catch (Exception exception) {
			TryCatchTemp.exceptionClosure("driver1", ReportMessage, exception);
		}	
	}
	
}
