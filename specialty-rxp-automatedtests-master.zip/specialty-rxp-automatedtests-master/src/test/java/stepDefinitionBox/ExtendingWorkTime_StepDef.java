package stepDefinitionBox;

import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;

import java.util.List;

import pageWebElementsBox.LoginPage;
import projectBox.ExtendingTimeMethods;
import projectBox.OrderEntry;
import projectBox.RxCommonMethods;
import projectBox.TaskTimeOutMethods;
import projectBox.TryCatchTemp;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ExtendingWorkTime_StepDef {

	@When("^User works for \"(.*?)\" minutes in \"(.*?)\" page$")
	public void user_works_for_minutes_in_page(String workTime, String nameScreen) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			TaskTimeOutMethods.continueWorkInWorkOrderPage(workTime);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User works for " + workTime + " minutes in " + workTime + " page");

			TryCatchTemp.checkFlagClosure("driver1", "User works for " + workTime + " minutes in " + workTime + " page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User works for " + workTime + " minutes in " + workTime + " page", exception);

		}
	}

	@Then("^User gets \"(.*?)\" message box with below text$")
	public void user_gets_message_box_with_below_text(String titlePopup, List<String> listMessages) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			TaskTimeOutMethods.validatePopup(titlePopup, listMessages.get(0));

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User gets " + titlePopup + " message box with below text");

			TryCatchTemp.checkFlagClosure("driver1", "User gets " + titlePopup + " message box with below text");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User gets " + titlePopup + " message box with below text", exception);

		}
	}



	@Then("^User does not get \"(.*?)\" message box with below text$")
	public void user_does_not_get_message_box_with_below_text(String titlePopup, List<String> listMessages) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			WaitMethods.waitForElementInvisibility( WaitMethods.wait10driver1, LoginPage.idTimeoutModalWindow);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User does not get " + titlePopup + " message box with below text");

			TryCatchTemp.checkFlagClosure("driver1", "User does not get " + titlePopup + " message box with below text");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User does not get " + titlePopup + " message box with below text", exception);

		} 
	}
	@Then("^User stays on the same work order in \"(.*?)\" page$")
	public void user_stays_on_the_same_work_order_in_page(String nameScreen) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

			OrderEntry.verifyGetWorkFirstOrder();

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User stays on the same work order in " + nameScreen + " page");

			TryCatchTemp.checkFlagClosure("driver1", "User stays on the same work order in " + nameScreen + " page");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User stays on the same work order in " + nameScreen + " page", exception);

		}
	}


	@When("^User performs no action in the \"(.*?)\" screen for \"(.*?)\" seconds$")
	public void user_performs_no_action_in_the_pop_up_for_seconds(String namePopUp, String waitTime) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			RxCommonMethods.waitForTime(waitTime);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User performs no action in the " + namePopUp + " pop up for "+ waitTime +" seconds");

			TryCatchTemp.checkFlagClosure("driver1", "User performs no action in the " + namePopUp + " pop up for "+ waitTime +" seconds");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User performs no action in the " + namePopUp + " pop up for "+ waitTime +" seconds", exception);

		}
	}



	@When("^User selects \"(.*?)\" from \"(.*?)\" menu option in the application$")
	public void user_selects_from_menu_option_in_the_application(String nameFavoriteOption, String nameMenuOption) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToDefaultFrame(BrowserMethods.driver1, WaitMethods.wait10driver1);

			ExtendingTimeMethods.navigateToExtendingTimePage(nameFavoriteOption, nameMenuOption);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User selects " + nameFavoriteOption + " from " + nameMenuOption + " menu option in the application");

			TryCatchTemp.checkFlagClosure("driver1", "User selects " + nameFavoriteOption + " from " + nameMenuOption + " menu option in the application");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User selects " + nameFavoriteOption + " from " + nameMenuOption + " menu option in the application", exception);

		}
	}

	@When("^User selects \"(.*?)\" from log off menu of the application$")
	public void user_selects_from_log_off_menu_of_the_application(String nameMenuOption) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			FrameHandlingMethods.switchToDefaultFrame(BrowserMethods.driver1, WaitMethods.wait10driver1);

			ExtendingTimeMethods.hoverOnMenuOption(nameMenuOption);

			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder", "User selects " + nameMenuOption + " from log off menu of the application");

			TryCatchTemp.checkFlagClosure("driver1", "User selects " + nameMenuOption + " from log off menu of the application");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User selects " + nameMenuOption + " from log off menu of the application", exception);

		}
	}

	@Then("^User does not find below options to edit Extending Time in \"(.*?)\" tab$")
	public void user_does_not_find_below_options_to_edit_Extending_Time_in_tab(String nameTab, List<String> listOfFavoriteOptions) throws Throwable {
		CommonMethods.testStepPassFlag = true;
		try {

			ExtendingTimeMethods.verifyExtendingTimeOptionsNotPresent(nameTab, listOfFavoriteOptions);


			TryCatchTemp.checkFlagClosure("driver1", "User does not find below options to edit Extending Time in " + nameTab + " tab");

		} catch (Exception exception) {

			TryCatchTemp.exceptionClosure("driver1", "User does not find below options to edit Extending Time in " + nameTab + " tab", exception);

		}
	}
}
