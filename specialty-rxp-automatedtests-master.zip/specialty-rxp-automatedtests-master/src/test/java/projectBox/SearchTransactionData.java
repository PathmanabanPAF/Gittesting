package projectBox;

import java.util.ArrayList;
import java.util.List;

public class SearchTransactionData {

	public static String nameDrug = LoadTransactionData.rowDataDrugSearch.get("Drug Name");
	
	public static String detailLevelDrug = LoadTransactionData.rowDataDrugSearch.get("Detail Level");
	
	public static String ndcDrug = LoadTransactionData.rowDataDrugSearch.get("NDC");	
	
	public static String ndcDrug9 = LoadTransactionData.rowDataDrugSearch.get("NDC-9");
	
	public static String specialtyDrug = LoadTransactionData.rowDataDrugSearch.get("Specialty");
	
	public static String icdCode1 = LoadTransactionData.rowDataDrugSearch.get("ICD Code");
	
	public static String icdDescription1 = LoadTransactionData.rowDataDrugSearch.get("ICD Description");
	
	public static String icdCode2 = LoadTransactionData.rowDataDrugSearch.get("ICD Code");
	
	public static String icdDescription2 = LoadTransactionData.rowDataDrugSearch.get("ICD Description");
		
	public static String getDrugName() { return nameDrug;	}
	
	public static String getDrugDetailLevel() { return detailLevelDrug;	}
	
	public static void setDrugName(String drugName) { nameDrug = drugName; }
	
	public static void setDrugNdc(String drugNDC) { ndcDrug = drugNDC; }
	
	public static String getDrugNdc() { return ndcDrug;	}
		
	public static String icdCode1() { return ndcDrug;	}
	
	public static void setDrugNdc9(String drugNDC9) { ndcDrug9 = drugNDC9; }
	
	public static String getDrugNdc9() { return ndcDrug9;	}
	
	public static String getDrugSpeciality() { return specialtyDrug; }
	
	public static String geticdCode1() { return icdCode1; }
	
	public static String geticdDescription1() { return icdDescription1; }
	
	public static String geticdCode2() { return icdCode2; }
	
	public static String geticdDescription2() { return icdDescription2; }
	
	public static List<List<String>> listValues = new ArrayList<List<String>>();
	/*
	 * <Method Name> :  setDefaultPrescriptionList
	 * <Description> :  Set Default PrescriptionList
	 * <Input Parameter1 > userRole : User name
	 * <Output> : NA
	 */
	public static void setDefaultICDList(List<List<String>> expList)
	{
		listValues = expList;
	}	
	/*
	 * <Method Name> :  getDefaultPrescriptionList
	 * <Description> :  get Default Prescription List
	 * <Input Parameter1 > userRole : User name
	 * <Output> : NA
	 */
	public static List<List<String>> getDefaultICDList()
	{		
		return listValues;
	}	
	
	
}
