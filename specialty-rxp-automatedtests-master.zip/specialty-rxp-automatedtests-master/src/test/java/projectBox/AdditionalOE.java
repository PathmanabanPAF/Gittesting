package projectBox;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.CommonMethods;
import globalBox.GetValueMethods;
import globalBox.TableAndPageHandlingMethods;
import globalBox.WaitMethods;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;
import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.SearchPage;


public class AdditionalOE 
{
	public static void verifyReasonforOEField(String nameField, String nameSection, List<String> expList)
	{
		By xpathField = null;

		switch(nameField)
		{
		case "DAW:" :
			xpathField = By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection +
					CommonWebElements.dynamicXpathGeneric2+
					CommonWebElements.dynamicXpathDropDown3 + nameField + CommonWebElements.dynamicXpathDropDown4
					);
			break;
		default:
			xpathField = By.xpath(CommonWebElements.dynamicXpathHeaderPart1 + nameSection +
					CommonWebElements.dynamicXpathHeaderPart2+
					CommonWebElements.dynamicXpathDropDown3 + nameField + CommonWebElements.dynamicXpathDropDown4
					);			
			break;
		}		
		WebElement dropdown = BrowserMethods.driver1.findElement(xpathField);  
		Select select = new Select(dropdown);  
		List<WebElement> weList = select.getOptions();
		List<String> actualList = new ArrayList<String>();
		for(WebElement we: weList)  
		{  
			actualList.add(we.getText());
		} 
		AssertionMethods.compareLists(expList, actualList);
	}	

	public static void clickMenuOptions(String nameField)
	{
		By xpathField = By.xpath("//*[@class='menu-item-title'and text()='"+ nameField+ "']");
		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait20driver1,xpathField);
	}

	public static void fieldValidationDiagnosisSearch(WebDriverWait wait,
			DataTable tableFields) {

		List<List<String>> listFields = tableFields.raw();

		String xpathFieldName;
		String xpathFieldType = "";

		int countFields = 0;
		for (List<String> listRows : listFields) {
			if (countFields != 0) {
				String nameField = listRows.get(0);
				String typeField = listRows.get(1);

				xpathFieldName = CommonWebElements.dynamicXpathColName1
						+ nameField
						+ CommonWebElements.dynamicXpathColName2;

				By fieldName = By.xpath(xpathFieldName);

				if (AssertionMethods.verifyElementExists(wait, fieldName)) {
					System.out.println("The field[" + nameField
							+ "]is displayed in Diagnosis Search section");

					// Assert.fail("The field["+ nameField
					// +"]is not displayed in "+
					// nameHeader +" section");
				} else {

					System.out
					.println("The field[" + nameField
							+ "]is not displayed in Diagnosis Search section");
				}

				switch (typeField) {
				case "Text box":

					xpathFieldType = xpathFieldName
					+ "/following-sibling::*//input[contains(@data-ctl,'TextInput')]";

					break;

				default:

					break;
				}

				By fieldValue = By.xpath(xpathFieldType);

				if (AssertionMethods.verifyElementExists(wait, fieldValue)) {
					System.out.println("The field[" + nameField
							+ "] has control type[" + typeField + "] in Diagnosis Search section \n");

				} else {

					System.out.println("The field[" + nameField
							+ "] has no control type[" + typeField + "] in Diagnosis Search section \n");
					CommonMethods.testStepPassFlag = false;
				}
			}
			countFields++;
		}

	}



	public static void selectColumnContainedValues(String nameSearch, String nameColumn, String icdCode)
	{	
		int columnNumber = SearchMethods.getTableColumnNumber(nameSearch,nameColumn);
		int intCounter =0;
		boolean blnFlag = false;
		By xpathColumnValue = By.xpath(CommonWebElements.dynamicXpathSearchHeader1 + nameSearch + CommonWebElements.dynamicXpathSearchHeader2 + SearchPage.dynamicXpathColumnValues1 + columnNumber + SearchPage.dynamicXpathColumnValues2);

		List<String> listColumnValues = GetValueMethods.getMultipleTextValues(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathColumnValue);
		List<List<String>> listData = new ArrayList<List<String>>();
		for(String columnValue : listColumnValues)
		{
			for( int i=1; i<=4; i++)
			{
				List<String> tempList = new ArrayList<String>();	
				if(columnValue.contains(icdCode))
				{	
					int ICDcolNum = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, WaitMethods.wait20driver1, SearchPage.xpathICDSearchResutlTbl, "ICD Code", By.xpath("text()"), false);
					int ICDDesccolNum = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, WaitMethods.wait20driver1, SearchPage.xpathICDSearchResutlTbl, "ICD Description", By.xpath("*/text()"), false); 
					String tempICDCode = TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, SearchPage.xpathICDSearchResutlTbl, i,(ICDcolNum-1),  By.xpath("*/text()"), false);
					String tempICDDesc = TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, SearchPage.xpathICDSearchResutlTbl, i,(ICDDesccolNum-1),  By.xpath("*/text()"), false);
					tempList.add(tempICDCode);
					tempList.add(tempICDDesc);
					ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(SearchPage.xpathDiagnosisSearch1 + (i+1) + SearchPage.xpathDiagnosisSearch2));
					intCounter++;						
				}
				listData.add(tempList);
				if(intCounter==2){blnFlag =true; break; }	

			}
			if(blnFlag){ break;}
		}
		SearchTransactionData.setDefaultICDList(listData);
	}

	public static void deleteSelectedValues(){		

		CommonMethods.testStepPassFlag = true;

		List<List<String>> listData = new ArrayList<List<String>>();

		List<List<String>> addedICDRecords = SearchTransactionData.getDefaultICDList();

		int counter=0;

		int rowCountActual = TableAndPageHandlingMethods.getRowCount(BrowserMethods.driver1, WaitMethods.wait15driver1, SearchPage.xpathDiagnosisCodesTbl);

		for(List<String> listValues : addedICDRecords){

			String valueICD =listValues.get(0);
			String valueICDescription =listValues.get(1);
			String reqRowCol = TableAndPageHandlingMethods.getRowColWithCellText(BrowserMethods.driver1, SearchPage.xpathDiagnosisCodesTbl, valueICD, By.xpath("/*text()"), false);
			String[] rowColArr = reqRowCol.split("|");
			List<String> tempList = new ArrayList<String>();	
			int ICDcolNum = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, WaitMethods.wait20driver1, SearchPage.xpathDiagnosisCodesTbl, "Code", By.xpath("text()"), false);
			int ICDDesccolNum = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, WaitMethods.wait20driver1, SearchPage.xpathDiagnosisCodesTbl, "Description", By.xpath("*/text()"), false); 
			String tempICDCode = TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, SearchPage.xpathDiagnosisCodesTbl, (Integer.parseInt(rowColArr[0])-1),(ICDcolNum),  By.xpath("*/text()"), false);
			String tempICDDesc = TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, SearchPage.xpathDiagnosisCodesTbl, (Integer.parseInt(rowColArr[0])-1),(ICDDesccolNum),  By.xpath("*/text()"), false);
			//tempList.add(tempICDCode);
			//tempList.add(tempICDDesc);
			listData.add(tempList);
			if(valueICD.equalsIgnoreCase(tempICDCode)&&valueICDescription.equalsIgnoreCase(tempICDDesc)){
				ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait15driver1, By.xpath(SearchPage.xpathDeleteIcon1 + Integer.parseInt(rowColArr[0])+ SearchPage.xpathDeleteIcon2)); 
				counter++;
			}else{

				CommonMethods.testStepPassFlag = false;

			}

		}
		
		int rowCountExpected = TableAndPageHandlingMethods.getRowCount(BrowserMethods.driver1, WaitMethods.wait15driver1, SearchPage.xpathDiagnosisCodesTbl);

		if((rowCountExpected-1)==(rowCountActual-counter)) {

			CommonMethods.testStepPassFlag = true;

		}else{

			CommonMethods.testStepPassFlag = false;
		}
	}

	public static void verifySelectedValues(){		

		CommonMethods.testStepPassFlag = true;

		List<List<String>> listData = new ArrayList<List<String>>();

		List<List<String>> addedICDRecords = SearchTransactionData.getDefaultICDList();

		for(List<String> listValues : addedICDRecords){

			String valueICD =listValues.get(0);
			String valueICDescription =listValues.get(1);
			String reqRowCol = TableAndPageHandlingMethods.getRowColWithCellText(BrowserMethods.driver1, SearchPage.xpathDiagnosisCodesTbl, valueICD, By.xpath("/*text()"), false);
			String[] rowColArr = reqRowCol.split("|");
			List<String> tempList = new ArrayList<String>();	
			int ICDcolNum = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, WaitMethods.wait20driver1, SearchPage.xpathDiagnosisCodesTbl, "Code", By.xpath("text()"), false);
			int ICDDesccolNum = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, WaitMethods.wait20driver1, SearchPage.xpathDiagnosisCodesTbl, "Description", By.xpath("*/text()"), false); 
			String tempICDCode = TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, SearchPage.xpathDiagnosisCodesTbl, (Integer.parseInt(rowColArr[0])-1),(ICDcolNum),  By.xpath("*/text()"), false);
			String tempICDDesc = TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, SearchPage.xpathDiagnosisCodesTbl, (Integer.parseInt(rowColArr[0])-1),(ICDDesccolNum),  By.xpath("*/text()"), false);
			//tempList.add(tempICDCode);
			//tempList.add(tempICDDesc);
			listData.add(tempList);

			if(valueICD.equalsIgnoreCase(tempICDCode)&&valueICDescription.equalsIgnoreCase(tempICDDesc)){

				CommonMethods.testStepPassFlag = true;

			}else{

				CommonMethods.testStepPassFlag = false;

			}


		}

	}

}


