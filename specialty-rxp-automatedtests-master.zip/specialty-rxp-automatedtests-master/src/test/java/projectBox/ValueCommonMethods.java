package projectBox;

import java.util.List;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.DateConversionMethods;
import globalBox.DropdownMethods;
import globalBox.GetValueMethods;
import globalBox.TextBoxMethods;
import globalBox.WaitMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import pageWebElementsBox.CommonWebElements;
public class ValueCommonMethods {
	/*
	 * <Method Name> :  getDefaultTextValues
	 * <Description> :  This methods is used to get the field default values
	 * <Input Parameter1 > localdriver  : name of the local driver
	 * <Input Parameter2 > wait 		: wait time 
	 * <Input Parameter3 > nameHeader 	: name of the header
	 * <Input Parameter4 > nameField 	: name of the field
	 * <Input Parameter5 > typeField 	:type of the field
	 * <Output> : actualValue
	 */	

	public static String getDefaultTextValues(WebDriver localdriver,WebDriverWait wait, String nameHeader, String nameField, String typeField) throws Throwable {
		
		By xpathFieldType;
		String actualValue="";
		String xpathHeader = "";
		
		xpathHeader = RxCommonMethods.getHeaderXpath(nameHeader);
	    
			switch (typeField) {

				case "Calendar":
				case "Text Box":

					xpathFieldType = By
					.xpath(xpathHeader + CommonWebElements.dynamicXpathCalendar3 + nameField + CommonWebElements.dynamicXpathCalendar4);

					actualValue = GetValueMethods.getElementAttributeValue(
							BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFieldType, "value");				

					break;

				case "Text box":

					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathTextBox3 + nameField + CommonWebElements.dynamicXpathTextBox4);
					
					actualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFieldType);
					break;

				case "Text area":

					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathTextArea3 + nameField + CommonWebElements.dynamicXpathTextArea4);
					actualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFieldType);

					break;

				case "Drop down":

					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathDropDown3 + nameField + CommonWebElements.dynamicXpathDropDown4);

					actualValue = DropdownMethods.getSelectedValueFromDropdown(
							BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFieldType);
					break;

				case "Read Only":

					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathReadOnly3 + nameField + CommonWebElements.dynamicXpathReadOnly4);
					actualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFieldType);
					break;
				}

		return actualValue;
	}
	
	
public static void verifyTextValues(WebDriver localdriver,WebDriverWait wait, String nameHeader, String nameField, String typeField,String expectedValue) throws Throwable {
		
		By xpathFieldType;
		String actualValue="";
		String xpathHeader = "";		
		xpathHeader = RxCommonMethods.getHeaderXpath(nameHeader);	    
			switch (typeField) {
				case "Calendar":
				case "Text Box":
					xpathFieldType = By
					.xpath(xpathHeader + CommonWebElements.dynamicXpathCalendar3 + nameField + CommonWebElements.dynamicXpathCalendar4);
					actualValue = GetValueMethods.getElementAttributeValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFieldType, "value");				
					break;
				case "Text box":
					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathTextBox3 + nameField + CommonWebElements.dynamicXpathTextBox4);					
					actualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFieldType);
					break;
				case "Text area":
					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathTextArea3 + nameField + CommonWebElements.dynamicXpathTextArea4);
					actualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFieldType);
					break;
				case "Drop down":
					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathDropDown3 + nameField + CommonWebElements.dynamicXpathDropDown4);
					actualValue = DropdownMethods.getSelectedValueFromDropdown(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFieldType);
					break;
				case "Read only":
					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathReadOnly3 + nameField + CommonWebElements.dynamicXpathReadOnly4);
					actualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFieldType);
					break;
				case "Non-editable":
					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathNonEditableOnly3 + nameField + CommonWebElements.dynamicXpathNonEditableOnly4);
					actualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFieldType);
					break;					
				}
			AssertionMethods.expectedActualTest(expectedValue.toLowerCase(), actualValue.toLowerCase());
	}
	
	public static void setFieldValue(WebDriver localdriver,WebDriverWait wait, String nameHeader, String nameField, String typeField, String valueField) throws Throwable 
	{
		
		By xpathFieldType;
		String xpathHeader = "";
	
		By datePickerIcon;
		xpathHeader = RxCommonMethods.getHeaderXpath(nameHeader);
	    
			switch (typeField) {

			case "PickCalendar":
				String dateFormat ="MM/dd/yyyy";
				datePickerIcon = By
						.xpath(xpathHeader
								+ CommonWebElements.dynamicXpathCalendar3
								+ nameField
								+ CommonWebElements.dynamicXpathCalendar4
								+ CommonWebElements.dynamicXpathCalendarPart4);
				ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, 
						datePickerIcon);

				if ("Today".equalsIgnoreCase(valueField)||"Tomorrow".equalsIgnoreCase(valueField)||"Yesterday".equalsIgnoreCase(valueField)) {

					valueField = DateConversionMethods.getDate(valueField, dateFormat, "IST");
				}					


				DatePicker.selectDatefromPicker(valueField, dateFormat);

				break;

			case "Calendar":

				xpathFieldType = By.xpath(xpathHeader
						+ CommonWebElements.dynamicXpathCalendar3
						+ nameField
						+ CommonWebElements.dynamicXpathCalendar4);

				if ("Today".equalsIgnoreCase(valueField)||"Tomorrow".equalsIgnoreCase(valueField)||"Yesterday".equalsIgnoreCase(valueField)) {
					valueField = DateConversionMethods.getDate(valueField, "MM/dd/yyyy", "IST");
				}

				TextBoxMethods.setElementAttributeValue(
						BrowserMethods.driver1, WaitMethods.wait20driver1,
						xpathFieldType, "value", valueField);
				break;


			case "Text box":
				if ("Today".equalsIgnoreCase(valueField)||"Tomorrow".equalsIgnoreCase(valueField)||"Yesterday".equalsIgnoreCase(valueField)) {
					valueField = DateConversionMethods.getDate(valueField, "MM/dd/yyyy", "IST");
				}


				xpathFieldType = By.xpath(xpathHeader
						+ CommonWebElements.dynamicXpathTextBox3
						+ nameField
						+ CommonWebElements.dynamicXpathTextBox4);
				TextBoxMethods.retryInputText(BrowserMethods.driver1,
						WaitMethods.wait20driver1, xpathFieldType,
						valueField);
				break;

			case "Text area":

				xpathFieldType = By.xpath(xpathHeader
						+ CommonWebElements.dynamicXpathTextArea3
						+ nameField
						+ CommonWebElements.dynamicXpathTextArea4);

				TextBoxMethods.inputText(BrowserMethods.driver1,
						WaitMethods.wait20driver1, xpathFieldType,
						valueField);
				break;

			case "Drop down":

				xpathFieldType = By.xpath(xpathHeader
						+ CommonWebElements.dynamicXpathDropDown3
						+ nameField
						+ CommonWebElements.dynamicXpathDropDown4);

				DropdownMethods.selectValueByValueFromDropdown(
						BrowserMethods.driver1, WaitMethods.wait20driver1,
						xpathFieldType, valueField);
				break;
			}
	}
	public static void verifyDefaultedValueinDropDown(String nameField, String nameSection, List<String> listOfFields)
	{
		String xpathHeader = RxCommonMethods.getHeaderXpath(nameSection);
		By xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathDropDown3	+ nameField + CommonWebElements.dynamicXpathDropDown4);		
		String actualValue = DropdownMethods.getSelectedValueFromDropdown(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldType);
		AssertionMethods.expectedActualTest(listOfFields.get(0), actualValue);
	}
}
