package projectBox;

import globalBox.AssertionMethods;
import globalBox.CommonMethods;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;

public class verifyCommonMethods {

	
	/*
	 * This method is used to validate whether a field is present or not Also
	 * this method is used validate the field type i.e. dropdown, text box..
	 * input parameters - wait, nameHeader, tableFields,fieldValue
	 */
	public static void fieldValidation(WebDriverWait wait, String nameHeader,
			DataTable tableFields) {
		List<List<String>> listFields = tableFields.raw();
		String xpathHeader = RxCommonMethods.getHeaderXpath(nameHeader);

		/*switch (nameHeader) {
		case "Drug Search":
			xpathHeader = CommonWebElements.dynamicXpathSearchHeader1 + nameHeader + CommonWebElements.dynamicXpathSearchHeader2;
			break;	
		case "Prescriber": 
		case "Prescription":
		case "Patient":
		{
			xpathHeader = "//*[normalize-space(text())='"
					+ nameHeader
					+ "']/ancestor-or-self::*[contains(@class, 'standardlabel')]/following-sibling::*";
			break;
	
		}
		
		case "DisplayProviderSearch":
			xpathHeader = "//*[normalize-space(text())='"
					+ nameHeader
					+ "']/ancestor::*[contains(@id,'modaldialog')]";
			break;
		case "Prescriber Search":{
			xpathHeader = CommonWebElements.dynamicXpathSearchHeader1 + nameHeader + CommonWebElements.dynamicXpathSearchHeader2;
			break;	}
		case "Search Provider":{
			xpathHeader = CommonWebElements.dynamicXpathSearchHeader1 + nameHeader + CommonWebElements.dynamicXpathSearchHeader2;
			break;	}
		default:

			break;
		}*/
		
		System.out.println(xpathHeader);
		By xpathHeader1 = By.xpath(xpathHeader);
		if (AssertionMethods.verifyElementExists(wait, xpathHeader1)) {
			System.out.println("The header[" + nameHeader + "] is present \n");

		} else {

			System.out.println("The header[" + nameHeader
					+ "] is not present \n");
			CommonMethods.testStepPassFlag = false;
		}

		String xpathFieldName;
		String xpathFieldType = "";

		int countFields = 0;
		for (List<String> listRows : listFields) {
			if (countFields != 0) {
				String nameField = listRows.get(0);
				String typeField = listRows.get(1);

				xpathFieldName = xpathHeader
						+ "//*[normalize-space(text())='"
						+ nameField
						+ "' and not(ancestor::*[contains(@style,'none')])]/ancestor-or-self::*[contains(@class,'dataLabelFor')]";

				By fieldName = By.xpath(xpathFieldName);

				if (AssertionMethods.verifyElementExists(wait, fieldName)) {
					System.out.println("The field[" + nameField
							+ "]is displayed in " + nameHeader + " section");

					// Assert.fail("The field["+ nameField
					// +"]is not displayed in "+
					// nameHeader +" section");
				} else {

					System.out
							.println("The field[" + nameField
									+ "]is not displayed in " + nameHeader
									+ " section");
				}

				switch (typeField) {
				case "Text box":

					xpathFieldType = xpathFieldName
							+ "/following-sibling::*//input[contains(@data-ctl,'TextInput')]";

					break;

				case "Calendar":

					xpathFieldType = xpathFieldName
							+ "/following-sibling::*//input[contains(@data-ctl,'DatePicker')]";

					break;

				case "Drop down":

					xpathFieldType = xpathFieldName
							+ "/following-sibling::*//select[contains(@data-ctl,'Dropdown')]";

					break;

				case "Text area":

					xpathFieldType = xpathFieldName
							+ "/following-sibling::*//textarea";

					break;
				
				case "Read only":

					xpathFieldType = xpathFieldName
							+ "/following-sibling::*//*[text()]";
					break;
					
				case "Non-editable":
					xpathFieldType = xpathFieldName
					+ "/following-sibling::*//input[@disabled]";
					
					break;
				default:

					break;
				}

				By fieldValue = By.xpath(xpathFieldType);

				if (AssertionMethods.verifyElementExists(wait, fieldValue)) {
					System.out.println("The field[" + nameField
							+ "] has control type[" + typeField + "] in "
							+ nameHeader + " section \n");

				} else {

					System.out.println("The field[" + nameField
							+ "] has no control type[" + typeField + "] in "
							+ nameHeader + " section \n");
					CommonMethods.testStepPassFlag = false;
				}
			}
			countFields++;
		}

	}

}
