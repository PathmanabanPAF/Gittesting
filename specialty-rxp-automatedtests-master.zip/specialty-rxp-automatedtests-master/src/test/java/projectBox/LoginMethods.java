package projectBox;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import pageWebElementsBox.LoginPage;
import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.CommonMethods;
import globalBox.EncryptDecryptMethods;
import globalBox.FrameHandlingMethods;
import globalBox.GetValueMethods;
import globalBox.ScreenshotMethods;
import globalBox.TextBoxMethods;
import globalBox.WaitMethods;

public class LoginMethods {
	/*
	 * <Method Name> :  navigateToUrl
	 * <Description> :  This method is used to navigate to the URL
	 * <Input Parameter1 > nameScenario : Scenario name
	 * <Output> : NA
	 */
	public static void navigateToUrl(String nameScenario) {
		
		CommonMethods.initialization("driver1", nameScenario, "url");
		
	}
	/*
	 * <Method Name> :  loginApplication
	 * <Description> :  This method is used to login to the application
	 * <Input Parameter1 > localdriver     : local web driver
	 * <Input Parameter2 > wait 		   : wait time
	 * <Input Parameter3 > locatorUserName : object of the user name
	 * <Input Parameter4 > locatorPassword : object of the Password
	 * <Input Parameter5 > locatorSubmit   : object of the submit button
	 * <Input Parameter6 > typeLogin       : type of login
	 * <Output> : NA
	 */
	public static void loginApplication(WebDriver localdriver,
			WebDriverWait wait, By locatorUserName, By locatorPassword,
			By locatorSubmit, String typeLogin) throws InterruptedException {

		
		TransactionData.setUserRole(typeLogin);

		String propertyNameUserName = "";

		String propertyNamePassword = "";

		String propertyNameEncryptDecrypt = "";

		switch (typeLogin) {

		case "Technician":
			propertyNameUserName = "username_technician";
			propertyNamePassword = "password_technician";
			propertyNameEncryptDecrypt = "statepasswordencryption_technician";
			break;

		case "Technician Supervisor":
			propertyNameUserName = "username_techniciansupervisor";
			propertyNamePassword = "password_techniciansupervisor";
			propertyNameEncryptDecrypt = "statepasswordencryption_technicianSupervisor";
			break;

		case "Pharmacist":
			propertyNameUserName = "username_pharmacist";
			propertyNamePassword = "password_pharmacist";
			propertyNameEncryptDecrypt = "statepasswordencryption_pharmacist";
			break;

		default:
			break;

		}

		String userName = CommonMethods
				.readPropertiesFile("inputdata.properties", propertyNameUserName);

		String password = EncryptDecryptMethods.performEncryptDecrypt(
				propertyNamePassword, propertyNameEncryptDecrypt);

		TextBoxMethods.inputText(localdriver, wait, locatorUserName, userName);

		TextBoxMethods.inputText(localdriver, wait, locatorPassword, password);

		ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
				"tempJPEGFilePlaceHolder",
				"Enter Username and Password"+ typeLogin + "in Login Screen of RxProcessing Application");

		ClickMethods.clickElement(localdriver, wait, locatorSubmit);

		WaitMethods.waitForPageLoad(BrowserMethods.driver1,
				WaitMethods.wait20driver1);

		WaitMethods.waitForPegaPageLoad(WaitMethods.wait5driver1,
				WaitMethods.wait20driver1);
	}
	/*
	 * <Method Name> :  verifyApplicationMenuName
	 * <Description> :  This method is used to application menu name
	 * <Input Parameter1 > userRole : Name of the user role
	 * <Output> : NA
	 */
	public static void verifyApplicationMenuName(String userRole) {

		String menuName = "";
		String expectedUserName = "";

		switch (userRole) {

		case "Technician":
			menuName = "menuname_technician";
			break;

		case "Technician Supervisor":
			menuName = "menuname_techniciansupervisor";
			break;

		case "Pharmacist":
			menuName = "menuname_pharmacist";
			break;
		}
		expectedUserName = CommonMethods.readPropertiesFile("inputdata.properties", menuName);

		String actualUserName = GetValueMethods.getTextValue(
				BrowserMethods.driver1, WaitMethods.wait20driver1,
				LoginPage.xpathMenuUserName);

		AssertionMethods.expectedActualTest(expectedUserName, actualUserName);
	}
	/*
	 * <Method Name> :  inactiveWait
	 * <Description> :  This method is used to pause the execution until the given time out is reached
	 * <Input Parameter1 > waitTime : expected wait time
	 * <Output> : NA
	 */
	public static void inactiveWait(String waitTime)
			throws InterruptedException {

		long waitTimeInMinutes = Integer.parseInt(waitTime);

		long waitTimeInMilliSeconds = TimeUnit.MINUTES
				.toMillis(waitTimeInMinutes);

		String menuName = "";
		String expectedUserName = "";

		String userRole = TransactionData.getUserRole();

		switch (userRole) {

		case "Technician":
			menuName = "menuname_technician";
			break;

		case "Technician Supervisor":
			menuName = "menuname_techniciansupervisor";
			break;

		case "Pharmacist":
			menuName = "menuname_pharmacist";
			break;
		}

		expectedUserName = CommonMethods.readPropertiesFile("inputdata.properties", menuName);
		
		FrameHandlingMethods.switchToDefaultFrame(BrowserMethods.driver1, WaitMethods.wait10driver1);

		String actualUserName = GetValueMethods.getTextValue(
				BrowserMethods.driver1, WaitMethods.wait20driver1,
				LoginPage.xpathMenuUserName);

		AssertionMethods.expectedActualTest(expectedUserName, actualUserName);

		Thread.sleep(waitTimeInMilliSeconds);

	}
	/*
	 * <Method Name> :  userTimeOutAction
	 * <Description> :  This method is used to handle the timed out pop up
	 * <Input Parameter1 > actionOfUser : Action to be performed on the pop up
	 * <Output> : NA
	 */
	public static void userTimeOutAction(String actionOfUser)
			throws InterruptedException {
		
		AssertionMethods.verifyElementExists(WaitMethods.wait60driver1,
				LoginPage.idTimeoutModalWindow);
		
		ScreenshotMethods
		.takeScreenshot(BrowserMethods.driver1,
				"tempJPEGFilePlaceHolder",
				"TimeOut pop up will be displayed after inactive session of 14 minutes");
		
		switch (actionOfUser) {
		
		case "accepts":
			
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("pzDisplayModalDialog", BrowserMethods.driver1, WaitMethods.wait10driver1);
			
			ClickMethods.clickElement(BrowserMethods.driver1,
					WaitMethods.wait10driver1, LoginPage.xpathTimeOutOkButton);
			
			ScreenshotMethods
			.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User clicks on Ok buttun in timeout pop up");
			
			FrameHandlingMethods.switchToDefaultFrame(BrowserMethods.driver1, WaitMethods.wait10driver1);
			break;
			
		default:
			
			long waitTimeInMilliSeconds = TimeUnit.MINUTES.toMillis(1);
			Thread.sleep(waitTimeInMilliSeconds);
			ScreenshotMethods
			.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"User ignores timeout pop up and waits total of 15 minutes");
			break;
			
		}
	}
	/*
	 * <Method Name> :  enterInvalidCredentials
	 * <Description> :  This method is used to enter the invalid credentials
	 * <Input Parameter1 > userName : object of the user name
	 * <Input Parameter2 > password : object of the password
	 * <Output> : NA
	 */
	public static void enterInvalidCredentials(String userName, String password) {

		TextBoxMethods.inputText(BrowserMethods.driver1,
				WaitMethods.wait20driver1, LoginPage.iDUsername, userName);

		TextBoxMethods.inputText(BrowserMethods.driver1,
				WaitMethods.wait20driver1, LoginPage.iDPassword, password);

		ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
				"tempJPEGFilePlaceHolder",
				"User enters invalid credential in login screen");

		ClickMethods.clickElement(BrowserMethods.driver1,
				WaitMethods.wait20driver1, LoginPage.idSubmitButton);

	}
	/*
	 * <Method Name> :  verifyLoginErrorMessage
	 * <Description> :  This method is used to verify login error message
	 * <Input Parameter1 > expectedErrorMessage : Expected error message
	 * <Output> : NA
	 */
	public static void verifyLoginErrorMessage(String expectedErrorMessage) {

		String actualErrorMessage = GetValueMethods.getTextValue(
				BrowserMethods.driver1, WaitMethods.wait20driver1,
				LoginPage.xpathLoginErrorMessage);

		ScreenshotMethods
				.takeScreenshot(BrowserMethods.driver1,
						"tempJPEGFilePlaceHolder",
						"Invalid Login error messaged in displayed for invalid credentails" + expectedErrorMessage);

		AssertionMethods.expectedActualTest(expectedErrorMessage,
				actualErrorMessage);

	}
	/*
	 * <Method Name> :  verifyLoginTime
	 * <Description> :  This method is used to verify login time
	 * <Input Parameter1 > userRole : Logged in User Role 
	 * <Input Parameter2 > expectedLoginTime : Expected Login Time
	 * <Output> : NA
	 */
	public static void verifyLoginTime(String userRole, String expectedLoginTime) {

		By xpathMenuName = LoginPage.xpathMenuUserName;

		WebDriverWait waitTime = new WebDriverWait(BrowserMethods.driver1,
				Integer.parseInt(expectedLoginTime));

		AssertionMethods.verifyElementExists(waitTime, xpathMenuName);

	}

}
