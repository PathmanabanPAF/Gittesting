package projectBox;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.CommonMethods;
import globalBox.GetValueMethods;
import globalBox.ScreenshotMethods;
import globalBox.SpreadSheetMethods;
import globalBox.TableAndPageHandlingMethods;
import globalBox.TextBoxMethods;
import globalBox.WaitMethods;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.SearchPage;

public class SearchMethods {
	/*
	 * <Method Name> :  verifyPrescriberInfoWithAPI
	 * <Description> :  This method is used to verify the prescriber information received from API
	 * <Input Parameter1 > nameSection : Name of the Section
	 * <Input Parameter2 > ListOfFields : List of the field passed from the feature file
	 * <Output> : NA
	 */	
	public static void verifyPrescriberInfoWithAPI(String nameSection, List<String> ListOfFields) throws ParseException
	{	
		int iterator = 0;
		for(String nameField : ListOfFields) 
		{
			if (iterator!=0)
			{
				By fieldxpath = By.xpath(
						CommonWebElements.dynamicXpathGeneric1 + nameSection +
						CommonWebElements.dynamicXpathGeneric2 +
						CommonWebElements.dynamicXpathReadOnly3 +  nameField +
						CommonWebElements.dynamicXpathReadOnly4 );	
				String actualFieldValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, fieldxpath);
				String expectedFieldValue ="";
				switch(nameField)
				{
				case "First Name":
					expectedFieldValue  = "MARK";
					break;
				case "Last Name":
					expectedFieldValue = "BAYNE";
					break;
				case "NPI":
					expectedFieldValue = "56893274";
					break;
				case "DEA":
					expectedFieldValue= "";
				}
				AssertionMethods.expectedActualTest(expectedFieldValue, actualFieldValue);
			}
			iterator++;
		}
	}
	/*
	 * <Method Name> :  clickSearchLookup
	 * <Description> :  This method is used to click search look up of given field
	 * <Input Parameter1 > nameField : Name of the input field
	 * <Input Parameter2 > nameSection : Name of the section
	 * <Output> : NA
	 */	
	public static void clickSearchLookup(String nameField, String nameSection)
	{
		By fieldXpath = By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection +
				CommonWebElements.dynamicXpathGeneric2 + 
				CommonWebElements.dynamicXpathReadOnly3 + nameField+
				CommonWebElements.dynamicXpathReadOnly4 + CommonWebElements.dynamicXpathSearchlookup);
		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, fieldXpath);

	}

	/*
	 * <Method Name> :  closeSearchLookup
	 * <Description> :  This method is used to close the search look up screen
	 * <Input Parameter2 > nameSection : Name of the section
	 * <Output> : NA
	 */	
	public static void closeSearchLookup(String nameSection)
	{
		/*By fieldXpath = By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection +
							CommonWebElements.dynamicXpathClosePopup);
		 */				
		By fieldXpath = SearchPage.closeSearchLookup;
		ClickMethods.clickElementByEnterKey(BrowserMethods.driver1, WaitMethods.wait10driver1, fieldXpath);
	}
	/*
	 * <Method Name> :  clickShowMore
	 * <Description> :  This method is used to click on show more link
	 * <Input Parameter2 > nameSection : Name of the section
	 * <Output> : NA
	 */	
	public static void clickShowMore()
	{
		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.showMore);
		//RxCommonMethods.clickLink("Show More");
	}
	/*
	 * <Method Name> :  verifyErrorMessageOnNoCriteria
	 * <Description> :  This method is used to close the search look up screen
	 * <Input Parameter2 > nameSection : Name of the section
	 * <Output> : NA
	 */	
	public static void verifyErrorMessageOnNoCriteria(String nameOfButton,List<String>  expectedErrorMsg) throws InterruptedException
	{
		RxCommonMethods.clickButton("Clear");
		RxCommonMethods.clickButton(nameOfButton);
		String expectedErrorMessage = expectedErrorMsg.get(0);
		By errMsgXpath = By.xpath("//*[text()='" + expectedErrorMsg.get(0) + "']");
		String actualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, errMsgXpath);
		AssertionMethods.expectedActualTest(expectedErrorMessage, actualValue);		
	}	
	/*
	 * <Method Name> :  validationOfSearchFields
	 * <Description> :  This method is used to verify the field error messages
	 * <Input Parameter2 > nameSection : Name of the section
	 * <Output> : NA
	 */		
	public static void validationOfSearchFields(String nameSection, DataTable tableFields) throws InterruptedException
	{
		List<List<String>> listFields = tableFields.raw();
		String xpathHeader = "";
		xpathHeader = RxCommonMethods.getHeaderXpath(nameSection);
		System.out.println(xpathHeader);
		By xpathField = null;
		By xpathFieldErr = null;
		int countFields = 0;
		for (List<String> listRows : listFields) 
		{
			if (countFields != 0) {
				String nameField = listRows.get(0);
				String typeField = listRows.get(1);
				String conditionField = listRows.get(2);
				String notificationMsg = listRows.get(3);
				switch(typeField)
				{
				case "Text box":
					if(nameSection.equalsIgnoreCase("Diagnosis Search")){

						xpathField = By.xpath(CommonWebElements.dynamicXpathTextBox3 + nameField+ CommonWebElements.dynamicXpathTextBox4);
						xpathFieldErr = By.xpath(CommonWebElements.dynamicXpathTextBox3 + nameField+ CommonWebElements.dynamicXpathTextBox4 +CommonWebElements.dynamicXpathErrorPart4);
						break;

					}else{

						xpathField = By.xpath(xpathHeader+ CommonWebElements.dynamicXpathTextBox3 + nameField+ CommonWebElements.dynamicXpathTextBox4);
						xpathFieldErr = By.xpath(xpathHeader+ CommonWebElements.dynamicXpathTextBox3 + nameField+ CommonWebElements.dynamicXpathTextBox4 +CommonWebElements.dynamicXpathErrorPart4);
						break;
					}

				}									
				switch(conditionField)
				{
				case "Min 3 Characters": 
					verifyMin3Characters(nameField,xpathField,xpathFieldErr,notificationMsg );
					break;
				case "10 Digits":
					verify10Digits( nameField,xpathField, xpathFieldErr, notificationMsg);
					break;
				case "Alpha Numeric":
					verifyAlphaNumeric(nameField, xpathField, xpathFieldErr, notificationMsg);
					break;
				case "Min 2 Characters":
					
					if(nameSection.equalsIgnoreCase("Diagnosis Search")){
						
						verifyMin2CharactersICDCode(nameField, xpathField, xpathFieldErr, notificationMsg);
						
					}else{
						
						verifyMin2Characters(nameField, xpathField, xpathFieldErr, notificationMsg);
						
					}
					
					break;
				case "5 Characters":
					verify5Characters(nameField, xpathField, xpathFieldErr, notificationMsg);
					break;
				}

			}
			countFields++;
		}
	}		
	/*
	 * <Method Name> :  verifyMin3Characters
	 * <Description> :  This method is used to verify the field error messages
	 * <Input Parameter2 > nameSection : Name of the section
	 * <Output> : NA
	 */				
	public static void verifyMin3Characters(String nameField,By xpathField, By xpathFieldErr, String notificationMsg) throws InterruptedException
	{

		RxCommonMethods.clickButton("Clear");
		String condition1 = "Jo";
		String condition2 = "Jon";
		//condition1
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition1);
		RxCommonMethods.clickButton("Search");			
		String actualErrMsg = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldErr);
		utilizeScreenshot(nameField + " validation for the condition min 3 characters ", condition1);
		AssertionMethods.expectedActualTest(notificationMsg, actualErrMsg);
		//condition2
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition2);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition min 3 characters ", condition2);
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathFieldErr);			
	}
	/*
	 * <Method Name> :  verifyMin2Characters
	 * <Description> :  This method is used to verify the field error messages
	 * <Input Parameter2 > nameSection : Name of the section
	 * <Output> : NA
	 */				
	public static void verifyMin2Characters(String nameField, By xpathField, By xpathFieldErr, String notificationMsg) throws InterruptedException
	{
		RxCommonMethods.clickButton("Clear");
		String condition1 = "J";
		String condition2 = "Jon";
		String condition3 = "Jo";
		//condition 1
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition1);
		RxCommonMethods.clickButton("Search");			
		String actualErrMsg = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldErr);
		utilizeScreenshot(nameField + " validation for the condition min 2 characters ", condition1);
		AssertionMethods.expectedActualTest(notificationMsg, actualErrMsg);

		//condition 2
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition2);
		RxCommonMethods.clickButton("Search");			
		String actualErrMsg2 = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldErr);
		utilizeScreenshot(nameField + " validation for the condition min 2 characters ", condition2);
		AssertionMethods.expectedActualTest(notificationMsg, actualErrMsg2);
		
		//condition 3
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition3);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition min 2 characters ", condition3);
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathFieldErr);					
	}
	
	public static void verifyMin2CharactersICDCode(String nameField, By xpathField, By xpathFieldErr, String notificationMsg) throws InterruptedException
	{
		CommonMethods.testStepPassFlag = true;
		RxCommonMethods.clickButton("Clear");
		String condition1 = "g";
		String condition2 = "g00";
		String condition3 = "g0";
		//condition 1
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition1);
		RxCommonMethods.clickButton("Search");			
		String actualErrMsg = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldErr);
		utilizeScreenshot(nameField + " validation for the condition min 2 characters ", condition1);
		AssertionMethods.expectedActualTest(notificationMsg, actualErrMsg);

		//condition 2
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition2);
		RxCommonMethods.clickButton("Search");			
		//String actualErrMsg2 = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldErr);
		utilizeScreenshot(nameField + " validation for the condition min 2 characters ", condition2);
		//AssertionMethods.expectedActualTest(notificationMsg, actualErrMsg2);
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathFieldErr);
		//condition 3
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition3);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition min 2 characters ", condition3);
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathFieldErr);					
	}
	/*
	 * <Method Name> :  verifyAlphaNumeric
	 * <Description> :  This method is used to verify the field error messages
	 * <Input Parameter2 > nameSection : Name of the section
	 * <Output> : NA
	 */				
	public static void verifyAlphaNumeric(String nameField, By xpathField, By xpathFieldErr, String notificationMsg) throws InterruptedException
	{
		RxCommonMethods.clickButton("Clear");
		String condition1  = "12345";
		String condition2  = "DEA";
		String condition3 = "DEA1234";
		String condition4  = "@@@";
		String condition5 = "DEA1234@@";
		RxCommonMethods.clickButton("Clear");
		// Condition 1
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition1);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition alpha numeric ", condition1);
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathFieldErr);

		// Condition 2
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition2);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition alpha numeric ", condition2);
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathFieldErr);
		// Condition 3
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition3);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition alpha numeric ", condition3);
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathFieldErr);
		// Condition 4
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition4);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition alpha numeric ", condition4);
		String actualErrMsg = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldErr);
		AssertionMethods.expectedActualTest(notificationMsg, actualErrMsg);
		// Condition 5
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition5);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition alpha numeric ", condition5);
		String actualErrMsg1 = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldErr);
		AssertionMethods.expectedActualTest(notificationMsg, actualErrMsg1);			
	}	
	/*
	 * <Method Name> :  verify10Degits
	 * <Description> :  This method is used to verify the field error messages
	 * <Input Parameter2 > nameSection : Name of the section
	 * <Output> : NA
	 */				
	public static void verify10Digits(String nameField, By xpathField, By xpathFieldErr, String notificationMsg) throws InterruptedException
	{
		RxCommonMethods.clickButton("Clear");
		//String condition = "";
		String condition1  = "123456789";
		String condition2  = "12345678900";
		String condition3  = "123456789T";
		String condition4  = "TestNPI";
		List<String> listOfConditions = new ArrayList<String>();
		listOfConditions.add(condition1);
		listOfConditions.add(condition2);
		listOfConditions.add(condition3);
		listOfConditions.add(condition4);
		String condition5  = "1234567890";
		for(String condition: listOfConditions)
		{
			TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition);
			RxCommonMethods.clickButton("Search");
			String actualErrMsg = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldErr);
			utilizeScreenshot(nameField + " validation for the condition 10 digits ", condition);
			AssertionMethods.expectedActualTest(notificationMsg, actualErrMsg);						
		}
		// Condition 5
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition5);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition 10 digits ", condition5 );
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathFieldErr);
		System.out.print(condition1);
		System.out.print(condition2);
		System.out.print(condition3);
		System.out.print(condition4);
	}	
	/*
	 * <Method Name> :  verify5Characters
	 * <Description> :  This method is used to verify the field error messages
	 * <Input Parameter2 > nameSection : Name of the section
	 * <Output> : NA
	 */						
	public static void verify5Characters(String nameField, By xpathField, By xpathFieldErr, String notificationMsg) throws InterruptedException
	{
		RxCommonMethods.clickButton("Clear");
		String condition1 = "12345";
		String condition2 = "1234A";
		String condition3 = "123456";
		String condition4 = "1234";
		String condition5 = "123@A";
		// Condition 1
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition1);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition 5 characters ", condition1);
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathFieldErr);
		// Condition 2
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition2);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition 5 characters ", condition2);
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathFieldErr);			
		// Condition 3
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition3);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition 5 characters ", condition3);
		String actualErrMsg = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldErr);
		AssertionMethods.expectedActualTest(notificationMsg, actualErrMsg);						
		// Condition 4
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition4);
		RxCommonMethods.clickButton("Search");
		utilizeScreenshot(nameField + " validation for the condition 5 characters ", condition4);
		String actualErrMsg1 = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldErr);
		AssertionMethods.expectedActualTest(notificationMsg, actualErrMsg1);	
		// Condition 5
		TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathField, condition5);
		RxCommonMethods.clickButton("Search");
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathFieldErr);
		utilizeScreenshot(nameField + " validation for the condition 5 characters ", condition5);
		//String actualErrMsg2 = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathFieldErr);
		//AssertionMethods.expectedActualTest(notificationMsg, actualErrMsg2);	
	}			
	/*
	 * <Method Name> :  utilizeScreenshot
	 * <Description> :  This method is used to verify the prescriber information received from API
	 * <Input Parameter1 > nameSection : Name of the Section
	 * <Input Parameter2 > ListOfFields : List of the field passed from the feature file
	 * <Output> : NA
	 */			
	public static void utilizeScreenshot(String Msg,String Condition)
	{
		ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", Msg +">>" + Condition  );
	}

	/*
	 * <Method Name> :  verifyPrescriberInfo
	 * <Description> :  This method is used to verify the prescriber information received from API
	 * <Input Parameter1 > nameSection : Name of the Section
	 * <Input Parameter2 > ListOfFields : List of the field passed from the feature file
	 * <Output> : NA
	 */	
	public static void verifyInformationOfField(String nameSection, List<List<String>> listFields) throws ParseException
	{	
		int iterator = 0;
		String expectedFieldValue;
		String actualFieldValue;
		//List<List<String>> listFields = tableFields.raw();
		for(List<String> listRows : listFields)
		{				
			if (iterator!=0)
			{
				String nameField = listRows.get(0);
				//String typeField = listRows.get(1);
				expectedFieldValue = listRows.get(2);
				By fieldxpath = By.xpath(
						CommonWebElements.dynamicXpathGeneric1 + nameSection +
						CommonWebElements.dynamicXpathGeneric2 +
						CommonWebElements.dynamicXpathReadOnly3 +  nameField +
						CommonWebElements.dynamicXpathReadOnly4 );	
				actualFieldValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, fieldxpath);
				AssertionMethods.expectedActualTest(expectedFieldValue, actualFieldValue);
			}
			iterator++;
		}
	}		

	/*
	 * <Method Name> :  verifyPrescriberInfo
	 * <Description> :  This method is used to verify the prescriber information received from API
	 * <Input Parameter1 > nameSection : Name of the Section
	 * <Input Parameter2 > ListOfFields : List of the field passed from the feature file
	 * <Output> : NA
	 */	
	public static void noteDefaultValues(String nameSection,List<String> listFields)
	{
		List<String> listOfValues = new ArrayList<String>();
		int iterator = 0;

		String xpathHeader = RxCommonMethods.getHeaderXpath(nameSection);

		for(String nameField : listFields)
		{
			if(iterator!=0)
			{
				By fieldxpath = By.xpath(
						xpathHeader +
						CommonWebElements.dynamicXpathReadOnly3 +  nameField +
						CommonWebElements.dynamicXpathReadOnly4 );	
				listOfValues.add(GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, fieldxpath));					
			}
			iterator++;
		}
		TransactionData.setDefaultPrescriptionList(listOfValues);
	}
	/*
	 * <Method Name> :  verifyDefaultValuesOnCancelSearch
	 * <Description> :  This method is used to verify the prescriber information received from API
	 * <Input Parameter1 > nameSection : Name of the Section
	 * <Input Parameter2 > ListOfFields : List of the field passed from the feature file
	 * <Output> : NA
	 */	
	public static void verifyDefaultValuesOnCancelSearch(String nameSection, String nameSearchlookup, List<String> listFields)		
	{
		int iterator = 0;
		int i =0;
		String atualValue;
		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.cancelSearchLookup);
		List<String> listOfDefaultValue = new ArrayList<String>();
		listOfDefaultValue = TransactionData.getDefaultPrescriptionList();

		String xpathHeader = RxCommonMethods.getHeaderXpath(nameSection);
		for(String nameField : listFields)
		{	
			if(iterator!=0)
			{
				By fieldxpath = By.xpath(
						xpathHeader +
						CommonWebElements.dynamicXpathReadOnly3 +  nameField +
						CommonWebElements.dynamicXpathReadOnly4 );	
				atualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, fieldxpath);
				AssertionMethods.expectedActualTest(atualValue, listOfDefaultValue.get(i));
				i++;
			}
			iterator++;
		}			
	}
	/*
	 * <Method Name> :  selectSearchLookupSubmit
	 * <Description> :  This method is used to verify the prescriber information received from API
	 * <Input Parameter1 > nameSection : Name of the Section
	 * <Input Parameter2 > ListOfFields : List of the field passed from the feature file
	 * <Output> : NA
	 */			
	public static void selectSearchLookupSubmit()
	{
		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.submitSearchLookup);
	}
	/*
	 * <Method Name> :  selectOneRecordFromTable
	 * <Description> :  This method is used to verify the prescriber information received from API
	 * <Input Parameter1 > nameSection : Name of the Section
	 * <Input Parameter2 > ListOfFields : List of the field passed from the feature file
	 * <Output> : NA
	 */					
	public static void selectOneRecordFromTable(List<List<String>> listFields)
	{
		By tableLocator = SearchPage.tablePrescriber;
		int rowNum = 0;
		int colNum = 0;
		By locatorInTD = By.xpath( "./*[text()]");
		//Boolean blnFlag = true;
		int countFields = 0;
		int counter = 1;
		//List<List<String>> listFields = tableFields.raw();
		for (List<String> listRows : listFields) 
		{
			if (countFields != 0) 
			{
				//String nameField = listRows.get(0);
				String fieldValue = listRows.get(1);
				String getRowColNum = TableAndPageHandlingMethods.getRowColWithCellText(BrowserMethods.driver1, tableLocator, fieldValue, locatorInTD, true);
				String[] listofValues = getRowColNum.split("|");
				rowNum = Integer.parseInt(listofValues[0]); 
				colNum = Integer.parseInt(listofValues[2]);
				/*					if(!fieldValue.equalsIgnoreCase(TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, tableLocator, (rowNum-1), (colNum-1), locatorInTD, true)))
							{
								blnFlag = false;
								break;
							}*/
				if(fieldValue.equalsIgnoreCase(TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, tableLocator, (rowNum-1), (colNum-1), locatorInTD, true)))
				{
					//blnFlag = false;
					counter++;
					break;
				}					
			}
			countFields++;
		}

		if(counter == listFields.size())
		{
			WebElement table_element = BrowserMethods.driver1.findElement(tableLocator);
			WebElement radioButton = table_element.findElement(By.xpath("./tr[" + rowNum + "]/td[1]//input"));
			radioButton.click();
		}
		else
		{		
			System.out.println("<<<The Search resutls are not matching with the criteria displayed in the results>>>>");
		}
	}

	public static void inputSearchFields(String nameSection, List<String> listFields) throws Throwable{
		String valueField= "";

		for(String nameField: listFields) {

			switch(nameField) {

			case "Drug Name":
				valueField = SearchTransactionData.getDrugName();
				break;

			case "NDC":
				valueField = SearchTransactionData.getDrugNdc();
				break;
			}

			By xpathFieldType = By.xpath(RxCommonMethods.getHeaderXpath(nameSection)
					+ CommonWebElements.dynamicXpathTextBox3
					+ nameField
					+ CommonWebElements.dynamicXpathTextBox4);


			TextBoxMethods.retryInputText(BrowserMethods.driver1,
					WaitMethods.wait20driver1,  xpathFieldType,
					valueField);

		}

	}

	public static void verifySearchResultsTextMessage(String searchText,String nameSearch,String nameScenario, List<String> listFieldNames){
	
		String expectedTextValue = searchText;
		int i=0;

		for(String fieldName: listFieldNames) {
			List<String> listOfColumnData = SpreadSheetMethods.getListOfColumnData(CommonMethods.readPropertiesFile("inputdata.properties", "workBookPath"),"SearchTestData.xlsx", nameSearch, nameScenario, fieldName);
			
			if(i>0){
				expectedTextValue = expectedTextValue+" and";
			}

			expectedTextValue = expectedTextValue + " "+ fieldName +":";
			if(!"".equals(listOfColumnData.get(0)))
				expectedTextValue = expectedTextValue + " " + listOfColumnData.get(0);
			i++;
		}

		String actualTextValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, SearchPage.xpathSearchResultsText);

		AssertionMethods.expectedActualTest(expectedTextValue, actualTextValue.trim());


	}


	public static void verifyTableHeaders(String nameSection, List<String> expectedListOfSearchResultHeaders){

		By xpathSearchResultsHeaders = By.xpath(CommonWebElements.dynamicXpathSearchHeader1 + nameSection + CommonWebElements.dynamicXpathSearchHeader2 + SearchPage.xpathHeaders);

		List<String> actualListOfHeaders = GetValueMethods.getMultipleTextValues(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathSearchResultsHeaders);

		actualListOfHeaders.remove(0);

		AssertionMethods.compareLists(expectedListOfSearchResultHeaders, actualListOfHeaders);
	}

	public static void selectSearchResultsRow(String nameSection, List<String> listOfColumns) 
	{

		By xpathSearchResultsHeaders = By.xpath(CommonWebElements.dynamicXpathSearchHeader1 + nameSection + CommonWebElements.dynamicXpathSearchHeader2 + SearchPage.xpathHeaders);


		for(String nameColumn: listOfColumns){

			List<String> listOfheaders = GetValueMethods.getMultipleTextValues(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathSearchResultsHeaders);
			int columnNumber = 0;
			for(String header:listOfheaders){
				columnNumber++;
				if(header.equals(nameColumn)){

					break;
				}
			}

			List<String> listColumnValues = GetValueMethods.getMultipleTextValues(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(SearchPage.dynamicXpathColumnValuePart1 + Integer.toString(3) + SearchPage.dynamicXpathColumnValuePart2 + Integer.toString(columnNumber) + SearchPage.dynamicXpathColumnValuePart3));

			if("Brand Name".equalsIgnoreCase(nameColumn)){

				SearchTransactionData.setDrugName(listColumnValues.get(0));

			} else if("NDC".equalsIgnoreCase(nameColumn)) {

				SearchTransactionData.setDrugNdc(listColumnValues.get(0));
			}

			ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(SearchPage.dynamicXpathRadioButtonPart1 + Integer.toString(3) + SearchPage.dynamicXpathRadioButtonPart2));
		}
	}

	/*
	 * <Method Name> :  verifySearchResultsinTable
	 * <Description> :  This method is used to verify the prescriber information received from API
	 * <Input Parameter1 > nameSection : Name of the Section
	 * <Input Parameter2 > ListOfFields : List of the field passed from the feature file
	 * <Output> : NA
	 */							
	public static void verifySearchResultsInTable(String nameSection, DataTable tableFields)
	{
		int countFields =0;
		List<List<String>> listFields = tableFields.raw();
		for (List<String> listRows : listFields) 
		{
			if (countFields != 0) 
			{
				String nameColumn = listRows.get(0);
				String fieldValue = listRows.get(1);
				int columnNumber = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, WaitMethods.wait20driver1, SearchPage.tablePrescriber, nameColumn,By.xpath(".//*[text()]"),false);
				List<String> listColumnValues = TableAndPageHandlingMethods.getAllColumnTextInTable(BrowserMethods.driver1, WaitMethods.wait20driver1, SearchPage.tablePrescriber, 1, columnNumber-1, By.xpath("./*[text()]"));
				for(String listValues : listColumnValues)
				{
					expectedContainsActualTest(listValues, fieldValue);
				}
			}
			countFields++;
		}
	}
	/*
	 * <Method Name> :  expectedContainsActualTest
	 * <Description> :  This method is used to verify the prescriber information received from API
	 * <Input Parameter1 > nameSection : Name of the Section
	 * <Input Parameter2 > ListOfFields : List of the field passed from the feature file
	 * <Output> : NA
	 */									
	public static void expectedContainsActualTest(String expectedValue,String ActualValue)
	{
		if(!ActualValue.toLowerCase().contains(expectedValue.toLowerCase()))
		{
			CommonMethods.testStepPassFlag = false;
		}			

	}



	public static void verifyDrugValue(String nameHeader, String nameField, String typeField) throws Throwable{

		String textValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait20driver1, nameHeader, nameField, typeField);

		AssertionMethods.expectedActualTest(SearchTransactionData.getDrugName(), textValue);

	}


	public static void verifyColumnStartswithValues(String nameSearch, String nameColumn, String valueToStartWith){

		int indexTableColumn = getTableColumnNumber(nameSearch,nameColumn);
		List<String> listColumnValues = GetValueMethods.getMultipleTextValues(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(SearchPage.dynamicXpathColumnValues1 + indexTableColumn + SearchPage.dynamicXpathColumnValues2));

		for(String columnValue : listColumnValues) {
			if(!columnValue.startsWith(valueToStartWith)){
				CommonMethods.testStepPassFlag = false;
			}
		}


	}


	public static int getTableColumnNumber(String nameSection,String nameColumn) {


		By xpathSearchHeaders = By.xpath(CommonWebElements.dynamicXpathSearchHeader1 + nameSection + CommonWebElements.dynamicXpathSearchHeader2 + SearchPage.xpathHeaders);
		List<String> listOfheaders = GetValueMethods.getMultipleTextValues(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathSearchHeaders);
		int columnNumber = 0;
		for(String header:listOfheaders){
			columnNumber++;
			if(header.equals(nameColumn)){

				break;
			}
		}

		return columnNumber;

	}


	public static void verifyNoSearchResultsInTable(String nameSection)
	{
		String noResutlsMsg = "No items";
		String actulMsg = TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, SearchPage.tablePrescriber, 1, 1, By.xpath(".//*[text()]"), false);
		AssertionMethods.expectedActualTest(noResutlsMsg, actulMsg);
	}


	public static void verifySearchResultsNDC(String NDC, String colName){

		List<String> listColValues = new ArrayList<String>();

		/*String errorMessage = "No result found. Please enter appropriate search criteria";

			WebElement ele = BrowserMethods.driver1.findElement(By.xpath(CommonWebElements.dynamicXpathTextPart1 + errorMessage +CommonWebElements.dynamicXpathTextPart2));

			if(ele.isDisplayed()){

				CommonMethods.testStepPassFlag = false;

			}*/


		int colNum = 0;

		colNum = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.drugResultsLocator, colName, SearchPage.druglocInd , false);

		listColValues = TableAndPageHandlingMethods.getAllColumnTextInTable(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.drugResultsLocator, 1, (colNum-1), SearchPage.druglocInd);

		for(String listValue: listColValues){

			System.out.println(listValue);

			if(NDC.contains(listValue)){


				CommonMethods.testStepPassFlag = true;

			}else{

				CommonMethods.testStepPassFlag = false;
			}

		}
	}



	public static void verifySearchCriteriaNDC(String NDC,String DrugName, String nameScreen) throws Throwable
	{


		String searchNDC = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameScreen, "NDC", "text box");

		String searchDrugName = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameScreen, "Drug Name", "text box");

		if (searchDrugName.equalsIgnoreCase(searchDrugName)&&searchNDC.equalsIgnoreCase(searchNDC)){

			CommonMethods.testStepPassFlag = true;

		}else{

			CommonMethods.testStepPassFlag = false;
		}

	}


	/*
	 * <Method Name> :  selectOneRecordFromTable
	 * <Description> :  This method is used to verify the prescriber information received from API
	 * <Input Parameter1 > nameSection : Name of the Section
	 * <Input Parameter2 > ListOfFields : List of the field passed from the feature file
	 * <Output> : NA
	 */					
	public static void selectOneRecord(String fieldValue)
	{
		By tableLocator = SearchPage.tablePrescriber;
		int rowNum = 0;
		int colNum = 0;
		By locatorInTD = By.xpath( "./*[text()]");
		String getRowColNum = TableAndPageHandlingMethods.getRowColWithCellText(BrowserMethods.driver1, tableLocator, fieldValue, locatorInTD, true);
		String[] listofValues = getRowColNum.split("|");
		rowNum = Integer.parseInt(listofValues[0]); 
		colNum = Integer.parseInt(listofValues[2]);
		if(fieldValue.equalsIgnoreCase(TableAndPageHandlingMethods.getCellText(BrowserMethods.driver1, tableLocator, (rowNum-1), (colNum-1), locatorInTD, true)))
		{
			WebElement table_element = BrowserMethods.driver1.findElement(tableLocator);
			WebElement radioButton = table_element.findElement(By.xpath("./tr[" + rowNum + "]/td[1]//input"));
			radioButton.click();
		}
		else
		{		
			System.out.println("<<<The Search resutls are not matching with the criteria displayed in the results>>>>");
		}
	}

	/*
	 * <Method Name> :  selectSingleRecordFromTbl
	 * <Description> :  This method is used to verify the prescriber information received from API
	 * <Input Parameter1 > nameSection : Name of the Section
	 * <Input Parameter2 > ListOfFields : List of the field passed from the feature file
	 * <Output> : NA
	 */					
	public static void selectSingleRecordFromTbl(List<List<String>> listFields,By locatorInTD, boolean useLocatorINTD)
	{
		By tableLocator = SearchPage.tablePrescriber;
		int rowNum = 1;
		int colNum ;			
		String getCellText = "";
		//locatorInTD = By.xpath("./*[text()]");
		int countFields = 0;
		int counter;
		int i;
		boolean blnFlag = false;

		WebElement table_element = BrowserMethods.driver1.findElement(tableLocator);
		List<WebElement> tr_collection = table_element.findElements(By.xpath("./tr"));
		for(i = 1; i< tr_collection.size();i++)
		{		
			counter = 1;
			 List<WebElement> td_collection = tr_collection.get(i).findElements(By.xpath("./td"));
			 for (List<String> listRows : listFields) 
			 {
				 if (countFields != 0) 
				 {						
					 	String nameField = listRows.get(0);	
					 	colNum = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, WaitMethods.wait20driver1, tableLocator, nameField, locatorInTD, false);
						String fieldValue = listRows.get(1);						
						if(useLocatorINTD)
						{ 
							try{
								getCellText = td_collection.get(colNum-1).findElement(locatorInTD).getText();
							   }catch(Exception e){}}
						else
						{
						    	getCellText = td_collection.get(colNum-1).getText();
						}
						if(fieldValue.equalsIgnoreCase(getCellText))
						{
							counter++;
						}
				 }
				 countFields++;
			 }
				 if(listFields.size()== counter)
				 {
					 rowNum = (i+1);
					 TransactionData.setSearchlookupResultRowNumber(rowNum);
					 blnFlag = true;
					 
					 break;
				 }
		}		
		if(blnFlag)
		{			
			WebElement radioButton = table_element.findElement(By.xpath("./tr[" + rowNum + "]/td[1]//input"));
			radioButton.click();
		}
		else
		{		
			System.out.println("<<< The Search resutls are not matching with the criteria displayed in the results >>>");
		}
	}	


	public static void selectAdditionalDetailsInTbl(List<List<String>> listFields,By locatorInTD, boolean useLocatorINTD)
	{
		/*By tableLocator = By.xpath(SearchPage.xpathSelectAdditionalDetailsTbl);
		WebElement table_element = BrowserMethods.driver1.findElement(tableLocator);
		List<WebElement> tr_collection = table_element.findElements(By.xpath("./tr"));	*/

	}
}
