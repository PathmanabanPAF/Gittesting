package projectBox;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.LoginPage;
import pageWebElementsBox.TaskTimeOutPage;
import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.FrameHandlingMethods;
import globalBox.GetValueMethods;
import globalBox.WaitMethods;

public class TaskTimeOutMethods {

	public static void validatePopup(String titlePopup, String contentPopUp) {

		String actualPopUpTitle = GetValueMethods.getTextValue(BrowserMethods.driver1,
				WaitMethods.wait20driver1, LoginPage.idTimeoutModalWindow);

		AssertionMethods.expectedActualTest(titlePopup, actualPopUpTitle);

		FrameHandlingMethods.switchToAFrameByNameWithOutDefaultContentSwitching(BrowserMethods.driver1, WaitMethods.wait10driver1, "pzDisplayModalDialog");

		String actualPopUpContent = GetValueMethods.getTextValue(BrowserMethods.driver1,
				WaitMethods.wait20driver1, TaskTimeOutPage.xpathTaskTimeOutText);

		AssertionMethods.expectedActualTest(contentPopUp, actualPopUpContent);

	}

	public static void continueWorkInWorkOrderPage(String timeInMinutes) throws InterruptedException {

		FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1,
				WaitMethods.wait20driver1);

		long waitTimeInMinutes = Integer.parseInt(timeInMinutes);

		long waitTimeInMilliSeconds = TimeUnit.MINUTES
				.toMillis(waitTimeInMinutes);

		long tenSecondsInMilliSeconds = TimeUnit.SECONDS
				.toMillis(10);

		long thirtySecondsInMilliSeconds = TimeUnit.SECONDS
				.toMillis(30);

		By xpathFieldType = By
				.xpath(CommonWebElements.dynamicXpathGeneric1
						+ "Patient"
						+ CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathTextBox3
						+ "Weight:"
						+ CommonWebElements.dynamicXpathTextBox4);
		long counter = TimeUnit.MINUTES
				.toMillis(0);
		
	
		while(counter < (waitTimeInMilliSeconds - tenSecondsInMilliSeconds)) {
		
			Thread.sleep(thirtySecondsInMilliSeconds);

/*			try{
				 BrowserMethods.driver1.switchTo().alert().accept(); 
			
			} catch(Exception e){
				
			}*/
			ClickMethods.clickElement(BrowserMethods.driver1,
					WaitMethods.wait20driver1, xpathFieldType);
			counter = counter + thirtySecondsInMilliSeconds;
		}
	}

}
