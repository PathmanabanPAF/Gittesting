package projectBox;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.DropdownMethods;
import globalBox.HoveringMethods;
import globalBox.KeyboardActions;
import globalBox.WaitMethods;

import java.util.List;

import org.openqa.selenium.By;

import cucumber.api.DataTable;
import pageWebElementsBox.CommonWebElements;

public class ActionsPerform 
{
	public static void performMouseActions(String nameField, String nameSection) throws InterruptedException
	{
		By xpathLocator = By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection+
				CommonWebElements.dynamicXpathGeneric2	+
				CommonWebElements.dynamicXpathDropDown3 + nameField +
				CommonWebElements.dynamicXpathDropDown4);
		HoveringMethods.hoverAndClickOnElement(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathLocator);
	}
	
	public static void performKeyBoardActions(String nameField, String nameSection,DataTable tableValues) throws InterruptedException
	{
		By xpathLocator = By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection+
				CommonWebElements.dynamicXpathGeneric2	+
				CommonWebElements.dynamicXpathDropDown3 + nameField +
				CommonWebElements.dynamicXpathDropDown4);
		int counter = 0;
		List<List<String>> listOfTableValues = tableValues.raw();
		for (List<String> listOfValues : listOfTableValues) 
		{
			if(counter!=0)
			{
				String actionName = listOfValues.get(0);
				String expFieldValue = listOfValues.get(1);
				switch (actionName)
				{
				case "Arrow Down":
					KeyboardActions.performArrowDown(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathLocator);
					break;
				case "Arrow Up"	:
					KeyboardActions.performArrowUp(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathLocator);
					break;
				case "0"	:
					KeyboardActions.performNumPad0(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathLocator);
					break;	
				case "1"	:
					KeyboardActions.performNumPad1(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathLocator);
					break;						
				case "2"	:
					KeyboardActions.performNumPad2(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathLocator);
					break;						
				}
				Thread.sleep(500);
				String actualValue = DropdownMethods.getSelectedValueFromDropdown(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathLocator);
				AssertionMethods.expectedActualTest(expFieldValue, actualValue);
			}
			counter++;
		}
	}
	
}
