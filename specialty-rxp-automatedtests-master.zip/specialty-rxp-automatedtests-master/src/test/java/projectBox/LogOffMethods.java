package projectBox;

import org.openqa.selenium.By;

import pageWebElementsBox.LogOffPage;
import pageWebElementsBox.LoginPage;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.DynamicXpathCalculation;
import globalBox.FrameHandlingMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;

public class LogOffMethods {
	/*
	 * <Method Name> :  performLogOut
	 * <Description> :  This method is used to log off from the application
	 * <Input Parameter1 > userAction : user action to be passed ex: Log off
	 * <Output> : NA
	 */
	 public static void performLogOut(String userAction) throws InterruptedException{
		 Thread.sleep(1000);
		FrameHandlingMethods.switchToDefaultFrame(BrowserMethods.driver1, WaitMethods.wait10driver1);
		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, LoginPage.xpathMenuUserName);

		Thread.sleep(2000);
		ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User clicks on Operator Name in RxProcessing application to logout of the application");

		By xpathLogOffButton = DynamicXpathCalculation.dynamicXpathCreation(LogOffPage.dynamicXpathLogOffPart1, userAction, LogOffPage.dynamicXpathLogOffPart2);
		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathLogOffButton);
		
		

		//ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User clicks on Log Off button in the User menu to logout of the RxProcessing application");
	}
}
