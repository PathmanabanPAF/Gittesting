package projectBox;

import java.util.List;

import org.openqa.selenium.By;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.HoveringMethods;
import globalBox.WaitMethods;
import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.ExtendingTimePage;
import pageWebElementsBox.LoginPage;

public class ExtendingTimeMethods {

	public static void navigateToExtendingTimePage(String nameFavoriteOption, String nameMenuOption) throws InterruptedException {

		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, LoginPage.xpathMenuUserName);

		By xpathFavoriteOptions = By.xpath(CommonWebElements.dynamicXpathLinkPart1 + nameFavoriteOption + CommonWebElements.dynamicXpathLinkPart2);

		By xpathFaouriteMenuOption = By.xpath(CommonWebElements.dynamicXpathLinkPart1 + nameMenuOption + CommonWebElements.dynamicXpathLinkPart2);

		HoveringMethods.hoverOnElementAndClickOtherElement(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFaouriteMenuOption , xpathFavoriteOptions);

	}

	public static void hoverOnMenuOption(String nameMenuOption) throws InterruptedException {

		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, LoginPage.xpathMenuUserName);

		By xpathFavoriteMenuOption = By.xpath(CommonWebElements.dynamicXpathLinkPart1 + nameMenuOption + CommonWebElements.dynamicXpathLinkPart2);

		HoveringMethods.hoverOnElement(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathFavoriteMenuOption);

	}

	public static void verifyExtendingTimeOptionsNotPresent(String nameMenuOption, List<String> listOfFavoriteOptions) {

		for(String option: listOfFavoriteOptions){

			By xpathMenuOption = By.xpath(CommonWebElements.dynamicXpathLinkPart1 + nameMenuOption + CommonWebElements.dynamicXpathLinkPart2 + ExtendingTimePage.xpathFavoriteOptions +CommonWebElements.dynamicXpathLinkPart1 + option + CommonWebElements.dynamicXpathLinkPart2);

			AssertionMethods.getElementInvisiblity(WaitMethods.wait10driver1, xpathMenuOption);

		}
	}

}
