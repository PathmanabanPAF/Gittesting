package projectBox;
import pageWebElementsBox.GraphViewPage;
import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.GetValueMethods;
import globalBox.WaitMethods;

public class GraphViewMethods {
	public static void checklabelTextInGraph(String expectedValue){
		String actualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, GraphViewPage.caseCountByTherapy);
		AssertionMethods.expectedActualTest(expectedValue,actualValue );
	}
	public static void checkXAxisValue(String expectedValue){
		String actualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, GraphViewPage.xAxis);
		AssertionMethods.expectedActualTest(expectedValue,actualValue );
	}
	public static void checkYAxisValue(String expectedValue){
		String actualValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, GraphViewPage.yAxis);
		AssertionMethods.expectedActualTest(expectedValue,actualValue );
	}	
	public static void GraphExistence(){
		AssertionMethods.verifyElementExists(WaitMethods.wait20driver1, GraphViewPage.graphView);
	}
}
