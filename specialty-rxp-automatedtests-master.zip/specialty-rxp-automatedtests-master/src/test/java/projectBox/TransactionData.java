package projectBox;

import java.util.ArrayList;
import java.util.List;

public class TransactionData {

	public static String userName = "";
	public static String idFirstCase = "";
	public static String idSecondCase = "";
	public static String tempPatientName = "";
	public static String UpdatedByUser = "";
	public static int countOfWorkOrders = 0;
	public static int searchlookupRowNumber =0;
	public static List<String> listValues = new ArrayList<String>();

	
	public static void setSearchlookupResultRowNumber(int rowNum)
	{
		searchlookupRowNumber = rowNum;
	}
	
	public static int getSearchlookupResultRowNumber()
	{
		return searchlookupRowNumber;
	}
	
	
	/*
	 * <Method Name> :  setDefaultPrescriptionList
	 * <Description> :  Set Default PrescriptionList
	 * <Input Parameter1 > userRole : User name
	 * <Output> : NA
	 */
	public static void setDefaultPrescriptionList(List<String> expList)
	{
		listValues = expList;
	}	
	/*
	 * <Method Name> :  getDefaultPrescriptionList
	 * <Description> :  get Default Prescription List
	 * <Input Parameter1 > userRole : User name
	 * <Output> : NA
	 */
	public static List<String> getDefaultPrescriptionList()
	{		
		return listValues;
	}	
	
	/*
	 * <Method Name> :  setUserRole
	 * <Description> :  Set the User Role
	 * <Input Parameter1 > userRole : User name
	 * <Output> : NA
	 */
	public static void setUserRole(String userRole) {	userName = userRole; }
	/*
	 * <Method Name> :  getUserRole
	 * <Description> :  get the User Role
	 * <Output> : userName
	 */
	public static String getUserRole() {	return userName;	}
	/*
	 * <Method Name> :  setFirstCaseId
	 * <Description> :  Set the First Case ID
	 * <Input Parameter1 > idCase : idCase
	 * <Output> : NA
	 */	
	public static void setFirstCaseId(String idCase) {	idFirstCase = idCase;	}
	/*
	 * <Method Name> :  getFirstCaseId
	 * <Description> :  get the First Case ID
	 * <Output> : idFirstCase
	 */
	public static String getFirstCaseId() {		return idFirstCase;	 }
	/*
	 * <Method Name> :  setSecondCaseId
	 * <Description> :  Set the Second Case ID
	 * <Input Parameter1 > idCase : idCase
	 * <Output> : NA
	 */	
	public static void setSecondCaseId(String idCase) {	idSecondCase = idCase;	}
	/*
	 * <Method Name> :  getSecondCaseId
	 * <Description> :  get the Second Case ID
	 * <Output> : idSecondCase
	 */
	public static String getSecondCaseId() { return idSecondCase;	}
	/*
	 * <Method Name> :  setWorkOrdersCount
	 * <Description> :  Set work orders count
	 * <Input Parameter1 > workOrders : count of work orders
	 * <Output> : NA
	 */	
	public static void setWorkOrdersCount(int workOrders) {	countOfWorkOrders = workOrders;	}
	/*
	 * <Method Name> :  getWorkOrdersCount
	 * <Description> :  get work orders count
	 * <Output> : countOfWorkOrders
	 */
	public static int getWorkOrdersCount() { return countOfWorkOrders;	}
	
	public static void setPatientName(String namePatient) {	tempPatientName = namePatient;	}
	/*
	 * <Method Name> :  getWorkOrdersCount
	 * <Description> :  get work orders count
	 * <Output> : countOfWorkOrders
	 */
	public static String getPatientName() { return tempPatientName;	}
	
	//nameAncillary
	public static String nameAncillary = LoadTransactionData.rowData1
			.get("Ancillary Name (Includes Ancillary ID)");
	//therapy
	public static String therapy = LoadTransactionData.rowData1.get("Therapy");
	//visiblilityPca
	public static String visiblilityPca = LoadTransactionData.rowData1
			.get("PCA visually able to see");
	//numberOfRefills
	public static String numberOfRefills = LoadTransactionData.rowData1
			.get("refills");

	/*
	 * <Method Name> :  setAcillaryName
	 * <Description> :  Set AcillaryName
	 * <Input Parameter1 > ancillary : AcillaryName 
	 * <Output> : NA
	 */	
	public static void setAcillaryName(String ancillary) {	nameAncillary = ancillary;	}
	/*
	 * <Method Name> :  getAncillaryName
	 * <Description> :  Get AcillaryName
	 * <Output> : nameAncillary
	 */
	public static String getAncillaryName() {	return nameAncillary;	}
	/*
	 * <Method Name> :  setTherapy
	 * <Description> :  set Therapy
	 * <Input Parameter1 > textTherapy : Therapy text 
	 * <Output> : NA
	 */	
	public static void setTherapy(String textTherapy) {	therapy = textTherapy;	}
	/*
	 * <Method Name> :  getTherapy
	 * <Description> :  Get Therapy name
	 * <Output> : therapy
	 */
	public static String getTherapy() { return therapy;	}
	/*
	 * <Method Name> :  setPcaVisiblility
	 * <Description> :  set PcaVisiblility
	 * <Input Parameter1 > isPcaVisible : PCAvisible value
	 * <Output> : NA
	 */	
	public static void setPcaVisiblility(String isPcaVisible) {	visiblilityPca = isPcaVisible;	}
	/*
	 * <Method Name> :  getPcaVisiblility
	 * <Description> :  Get PcaVisiblility
	 * <Output> : visiblilityPca
	 */
	public static String getPcaVisiblility() {	return visiblilityPca;	}
	/*
	 * <Method Name> :  setNumberOfRefills
	 * <Description> :  set Number of Refills
	 * <Input Parameter1 > refillsNumber : Refills number
	 * <Output> : NA
	 */	
	public static void setNumberOfRefills(String refillsNumber) {	numberOfRefills = refillsNumber;	}
	/*
	 * <Method Name> :  getNumberOfRefills
	 * <Description> :  Get Number of Refills
	 * <Output> : numberOfRefills
	 */
	public static String getNumberOfRefills() {		return numberOfRefills;	}
	/*
	 * <Method Name> :  setUpdatedBy
	 * <Description> :  Set the UpdatedByUser
	 * <Input Parameter1 > UpdatedBy : UpdatedBy
	 * <Output> : NA
	 */	
	public static void setUpdatedBy(String UpdatedBy) {	UpdatedByUser = UpdatedBy; }
	/*
	 * <Method Name> :  getUpdatedBy
	 * <Description> :  get the UpdatedByUser
	 * <Output> : UpdatedByUser
	 */
	public static String getUpdatedBy() {	return UpdatedByUser;	}
	
	
	
	

}
