package projectBox;

import java.text.ParseException;
import java.util.List;

import org.openqa.selenium.By;

import cucumber.api.DataTable;
import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.DynamicXpathCalculation;
import globalBox.FrameHandlingMethods;
import globalBox.GetValueMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;
import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.LandingPage;
import pageWebElementsBox.OrderEntryPage;

public class OrderEntry {
	/*
	 * <Method Name> :  verifyColumns
	 * <Description> :  This methods is used to verify columns list
	 * <Input Parameter1 > listOfExpectedColumns : List of the Expected Columns
	 * <Output> : NA
	 */
	public static void verifyColumns(List<String> listOfExpectedColumns) {

		List<String> listOfActualColumns = GetValueMethods
				.getMultipleTextValues(BrowserMethods.driver1,
						WaitMethods.wait10driver1,
						OrderEntryPage.xpathColumnHeaders);

		AssertionMethods.compareLists(listOfExpectedColumns,
				listOfActualColumns);
	}
	/*
	 * <Method Name> :  verifyFirstCaseCreation
	 * <Description> :  This methods is used to set the first case id in the application
	 * <Output> : idFirstCase ; First case id value stored in the corresponding variable
	 */
	public static void verifyFirstCaseCreation() {

		String idFirstCase = GetValueMethods.getTextValue(BrowserMethods.driver1,
				WaitMethods.wait10driver1, OrderEntryPage.xpathReferralCaseId);

		TransactionData.setFirstCaseId(idFirstCase);

	}
	/*
	 * <Method Name> :  verifySecondCaseCreation
	 * <Description> :  This methods is used to set the second case id in the application
	 * <Output> : idSecondCase ; Second case id value stored in the corresponding variable
	 */
	public static void verifySecondCaseCreation() {

		String idSecondCase = GetValueMethods.getTextValue(BrowserMethods.driver1,
				WaitMethods.wait10driver1, OrderEntryPage.xpathReferralCaseId);

		TransactionData.setSecondCaseId(idSecondCase);

	}


	/*
	 * <Method Name> :  verifyGetWorkFirstOrder
	 * <Description> :  This methods is used to verify the work first order
	 * <Output> : NA
	 */

	public static void verifyGetWorkFirstOrder() throws ParseException, InterruptedException {
		
		RxCommonMethods.getRequiredWorkOrder(TransactionData.getFirstCaseId());

		/*FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

		String idWorkOrder = "";

		idWorkOrder = GetValueMethods.getTextValue(BrowserMethods.driver1,
				WaitMethods.wait10driver1, OrderEntryPage.xpathReferralCaseId);

		ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System retreives first work order on clicking work basket button");

		AssertionMethods.expectedActualTest(TransactionData.getFirstCaseId(), idWorkOrder);*/

	}
	/*
	 * <Method Name> :  verifyGetWorkSecondOrder
	 * <Description> :  This methods is used to verify the work second order
	 * <Output> : NA
	 */

	public static void verifyGetWorkSecondOrder() throws ParseException, InterruptedException {
		
		RxCommonMethods.getRequiredWorkOrder(TransactionData.getSecondCaseId());
		
		/*FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

		String idWorkOrder = "";

		idWorkOrder = GetValueMethods.getTextValue(BrowserMethods.driver1,
				WaitMethods.wait10driver1, OrderEntryPage.xpathReferralCaseId);

		ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "System retreives second work order on clicking work basket button");

		AssertionMethods.expectedActualTest(TransactionData.getSecondCaseId(), idWorkOrder);*/

	}
	/*
	 * <Method Name> :  verifyWorkOrderFifoSequence
	 * <Description> :  This methods is used to verify the work order in FIFO sequence
	 * <Input Parameter1 > nameWorkbasket : Name of the work basket
	 * <Output> : NA
	 */

	public static void verifyWorkOrderFifoSequence(String nameWorkbasket) throws InterruptedException{

		FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

		String idWorkOrder = "";

		idWorkOrder = GetValueMethods.getTextValue(BrowserMethods.driver1,
				WaitMethods.wait10driver1, OrderEntryPage.xpathReferralCaseId);

		ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User receives first order created on clicking " + nameWorkbasket+ " work basket");

		

		FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

		RxCommonMethods.clickButton(nameWorkbasket);

		FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

		ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "tempJPEGFilePlaceHolder", "User receives second order created on clicking " + nameWorkbasket+ " work basket");

		idWorkOrder = GetValueMethods.getTextValue(BrowserMethods.driver1,
				WaitMethods.wait10driver1, OrderEntryPage.xpathReferralCaseId);

		AssertionMethods.expectedActualTest(TransactionData.getSecondCaseId(), idWorkOrder);

	}

	/*
	 * <Method Name> :  verifyEmptyWorkBassketMessage
	 * <Description> :  This methods is used to verify empty work basket message
	 * <Input Parameter1 > expetedEmptyWorkBasketMessage : Expected empty work basket message
	 * <Output> : NA
	 */

	public static void verifyEmptyWorkBassketMessage(String expetedEmptyWorkBasketMessage) {

		String actualEmptyWorkBasketMessage = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, OrderEntryPage.xpathEmptyWorkBaksetMessage);

		AssertionMethods.expectedActualTest(expetedEmptyWorkBasketMessage, actualEmptyWorkBasketMessage);

	}
	/*
	 * <Method Name> :  verifyWorkOrderCount
	 * <Description> :  This methods is used to verify work order count
	 * <Input Parameter1 > expectedWorkOrderCount : Expected work order count
	 * <Input Parameter2 > expectedWorkOrderCount : name of the work basket
	 * <Output> : NA
	 */	

	public static void verifyWorkOrderCount(String expectedWorkOrderCount, String nameOfWorkBasket){

		By xpathWorkOrderCount = DynamicXpathCalculation.dynamicXpathCreation(LandingPage.dynamicXpathWIPCountPart1, nameOfWorkBasket, LandingPage.dynamicXpathWIPCountPart2);

		String actualWorkOrderCount = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathWorkOrderCount);

		AssertionMethods.expectedActualTest(expectedWorkOrderCount, actualWorkOrderCount.trim());

	}
	/*
	 * <Method Name> :  verifyLastWorkOrderError
	 * <Description> :  This methods is used to verify last work order error message
	 * <Input Parameter1 > expectedLastWorkOrderError : Expected Last work order error message
	 * <Output> : NA
	 */		
	public static void verifyLastWorkOrderError(String expectedLastWorkOrderError){

		String actualLastWorkOrderError = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, OrderEntryPage.xpathLastWorkOrderError);

		AssertionMethods.expectedActualTest(expectedLastWorkOrderError, actualLastWorkOrderError.trim());

	}
	/*
	 * <Method Name> :  setWorkOrderCount
	 * <Description> :  This methods is used to set work order count
	 * <Input Parameter1 > nameOfWorkBasket : name of the Work Basket
	 * <Output> : NA
	 */			
	public static void setWorkOrderCount(String nameOfWorkBasket){
		By xpathWorkOrderCount = DynamicXpathCalculation.dynamicXpathCreation(LandingPage.dynamicXpathWIPCountPart1, nameOfWorkBasket, LandingPage.dynamicXpathWIPCountPart2);

		String actualWorkOrderCount = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathWorkOrderCount);

		TransactionData.setWorkOrdersCount(Integer.parseInt(actualWorkOrderCount));
	}

	public static void verifyWorkOrderStatus(String nameField, String expectedStatusValue, String nameSection){

		By xpathStatus = By.xpath(CommonWebElements.dynamicXpathHeaderPart1 + nameSection + CommonWebElements.dynamicXpathHeaderPart2 +  CommonWebElements.dynamicXpathStatusPart3);

		String actualStatusValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathStatus);

		AssertionMethods.expectedActualTest(expectedStatusValue, actualStatusValue.trim());

	}


	public static void verifyAgeNotification(String nameField, String minimumYears, String nameSection, String expectedErrormessage){

		By xpathAgeValue = By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathReadOnly3 + nameField + CommonWebElements.dynamicXpathReadOnly4);

		String actualAgeValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathAgeValue);
		
		String[] actualAgeArr = actualAgeValue.split("Y");
		
		String actualAge = actualAgeArr[0];

/*		StringBuffer str = new StringBuffer(actualAgeValue);
		char textOfAge = str.charAt(0);
		int ageInYears = Integer.parseInt(Character.toString(actualAge));*/
		
		int ageInYears = Integer.parseInt((actualAge));
		
		//By xpathAgeNotification = By.xpath(OrderEntryPage.dynamicXpathAgeNotificationPart1 + OrderEntryPage.dynamicXpathAgeNotificationPart2 + OrderEntryPage.dynamicXpathAgeNotificationPart3 +OrderEntryPage.dynamicXpathAgeNotificationPart4);
		
		By xpathAgeNotification = By.xpath(OrderEntryPage.dynamicXpathAgeNotificationPart1 + nameSection + OrderEntryPage.dynamicXpathAgeNotificationPart2 + OrderEntryPage.dynamicXpathAgeNotificationPart3 + expectedErrormessage +OrderEntryPage.dynamicXpathAgeNotificationPart4);

		if(ageInYears<17) {
			
			String actualAgeNofitication = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathAgeNotification);
			
			AssertionMethods.expectedActualTest(expectedErrormessage, actualAgeNofitication);
			
		} else {
			
			AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathAgeNotification);
			
		}


	}
	/*
	 * <Method Name> :  patientName
	 * <Description> :  This methods is used to set the patient name
	 * <Output> : NA
	 */	
	
	public static void patientName(){
		
		String patientName = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, LandingPage.xpathPatientName);
		
		TransactionData.setPatientName(patientName);
				
	}
	/*
	 * <Method Name> :  verifyDrugAPIValues
	 * <Description> :  This methods is used to verify values populated from API in Drug section
	 * <Input Parameter1 > nameHeader : name of the section
	 * <Input Parameter2 > tableValues : list of field names and type of the fields 
	 * <Output> : NA
	 */	

	public static void verifyDrugAPIValues(String nameHeader,  DataTable tableValues) throws Throwable{
		
		List<List<String>> listOfTableValues = tableValues.raw();
		int countIteration = 0;

		String nameField = "";
		String typeField = "";
		String expectedValue = "";
		String actualValue = "" ;
	  
		for (List<String> listOfValues : listOfTableValues) {

			if (countIteration > 0) {
				
				nameField = listOfValues.get(0);
				typeField = listOfValues.get(1);
				switch (nameField) {

				case "Prescribed Drug:":

					expectedValue = "HUMIRA 20MG/0.4ML PFS 2EA/BX";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					break;

				case "Prescribed Quantity:":
					
					expectedValue = "";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					break;

				case "Dispensed Drug:":

					expectedValue = "HUMIRA 20MG/0.4ML PFS 2EA/BX";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					
					break;

				case "Dispensed Quantity:":

					expectedValue = "";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					
					break;
				}
				AssertionMethods.expectedActualTest(expectedValue, actualValue);
			}
			countIteration++;
		}
		

		
	}
	
	/*
	 * <Method Name> :  verifyPrescriptionAPIValues
	 * <Description> :  This methods is used to verify values populated from API in Prescription section
	 * <Input Parameter1 > nameHeader : name of the section
	 * <Input Parameter2 > tableValues : list of field names and type of the fields 
	 * <Output> : NA
	 */	


public static void verifyPrescriptionAPIValues(String nameHeader,  DataTable tableValues) throws Throwable{
		
		List<List<String>> listOfTableValues = tableValues.raw();
		int countIteration = 0;

		String nameField = "";
		String typeField = "";
		String expectedValue = "";
		String actualValue = "" ;
	  
		for (List<String> listOfValues : listOfTableValues) {

			if (countIteration > 0) {
				
				nameField = listOfValues.get(0);
				typeField = listOfValues.get(1);
				switch (nameField) {

				case "Date Written:":

					expectedValue = "";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					break;

				case "Rx Expires:":
					
					expectedValue = "";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					break;

				case "SIG Code:":

					expectedValue = "";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					
					break;

				case "SIG Text":

					expectedValue = "";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					
					break;
				case "Days Supply:":

					expectedValue = "";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					
					break;
				case "Refills:":

					expectedValue = "";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					
					break;
				case "DAW:":

					expectedValue = "";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					
					break;
				case "Rx Origin Code:":

					expectedValue = "eScript by Prescriber";
					actualValue = ValueCommonMethods.getDefaultTextValues(BrowserMethods.driver1, WaitMethods.wait10driver1, nameHeader, nameField, typeField);
					
					break;
				}
				AssertionMethods.expectedActualTest(expectedValue, actualValue);
			}
			countIteration++;
		}
		

		
	}
	
	
	
}
