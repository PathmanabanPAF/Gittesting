package projectBox;

import java.util.HashMap;
import java.util.Map;

import globalBox.CommonMethods;
import globalBox.SpreadSheetMethods;

import org.apache.poi.ss.usermodel.Row;
import org.junit.Test;


public class LoadTransactionData {
	
	public static Map<String, String> rowData1 = new HashMap<String, String>();
	public static Map<String, String> rowDataWebServices = new HashMap<String, String>();
	public static Map<String, String> rowDataDrugSearch = new HashMap<String, String>();

	/*
	 * <Method Name> :  loadTestDataFromExcel
	 * <Description> :  This method is used to load data from excel
	 * <Input Parameter1 > idTestData : cell test data 
	 * <Output> : NA
	 */
	
	public static void loadTestDataFromExcel(String idTestData){
		
		String workbookPath = CommonMethods
				.readPropertiesFile("inputdata.properties", "workBookPath");
		
		String workbookName = "TestData.xlsx";
		
		String workbookSheetName = "TestData1";
		
		
		int numberColumn = SpreadSheetMethods.getColumnNumber(idTestData,workbookPath, workbookName, workbookSheetName);
		//Row dataRow = SpreadSheetMethods.getRowObject(idTestData,workbookPath, workbookName, workbookSheetName);
		Row dataRow = SpreadSheetMethods.getRowObject(idTestData,workbookPath, workbookName, workbookSheetName, numberColumn);
		
		rowData1 = SpreadSheetMethods.getAllColumnValuesFromRow(dataRow);
		
		System.out.println(rowData1);
	}
	/*
	 * <Method Name> :  getStoredData
	 * <Description> :  This method is used to print the stored data in console
	 * <Output> : NA
	 */
	@Test
	public void getStoredData(){
		
		loadWebServicesFromExcel("Person API");
		
		System.out.println("**\nAncillary Name:"+ WebServicesTransactionData.getApiParameterName()+"\n**");
		
		/*System.out.println("**\nNumber of Refills:"+ TransactionData.getNumberOfRefills()+"\n**");
		
		System.out.println("**\nPCA visibility:"+ TransactionData.getPcaVisiblility()+"\n**");
		
		System.out.println("**\nTherapy:"+ TransactionData.getTherapy()+"\n**");*/
	}
	
	
	public static void loadWebServicesFromExcel(String idTestData){
		
		String workbookPath = CommonMethods
				.readPropertiesFile("inputdata.properties", "workBookPath");
		
		String workbookName = "WebServicesDetails.xlsx";
		
		String workbookSheetName = "WebServices";
		
		
		int numberColumn = SpreadSheetMethods.getColumnNumber(idTestData,workbookPath, workbookName, workbookSheetName);
		
		Row dataRow = SpreadSheetMethods.getRowObject(idTestData,workbookPath, workbookName, workbookSheetName, numberColumn);
		
		rowDataWebServices = SpreadSheetMethods.getAllColumnValuesFromRow(dataRow);
		
		System.out.println(rowDataWebServices);
	}
	
	
	public static void loadDrugSearchTestData(String idTestData){
		
		String workbookPath = CommonMethods
				.readPropertiesFile("inputdata.properties", "workBookPath");
		
		String workbookName = "SearchTestData.xlsx";
		
		String workbookSheetName = "DrugSearch";
				
		int numberColumn = SpreadSheetMethods.getColumnNumber(idTestData,workbookPath, workbookName, workbookSheetName);
		
		Row dataRow = SpreadSheetMethods.getRowObject(idTestData,workbookPath, workbookName, workbookSheetName, numberColumn-1);
		
		rowDataDrugSearch = SpreadSheetMethods.getAllColumnValuesFromRow(dataRow);
		
		System.out.println(rowDataDrugSearch);
	}

}
