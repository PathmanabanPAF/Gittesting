package projectBox;

import globalBox.BrowserMethods;
import globalBox.DynamicXpathCalculation;
import globalBox.FrameHandlingMethods;
import globalBox.GetValueMethods;
import globalBox.WaitMethods;

import org.openqa.selenium.By;

import pageWebElementsBox.LandingPage;


public class GetWorkMethods {
	/*
	 * <Method Name> :  previousWorkClearance
	 * <Description> :  This method is used to clear all the existing works available in the work basket 
	 * <Input Parameter1 > workBasketname : Work basket name
	 * <Output> : NA
	 */

	public static void previousWorkClearance(String workBasketname) throws InterruptedException {
		FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);

		By dynamicXpathWorkBasketCount= DynamicXpathCalculation.dynamicXpathCreation(LandingPage.dynamicXpathWorkBasketCount1,workBasketname,LandingPage.dynamicXpathWorkBasketCount2);

		String workBasketCount = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, dynamicXpathWorkBasketCount);

		int countWB = Integer.parseInt(workBasketCount);

		int i=0;

		while(i<countWB){

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);

			RxCommonMethods.clickButton(workBasketname);

			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);

			RxCommonMethods.clickLink("Complete stage");

			RxCommonMethods.clickButton("Close");

			i++;
		}
		FrameHandlingMethods.switchToDefaultFrame(BrowserMethods.driver1, WaitMethods.wait20driver1);
	}
}




