package projectBox;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import globalBox.AlertMethods;
import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.CommonMethods;
import globalBox.DateConversionMethods;
import globalBox.DropdownMethods;
import globalBox.DynamicXpathCalculation;
import globalBox.EncryptDecryptMethods;
import globalBox.FrameHandlingMethods;
import globalBox.GetValueMethods;
import globalBox.KeyboardActions;
import globalBox.TextBoxMethods;
import globalBox.WaitMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;
import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.OrderEntryPage;
import pageWebElementsBox.SearchPage;

public class RxCommonMethods {
	/*
	 * <Method Name> : loginApplication <Description> : This method is used to
	 * log into the application <Input Parameter1 > local driver : current web
	 * driver <Input Parameter2 > wait : wait time <Input Parameter3 >
	 * locatorUserName : locator of user name field <Input Parameter4 >
	 * locatorPassword : locator of password field <Input Parameter5 >
	 * locatorSubmit : locator of submit button <Input Parameter6 > typeLogin :
	 * type of login <Output> : NA
	 */
	public static void loginApplication(WebDriver localdriver,
			WebDriverWait wait, By locatorUserName, By locatorPassword,
			By locatorSubmit, String typeLogin) {

		String propertyNameUserName = "";

		String propertyNamePassword = "";

		String propertyNameEncryptDecrypt = "";

		switch (typeLogin) {

		case "Technician":
			propertyNameUserName = "username_technician";
			propertyNamePassword = "password_technician";
			propertyNameEncryptDecrypt = "statepasswordencryption_technician";
			break;

		case "Technician Supervisor":
			propertyNameUserName = "username_technicianSupervisor";
			propertyNamePassword = "password_technicianSupervisor";
			propertyNameEncryptDecrypt = "statepasswordencryption_technicianSupervisor";
			break;

		case "Pharmacist":
			propertyNameUserName = "username_pharmacist";
			propertyNamePassword = "password_pharmacist";
			propertyNameEncryptDecrypt = "statepasswordencryption_pharmacist";
			break;

		default:
			break;

		}

		String userName = CommonMethods
				.readPropertiesFile("inputdata.properties", propertyNameUserName);

		String password = EncryptDecryptMethods.performEncryptDecrypt(
				propertyNamePassword, propertyNameEncryptDecrypt);

		TextBoxMethods.inputText(localdriver, wait, locatorUserName, userName);

		TextBoxMethods.inputText(localdriver, wait, locatorPassword, password);

		ClickMethods.clickElement(localdriver, wait, locatorSubmit);

		WaitMethods.waitForPageLoad(BrowserMethods.driver1,
				WaitMethods.wait20driver1);

		WaitMethods.waitForPegaPageLoad(WaitMethods.wait5driver1,
				WaitMethods.wait20driver1);
	}

	/*
	 * <Method Name> : clickButton <Description> : This method is used click the
	 * button <Input Parameter1 > nameButton : name of the button to be selected
	 * <Output> : NA
	 */

	public static void clickButton(String nameButton)
			throws InterruptedException {

		By xpathButton = DynamicXpathCalculation.dynamicXpathCreation(
				CommonWebElements.dynamicXpathButtonPart1, nameButton,
				CommonWebElements.dynamicXpathButtonPart2);

		ClickMethods.clickElement(BrowserMethods.driver1,
				WaitMethods.wait20driver1, xpathButton);

		WaitMethods.waitForPegaPageLoad(WaitMethods.wait5driver1,
				WaitMethods.wait20driver1);

		WaitMethods.waitForPageLoad(BrowserMethods.driver1,
				WaitMethods.wait20driver1);

	}

	/*
	 * <Method Name> : clickLink <Description> : This method is used click the
	 * link <Input Parameter1 > nameButton : name of the link to be clicked
	 * <Output> : NA
	 */

	public static void clickLink(String nameLink) {

		By xpathLink = DynamicXpathCalculation.dynamicXpathCreation(
				CommonWebElements.dynamicXpathLinkPart1, nameLink,
				CommonWebElements.dynamicXpathLinkPart2);

		ClickMethods.clickElement(BrowserMethods.driver1,
				WaitMethods.wait20driver1, xpathLink);
	}

	public static String getHeaderXpath(String nameHeader) 
	{
		String xpathHeader = "";
		switch (nameHeader) {

		case "Settings":
			break;
		case "Drug Search":
		case "Prescriber Search":
		case "Supervising Prescriber Search":
		case "Diagnosis Search":
		case "Search Provider":{
			xpathHeader = CommonWebElements.dynamicXpathSearchHeader1 + nameHeader + CommonWebElements.dynamicXpathSearchHeader2;
			break;
		}		
		case "Reason for Withdraw / Cancel Order Entry":	
		case "Supervising Prescriber":{
			xpathHeader = CommonWebElements.dynamicXpathHeaderPart1 + nameHeader + CommonWebElements.dynamicXpathHeaderPart2;
			break;
		}				
		default:
			FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);
			xpathHeader = CommonWebElements.dynamicXpathGeneric1 + nameHeader + CommonWebElements.dynamicXpathGeneric2;
			break;
		}
		return xpathHeader;
	}

	/*
	 * <Method Name> : enterFieldValues <Description> : This method is used
	 * enter the field value <Input Parameter1 > tableFieldDetails : Data table
	 * list <Input Parameter2 > nameSection : name of the field <Output> : NA
	 */

	public static void enterFieldValues(List<List<String>> listOfTableValues, String nameSection) throws Throwable 
	{
		int count = 0;

		String nameField = "";
		String typeField = "";
		String valueField = "";

		for (List<String> listOfValues : listOfTableValues) {

			if (count > 0) {
				nameField = listOfValues.get(0);
				typeField = listOfValues.get(1);
				valueField = listOfValues.get(2);

				ValueCommonMethods.setFieldValue(BrowserMethods.driver1, WaitMethods.wait20driver1, nameSection, nameField, typeField, valueField);

			}
			count++;
		}

	}

	/*
	 * <Method Name> : verifyFieldValues <Description> : This method is used
	 * verify the field values <Input Parameter1 > local driver : local web
	 * driver <Input Parameter2 > wait : Wait time <Input Parameter3 >
	 * nameHeader : name of the header <Input Parameter4 > tableValues : data
	 * table values <Output> : NA
	 */

	public static void verifyFieldValues(WebDriver localdriver, WebDriverWait wait, String nameHeader, DataTable tableValues) throws ParseException {
		
		List<List<String>> listOfTableValues = tableValues.raw();

		int countIteration = 0;

		String nameField = "";
		String typeField = "";
		String valueField = "";
		String actualValue = "";
		String xpathHeader = "";
		By xpathFieldType;

		xpathHeader = getHeaderXpath(nameHeader);

		for (List<String> listOfValues : listOfTableValues) {

			if (countIteration > 0) {
				nameField = listOfValues.get(0);
				typeField = listOfValues.get(1);
				valueField = listOfValues.get(2);

				switch (typeField) {

				case "Calendar":
				case "Text Box":{
					if ("Today".equalsIgnoreCase(valueField)||"Tomorrow".equalsIgnoreCase(valueField)||"Yesterday".equalsIgnoreCase(valueField)) {
						valueField = DateConversionMethods.getDate(valueField, "M/d/yyyy", "IST");
					}

					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathCalendar3 + nameField + CommonWebElements.dynamicXpathCalendar4);

					actualValue = GetValueMethods.getElementAttributeValue(localdriver, wait, xpathFieldType, "value");

					break;
				}
				case "Text box":
					if ("Today".equalsIgnoreCase(valueField)||"Tomorrow".equalsIgnoreCase(valueField)||"Yesterday".equalsIgnoreCase(valueField)) {
						valueField = DateConversionMethods.getDate(valueField, "M/d/yyyy", "IST");
					}

					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathTextBox3 + nameField + CommonWebElements.dynamicXpathTextBox4);

					actualValue = GetValueMethods.getTextValue(localdriver, wait, xpathFieldType);

					break;

				case "Text area":

					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathTextArea3 + nameField + CommonWebElements.dynamicXpathTextArea4);

					actualValue = GetValueMethods.getTextValue(localdriver,wait, xpathFieldType);

					break;

				case "Drop down":

					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathDropDown3 + nameField + CommonWebElements.dynamicXpathDropDown4);

					actualValue = DropdownMethods.getSelectedValueFromDropdown(localdriver, wait, xpathFieldType);

					break;
				}
				AssertionMethods.expectedActualTest(valueField, actualValue);
			}
			countIteration++;
		}
	}

	public static void verifyPlaceHolderValues(WebDriver localdriver,
			WebDriverWait wait, String nameHeader, DataTable tableValues,
			String attributeName) {
		List<List<String>> listTableValues = tableValues.raw();
		int countIterations = 0;

		String namePlaceHoldertField = "";
		String typePlaceHoldertField = "";
		String expectedFieldValue = "";
		String actualValue = "";
		By xpathFieldType = null;
		String xpathHeader = "";

		xpathHeader = getHeaderXpath(nameHeader);

		for (List<String> listOfValues : listTableValues) {

			if (countIterations > 0) {
				namePlaceHoldertField = listOfValues.get(0);
				typePlaceHoldertField = listOfValues.get(1);
				expectedFieldValue = listOfValues.get(2);

				switch (typePlaceHoldertField) {

				case "Calendar":

					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathCalendar3 + namePlaceHoldertField + CommonWebElements.dynamicXpathCalendar4);

					break;

				case "Text box":

					xpathFieldType = By.xpath(xpathHeader + CommonWebElements.dynamicXpathTextBox3 + namePlaceHoldertField + CommonWebElements.dynamicXpathTextBox4);

					break;

				default:
					break;
				}

				actualValue = GetValueMethods.getElementAttributeValue(
						localdriver, wait, xpathFieldType, attributeName);
				AssertionMethods.expectedActualTest(expectedFieldValue.trim(),
						actualValue.trim());
			}
			countIterations++;
		}
	}

	public static void verifyBlankFieldValidationErrorMessages(
			WebDriver localdriver, WebDriverWait wait, String nameHeader,
			DataTable tableValues, String nameButton, boolean checkExistance)
					throws InterruptedException {

		List<List<String>> listOfTableValues = tableValues.raw();

		int countLooping = 0;

		String errorFieldName = "";
		String typeField = "";
		String expectedErrorValue = "";
		String actualErrorValue = "";
		By xpathErrorFieldType = null;
		String bufferString = "";
		String bufferValue = "";
		String xpathError = "";

		String xpathHeader = "";

		xpathHeader = getHeaderXpath(nameHeader);

		for (List<String> listOfValues : listOfTableValues) {

			if (countLooping > 0) {

				errorFieldName = listOfValues.get(0);
				typeField = listOfValues.get(1);
				expectedErrorValue = listOfValues.get(2);

				switch (typeField) {

				case "Calendar":

					bufferString = xpathHeader + CommonWebElements.dynamicXpathCalendar3 + errorFieldName + CommonWebElements.dynamicXpathCalendar4;

					break;

				case "Text box":

					bufferString = xpathHeader + CommonWebElements.dynamicXpathTextBox3 + errorFieldName + CommonWebElements.dynamicXpathTextBox4;

					break;

				case "Text area":

					bufferString = xpathHeader + CommonWebElements.dynamicXpathTextArea3 + errorFieldName + CommonWebElements.dynamicXpathTextArea4;
					xpathError = "/parent::*";
					break;

				case "Drop down":

					bufferString = xpathHeader + CommonWebElements.dynamicXpathDropDown3 + errorFieldName + CommonWebElements.dynamicXpathDropDown4;
					break;

				}

				xpathError = xpathError + CommonWebElements.dynamicXpathErrorPart4;

				xpathErrorFieldType = By.xpath(bufferString
						+ xpathError);

				if(checkExistance)
				{
					bufferValue = GetValueMethods.getTextValue(
							localdriver,
							wait,
							By.xpath(bufferString));

					TextBoxMethods.clearText(localdriver,
							wait, By.xpath(bufferString));

					clickButton(nameButton);

					actualErrorValue = GetValueMethods.getTextValue(localdriver,
							wait, xpathErrorFieldType);

					AssertionMethods.expectedActualTest(expectedErrorValue,
							actualErrorValue);

					TextBoxMethods.inputText(localdriver,
							wait, By.xpath(bufferString),
							bufferValue);
				}else{
					clickButton(nameButton);
					AssertionMethods.getElementInvisiblity(wait, xpathErrorFieldType);
				}
				xpathError = "";
			}
			countLooping++;
		}
	}


	public static void verifyFieldValidationErrorMessages(
			WebDriver localdriver, WebDriverWait wait, String nameHeader,
			DataTable tableValues, String nameButton, boolean checkExistance)
					throws InterruptedException {

		List<List<String>> listOfTableValues = tableValues.raw();

		int countLooping = 0;

		String errorFieldName = "";
		String typeField = "";
		String expectedErrorValue = "";
		String actualErrorValue = "";
		By xpathErrorFieldType = null;
		String bufferString = "";
		String xpathError = "";

		String xpathHeader = "";

		xpathHeader = getHeaderXpath(nameHeader);

		for (List<String> listOfValues : listOfTableValues) {

			if (countLooping > 0) {

				errorFieldName = listOfValues.get(0);
				typeField = listOfValues.get(1);
				expectedErrorValue = listOfValues.get(2);

				switch (typeField) {

				case "Calendar":

					bufferString = xpathHeader + CommonWebElements.dynamicXpathCalendar3 + errorFieldName + CommonWebElements.dynamicXpathCalendar4;

					break;

				case "Text box":

					bufferString = xpathHeader + CommonWebElements.dynamicXpathTextBox3 + errorFieldName + CommonWebElements.dynamicXpathTextBox4;

					break;

				case "Text area":

					bufferString = xpathHeader + CommonWebElements.dynamicXpathTextArea3 + errorFieldName + CommonWebElements.dynamicXpathTextArea4;
					xpathError = "/parent::*";
					break;

				case "Drop down":

					bufferString = xpathHeader + CommonWebElements.dynamicXpathDropDown3 + errorFieldName + CommonWebElements.dynamicXpathDropDown4;
					break;
				}

				xpathError = xpathError + CommonWebElements.dynamicXpathErrorPart4;
				xpathErrorFieldType = By.xpath(bufferString
						+ xpathError);

				if(checkExistance)
				{
					clickButton(nameButton);

					actualErrorValue = GetValueMethods.getTextValue(localdriver,
							wait, xpathErrorFieldType);

					AssertionMethods.expectedActualTest(expectedErrorValue,
							actualErrorValue);


				}else{
					clickButton(nameButton);
					AssertionMethods.getElementInvisiblity(wait, xpathErrorFieldType);
				}
				xpathError = "";
			}
			countLooping++;
		}
	}

	public static void waitForTime(String waitTime) throws InterruptedException {

		long waitTimeInMinutes = Integer.parseInt(waitTime);

		long waitTimeInMilliSeconds = TimeUnit.SECONDS
				.toMillis(waitTimeInMinutes);

		Thread.sleep(waitTimeInMilliSeconds);
	}




	public static void getRequiredWorkOrder(String expectedWorkOrderId) throws ParseException, InterruptedException {
		FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget1Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);

		String idWorkOrder = GetValueMethods.getTextValue(BrowserMethods.driver1,
				WaitMethods.wait10driver1, OrderEntryPage.xpathReferralCaseId);

		List<String> nameFields = new ArrayList<>();
		nameFields.add("Date Written:");
		nameFields.add("Rx Expires:");
		nameFields.add("SIG Code:");
		nameFields.add("SIG Text");
		nameFields.add("Days Supply:");
		nameFields.add("Refills:");
		nameFields.add("Prescribed Drug:");
		nameFields.add("Prescribed Quantity:");
		nameFields.add("Dispensed Drug:");
		nameFields.add("Dispensed Quantity:");


		List<String> fieldValues = new ArrayList<>();
		fieldValues.add(DateConversionMethods.getCurrentDateInTimeZones("MM/dd/yyyy", "EST"));
		fieldValues.add(DateConversionMethods.getCurrentDateInTimeZones("MM/dd/yyyy", "EST"));
		fieldValues.add("1");
		fieldValues.add("1");
		fieldValues.add("1");
		fieldValues.add("1");
		fieldValues.add("1");
		fieldValues.add("1");
		fieldValues.add("1");
		fieldValues.add("1");

		String nameSection1 = "Prescription";
		String nameSection2 = "Drug";

		System.out.println("xpth:"+ CommonWebElements.dynamicXpathGeneric1 + nameSection1 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathCalendar3 + nameFields.get(0) + CommonWebElements.dynamicXpathCalendar4);

		while(!expectedWorkOrderId.equals(idWorkOrder)){
			TextBoxMethods.retryInputText(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection1 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathCalendar3 + nameFields.get(0) + CommonWebElements.dynamicXpathCalendar4), fieldValues.get(0));
			KeyboardActions.performTabAction(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection1 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathCalendar3 + nameFields.get(0) + CommonWebElements.dynamicXpathCalendar4));
			WaitMethods.waitForPageLoad(BrowserMethods.driver1, WaitMethods.wait10driver1);
			WaitMethods.waitForPegaPageLoad(WaitMethods.wait5driver1, WaitMethods.wait20driver1);
			TextBoxMethods.retryInputText(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection1 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathCalendar3 + nameFields.get(1) + CommonWebElements.dynamicXpathCalendar4), fieldValues.get(1));
			TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection1 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathTextBox3 + nameFields.get(2) + CommonWebElements.dynamicXpathTextBox4), fieldValues.get(2));
			TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection1 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathTextArea3 + nameFields.get(3) + CommonWebElements.dynamicXpathTextArea4), fieldValues.get(3));
			TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection1 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathTextBox3 + nameFields.get(4) + CommonWebElements.dynamicXpathTextBox4), fieldValues.get(4));
			TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection1 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathTextBox3 + nameFields.get(5) + CommonWebElements.dynamicXpathTextBox4), fieldValues.get(5));
			TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection2 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathTextBox3 + nameFields.get(6) + CommonWebElements.dynamicXpathTextBox4), fieldValues.get(6));
			TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection2 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathTextBox3 + nameFields.get(7) + CommonWebElements.dynamicXpathTextBox4), fieldValues.get(7));
			TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection2 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathTextBox3 + nameFields.get(8) + CommonWebElements.dynamicXpathTextBox4), fieldValues.get(8));
			TextBoxMethods.inputText(BrowserMethods.driver1, WaitMethods.wait20driver1, By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection2 + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathTextBox3 + nameFields.get(9) + CommonWebElements.dynamicXpathTextBox4), fieldValues.get(9));
			AlertMethods.closeAlertPopup(BrowserMethods.driver1);
			AlertMethods.closeAlertPopup(BrowserMethods.driver1);
			clickButton("Submit");
			WaitMethods.waitForPageLoad(BrowserMethods.driver1, WaitMethods.wait10driver1);
			WaitMethods.waitForPegaPageLoad(WaitMethods.wait5driver1, WaitMethods.wait20driver1);
			idWorkOrder = GetValueMethods.getTextValue(BrowserMethods.driver1,
					WaitMethods.wait10driver1, OrderEntryPage.xpathReferralCaseId);

		}
		TransactionData.setFirstCaseId(expectedWorkOrderId);

		System.out.println("");
	}

	public static void verifyFieldNonExistance(String nameSection, DataTable tableReportedTime){

		List<List<String>> listOfFieldDetails = tableReportedTime.raw();
		int coountIter= 0;

		if(coountIter>0){
			for(List<String> listOfFields: listOfFieldDetails) {

				String nameField = listOfFields.get(0);
				String typeField = listOfFields.get(1);
				By xpathField = null;

				switch(typeField){

				case "Calendar" :

					xpathField =By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection +CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathCalendar3 + nameField + CommonWebElements.dynamicXpathCalendar4);

					break;

				}

				AssertionMethods.getElementInvisiblity(WaitMethods.wait10driver1, xpathField);

			}
			coountIter++;
		}


	}


	public static void performAction(String nameHeader, DataTable tableValues) throws InterruptedException {

		List<List<String>> listOfTableValues = tableValues.raw();

		int countLooping = 0;
		String xpathHeader = "";
		String bufferXpathString = "";
		By xpathActionFieldType;

		switch (nameHeader) {

		case "Settings":
		case "Drug Search":
		case "DisplayProviderSearch":{
			break;
		}
		default:
			xpathHeader = CommonWebElements.dynamicXpathGeneric1 + nameHeader + CommonWebElements.dynamicXpathGeneric2;
			break;
		}

		for (List<String> listOfValues : listOfTableValues) {

			if (countLooping > 0) {

				String nameActionField = listOfValues.get(0);

				String typeActionField= listOfValues.get(1);

				String actionOnField= listOfValues.get(2);


				switch (typeActionField) {

				case "Calendar":

					bufferXpathString = xpathHeader + CommonWebElements.dynamicXpathCalendar3 + nameActionField + CommonWebElements.dynamicXpathCalendar4;

					break;

				case "Text box":

					bufferXpathString = xpathHeader + CommonWebElements.dynamicXpathTextBox3 + nameActionField + CommonWebElements.dynamicXpathTextBox4;

					break;

				case "Text area":

					bufferXpathString = xpathHeader + CommonWebElements.dynamicXpathTextArea3 + nameActionField + CommonWebElements.dynamicXpathTextArea4;

					break;

				case "Drop down":

					bufferXpathString = xpathHeader + CommonWebElements.dynamicXpathDropDown3 + nameActionField + CommonWebElements.dynamicXpathDropDown4;

					break;
				}

				xpathActionFieldType = By.xpath(bufferXpathString);


				if("Tab".equalsIgnoreCase(actionOnField)) {

					KeyboardActions.performTabAction(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathActionFieldType);

				} else if("Enter".equalsIgnoreCase(actionOnField)) {

					ClickMethods.clickElementByEnterKey(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathActionFieldType);

				} 	

			}
			countLooping++;
		}
	}

	public static void verifyButtons(String nameHeader, List<String> expectedListOfButtons) {

		By xpathListOfButtons = DynamicXpathCalculation.dynamicXpathCreation(SearchPage.dynamicXpathModalButtons1, nameHeader, SearchPage.dynamicXpathModalButtons2);

		List<String> actualListOfButtons = GetValueMethods.getMultipleTextValues(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathListOfButtons);

		AssertionMethods.compareLists(expectedListOfButtons, actualListOfButtons);
	}

}
