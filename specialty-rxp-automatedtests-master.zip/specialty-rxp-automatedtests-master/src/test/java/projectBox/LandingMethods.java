package projectBox;


import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.DynamicXpathCalculation;
import globalBox.FrameHandlingMethods;
import globalBox.GetValueMethods;
import globalBox.ScreenshotMethods;
import globalBox.WaitMethods;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;

import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.LandingPage;


public class LandingMethods {
		
	/*
	 * <Method Name> :  createOption
	 * <Description> :  This method is used to create option
	 * <Input Parameter1 > nameLink : Name of link
	 * <Input Parameter2 > nameOption : Name of the option
	 * <Output> : NA
	 */
	
	public static void createOption(String nameLink, String nameOption){
		
		FrameHandlingMethods.switchToDefaultFrame(BrowserMethods.driver1, WaitMethods.wait20driver1);
		
		RxCommonMethods.clickLink(nameLink);
		
		ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
				"tempJPEGFilePlaceHolder", "User click Create link in Landing page");
		
         RxCommonMethods.clickLink(nameOption);
	
	}
	
	/*
	 * <Method Name> :  verifyTRCValues
	 * <Description> :  This method is used to verify TRC values
	 * <Input Parameter1 > expectedTrcValues : List of TRC values
	 * <Output> : NA
	 */
	
	public static void verifyTRCValues(List<String> expectedTrcValues) {

		FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);
		
		List<String> actualTrcValues = GetValueMethods.getMultipleTextValues(
				BrowserMethods.driver1, WaitMethods.wait10driver1,
				LandingPage.xpathTRCValue);

		AssertionMethods.compareLists(expectedTrcValues, actualTrcValues);

	}

	/*
	 * <Method Name> :  verifyWorkBaskets
	 * <Description> :  This method is used to verify work basket list
	 * <Input Parameter1 > expectedWorkBaskets : Expected work basket list
	 * <Output> : NA
	 */

	public static void verifyWorkBaskets(List<String> expectedWorkBaskets) {

		FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);
		
		List<String> actualWorkbaskets = GetValueMethods.getMultipleTextValues(
				BrowserMethods.driver1, WaitMethods.wait10driver1,
				LandingPage.xpathWorkBaskets);

		AssertionMethods.compareLists(expectedWorkBaskets, actualWorkbaskets);

	}

	/*
	 * <Method Name> :  verifyWIPCountView
	 * <Description> :  This method is used to verify WIP count
	 * <Input Parameter1 > listWorkBaskets : Expected WIP count list
	 * <Output> : NA
	 */
		
	public static void verifyWIPCountView(List<String> listWorkBaskets) {

		FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait10driver1);
		
		for (String workBasket : listWorkBaskets) {

			By xpathWIPCount = DynamicXpathCalculation.dynamicXpathCreation(
					LandingPage.dynamicXpathWIPCountPart1, workBasket,
					LandingPage.dynamicXpathWIPCountPart2);
			
			AssertionMethods.verifyElementExists(WaitMethods.wait10driver1,
					xpathWIPCount);

		}

	}
	
	
	/*public static void workOrderID(){
		
		String caseId = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, LandingPage.xpathWordOrderId);
		
		String CaseId1 = caseId.replace("(", "");
		String finalCaseId = caseId.replace(")", "");
		TransactionData.setSecondCaseId(finalCaseId);
				
	}*/
	
	public static void patientName(){
		
		String patientName = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, LandingPage.xpathPatientName);
		
		TransactionData.setPatientName(patientName);
				
	}
	public static void updatedBy(){
		
		String updatedBy = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, LandingPage.xpathuserLoggedIn);
		
		TransactionData.setUpdatedBy(updatedBy);
		
		
	}

	
	public static void VerifyLockedCaseDetails(String nameColumn, List<String> FieldNames) throws Throwable{
	
		 FrameHandlingMethods.switchToAFrameByNameAfterDefaultContentSwitching("PegaGadget0Ifr", BrowserMethods.driver1, WaitMethods.wait20driver1);
		 List<String> actualColumnList = new ArrayList<String>();
    	 List<String> actualLockCaseDetails = new ArrayList<String>();
    	  //	List<List<String>> listFields = FieldNames.raw();
   			for(int i =0;i< FieldNames.size();i++ ) {
   			nameColumn = FieldNames.get(i);
   			By locatorColumnName = By.xpath(LandingPage.xpathMyLockCasesPart1 + nameColumn +  LandingPage.xpathMyLockCasesPart2);
    	    String actualColumnName = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, locatorColumnName);
    	    Thread.sleep(2000);
    	    actualColumnList.add(actualColumnName);
    	
    	    	ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
    					"tempJPEGFilePlaceHolder",
    					"Expected Column name is displayed");
   			}
	   		AssertionMethods.compareLists(FieldNames, actualColumnList);

	   		String workOrderId = TransactionData.getFirstCaseId();
	   		String CaseId1 = workOrderId.replace("(", "");
			String finalworkOrderId = CaseId1.replace(")", "");
			//TransactionData.setSecondCaseId(finalworkOrderId);
	   		String namePatient = TransactionData.getPatientName();
	   		String updatedBy = TransactionData.getUpdatedBy();
	   		int noOfLockCases = BrowserMethods.driver1.findElements(By.xpath("//*[@id='bodyTbl_right']//tr")).size();
	   		if (!(noOfLockCases<=1)) {
	   			for (int j=2; j<=noOfLockCases; j++){
	   				
	   				By lockCaseDetails = By.xpath(LandingPage.xpathLockedCasedetailspart1+j+LandingPage.xpathLockedCasedetailspart2+"1"+LandingPage.xpathLockedCasedetailspart3);
	   				String expectedCaseId = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, lockCaseDetails);
	   				if (expectedCaseId.equalsIgnoreCase(finalworkOrderId)){
	   					int expectedRow = j;
	   					
	   					for (int k=1; k<=4; k++){
	   						By XpathActualLockCaseDetails = By.xpath(LandingPage.xpathLockedCasedetailspart1+expectedRow+LandingPage.xpathLockedCasedetailspart2+k+LandingPage.xpathLockedCasedetailspart3);
	   						String LockCaseDetails = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, XpathActualLockCaseDetails);
	   						actualLockCaseDetails.add(LockCaseDetails);
	   					}
		   				String lockedCaseId = actualLockCaseDetails.get(0);
		   				String lockedCaseupdatedBy = actualLockCaseDetails.get(1);
		   				String lockedCasePatientName = actualLockCaseDetails.get(3);
			   			 if (finalworkOrderId.equalsIgnoreCase(lockedCaseId)&&updatedBy.equalsIgnoreCase(lockedCaseupdatedBy)&&namePatient.equalsIgnoreCase(lockedCasePatientName)){
				   	   		  ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
								"tempJPEGFilePlaceHolder",
								"A Case " +workOrderId+ " with patient Name " +namePatient+ " is locked by the user" +updatedBy); 
				   	   		     	   		  
				   	   	  }else{
				   	   		  ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
								"tempJPEGFilePlaceHolder",
								"A Case " +workOrderId+ " with patient Name " +namePatient+ " is not locked by the user" +updatedBy); 
				   	   		  
				   	   	  }	
	   				}
	   				
	   			}
	   		
	   		}else{
	   	   		  ScreenshotMethods.takeScreenshot(BrowserMethods.driver1,
					"tempJPEGFilePlaceHolder",
					"No lock cases are displayed"); 
	   	   		  
	   			 }		
	   		
		}
	public static void verifyMylockedCaseExistence(){
		
		String workOrderId = TransactionData.getFirstCaseId();
   		String CaseId1 = workOrderId.replace("(", "");
		String finalworkOrderId = CaseId1.replace(")", "");

		By xpathLink = By.xpath(CommonWebElements.dynamicXpathLinkPart1 + finalworkOrderId + CommonWebElements.dynamicXpathLinkPart2);
		
		AssertionMethods.getElementInvisiblity(WaitMethods.wait20driver1, xpathLink);
		
	}
		



}	
	
	


