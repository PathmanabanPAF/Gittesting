package projectBox;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.DateConversionMethods;
import globalBox.DropdownMethods;
import globalBox.GetValueMethods;
import globalBox.KeyboardActions;
import globalBox.RestWebservicesMethods;
import globalBox.TextBoxMethods;
import globalBox.WaitMethods;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;

import pageWebElementsBox.CommonWebElements;

public class ReviewPatientInfoMethods {

	public static void verifyPatientInfoWithAPI(String nameSection, List<String> ListOfFields) throws ParseException{
		
		Map<String, String> parameters = new HashMap<String, String>();
		
		parameters.put(CommonMethods.readPropertiesFile("webservices.properties","personapiparametername"), CommonMethods.readPropertiesFile("webservices.properties", "personapiparametervalue"));

		RestWebservicesMethods.callGetJson(CommonMethods.readPropertiesFile("webservices.properties","personapiurl"), "Authorization", "Basic UUZTUjAxOjZJQUBFR1NM", parameters);

		By xpathReadOnlyValue;
		for(String nameField : ListOfFields) {
			String expectedFieldValue = "";
			if("Additional Information".equals(nameSection)){
			 xpathReadOnlyValue = By.xpath(CommonWebElements.dynamicXpathCollapsibleHeaderPart1 + nameSection + CommonWebElements.dynamicXpathCollapsibleHeaderPart2 + CommonWebElements.dynamicXpathReadOnly3 + nameField + CommonWebElements.dynamicXpathReadOnly4);
			} else {
				xpathReadOnlyValue = By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathReadOnly3 + nameField + CommonWebElements.dynamicXpathReadOnly4);
				
			}
			String actualFieldValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathReadOnlyValue);

			switch(nameField){

			case "DOB:":
				String valueAPI =  RestWebservicesMethods.getNodeValueGetJson("birthDate");
				expectedFieldValue = DateConversionMethods.changeDateFormat(valueAPI, "yyyy-MM-dd", "MM/dd/yyyy");


				break;

			case "Gender":
				expectedFieldValue = RestWebservicesMethods.getNodeValueGetJson("gender");
				break;

			case "Phone number":

				int countOfPhoneNumbers = RestWebservicesMethods.getCountGetJsonNodes("phoneNumbers.number");

				for (int k = 0; k < countOfPhoneNumbers; k++) {
					String valueHome = RestWebservicesMethods.getNodeValueGetJson("phoneNumbers.classifications.home[" + k + "]");
					if("True".equalsIgnoreCase(valueHome)){
						expectedFieldValue = RestWebservicesMethods.getNodeValueGetJson("phoneNumbers.number[" + k + "]");
						break;
					}
				}

				break;

			case "Phone Type":

				int countOfPhoneNumber = RestWebservicesMethods.getCountGetJsonNodes("phoneNumbers.number");

				for (int k = 0; k < countOfPhoneNumber; k++) {
					String valueHome = RestWebservicesMethods.getNodeValueGetJson("phoneNumbers.classifications.home[" + k + "]");
					if("True".equalsIgnoreCase(valueHome)){
						expectedFieldValue = "Home";
						break;
					}
				}
				
				break;

			case "Shipping Address":

				expectedFieldValue = getAdditionalAddress();
				break;
				
			case "RxHome ID":

				expectedFieldValue = RestWebservicesMethods.getNodeValueGetJson("mdmId");				
				break;

			case "Name":

				expectedFieldValue = getPatientNameAPI();
				break;

			case "Address":

				expectedFieldValue = getHomeAddress();
				break;

			}

			AssertionMethods.expectedActualTest(expectedFieldValue, actualFieldValue);

		}

	}


	public static String getAdditionalAddress(){

		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put(CommonMethods.readPropertiesFile("webservices.properties", "personapiparametername"), CommonMethods.readPropertiesFile("webservices.properties", "personapiparametervalue"));

		RestWebservicesMethods.callGetJson(CommonMethods.readPropertiesFile("webservices.properties","personapiurl"), "Authorization", "Basic UUZTUjAxOjZJQUBFR1NM", parameters);

		int countOfAdresses = RestWebservicesMethods.getCountGetJsonNodes("postalAddresses.classifications.customTags");

		for (int k = 0; k < countOfAdresses; k++) {

			String valueHome = RestWebservicesMethods.getNodeValueGetJson("	postalAddresses.classifications.customTags["+ k +"]");

			System.out.println("set:"+ valueHome);

			if("SHIPD".equalsIgnoreCase(valueHome)){

				String lines = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.streetAddress[" + k + "]");
				String city = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.city[" + k + "]");
				String state = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.state[" + k + "].code");
				String postalCode = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.postalCode[" + k + "]");
				String country = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.country[" + k + "].iso3code");

				String shipDAddressLine = lines + ", " + city + ", " + state + ", " + postalCode + ", " + country;

				return shipDAddressLine;

			}
		}

		for (int k = 0; k < countOfAdresses ; k++) {

			String valueHome = RestWebservicesMethods.getNodeValueGetJson("phoneNumbers.classifications.home[" + k + "]");

			if("HOMED".equalsIgnoreCase(valueHome)){
				String lines = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.streetAddress[" + k+1 + "]");
				String city = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.city[" + k+1 + "]");
				String state = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.state[" + k+1 + "].code");
				String postalCode = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.postalCode[" + k+1 + "]");
				String country = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.country[" + k+1 + "].iso3code");

				String otherAddressLine = lines + ", " + city + ", " + state + ", " + postalCode + ", " + country;

				return otherAddressLine;
			}
		}

		return null;
	}


	public static String getPatientNameAPI() {

		String firstName = RestWebservicesMethods.getNodeValueGetJson("name.first");
		String middleName = RestWebservicesMethods.getNodeValueGetJson("name.middle");
		String lastName = RestWebservicesMethods.getNodeValueGetJson("name.last");
		String suffixName = RestWebservicesMethods.getNodeValueGetJson("name.generationalSuffix");

		String finalName = firstName + ", " + middleName + ", " + lastName + " ,"+ suffixName;

		return finalName;
	}

	public static String getHomeAddress() {

		int countOfAdresses = RestWebservicesMethods.getCountGetJsonNodes("postalAddresses.classifications.customTags");

		for (int k = 0; k < countOfAdresses; k++) {

			String valueHome = RestWebservicesMethods.getNodeValueGetJson("	postalAddresses.classifications.customTags["+ k +"]");

			System.out.println("set:"+ valueHome);

			if("HOMED".equalsIgnoreCase(valueHome)){

				String addressHome = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.streetAddress[" + k + "]");
				String cityHome = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.city[" + k + "]");
				String stateHome = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.state[" + k + "].code");
				String postalCodeHome = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.postalCode[" + k + "]");
				String countryHome = RestWebservicesMethods.getNodeValueGetJson("postalAddresses.country[" + k + "].iso3code");

				String shipDAddressLine = addressHome + ", " + cityHome + ", " + stateHome + ", " + postalCodeHome + ", " + countryHome;

				return shipDAddressLine;

			}
		}
		return null;
	}
	
	
	public static void verifyPatientAge(String nameField, String format, String dependField, String nameSection) throws ParseException{
		
		By xpathAgeValue = By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathReadOnly3 + nameField + CommonWebElements.dynamicXpathReadOnly4);
		
		By xpathDOBValue = By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection + CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathReadOnly3 + dependField + CommonWebElements.dynamicXpathReadOnly4);
		
		String actualAgeValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathAgeValue);
		
		String actualDOBValue = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathDOBValue);
		
		String textDOBValue = DateConversionMethods.changeDateFormat(actualDOBValue, "MM/dd/yyyy", "MM/dd/yyyy");
	
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		
		LocalDate localDOBDateValue = LocalDate.parse(textDOBValue, formatter);
		
		String  actualCurrentDate = DateConversionMethods.getCurrentDateInTimeZones("MM/dd/yyyy", "EST");
		LocalDate localCurrentDateValue = LocalDate.parse(actualCurrentDate, formatter);
		
		
		Period period = Period.between(localDOBDateValue, localCurrentDateValue);
		
		String expectedAgeValue = period.getYears() + " Years " + period.getMonths() +  " Months";
		
		AssertionMethods.expectedActualTest(expectedAgeValue, actualAgeValue);

	}
	
	public static void selectFieldValueFromDropDown(String nameField, String valueField, String nameSection){
		
		By xpathDropdownField = By.xpath(CommonWebElements.dynamicXpathDropDownField1 + nameSection + CommonWebElements.dynamicXpathDropDownField2 +  CommonWebElements.dynamicXpathDropDownField3  + nameField + CommonWebElements.dynamicXpathDropDownField4);
		
		DropdownMethods.retryingSelectValueFromDropdown(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathDropdownField, valueField);
		
		//KeyboardActions.performTabAction(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathTextBoxField);

	}

	
	public static void inputTextValue(String nameField, String valueField, String nameSection) throws InterruptedException{
		
		By xpathTextBoxField = By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection + CommonWebElements.dynamicXpathGeneric2  +  CommonWebElements.dynamicXpathTextBox3  + nameField + CommonWebElements.dynamicXpathTextBox4);
		
		TextBoxMethods.retryInputText(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathTextBoxField, valueField);
		
		KeyboardActions.performTabAction(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathTextBoxField);

	}

	public static void verifyConvertedWeightValues(String nameField, String valueToBeConverted, String unitToConvert, String nameSection){
		By xpathTexBoxField = By.xpath(CommonWebElements.dynamicXpathGeneric1 + nameSection + CommonWebElements.dynamicXpathGeneric2 +  CommonWebElements.dynamicXpathTextBox3 + nameField + CommonWebElements.dynamicXpathTextBox4);
		
		double convertedValue = 0;
		
		String actualValue = GetValueMethods.getElementAttributeValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathTexBoxField, "value");
		
		switch(unitToConvert){
		
		case "Kgs":
			convertedValue = Integer.parseInt(valueToBeConverted) * 0.45395;
			
			break;
		case "lbs":
			
			convertedValue = Integer.parseInt(valueToBeConverted) * 2.2046;
			break;
		}
		
		double roundOff = Math.round(convertedValue * 100.0) / 100.0;
		
		String expectedValue = Double.toString(roundOff);
		
		AssertionMethods.expectedActualTest(expectedValue, actualValue);
		
	}

}
