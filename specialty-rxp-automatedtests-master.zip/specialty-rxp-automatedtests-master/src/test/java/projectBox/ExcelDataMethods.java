package projectBox;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.CommonMethods;
import globalBox.CountMethods;
import globalBox.GetValueMethods;
import globalBox.SpreadSheetMethods;
import globalBox.WaitMethods;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;

import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.SearchPage;
import cucumber.api.DataTable;

public class ExcelDataMethods {


	public static void enterExcelData(String nameSection, String nameScenario, DataTable tableFieldData) throws Throwable 
	{

		List<List<String>> listOfFieldData = tableFieldData.raw();

		int countOfFieldData = 0;

		for(List<String> listOfRowData: listOfFieldData) 
		{

			if(countOfFieldData>0){

				String nameField = listOfRowData.get(0);
				String typeField = listOfRowData.get(1);


				List<String> listOfColumnData = SpreadSheetMethods.getListOfColumnData(CommonMethods.readPropertiesFile("inputdata.properties", "workBookPath"),"SearchTestData.xlsx", nameSection, nameScenario, nameField);


				ValueCommonMethods.setFieldValue(BrowserMethods.driver1, WaitMethods.wait20driver1, nameSection, nameField, typeField, listOfColumnData.get(0));
			}

			countOfFieldData++;

		}

	}


	public static void verifySearchresultsColumnsData(String nameSearch, String nameScenario, String typeResults, List<String> listOfColumnNames) {
		int countOfFieldData = 0;
		
		for(String nameColumn: listOfColumnNames){

			if(countOfFieldData > 0) {

				List<String> listOfExpectedColumnValues = SpreadSheetMethods.getListOfColumnData(CommonMethods.readPropertiesFile("inputdata.properties", "workBookPath"),"SearchTestData.xlsx", nameSearch, nameScenario, nameColumn);


				By xpathNextPageButton = By.xpath(CommonWebElements.dynamicXpathSearchHeader1 + nameSearch + CommonWebElements.dynamicXpathSearchHeader2 + SearchPage.dynamicXpathNextPageButton3);

				int sizeOfNextButtons = CountMethods.getNumberOfWebElementsWithoutFailure(BrowserMethods.driver1, WaitMethods.wait3driver1, xpathNextPageButton);

				int columnNumber = SearchMethods.getTableColumnNumber(nameSearch, nameColumn);

				do {

					By xpathColumnValue = By.xpath(CommonWebElements.dynamicXpathSearchHeader1 + nameSearch + CommonWebElements.dynamicXpathSearchHeader2 + SearchPage.dynamicXpathColumnValues1 + columnNumber + SearchPage.dynamicXpathColumnValues2);

					List<String> listColumnValues = GetValueMethods.getMultipleTextValues(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathColumnValue);

					switch(typeResults.toLowerCase()){

					case "matched":
						AssertionMethods.verifyListMatchesText(listOfExpectedColumnValues.get(0), listColumnValues);
						break;
					case "contains":
						AssertionMethods.verifyListContainsText(listOfExpectedColumnValues.get(0), listColumnValues);
						break;
					case "starts-with":
						AssertionMethods.verifyListStartsWithText(listOfExpectedColumnValues.get(0), listColumnValues);
						break;
					case "not contains":
						AssertionMethods.verifyListNotContainsText(listOfExpectedColumnValues.get(0), listColumnValues);
						break;
					}
					
					if(sizeOfNextButtons>0){

					ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathNextPageButton);
					}
					try{
						sizeOfNextButtons = CountMethods.getNumberOfWebElementsWithoutFailure(BrowserMethods.driver1, WaitMethods.wait5driver1, xpathNextPageButton);

					} catch(Exception e){
						
					}
					
				} while(sizeOfNextButtons > 0);
			}
			countOfFieldData++;

		}

		
	}


	public static void selectSignleRecord(String nameSection, String nameScenario, DataTable tableFieldData)
	{
		List<List<String>> listOfFieldData = tableFieldData.raw();
		List<List<String>> listOfListFieldData = new ArrayList<List<String>>() ;

		int counter = 0;
		for(List<String> listOfRowData: listOfFieldData) 
		{
			String nameField = listOfRowData.get(0);
			if(counter==0)
			{
				List<String> tempList = new ArrayList<String>();
				tempList.add(nameField);
				listOfListFieldData.add(tempList);
			}
			if(counter!=0)	
			{	
				List<String> listOfColumnData = SpreadSheetMethods.getListOfColumnData(CommonMethods.readPropertiesFile("inputdata.properties", "workBookPath"),"SearchTestData.xlsx", nameSection, nameScenario, nameField);			
				List<String> tempList = new ArrayList<String>();
				tempList.add(nameField);
				tempList.add(listOfColumnData.get(0));
				listOfListFieldData.add(tempList);
			}			
			counter++;
		}
		//SearchMethods.selectOneRecordFromTable(listOfListFieldData);		
		SearchMethods.selectSingleRecordFromTbl(listOfListFieldData, By.xpath("./*[text()]"), false);
	}


	public static void verifyFieldValues(String nameSection, String nameSheet,String nameScenario, DataTable tableFieldData) throws Throwable
	{
		int counter =0;
		List<List<String>> listOfFieldData = tableFieldData.raw();
		for(List<String> listOfRowData: listOfFieldData) 
		{
			if(counter!=0)
			{
				String nameField = listOfRowData.get(0);
				String fieldType = listOfRowData.get(1);
				List<String> listOfColumnData = SpreadSheetMethods.getListOfColumnData(CommonMethods.readPropertiesFile("inputdata.properties", "workBookPath"),"SearchTestData.xlsx", nameSheet, nameScenario, nameField);			
				ValueCommonMethods.verifyTextValues(BrowserMethods.driver1,WaitMethods.wait20driver1, nameSection, nameField, fieldType,listOfColumnData.get(0));							
			}
			counter++;

		}

	}


	public static void verifyPhoneNumberSearchResults(String nameSearch, String nameScenario, String typeResults, List<String> listOfColumnNames){
		int countOfFieldData = 0;

		for(String nameColumn: listOfColumnNames){
			if(countOfFieldData>0){
				List<String> listOfColumnValues = SpreadSheetMethods.getListOfColumnData(CommonMethods.readPropertiesFile("inputdata.properties", "workBookPath"),"SearchTestData.xlsx", nameSearch, nameScenario, nameColumn);			


				By xpathNumberOfRows = By.xpath(CommonWebElements.dynamicXpathSearchHeader1 + nameSearch + CommonWebElements.dynamicXpathSearchHeader2 +
						SearchPage.xpathRowCount);

				int rowCount = CountMethods.getElementsNumber(BrowserMethods.driver1,WaitMethods.wait20driver1, xpathNumberOfRows);

				for (int i=1;i<rowCount;i++){

					By xpathPhoneNumberColumn = By.xpath(CommonWebElements.dynamicXpathSearchHeader1 + nameSearch + CommonWebElements.dynamicXpathSearchHeader2 +
							SearchPage.dynamicXpathPhoneNumberColumn3 + Integer.toString(i+1)+ SearchPage.dynamicXpathPhoneNumberColumn4 +
							CommonWebElements.dynamicXpathReadOnly3 +  nameColumn + CommonWebElements.dynamicXpathReadOnly4);

					List<String> listOfRowPhoneNumbers = GetValueMethods.getMultipleTextValues(BrowserMethods.driver1,WaitMethods.wait20driver1, xpathPhoneNumberColumn);

					if(!listOfRowPhoneNumbers.contains(listOfColumnValues.get(0))){
						CommonMethods.testStepPassFlag = false;
					}
				}
			}
			countOfFieldData++;
		}
	}


}
