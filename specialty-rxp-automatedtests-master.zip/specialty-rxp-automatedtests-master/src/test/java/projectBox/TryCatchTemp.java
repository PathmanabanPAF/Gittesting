package projectBox;

import globalBox.CommonMethods;

import org.junit.Assert;

public class TryCatchTemp {

	public static void exceptionClosure(String nameOfDriver, String stepMessage, Exception exception) {

		CommonMethods.closure(nameOfDriver, "","Exception encountered ::" + exception.toString(),"Step::<<" + stepMessage + ">> has failed due to an exception"+ exception.toString());

		Assert.fail(exception.toString());
	}

	public static void checkFlagClosure(String nameOfDriver, String stepMessage) {

		if (CommonMethods.testStepPassFlag == false) {

			CommonMethods.closure(nameOfDriver, "" , "screenshotFileMessage","Step::<<" + stepMessage + ">> has failed due to testStepPassFlag false value");

			Assert.fail("There is failure while User "+ stepMessage);

		}
	}
}
