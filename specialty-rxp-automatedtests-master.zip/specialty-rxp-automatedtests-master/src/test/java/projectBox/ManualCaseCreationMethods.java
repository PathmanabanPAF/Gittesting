package projectBox;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.DynamicXpathCalculation;
import globalBox.WaitMethods;

import org.openqa.selenium.By;

import pageWebElementsBox.ManualCaseCreatePage;

public class ManualCaseCreationMethods {
	/*
	 * <Method Name> :  caseSummaryCheck
	 * <Description> :  This methods is used to verify the case summary
	 * <Input Parameter1 > nameField : field name
	 * <Input Parameter2 > nameFieldValue :field value
	 * <Input Parameter3 > nameHeader : Name of the header
	 * <Output> : NA
	 */
	public static void caseSummaryCheck(String caseAction, String nameField, String nameFieldValue, String nameHeader )
	{

		By dynamicXpathCaseSummary = DynamicXpathCalculation.dynamicXpathCreation(ManualCaseCreatePage.dynamicXpathCaseSummary1, nameHeader, ManualCaseCreatePage.dynamicXpathCaseSummary2);
		
		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait20driver1,dynamicXpathCaseSummary);
		
		String fieldValue = ManualCaseCreatePage.dynamicXpathCaseSummary1 + nameHeader + ManualCaseCreatePage.dynamicXpathCaseSummary2 + ManualCaseCreatePage.dynamicXpathCaseSummary3 + nameField + ManualCaseCreatePage.dynamicXpathCaseSummary4 + nameFieldValue + ManualCaseCreatePage.dynamicXpathCaseSummary5 ;

		By consolidatedField = By.xpath(fieldValue);
		AssertionMethods.verifyElementExists(WaitMethods.wait20driver1, consolidatedField);
		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait20driver1,dynamicXpathCaseSummary);
	}
}
