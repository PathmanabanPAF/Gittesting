package projectBox;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.openqa.selenium.By;
import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.SearchPage;
import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.GetValueMethods;
import globalBox.ScreenshotMethods;
import globalBox.TableAndPageHandlingMethods;
import globalBox.WaitMethods;

public class SortingMethods {
	
	public static void columnSort(String colName){
		
		//String sortOrder = "";
		int rowCount = 0;
		
		By colNameXpath = By.xpath(CommonWebElements.dynamicXpathColName1 + colName + CommonWebElements.dynamicXpathColName2);

		ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, colNameXpath);
		
			
		//sortOrder = getSortingOrder(colName);
		
		rowCount = TableAndPageHandlingMethods.getRowCount(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.drugResultsLocator);
		
		if(rowCount>2){
			
			columnSortAscending(colName);
			
			ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, colNameXpath);
			
			columnSortDescending(colName);
			
			/*
			if(sortOrder.equalsIgnoreCase("This column is sorted in ascending order. Enter to sort.")){
				
				columnSortDescending(colName);
				
			}else if(sortOrder.equalsIgnoreCase("This column is sorted in descending order. Enter to sort.")){
				
				columnSortAscending(colName);
			}*/
		
		}else{
			
			ScreenshotMethods.takeScreenshot(BrowserMethods.driver1, "Cant able to sort, as only one record displayed", "Cant able to sort, as only one record displayed");
			
		}
	}
	public static String getSortingOrder(String colName){
		
		String sortingOrder = "";
		
		By colXpath = By.xpath(CommonWebElements.dynamicXpathColumnName1 + colName + CommonWebElements.dynamicXpathColumnName2);
		
		sortingOrder = GetValueMethods.getElementPresentTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, colXpath);
		
		return sortingOrder;
	}

	public static void columnSortDescending(String colName){
		
		int colNum = 0;

		//List<String> columnTextResultList = new ArrayList<String>();
		
		//List<String> columnTextResultList1 = new ArrayList<String>();
		
		List<String> descOrderList = new ArrayList<String>();
		
		colNum = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.drugResultsLocator, colName, SearchPage.druglocInd , false);
		
		List<String> colValues = TableAndPageHandlingMethods.getAllColumnTextInTable(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.drugResultsLocator, 1, (colNum-1), SearchPage.druglocInd);
											
		Collections.sort(colValues, Collections.reverseOrder());
	    
		for(String listValue: colValues){
	    	
			System.out.println(listValue);
	    	
			descOrderList.add(listValue);
	    
		}
			
		List<String> colValuesAfterDescSort = TableAndPageHandlingMethods.getAllColumnTextInTable(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.drugResultsLocator, 1, (colNum-1), SearchPage.druglocInd);
	    
		AssertionMethods.compareLists(descOrderList, colValuesAfterDescSort);
	
	}
	
	
	
	

	public static void columnSortAscending(String colName){
		
		int colNum = 0;

	/*	List<String> columnTextResultList = new ArrayList<String>();
		
		List<String> columnTextResultList1 = new ArrayList<String>();*/

		List<String> ascendOrderList = new ArrayList<String>();
		
		//boolean isNamesOrdered = Ordering.natural().isOrdered(listColumnValues);
		

		colNum = TableAndPageHandlingMethods.getColNumber(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.drugResultsLocator, colName, SearchPage.druglocInd , false);

		
		List<String> colValues = TableAndPageHandlingMethods.getAllColumnTextInTable(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.drugResultsLocator, 1, (colNum-1), SearchPage.druglocInd);
	   
		Collections.sort(colValues);
		    
		for(String listValue: colValues){
	    	
			System.out.println(listValue);
	    	
			ascendOrderList.add(listValue);
	    
		}
	   
		List<String> colValuesAfterAscSort = TableAndPageHandlingMethods.getAllColumnTextInTable(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.drugResultsLocator, 1, (colNum-1), SearchPage.druglocInd);
	    
		AssertionMethods.compareLists(ascendOrderList, colValuesAfterAscSort);
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
