package projectBox;

import java.text.ParseException;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;
//import cucumber.api.java.it.Date;
import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.DatePickerPopup;
import globalBox.BrowserMethods;
import globalBox.ClickMethods;
import globalBox.CommonMethods;
import globalBox.DateConversionMethods;
import globalBox.DynamicXpathCalculation;
import globalBox.GetValueMethods;
//import globalBox.GetValueMethods;
import globalBox.WaitMethods;

public class DatePicker {

	public static void selectDatefromPicker(String selectDate,String dateFormat) throws Exception
	{
		int indexOfYear = 0;
		int indexOfMonth = 0;
		int indexOfDate =0;
		/*String defaultSelectedDate = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1,DatePickerPopup.defaultDate); 
		String defaulSelectedtMonth = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1,DatePickerPopup.defaultMonth);
		String defaulSelectedtYear = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1,DatePickerPopup.defaultYear);
		*/
        String arrDateFormat[] = (dateFormat.split("/"));
        String arrSelectDate[] = (selectDate.split("/"));        
        for (int yy = 0; yy < arrDateFormat.length; yy++){
        	if (arrDateFormat[yy].toUpperCase().contains(("Y"))) { indexOfYear = yy; break; }
        }
        int yearDiff = Integer.parseInt(arrSelectDate[indexOfYear])- Calendar.getInstance().get(Calendar.YEAR);
        selectYEAR(yearDiff);
        
        for (int mm = 0; mm < arrDateFormat.length; mm++){
        	if (arrDateFormat[mm].toUpperCase().contains(("M"))) { indexOfMonth = mm; break;}
        }  
        int monthDiff = Integer.parseInt(arrSelectDate[indexOfMonth])- (Calendar.getInstance().get(Calendar.MONTH)+1);
        selectMONTH(monthDiff);
        for (int dd = 0; dd < arrDateFormat.length; dd++){
        	if (arrDateFormat[dd].toUpperCase().contains(("D"))) { indexOfDate = dd; break;	}
        }    
        
        selectDate(Integer.parseInt(arrSelectDate[indexOfDate]));
      }
	

		
		//********************select the YEAR********************
		public static void selectYEAR(int yearDiff) throws InterruptedException{

	    	if(yearDiff>0){
	            for(int i=0;i< yearDiff;i++){
	                System.out.println("Year Diff->"+i);
	                ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, 
	                		DatePickerPopup.nextYearButton);	        Thread.sleep(1000);}
	         }
	        //if you have to move previous year
	        if(yearDiff<0){
	            for(int i=0;i< (yearDiff*(-1));i++){
	                System.out.println("Year Diff->"+i);
	                ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, 
	                		DatePickerPopup.previousYearButton);	        Thread.sleep(1000);}
	            }

		}
		
		//********************select the MONTH********************
		public static void selectMONTH(int monthDiff)throws InterruptedException{
	    	if(monthDiff>0){
	            for(int i=0;i< monthDiff;i++){
	                System.out.println("Month Diff->"+i);
	                ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, 
	                		DatePickerPopup.nextMonthButton);	        Thread.sleep(1000);}
	         }
	        //if you have to move previous year
	         if(monthDiff<0){
	            for(int i=0;i< (monthDiff*(-1));i++){
	                System.out.println("Month Diff->"+i);
	                ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1, 
	                		DatePickerPopup.previousMonthButton);	        Thread.sleep(1000);}
	            }
	        Thread.sleep(1000);
		}
		
		//********************select Date from the table********************
		public static void selectDate(int pickDate) throws InterruptedException{
			By pickDateDynamicXpath = DynamicXpathCalculation.dynamicXpathCreation(DatePickerPopup.pickDateString1, Integer.toString(pickDate), DatePickerPopup.pickDateString2);
			ClickMethods.clickElement(BrowserMethods.driver1, WaitMethods.wait10driver1,pickDateDynamicXpath );
		}
		
		//********************Return month name********************
		public static String theMonth(int month){
		    String[] monthNames = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
		    return monthNames[month];
		}		
		//********************click Calendar ICON for given data table value********************
		
		public static void clickCalenderICON(WebDriver localdriver,WebDriverWait wait, 
				String nameHeader, DataTable tableValues){
			
			List<List<String>> listTableValues = tableValues.raw();
			int countIterations = 0;
			String namePlaceHoldertField = "";
			By xpathFieldType = null;
			
			for (List<String> listOfValues : listTableValues) {
				if (countIterations > 0) {
					namePlaceHoldertField = listOfValues.get(0);
					xpathFieldType = By
							.xpath(CommonWebElements.dynamicXpathGeneric1
									+ nameHeader
									+ CommonWebElements.dynamicXpathGeneric2 + CommonWebElements.dynamicXpathCalendar3
									+ namePlaceHoldertField
									+ CommonWebElements.dynamicXpathCalendar4
									+ CommonWebElements.dynamicXpathCalendarPart4);
				}
				countIterations++;
			}

			
			ClickMethods.clickElement(localdriver, WaitMethods.wait10driver1, 
					xpathFieldType);	
		}
		//********************Check Default selected date in calendar********************
		
		public static void checkDefaultDateInPicker(String valueField) throws ParseException {
			String dateFormat ="MM/dd/yyyy";
			valueField = DateConversionMethods.getDate(valueField, dateFormat, "EST");
			
			int getCurrentDate = DateConversionMethods.getDateValueFromDate(valueField, dateFormat);
			int getCurrentYEAR = DateConversionMethods.getYearFromDate(valueField, dateFormat);
			String getCurrentMonth = theMonth(DateConversionMethods.getMonthFromDate(valueField, dateFormat));
			
			String selectedDateInPicker = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1,DatePickerPopup.defaultDate); 
			String selectedtMonthInPicker = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1,DatePickerPopup.defaultMonth);
			String selectedtYearInPicker = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1,DatePickerPopup.defaultYear);
			int expectedYear = Integer.parseInt(selectedtYearInPicker); 
			
			if(!(Integer.parseInt(selectedDateInPicker)== getCurrentDate && 
					selectedtMonthInPicker.equalsIgnoreCase(getCurrentMonth) &&
					expectedYear == getCurrentYEAR)){
				CommonMethods.testStepPassFlag = false;
			}
		}

}