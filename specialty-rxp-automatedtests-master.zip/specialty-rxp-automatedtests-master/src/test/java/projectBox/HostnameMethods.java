package projectBox;

import org.openqa.selenium.By;

import pageWebElementsBox.CommonWebElements;
import pageWebElementsBox.LoginPage;
import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.DynamicXpathCalculation;
import globalBox.GetValueMethods;
import globalBox.WaitMethods;

public class HostnameMethods {
	/*
	 * <Method Name> :  verifyFooterValue
	 * <Description> :  This method is used to verify the footer value
	 * <Input Parameter1 > footerField : Name of footer value
	 * <Input Parameter2 > expectedHostName : Expected name of the host 
	 * <Output> : NA
	 */
	public static void verifyFooterValue(String footerField, String expectedHostName){
		String actualHostName="";
		By dynamicXpathFooterValue = DynamicXpathCalculation.dynamicXpathCreation(LoginPage.dynamicXpathFooterValue1, footerField, LoginPage.dynamicXpathFooterValue2);

		actualHostName= GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, dynamicXpathFooterValue);
		
		int indexofCharacter = actualHostName.indexOf(".express");		
		StringBuffer sBuffer = new StringBuffer(actualHostName);	
		actualHostName = sBuffer.replace(indexofCharacter-3, indexofCharacter, "").toString();
		System.out.println("First:"+actualHostName);
		
		indexofCharacter = expectedHostName.indexOf(".express");
		StringBuffer strBuffer = new StringBuffer(expectedHostName);
		expectedHostName = strBuffer.replace(indexofCharacter-3, indexofCharacter, "").toString();
		System.out.println("Second:"+expectedHostName);
		AssertionMethods.expectedActualTest(expectedHostName, actualHostName);
	}
	/*
	 * <Method Name> :  verifyHostName
	 * <Description> :  This method is used to verify host name
	 * <Input Parameter1 > expectedHost : Expected name of the host
	 * <Output> : NA
	 */	
	public static void verifyHostName(String expectedHost){

		String hostHeader1 = "";
		String hostHeader2 = "";
		By xpathHostHeader1 = By.xpath(CommonWebElements.dynamicXpathHostName1);
		hostHeader1 = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathHostHeader1);

		By xpathHostHeader2 = By.xpath(CommonWebElements.dynamicXpathHostName1+CommonWebElements.dynamicXpathHostName2);
		hostHeader2 = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait20driver1, xpathHostHeader2);

		String actualHost = hostHeader1+hostHeader2;
		int indexofCharacter = actualHost.indexOf(".express");		
		StringBuffer sBuffer = new StringBuffer(actualHost);	
		actualHost = sBuffer.replace(indexofCharacter-3, indexofCharacter, "").toString();
		System.out.println("First:"+actualHost);
		
		indexofCharacter = expectedHost.indexOf(".express");
		StringBuffer strBuffer = new StringBuffer(expectedHost);
		expectedHost = strBuffer.replace(indexofCharacter-3, indexofCharacter, "").toString();
		System.out.println("Second:"+expectedHost);
		AssertionMethods.expectedActualTest(expectedHost, actualHost);

	}

}
