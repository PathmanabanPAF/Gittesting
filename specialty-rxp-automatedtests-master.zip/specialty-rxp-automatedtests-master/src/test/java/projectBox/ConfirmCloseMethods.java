package projectBox;

import globalBox.AssertionMethods;
import globalBox.BrowserMethods;
import globalBox.DynamicXpathCalculation;
import globalBox.GetValueMethods;
import globalBox.WaitMethods;

import org.openqa.selenium.By;

import pageWebElementsBox.ConfirmClosePage;

public class ConfirmCloseMethods {
	/*
	 * <Method Name> :  verifyConfirmClosePopUpMessage
	 * <Description> :  This method is used to verify the confirm close pop up message
	 * <Input Parameter1 > nameOfPopUp : Name of the POP up
	 * <Input Parameter2 > expectedConfirmClosePopUpMessage : Confirmation message to be verified
	 * <Output> : NA
	 */
	public static void verifyConfirmClosePopUpMessage(String nameOfPopUp, String expectedConfirmClosePopUpMessage)
	{	
		By xpathConfirmClosePopupMessage = DynamicXpathCalculation.dynamicXpathCreation(ConfirmClosePage.dynamicXpathPopUpMessagePart1, nameOfPopUp, ConfirmClosePage.dynamicXpathPopUpMessagePart2);
		String actualConfirmClosePopUpMessage = GetValueMethods.getTextValue(BrowserMethods.driver1, WaitMethods.wait10driver1, xpathConfirmClosePopupMessage);
		AssertionMethods.expectedActualTest(expectedConfirmClosePopUpMessage, actualConfirmClosePopUpMessage.trim());
	}
	
}
