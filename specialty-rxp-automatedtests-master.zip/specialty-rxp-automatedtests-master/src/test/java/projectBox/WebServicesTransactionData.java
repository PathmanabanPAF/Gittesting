package projectBox;

public class WebServicesTransactionData {
	
	public static String nameAPI = LoadTransactionData.rowDataWebServices
			.get("WebService Name");
	
	public static String urlAPI = LoadTransactionData.rowDataWebServices
			.get("Url");
		
	public static String parameterNameAPI = LoadTransactionData.rowDataWebServices
			.get("Parameter Namee");
	
	public static String parameterValueAPI = LoadTransactionData.rowDataWebServices
			.get("Parameter Value");
	
	public static String  headerNameAPI= LoadTransactionData.rowDataWebServices
			.get("Header Name");
	
	public static String headerValueAPI = LoadTransactionData.rowDataWebServices
			.get("Header Value");

	
	
	public static String getApiName() {	return nameAPI;	}
	
	public static String getApiUrl() {	return nameAPI;	}
	
	public static String getApiParameterName() {	return nameAPI;	}
	
	public static String getApiParameterValue() {	return nameAPI;	}
	
	public static String getApiHeaderName() {	return nameAPI;	}
	
	public static String headerValueAPI() {	return nameAPI;	}
}
