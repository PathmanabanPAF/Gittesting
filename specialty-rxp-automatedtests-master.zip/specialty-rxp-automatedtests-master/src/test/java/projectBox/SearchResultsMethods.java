package projectBox;

import pageWebElementsBox.SearchPage;
import globalBox.BrowserMethods;
import globalBox.CommonMethods;
import globalBox.TableAndPageHandlingMethods;
import globalBox.WaitMethods;

public class SearchResultsMethods {
	
	public static void verifySearchResultsCount(int numberofSearchResults) {
		
		int rowCount = TableAndPageHandlingMethods.getRowCount(BrowserMethods.driver1, WaitMethods.wait10driver1, SearchPage.xpathSearchResultsTable);
		
		if((rowCount-1) > 20) {
			CommonMethods.testStepPassFlag = false;
		}
		
	}

}
