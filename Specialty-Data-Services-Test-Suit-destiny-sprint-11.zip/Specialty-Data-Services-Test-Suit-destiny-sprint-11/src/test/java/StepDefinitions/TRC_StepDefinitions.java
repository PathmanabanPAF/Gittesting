package StepDefinitions;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalEnums.SqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TRC_StepDefinitions extends BaseUtil{
	private BaseUtil base;
	public String trcId, therapyType; 
	public String requestBody, query, oldTrcInformation;
	JSONObject jsonResponseBody;
	//JSONObject requestBodyJson;
	JSONObject trcInfo, oldTrcInfo, newTrcInfo;
	JSONArray requestBodyArray;

	
	public TRC_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I use \"([^\"]*)\" TRC Id$")
	public void i_use_TRC_Id(String trc) throws Throwable {
	    trcId = trc;
	}

	@Given("^I get a valid TRC Id$")
	public void i_get_a_valid_TRC_Id() throws Throwable {
		query = SqlQueries.GetTrcId.toString();
		trcId = MiscTools.executeSingleSelect(base.environment, query);
	}
	
	@Given("^I get an invalid TRC Id$")
	public void i_get_an_invalid_TRC_Id() throws Throwable {
		trcId = MiscTools.getRandomString(3).toUpperCase();
	}

	@Given("^I get an empty TRC Id$")
	public void i_get_an_empty_TRC_Id() throws Throwable {
		trcId = "";
	}
	
	@Given("^I have a non existent TRC Id$")
	public void i_have_a_non_existent_TRC_Id() throws Throwable {
		trcId = MiscTools.getNonExistentTrc(base.environment);
	}
	
	@Given("^I leave empty Description field$")
	public void i_leave_empty_Description_field() throws Throwable {
		base.requestBodyJson = base.requestBodyJson.put("trcDescription","");
		base.requestBody = base.requestBodyJson.toString();
	}

	@Given("^I leave empty City field$")
	public void i_leave_empty_City_field() throws Throwable {
		base.requestBodyJson = base.requestBodyJson.put("city", "");
	}

	@Given("^I fill city fill w/non existent city$")
	public void i_fill_city_fill_w_non_existent_city() throws Throwable {
		String city = MiscTools.getNonExistentCity(base.environment);
		base.requestBodyJson.put("city", city);
	}

	@Given("^I leave empty Phone Number field$")
	public void i_leave_empty_Phone_Number_field() throws Throwable {
		base.requestBodyJson = base.requestBodyJson.put("phoneNumber", "");
	}
//Move to shared step definitions, did not deleted for any problem
//	@Given("^I use an invalid Phone Number format$")
//	public void i_use_an_invalid_Phone_Number_format() throws Throwable {
//		requestBodyJson.put("phoneNumber",MiscTools.getNumericRandomString(3)+"-"+MiscTools.getNumericRandomString(3));
//	}
//	
	@Given("^I fill Call From and Call to Fields w/negative values$")
	public void i_fill_Call_From_and_Call_to_Fields_w_negative_values() throws Throwable {
		base.requestBodyJson = base.requestBodyJson.put("callTo", MiscTools.getRandomInt(0, 24)*-1);
		base.requestBodyJson = base.requestBodyJson.put("callFrom", MiscTools.getRandomInt(0, 24)*-1);
	}
	
	@Given("^I fill Call From w/greater value than Call to Field$")
	public void i_fill_Call_From_w_greater_value_than_Call_to_Field() throws Throwable {
		int callTo = MiscTools.getRandomInt(0,23);
		base.requestBodyJson.put("callTo", callTo);
		base.requestBodyJson.put("callFrom", MiscTools.getRandomInt(callTo,24));
	}

	@Given("^I fill Call From and Call to Fields w/invalid values$")
	public void i_fill_Call_From_and_Call_to_Fields_w_invalid_values() throws Throwable {
		base.requestBodyJson.put("callTo", MiscTools.getRandomInt(24,30));
		base.requestBodyJson.put("callFrom", MiscTools.getRandomInt(24,30));
	}

	@Given("^I set as null Call From and Call To Fields$")
	public void i_set_as_null_Call_From_and_Call_To_Fields() throws Throwable {
		base.requestBodyJson.put("callTo", JSONObject.NULL);
		base.requestBodyJson.put("callFrom", JSONObject.NULL);
	}

	@Given("^I have the required TRC information$")
	public void i_have_the_required_TRC_information() throws Throwable {
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.TRC_INF);
		base.requestBodyJson = MiscTools.refreshTrcRequest(trcId, base.requestBodyJson, base.environment);
		requestBody = base.requestBodyJson.toString();
		System.out.println(requestBody);
	}

	@Given("^I do not have Authorization$")
	public void i_do_not_have_Authorization() throws Throwable {
		base.oauthServiceApi.setAuthorized("N");
	}
	
	@Given("^I get new values for all TRC fields$")
	public void i_get_new_values_for_all_TRC_fields() throws Throwable {
		base.requestBodyJson = GetResponses.createTrcByIdRespose(trcId, base.environment);
		oldTrcInformation = base.requestBodyJson.toString();
		base.requestBodyJson = MiscTools.getNewTrcValues(trcId, base.requestBodyJson, base.environment);
		base.requestBody = base.requestBodyJson.toString();
		//System.out.println(requestBody);
	}

	@Given("^I get (\\d+) valid Therapy Types? not added to any TRC$")
	public void i_get_valid_Therapy_Type_not_added_to_any_TRC(int rows) throws Throwable {
		query = String.format(SqlQueries.GetTTNotInTrc.toString(),trcId,"not",rows);
		System.out.println(query);
		base.requestBodyArray = MiscTools.executeMultipleRowSelectArray(base.environment, query);
		base.requestBody = base.requestBodyArray.toString();
		System.out.println(base.requestBody);
	}
	
	@Given("^I get an already added to any TRC Therapy Type$")
	public void i_get_an_already_added_to_any_TRC_Therapy_Type() throws Throwable {
		query = String.format(SqlQueries.GetTTNotInTrc.toString(),trcId,"",1);
		System.out.println(query);
		base.requestBodyArray = MiscTools.executeMultipleRowSelectArray(base.environment, query);
		base.requestBody = base.requestBodyArray.toString();
		System.out.println(base.requestBody);
	}

	@Given("^I use a non existent Therapy Type$")
	public void i_use_a_non_existent_Therapy_Type() throws Throwable {
		base.therapyType = MiscTools.getNonExistentTherapyType(base.environment);
		trcInfo = JsonTools.readJsonFile(ResourcePaths.TRC_TT_INF);
		trcInfo.put("trcId", trcId);trcInfo.put("therapyType",base.therapyType);
		base.requestBodyArray = new JSONArray();base.requestBodyArray.put(trcInfo);
		base.requestBody = base.requestBodyArray.toString();
		System.out.println(base.requestBody);
	}

	@Given("^I use an empty Therapy Type$")
	public void i_use_an_empty_Therapy_Type() throws Throwable {
		trcInfo = JsonTools.readJsonFile(ResourcePaths.TRC_TT_INF);
		trcInfo.put("trcId", trcId);trcInfo.put("therapyType","");
		base.requestBodyArray = new JSONArray();base.requestBodyArray.put(trcInfo);
		base.requestBody = base.requestBodyArray.toString();
	}

	@When("^I send a request to retrieve TRC information$")
	public void i_send_a_request_to_retrieve_TRC_information() throws Throwable {
		base.oaResponse = base.oauthServiceApi.retrive(ApiPaths.TRC_ID+trcId);
		base.responseBody = base.oaResponse.getBody();
    	MiscTools.printIdented("TRC Id used: "+trcId);
	}

	@When("^I send a request to retrieve TRC Therapies$")
	public void i_send_a_request_to_retrieve_TRC_Therapies() throws Throwable {
		base.response = base.serviceApi.retrive(ApiPaths.TRC_TT+trcId);
    	base.responseBody = base.response.getBody().asString();
    	MiscTools.printIdented("TRC Id used: "+trcId);
	}

	@When("^I send a request to create one TRC record$")
	public void i_send_a_request_to_create_one_TRC_record() throws Throwable {
		System.out.println(ApiPaths.TRC_ID);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.TRC_ID,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.requestBody);
	}
	
	@When("^I send a request to update TRC information$")
	public void i_send_a_request_to_update_TRC_information() throws Throwable {
		requestBody = base.requestBodyJson.toString();
		String apiPath = String.format(ApiPaths.PUT_TRC, trcId);
		System.out.println(apiPath);
		base.oaResponse = base.oauthServiceApi.update(apiPath,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.requestBody);
	}
	
	@When("^I send a request to add Therapy types? to TRC$")
	public void i_send_a_request_to_add_Therapy_type_to_TRC() throws Throwable {
		System.out.println(base.requestBody);
		String apiPath = String.format(ApiPaths.TRC_TT, trcId);
		System.out.println(apiPath);
		base.oaResponse = base.oauthServiceApi.create(apiPath,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.oaResponse.getBody());
	}
	
	@When("^I send a request to add Therapy type to TRC w/o params in Url$")
	public void i_send_a_request_to_add_Therapy_type_to_TRC_w_o_params_in_Url() throws Throwable {
		System.out.println(base.requestBody);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.TRC_TT_OLD,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.oaResponse.getBody());
	}
	@When("^I send a request to update TRC information w/o params in Url$")
	public void i_send_a_request_to_update_TRC_information_w_o_params_in_Url() throws Throwable {
		requestBody = base.requestBodyJson.toString();
		System.out.println(ApiPaths.TRC_ID);
		base.oaResponse = base.oauthServiceApi.update(ApiPaths.TRC_ID,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.requestBody);
	}

	@Then("^I should get the TRC Therapies$")
	public void i_should_get_the_TRC_Therapies() throws Throwable {
		trcInfo =  GetResponses.createTrcByTTRespose(trcId, base.environment);
		jsonResponseBody = new JSONObject(base.responseBody);
		JSONAssert.assertEquals(trcInfo,jsonResponseBody,JSONCompareMode.NON_EXTENSIBLE);
	}
	
	@Then("^I should get the TRC information$")
	public void i_should_get_the_TRC_information() throws Throwable {
		trcInfo = GetResponses.createTrcByIdRespose(trcId, base.environment);
		jsonResponseBody = new JSONObject(base.responseBody);
		JSONAssert.assertEquals(trcInfo,jsonResponseBody,JSONCompareMode.NON_EXTENSIBLE);
	}
	
	@Then("^a new TRC should be created$")
	public void a_new_TRC_should_be_created() throws Throwable {
		MiscTools.printIdented("TRC Id created: "+trcId);
		String query = String.format(SqlQueries.TrcIdExists.toString(), trcId);
		assertFalse(MiscTools.executeSingleRowSelect(base.environment, query).isEmpty());
	}

	@Then("^a new TRC should not be created$")
	public void a_new_TRC_should_not_be_created() throws Throwable {
		MiscTools.printIdented("Bad Request TRC Id: "+trcId);
		String query = String.format(SqlQueries.TrcIdExists.toString(), trcId);
		assertTrue(MiscTools.executeSingleRowSelect(base.environment, query).isEmpty());
	}

	@Then("^new TRC should have the expected values$")
	public void new_TRC_should_have_the_expected_values() throws Throwable {
		base.oaResponse = base.oauthServiceApi.retrive(ApiPaths.TRC_ID+trcId);
		trcInfo = GetResponses.trcRequestToResponse(requestBody);
		jsonResponseBody = new JSONObject(base.oaResponse.getBody());
		JSONAssert.assertEquals(trcInfo,jsonResponseBody,JSONCompareMode.NON_EXTENSIBLE);
	}
	
	@Then("^TRC should have the new values$")
	public void TRC_should_have_the_new_values() throws Throwable {
		trcInfo = GetResponses.createTrcByIdRespose(trcId, base.environment);
		newTrcInfo = GetResponses.trcRequestToResponse(requestBody);
		JSONAssert.assertEquals(trcInfo,newTrcInfo,JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^TRC information should be updated$")
	public void trc_information_should_be_updated() throws Throwable {
		String statusMessage = MiscTools.getMsgFromRes(base.responseBody);
		Assert.assertEquals("UPDATED",statusMessage);
	}

	@Then("^Therapy Type should be added to TRC$")
	public void therapy_Type_should_be_added_to_TRC() throws Throwable {
		JSONArray addedTherapiesArray = MiscTools.getTTFromRequest(base.requestBodyArray);
		query = String.format(SqlQueries.TherapyTypeAddedToTrc.toString(),trcId,addedTherapiesArray.join("','"));
		String actualAddedTT = MiscTools.executeSingleSelect(base.environment, query.replaceAll("\"", ""));
		Assert.assertEquals(addedTherapiesArray.length(),Integer.parseInt(actualAddedTT));
	}
	
	@Then("^Therapy Type should not be added to TRC$")
	public void therapy_Type_should_not_be_added_to_TRC() throws Throwable {
		JSONArray addedTherapiesArray = MiscTools.getTTFromRequest(base.requestBodyArray);
		query = String.format(SqlQueries.TherapyTypeAddedToTrc.toString(),trcId,addedTherapiesArray.join("','"));
		String actualAddedTT = MiscTools.executeSingleSelect(base.environment, query.replaceAll("\"", ""));
		Assert.assertEquals(0,Integer.parseInt(actualAddedTT));
	}

	@Then("^TRC information should not be updated$")
	public void trc_information_should_not_be_updated() throws Throwable {
		trcInfo = GetResponses.createTrcByIdRespose(trcId, base.environment);
		oldTrcInfo = new JSONObject(oldTrcInformation);
		JSONAssert.assertEquals(trcInfo,oldTrcInfo,JSONCompareMode.NON_EXTENSIBLE);
	}

}
