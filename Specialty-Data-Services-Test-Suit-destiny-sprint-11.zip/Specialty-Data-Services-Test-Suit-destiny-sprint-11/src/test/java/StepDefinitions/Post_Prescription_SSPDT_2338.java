package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;

public class Post_Prescription_SSPDT_2338 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public Post_Prescription_SSPDT_2338(BaseUtil base){
		this.base = base;
	}
	
	//Scenario1

	@Given("^I have valid patientid, Prescription details, Fill details & prescribedItems \\(Renewal Autofax 'Y'\\)$")
	public void i_have_valid_patientid_Prescription_details_Fill_details_prescribedItems_Renewal_Autofax_Y() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_API_Renewal_Autofax_SSPDT2338_Tc1);
		System.out.println("XML:"+base.requestBodyJson);
	}
	
	@When("^I send a request to insert new prescription record for renewal autofax$")
	public void i_send_a_request_to_insert_new_prescription_record_for_renewal_autofax() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("APIpath"+ApiPaths.PRESCRIPTION);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.PRESCRIPTION_NEW,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
	}


	@Then("^RxNumber created and RenewalAutofax attribute mapped to THOT\\.Prescriptions_table\\.Renewal_Autofax 'Y'$")
	public void rxnumber_created_and_RenewalAutofax_attribute_mapped_to_THOT_Prescriptions_table_Renewal_Autofax_Y() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		String prescriptionid=JsonTools.findKeys(jsonResponseBody, "x_rxNumber");
		System.out.println("Prescription Id:  "+prescriptionid);
		int prescription_id=Integer.parseInt(prescriptionid);
		String query="SELECT Renewal_autofax FROM THOT.prescriptions_table WHERE PRESCRIPTION_ID = "+prescription_id +"and PATIENT_ID = 8561389";
		String Autofaxflag=MiscTools.executeSingleSelect(base.environment, String.format(query.toString(),""));
		System.out.println("Autofaxflag:"+Autofaxflag);
		
	}

	@Given("^I have valid patientid, Prescription details, Fill details & prescribedItems \\(Renewal Autofax 'N'\\)$")
	public void i_have_valid_patientid_Prescription_details_Fill_details_prescribedItems_Renewal_Autofax_N() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_API_Renewal_Autofax_SSPDT2338_Tc2);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^RxNumber created and RenewalAutofax attribute mapped to THOT\\.Prescriptions_table\\.Renewal_Autofax 'N'$")
	public void rxnumber_created_and_RenewalAutofax_attribute_mapped_to_THOT_Prescriptions_table_Renewal_Autofax_N() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    // throw new PendingException();
		String prescriptionid=JsonTools.findKeys(jsonResponseBody, "x_rxNumber");
		System.out.println("Prescription Id:  "+prescriptionid);
		int prescription_id=Integer.parseInt(prescriptionid);
		String query="SELECT Renewal_autofax FROM THOT.prescriptions_table WHERE PRESCRIPTION_ID = "+prescription_id +"and PATIENT_ID = 8561389";
		String Autofaxflag=MiscTools.executeSingleSelect(base.environment, String.format(query.toString(),""));
		System.out.println("Autofaxflag:"+Autofaxflag);
	}

	@Given("^I have valid patientid, Prescription details, Fill details & prescribedItems \\(Renewal Autofax ''\\)$")
	public void i_have_valid_patientid_Prescription_details_Fill_details_prescribedItems_Renewal_Autofax() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_API_Renewal_Autofax_SSPDT2338_Tc3);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^RxNumber created and RenewalAutofax attribute mapped to THOT\\.Prescriptions_table\\.Renewal_Autofax 'null'$")
	public void rxnumber_created_and_RenewalAutofax_attribute_mapped_to_THOT_Prescriptions_table_Renewal_Autofax_null() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		String prescriptionid=JsonTools.findKeys(jsonResponseBody, "x_rxNumber");
		System.out.println("Prescription Id:  "+prescriptionid);
		int prescription_id=Integer.parseInt(prescriptionid);
		String query="SELECT Renewal_autofax FROM THOT.prescriptions_table WHERE PRESCRIPTION_ID = "+prescription_id +"and PATIENT_ID = 8561389";
		String Autofaxflag=MiscTools.executeSingleSelect(base.environment, String.format(query.toString(),""));
		System.out.println("Autofaxflag:"+Autofaxflag);
	}

	/*@Given("^I have accredo patientId, TherapyId & Refill No = (\\d+)$")
	public void i_have_accredo_patientId_TherapyId_Refill_No(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	//throw new PendingException();
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_API_Renewal_Autofax_Tc1);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@When("^I send a request to insert prescription record$")
	public void i_send_a_request_to_insert_prescription_record() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		System.out.println("APIpath"+ApiPaths.PRESCRIPTION);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.PRESCRIPTION,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
	}
	
	

	@Then("^the response status should be Success with POST Status$")
	public void the_response_status_should_be_Success_with_POST_Status() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		int status =base.oaResponse.getStatusCode().value();
		System.out.println("STATUS"+status);
		int expected_status=201;
		Assert.assertEquals(expected_status, status);
	}
	

	@Then("^retrieve prescription records with AutoFax attribute as NULL in both RxHome & DB$")
	public void retrieve_prescription_records_with_AutoFax_attribute_as_NULL_in_both_RxHome_DB() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		System.out.println("Will get prescription Id");
		String prescriptionid=JsonTools.findKeys(jsonResponseBody, "x_rxNumber");
		System.out.println("Prescription Id:  "+prescriptionid);
		int prescription_id=Integer.parseInt(prescriptionid);
		String query="SELECT Renewal_autofax FROM THOT.prescriptions_table WHERE PRESCRIPTION_ID = "+prescription_id +"and PATIENT_ID = 11345173";
		String Autofaxflag=MiscTools.executeSingleSelect(base.environment, String.format(query.toString(),""));
		System.out.println("Autofaxflag:"+Autofaxflag);
		
		if(Autofaxflag.contentEquals("Y"))
		{
			System.out.println("Autofaxflag is not null: "+Autofaxflag);
		}
		else
		{
			System.out.println("Autofaxflag is not null: "+Autofaxflag);
		}
	
	}

	
	//Scenario2

	@Given("^I have accredo patientId, TherapyId & Refill No not equal to (\\d+)$")
	public void i_have_accredo_patientId_TherapyId_Refill_No_not_equal_to(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_API_Renewal_Autofax_Tc2);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^retrieve prescription records with AutoFax attribute as Y flag in both RxHome & DB$")
	public void retrieve_prescription_records_with_AutoFax_attribute_as_Y_flag_in_both_RxHome_DB() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		System.out.println("Will get prescription Id");
		String prescriptionid=JsonTools.findKeys(jsonResponseBody, "x_rxNumber");
		System.out.println("Prescription Id:  "+prescriptionid);
		int prescription_id=Integer.parseInt(prescriptionid);
		String query="SELECT Renewal_autofax FROM THOT.prescriptions_table WHERE PRESCRIPTION_ID = "+prescription_id +"and PATIENT_ID = 11345173";
		String Autofaxflag=MiscTools.executeSingleSelect(base.environment, String.format(query.toString(),""));
		System.out.println("Autofaxflag:"+Autofaxflag);
	}

	//Scenario3

	@Given("^I have invalid accredo patientId, TherapyId & Refill No = (\\d+)$")
	public void i_have_invalid_accredo_patientId_TherapyId_Refill_No(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_API_Renewal_Autofax_Tc3);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^get error message as \"([^\"]*)\"$")
	public void get_error_message_as(String arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		System.out.println("Will get prescription Id");
		String error_msg=JsonTools.findKeys(jsonResponseBody, "message");
		System.out.println("Error message:  "+error_msg);
	}*/
}
