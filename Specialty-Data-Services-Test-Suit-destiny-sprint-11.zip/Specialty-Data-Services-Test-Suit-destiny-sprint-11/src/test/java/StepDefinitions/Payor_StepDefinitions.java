package StepDefinitions;

import org.json.JSONArray;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.MiscTools;
import GlobalEnums.SqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Payor_StepDefinitions extends BaseUtil{
	private BaseUtil base;
	public String payorId;
	
	public Payor_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I get a valid Payor Id$")
	public void i_get_a_valid_Payor_Id() throws Throwable {
		payorId = MiscTools.executeSingleSelect(base.environment, SqlQueries.ClaimCenterId.toString());
	}

	@When("^I send a request to retrieve Payor information$")
	public void i_send_a_request_to_retrieve_Payor_information() throws Throwable {
		//base.response = base.serviceApi.retrive(ApiPaths.PAYOR+payorId);
    	base.responseBody = base.response.getBody().asString();
    	MiscTools.printIdented("Payor Id used: "+payorId);
    	//System.out.println(base.responseBody);
	}

	@Then("^I should get the Payor information$")
	public void i_should_get_the_Payor_information() throws Throwable {
		//JSONObject jsonPayorInfo = GetResponses.createPayorRespose(payorId, base.environment);
		JSONObject jsonResponseBody = new JSONObject(base.responseBody);
//		System.out.println(jsonPayorInfo);
//		System.out.println("-------");
//		System.out.println(jsonResponseBody);
		//JSONAssert.assertEquals(jsonPayorInfo,jsonResponseBody,JSONCompareMode.NON_EXTENSIBLE);
	}

	@Given("^I get an invalid Payor Id$")
	public void i_get_an_invalid_Payor_Id() throws Throwable {
		payorId = MiscTools.executeSingleSelect(base.environment, SqlQueries.MaxClaimCenter.toString());
		payorId = Integer.toString(Integer.parseInt(payorId) + 1 + (int)(Math.random() * 10));
	}

	@Given("^I get an empty Payor Id$")
	public void i_get_an_empty_Payor_Id() throws Throwable {
		payorId = "";
	}

}
