package StepDefinitions;

import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalEnums.SqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TRCAOM_StepDefinitions extends BaseUtil{
	
	private BaseUtil base;
	public String trcGroup, trcCode,trcAomTherapyType, requestBody;
	public JSONArray trcAomPhonesArrayInfo;
	public JSONObject trcAomPhonesInfo;

	public TRCAOM_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I get a valid TRC Group$")
	public void i_get_a_valid_TRC_Group() throws Throwable {
		trcGroup = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetTrcGroup.toString());
	}

	@Given("^I get a valid TRC AOM Therapy Type$")
	public void i_get_a_valid_TRC_AOM_Therapy_Type() throws Throwable {
		trcAomTherapyType = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetTrcAomTherapyType.toString());
	}
	
	@Given("^I get an invalid TRC Group$")
	public void i_get_an_invalid_TRC_Group() throws Throwable {
		trcGroup = MiscTools.getRandomString(5);
	}

	@Given("^I get an invalid TRC AOM Therapy Type$")
	public void i_get_an_invalid_TRC_AOM_Therapy_Type() throws Throwable {
		trcAomTherapyType = MiscTools.getRandomString(4).toUpperCase();
	   
	}
	
	@Given("^I get an empty TRC Group$")
	public void i_get_an_empty_TRC_Group() throws Throwable {
		trcGroup = "";
	}

	@Given("^I get an empty TRC AOM Therapy Type$")
	public void i_get_an_empty_TRC_AOM_Therapy_Type() throws Throwable {
		trcAomTherapyType = "";
	}

	@Given("^I get a Trc Group & Trc Code$")
	public void i_get_a_Trc_Group_Trc_Code() throws Throwable {
		Map<String, String> trcGroupInfo = MiscTools.executeSingleRowSelect(base.environment,SqlQueries.GetTrcGroupPhones.toString());
		trcGroup = trcGroupInfo.get("trcGroup");trcCode = trcGroupInfo.get("trcCode");
	}

	@Given("^I have the required TRC AOM Therapy information$")
	public void i_have_the_required_TRC_AOM_Therapy_information() throws Throwable {
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.TRC_AOM_TT_INF);
		base.requestBodyJson = MiscTools.refreshTrcAomTTRequest(base.requestBodyJson, base.environment);
	}

	@Given("^I have the required TRC AOM Phone information$")
	public void i_have_the_required_TRC_AOM_Phone_information() throws Throwable {
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.TRC_AOM_P_INF);
		base.requestBodyJson = MiscTools.refreshTrcAomPRequest(trcGroup, trcCode, base.requestBodyJson, base.environment);
	}

	@Given("^I fill TRC Group field w/an invalid value$")
	public void i_fill_TRC_Group_field_w_an_invalid_value() throws Throwable {
		int length = MiscTools.getRandomInt(5, 9);
		trcGroup = MiscTools.getNonExistentValue(base.environment, length, SqlQueries.TrcGroupExists.toString());
		base.requestBodyJson.put("trcGroup", trcGroup);
	}
	
	@Given("^I fill Therapy Type field w/an already added Value$")
	public void i_fill_Therapy_Type_field_w_an_already_added_Value() throws Throwable {
		base.therapyType = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetTTAddedToTrcAom.toString());
		base.requestBodyJson.put("therapyType", base.therapyType);
	}

	@Given("^I fill Therapy Type field w/an invalid value$")
	public void i_fill_Therapy_Type_field_w_an_invalid_value() throws Throwable {
		base.therapyType = MiscTools.getNonExistentValue(base.environment, 4, SqlQueries.TherapyTypeExists.toString());
		base.requestBodyJson.put("therapyType", base.therapyType);
	}

	@Given("^I fill Eligible field w/an invalid value$")
	public void i_fill_Eligible_field_w_an_invalid_value() throws Throwable {
		base.requestBodyJson.put("eligible",MiscTools.getInvalidEligible());
	}

	@Given("^I use a Trc Group-Trc Pg combination w/a Phone already added$")
	public void i_use_a_Trc_Group_Trc_Pg_combination_w_a_Phone_already_added() throws Throwable {
		String query = String.format(SqlQueries.GetTrcPg.toString(), trcGroup);
		String trcPg = MiscTools.executeSingleSelect(base.environment, query);
		base.requestBodyJson.put("trcPg", trcPg);
	}

	@When("^I send a request to create one TRC AOM Therapy record$")
	public void i_send_a_request_to_create_one_TRC_AOM_Therapy_record() throws Throwable {
		requestBody = base.requestBodyJson.toString();
		System.out.println(requestBody);
		String apiPath = String.format(ApiPaths.TRC_AOM_THERAPIES,trcGroup);
		System.out.println(apiPath);
		base.oaResponse = base.oauthServiceApi.create(apiPath,requestBody);
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
	}

	@When("^I send (?:a|the) request to create one TRC AOM Phone record$")
	public void i_send_a_request_to_create_one_TRC_AOM_Phone_record() throws Throwable {
		base.requestBody = base.requestBodyJson.toString();
		String apiPath = String.format(ApiPaths.TRC_AOM_PHONES, trcGroup);
		System.out.println(apiPath);
		System.out.println(base.requestBodyJson);
		base.oaResponse = base.oauthServiceApi.create(apiPath,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
	}
	
	@When("^I send a request to create one TRC AOM (?:Phone|Therapy) w/o param in url$")
	public void i_send_a_request_to_create_one_TRC_AOM_Phone_w_o_param_in_url() throws Throwable {
		requestBody = base.requestBodyJson.toString();		
		System.out.println(base.requestBodyJson);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.TRC_AOM_OLD,requestBody);
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
	}

	@When("^I send a request to retrieve TRC AOM phones information$")
	public void i_send_a_request_to_retrieve_TRC_AOM_phones_information() throws Throwable {
		String apiPathWithParams = String.format(ApiPaths.TRC_AOM_PHONES, trcGroup);
		base.response = trcGroup != "" ? base.serviceApi.retrive(apiPathWithParams):base.serviceApi.retriveEncodingFalse(apiPathWithParams);
    	base.responseBody = base.response.getBody().asString();
    	MiscTools.printIdented("TRC Group used: "+trcGroup);
	}

	@When("^I send a request to retrieve TRC AOM information$")
	public void i_send_a_request_to_retrieve_TRC_AOM_information() throws Throwable {
		String apiPathWithParams = String.format(ApiPaths.TRC_AOM_TT, trcAomTherapyType);
		base.response = base.serviceApi.retrive(apiPathWithParams);
    	base.responseBody = base.response.getBody().asString();
    	MiscTools.printIdented("Therapy Type used: "+trcAomTherapyType);
	}

	@Then("^I should get the correct TRC AOM information$")
	public void i_should_get_the_correct_TRC_AOM_information() throws Throwable {
		trcAomPhonesInfo = GetResponses.createTrcAomByTherapyTypeResponse(trcAomTherapyType, base.environment);
		JSONObject jsonResponseBody = new JSONObject(base.responseBody);
		JSONAssert.assertEquals(trcAomPhonesInfo,jsonResponseBody,JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^I should get the correct TRC AOM phones information$")
	public void i_should_get_the_correct_TRC_AOM_phones_information() throws Throwable {
		trcAomPhonesArrayInfo = GetResponses.createTrcAomPhonesResponse(trcGroup, base.environment);
		JSONArray jsonArrayResponseBody = new JSONArray(base.responseBody);
		JSONAssert.assertEquals(trcAomPhonesArrayInfo,jsonArrayResponseBody,JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^a new TRC AOM Therapy should be created$")
	public void a_new_TRC_AOM_Therapy_should_be_created() throws Throwable {

	}

	@Then("^new TRC AOM Therapy should have the expected values$")
	public void new_TRC_AOM_Therapy_should_have_the_expected_values() throws Throwable {

	}
	
	@Then("^a new TRC AOM Therapy should not be created$")
	public void a_new_TRC_AOM_Therapy_should_not_be_created() throws Throwable {

	}

	@Then("^a new TRC AOM Phone should be created$")
	public void a_new_TRC_AOM_Phone_should_be_created() throws Throwable {

	}

	@Then("^new TRC AOM Phone should have the expected values$")
	public void new_TRC_AOM_Phone_should_have_the_expected_values() throws Throwable {
		String query = String.format(SqlQueries.TrcAomPhonesInfo.toString(), trcGroup);
		trcAomPhonesInfo = MiscTools.executeSingleSelectJson(base.environment, query);
		JSONAssert.assertEquals(base.requestBodyJson,trcAomPhonesInfo,JSONCompareMode.NON_EXTENSIBLE);
	}
	
	@Then("^a new TRC AOM Phone should not be created$")
	public void a_new_TRC_AOM_Phone_should_not_be_created() throws Throwable {
		

	}

}
