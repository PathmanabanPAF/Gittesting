package StepDefinitions;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		plugin = {"pretty", "json:target/cucumber.json"},
		//tags = {"@SSPSS-1927"},
		//SSPSS-1537 Payment API Get method
		//tags = {"@SSPSS-1537"},
		//SSPSS-1411 is no longer used...Use SSPSS-1365 for this Payment API Post testing
		//tags = {"@SSPSS-1411"},
		//Regression needs Update every sprint
		//tags = {"@Regression"},
		//SSPSS-1365 Payment API Post method
		//tags = {"@SSPSS-1365"},
		//SSPDT AutoFlag testing
		//tags = {"@SSPDT1914"},
		//Quick Regression will not work 100% 
		//tags = {"@quick-regression"},
		//SSPDT 931 Person GUID testing
		//tags = {"@SSPDT931"},
		//tags = {"@SSPDT2368"},
		//SSPSS775 no longer used
		//tags = {"@SSPSS-775"},
		//tags = {"@SSPSS-1355"},
		//SSPSS-1255 Invoice API SSPSS 1419 Invoice API enhancements
		//tags = {"@SSPSS-1255"},
		//tags = {"@SSPDT2345"},
		//tags = {"@SSPDT2336"},
		//tags = {"@SSPSS-1850"},
		//tags = {"@SSPSS-1927"},
		//tags = {"@SSPSS-1991"},
		//tags = {"@CreateManufacturer"},
		//tags = {"@SSPDT2237"},
		//tags = {"@SSPDT2338"},
		//tags = {"@SSPDT2448"},
		//features={"src/test/resources"},
		//features={"src/test/resources/SSSquad/Sprint18/SSPSS-1537.feature"},
		//features={"src/test/resources/SSSquad/Sprint17/SSPSS-1255.feature"},
		//features={"src/test/resources/SSSquad/Sprint17/SSPSS-1355.feature"},
		//features={"src/test/resources/SSSquad/Sprint17/SSPSS-775.feature"},
		//features={"src/test/resources/Destiny/Sprint_17/Prescription/SSPDT-931-1786.feature"},
		//features={"src/test/resources/Destiny/Sprint_17/Prescription/SSPDT-1914.feature"},
		//features={"src/test/resources/Destiny/Sprint_18/Prescription/Regression.feature"},
		//features={"src/test/resources/SSSquad/Sprint17/SSPSS-1365.feature"},
		//features={"src/test/resources/SSSquad/Sprint18/SSPSS-1411.feature"},
		//features={"src/test/resources/Destiny/Sprint_18/Prescription/SSPDT2345.feature"},
		//features={"src/test/resources/Destiny/Sprint_18/Prescription/SSPDT2336-2458.feature"},
		//features={"src/test/resources/SSSquad/Sprint18/SSPSS-1850.feature"},
		//features={"src/test/resources/SSSquad/Sprint18/SSPSS-1927.feature"},
		//features={"src/test/resources/SSSquad/Sprint18/SSPSS-1991.feature"},
		//features={"src/test/resources/SSSquad/Sprint18/SSPSS-1991.feature"},
		//features={"src/test/resources/Destiny/Sprint_1/Manufacturer/SSPDT-4.feature"},
		//features={"src/test/resources/Destiny/Sprint_18/Prescription/SSPDT2237.feature"},
		//features={"src/test/resources/Destiny/Sprint_18/Prescription/SSPDT2338.feature"},
		//features={"src/test/resources/Destiny/Sprint_18/Prescription/SSPDT2448.feature"},
		//features={"src/test/resources/Destiny/Sprint_18/Prescription/SSPDT2368.feature"},
		//eatures={"src/test/resources/SSSquad/Sprint18/SSPSS-1927.feature"},
		monochrome = false)

public class RunCakeTest {
	
}