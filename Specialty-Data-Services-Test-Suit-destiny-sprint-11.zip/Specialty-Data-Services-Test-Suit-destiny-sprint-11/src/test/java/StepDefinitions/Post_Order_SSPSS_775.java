package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;
import io.restassured.response.Response;

import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

public class Post_Order_SSPSS_775 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public Post_Order_SSPSS_775(BaseUtil base){
		this.base = base;
	}


	//Scenario1 @CreateOrderwithvalidpatientId
	@Given("^I have patientid, Product GUID, Fillno and Product type$")
	public void i_have_patientid_Product_GUID_Fillno_and_Product_type() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Order_API);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@When("^I send a request to create one Order record$")
	public void i_send_a_request_to_create_one_Order_record() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		
		System.out.println("APIpath"+ApiPaths.ORDERS);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.ORDERS,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
	}

	@Then("^I should get Order GUID and ConfirmationNo$")
	public void i_should_get_Order_GUID_and_ConfirmationNo() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		System.out.println("Will get Order id & confirmation no");
		String OrderGUID=JsonTools.findKeys(jsonResponseBody, "orderGuid");
		System.out.println("Order GUID:  "+OrderGUID);
		String Confirmationno=JsonTools.findKeys(jsonResponseBody, "confirmationNo");
		System.out.println("Confirmation No:  "+Confirmationno);
		
	}
	
	//Scenario2 @CreateOrderwithinvalidpatientId
	
	@Given("^I have invalid patientid, Product GUID, Fillno and Product type$")
	public void i_have_invalid_patientid_Product_GUID_Fillno_and_Product_type() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Order_API_Invalid);
		System.out.println("XML:"+base.requestBodyJson);
	}


	@When("^I send a request to create one Order record for invalid Patient Id$")
	public void i_send_a_request_to_create_one_Order_record_for_invalid_Patient_Id() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();

		System.out.println("APIpath"+ApiPaths.ORDERS);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.ORDERS,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		base.responseBody="["+base.responseBody+"]";
		System.out.println(base.responseBody);
		
	}
	

	@Then("^the response status should be (\\d+)$")
	public void the_response_status_should_be(int arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		int status =base.oaResponse.getStatusCode().value();
		System.out.println("Not STATUS"+status);
		int expected_status=404;
		Assert.assertEquals(expected_status, status);
	}


	@Then("^I should get error information as Patient Id was not found$")
	public void i_should_get_error_information_as_Patient_Id_was_not_found() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+messageinfo);
		String legacyPatientId=JsonTools.findKeys(messageinfo, "message");
        System.out.println("Search Results: "+legacyPatientId);
        Assert.assertEquals("Patient Id was not found.",legacyPatientId);
        System.out.println("Validated Search Results");
	}




}
