package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;
import io.restassured.response.Response;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

public class Get_Invoice_SSPSS_1255 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public Get_Invoice_SSPSS_1255(BaseUtil base){
		this.base = base;
	}


	
	//Scenario 1 @Getinvoicebypatientid
	@Given("^I have patientid, startdate and endate$")
	public void i_have_patientid_startdate_and_endate() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		//base.sb = MiscTools.executeSingleSelect(base.environment, String.format(prescriptionSqlQueries.Getprescriptiontest.toString(),""));
		//base.rxId = MiscTools.executeSingleSelect_col2(base.environment, String.format(prescriptionSqlQueries.Getprescriptiontest.toString(),""));
		//System.out.println("Pharmacy Id: "+base.sb);
		String PatientId=Readproperty("SSPSS1255_TC1_patientId");
		System.out.println("PersonGUID: "+PatientId);
		String startdate=Readproperty("SSPSS1255_TC1_shipfromdate");
		System.out.println("shipfrom: "+startdate);
		String enddate=Readproperty("SSPSS1255_TC1_shiptodate");
		System.out.println("shipto: "+enddate);
		base.params.put("accredoPatientId="+PatientId);
		base.params.put("startDate="+startdate);
		base.params.put("endDate="+enddate);
		System.out.println("Parameters path: "+base.params);
		
	}

	@When("^I search for invoices$")
	public void search_prescriptions_by_using_person_GUID() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String apiPathWithParams =  MiscTools.concatenateParams(ApiPaths.INVOICES,base.params);
		System.out.println("API path with parameteres:" +apiPathWithParams);
		//Get Request
    	base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams);
		//base.response=base.serviceApi.retrive("");
		base.responseBody = base.oaResponse.getBody();
		base.responseBody="["+base.responseBody+"]";
		System.out.println("Response body: "+base.responseBody);
		
    	//MiscTools.printIdented("Prescription used: Service Branch->"+base.sb+" Prescription Id->"+base.rxId+ (base.refill == null?"":" Refill->"+base.refill));
		
	}

	@Then("^the response status success$")
	public void the_response_status_success() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		int status =base.oaResponse.getStatusCode().value();
		System.out.println("STATUS"+status);
		int expected_status=200;
		Assert.assertEquals(expected_status, status);
	}

	
	@Then("^I should get invoices information$")
	public void i_should_get_invoices_information() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "accredoPatientId");
        System.out.println("patient id: "+legacyPatientId);
        Assert.assertEquals("11308489",legacyPatientId);
        System.out.println("Validated patient id");
	}
	
	@Then("^invoice startdate and endate should be within given date inputs$")
	public void invoice_startdate_and_endate_should_be_within_given_date_inputs() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		System.out.println("Dates will be validated");
	}

	
	//Scenario 2 	@Getinvoicebyinvalidpatientid
	@Given("^I have invalid patientid, startdate and endate$")
	public void i_have_invalid_patientid_startdate_and_endate() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String PatientId=Readproperty("SSPSS1255_TC2_patientId");
		System.out.println("PersonGUID: "+PatientId);
		String startdate=Readproperty("SSPSS1255_TC2_shipfromdate");
		System.out.println("shipfrom: "+startdate);
		String enddate=Readproperty("SSPSS1255_TC2_shiptodate");
		System.out.println("shipto: "+enddate);
		base.params.put("accredoPatientId="+PatientId);
		base.params.put("startDate="+startdate);
		base.params.put("endDate="+enddate);
		System.out.println("Parameters path: "+base.params);
	}

	@When("^I search for invoices for invalid patient id$")
	public void i_search_for_invoices_for_invalid_patient_id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String apiPathWithParams =  MiscTools.concatenateParams(ApiPaths.INVOICES,base.params);
		System.out.println("API path with parameteres:" +apiPathWithParams);
		//Get Request
    	base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams);
		//base.response=base.serviceApi.retrive("");
		base.responseBody = base.oaResponse.getBody();
		base.responseBody="["+base.responseBody+"]";
		System.out.println("Response body: "+base.responseBody);
		
	}
	
	@Then("^the response status not success$")
	public void the_response_status_not_success() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		int status =base.oaResponse.getStatusCode().value();
		System.out.println("Not STATUS"+status);
		int expected_status=404;
		Assert.assertEquals(expected_status, status);
	}


	@Then("^I should get information as No Invoice found$")
	public void i_should_get_information_as_No_Invoice_found() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+messageinfo);
		String legacyPatientId=JsonTools.findKeys(messageinfo, "message");
        System.out.println("Search Results: "+legacyPatientId);
        Assert.assertEquals("Patient Id was not found.",legacyPatientId);
        System.out.println("Validated Search Results");
	}
	
	
	//Scenario3 : 	#@Getinvoicebyoutsidedaterange
	@Given("^I have patientid, startdate and endate with more than (\\d+) days date range$")
	public void i_have_patientid_startdate_and_endate_with_more_than_days_date_range(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		 //throw new PendingException();
		String PatientId=Readproperty("SSPSS1255_TC3_patientId");
		System.out.println("PersonGUID: "+PatientId);
		String startdate=Readproperty("SSPSS1255_TC3_shipfromdate");
		System.out.println("shipfrom: "+startdate);
		String enddate=Readproperty("SSPSS1255_TC3_shiptodate");
		System.out.println("shipto: "+enddate);
		base.params.put("accredoPatientId="+PatientId);
		base.params.put("startDate="+startdate);
		base.params.put("endDate="+enddate);
		System.out.println("Parameters path: "+base.params);
	}
	

	@Then("^the response status (\\d+)$")
	public void the_response_status(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		int status =base.oaResponse.getStatusCode().value();
		System.out.println("Not STATUS"+status);
		int expected_status=400;
		Assert.assertEquals(expected_status, status);
	}

	@Then("^I should get error information as Range cannot be greater than (\\d+)$")
	public void i_should_get_error_information_as_Range_cannot_be_greater_than(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+messageinfo);
		String legacyPatientId=JsonTools.findKeys(messageinfo, "message");
        System.out.println("Search Results: "+legacyPatientId);
        Assert.assertEquals("Range cannot be greater than 180 days.",legacyPatientId);
        System.out.println("Validated Search Results");
		
	}

	//Scenario4 @Getinvoicebypatientidwithoutdate
	
	@Given("^I have patientid$")
	public void i_have_patientid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String PatientId=Readproperty("SSPSS1255_TC4_patientId");
		System.out.println("PersonGUID: "+PatientId);
		base.params.put("accredoPatientId="+PatientId);
	}
	

	@Then("^I should get invoices information with default date range of (\\d+)$")
	public void i_should_get_invoices_information_with_default_date_range_of(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "accredoPatientId");
        System.out.println("patient id: "+legacyPatientId);
        Assert.assertEquals("11308489",legacyPatientId);
        System.out.println("Validated patient id");
	
	}

	//Scenario 5 - Search by Invoice id
	@Given("^I have invoice id$")
	public void i_have_invoice_id() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		//base.params.put("accredoPatientId="+"11345572");
	}

	
	@When("^I search for invoices by invoice id$")
	public void i_search_for_invoices_by_invoice_id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String apiPathWithParams =  MiscTools.concatenateParams(ApiPaths.INVOICES_INVOICEID,base.params);
		System.out.println("API path with parameteres:" +apiPathWithParams);
		//Get Request
    	base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams);
		//base.response=base.serviceApi.retrive("");
		base.responseBody = base.oaResponse.getBody();
		base.responseBody="["+base.responseBody+"]";
		System.out.println("Response body: "+base.responseBody);
	}
	
	//Scenario 6 - Search by Invoice id with invoice seq no
	@Given("^I have invoice id with invoice seq no$")
	public void i_have_invoice_id_with_invoice_seq_no() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		//base.params.put("accredoPatientId="+"11345572");
	}

	@When("^I search for invoices by invoice id with seq no$")
	public void i_search_for_invoices_by_invoice_id_with_seq_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String apiPathWithParams =  MiscTools.concatenateParams(ApiPaths.INVOICES_INVOICEID_SEQNO,base.params);
		System.out.println("API path with parameteres:" +apiPathWithParams);
		//Get Request
    	base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams);
		//base.response=base.serviceApi.retrive("");
		base.responseBody = base.oaResponse.getBody();
		base.responseBody="["+base.responseBody+"]";
		System.out.println("Response body: "+base.responseBody);
	}
	
	@Then("^I should get invoices information for invoice id$")
	public void i_should_get_invoices_information_for_invoice_id() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "accredoPatientId");
        System.out.println("patient id: "+legacyPatientId);
        Assert.assertEquals("262396",legacyPatientId);
        System.out.println("Validated patient id");
	}
	public String Readproperty(String name)
	{
		Properties prop = new Properties();
		InputStream input = null;
		String name1 = null;
		try {

		input = new FileInputStream("C:\\Specialty-Data-Services-Test-Suit-destiny-sprint-11\\input_SSquad.properties");
		
		// load a properties file
		prop.load(input);

		// get the property value and print it out
		
		if(name.contentEquals("SSPSS1255_TC1_patientId"))
		{
		 name1=prop.getProperty("SSPSS1255_TC1_patientId");
		}
		else if(name.contentEquals("SSPSS1255_TC1_shipfromdate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC1_shipfromdate");
		}
		else if(name.contentEquals("SSPSS1255_TC1_shiptodate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC1_shiptodate");
		}
		else if(name.contentEquals("SSPSS1255_TC2_patientId"))
		{
			 name1=prop.getProperty("SSPSS1255_TC2_patientId");
		}
		else if(name.contentEquals("SSPSS1255_TC2_shipfromdate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC2_shipfromdate");
		}
		else if(name.contentEquals("SSPSS1255_TC2_shiptodate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC2_shiptodate");
		}
		else if(name.contentEquals("SSPSS1255_TC3_patientId"))
		{
			 name1=prop.getProperty("SSPSS1255_TC3_patientId");
		}
		else if(name.contentEquals("SSPSS1255_TC3_shipfromdate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC3_shipfromdate");
		}
		else if(name.contentEquals("SSPSS1255_TC3_shiptodate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC3_shiptodate");
		}
		else if(name.contentEquals("SSPSS1255_TC4_patientId"))
		{
			 name1=prop.getProperty("SSPSS1255_TC4_patientId");
		}
		//System.out.println(prop.getProperty("dbuser"));
		//System.out.println(prop.getProperty("dbpassword"));

		} catch (IOException ex) {
			System.out.println("Error");
			ex.printStackTrace();
	
	}
		return name1;
}

}
