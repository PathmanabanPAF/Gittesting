package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;

public class Post_DurAPI_SSPSS_1850 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public Post_DurAPI_SSPSS_1850(BaseUtil base){
		this.base = base;
	}
	
	//Scenario1
	@Given("^I have valid DUR id, overrride code, alert message LD$")
	public void i_have_valid_DUR_id_overrride_code_alert_message_LD() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.AutoResolve_PostDUR_Tc1);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@When("^I send a request to POST DUR Auto resolution$")
	public void i_send_a_request_to_POST_DUR_Auto_resolution() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		System.out.println("APIpath"+ApiPaths.DURAPI1);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.DURAPI1,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		//jsonResponseBody = new JSONObject(base.responseBody);
		
		
		//base.responseBody="["+base.responseBody+"]";
	}

	@Then("^I should get Low Dose alerts auto-resolved$")
	public void i_should_get_Low_Dose_alerts_auto_resolved() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		/*base.responseBody="["+base.responseBody+"]";
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		//String dur_status=JsonTools.findKeys(jsonResponseBody, "durStatusCode");
		System.out.println("DUR Status:  "+messageinfo);*/
	}

	//Scenario2
	@Given("^I have valid DUR id, overrride code, alert message HD$")
	public void i_have_valid_DUR_id_overrride_code_alert_message_HD() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.AutoResolve_PostDUR_Tc2);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^I should get High Dose alerts auto-resolved$")
	public void i_should_get_High_Dose_alerts_auto_resolved() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		/*base.responseBody="["+base.responseBody+"]";
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		//String dur_status=JsonTools.findKeys(jsonResponseBody, "durStatusCode");
		System.out.println("DUR Status:  "+messageinfo);*/
	}

	//Scenario3
	@Given("^I have valid DUR id, overrride code, alert message TD$")
	public void i_have_valid_DUR_id_overrride_code_alert_message_TD() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.AutoResolve_PostDUR_Tc3);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^I should get TD alerts auto-resolved$")
	public void i_should_get_TD_alerts_auto_resolved() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		/*base.responseBody="["+base.responseBody+"]";
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		//String dur_status=JsonTools.findKeys(jsonResponseBody, "durStatusCode");
		System.out.println("DUR Status:  "+messageinfo);*/
	}

}
