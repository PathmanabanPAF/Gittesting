package StepDefinitions;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.BrowserDriver;
import GlobalClasses.DBConnection;
import GlobalClasses.JsonTools;
import GlobalClasses.ResourcePaths;
import GlobalEnums.SqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentMethods_StepDefinitions extends BaseUtil{
	
	private BaseUtil base;
	public String requestBody;
	
	private String query;
	private String month,year;
	private String patientIdWithOutCC;
	private static String creditCardNumber,cardIssuer,paymentMethodId,resultReject,amount,txResultQry;
	private final String urlCards = "http://www.getcreditcardnumbers.com/credit-card-generator";
	
	public PaymentMethods_StepDefinitions(BaseUtil base){this.base = base;};
	
	public static String getcardIssuer(){return cardIssuer;}
	public static String getresultReject(){return resultReject;}
	public static String getpaymentMethodId(){return paymentMethodId;}
	public static String getcreditCardNumber(){return creditCardNumber;}
	JSONObject RequestBodyJson,resultResponse, responseDecliantion,resultDuplicateResponse;
	
	@Given("^I need a patient with a credit card$")
	public void i_need_a_patient_with_a_credit_card() throws Throwable {
		DBConnection  db = new DBConnection(base.environment);
		query = SqlQueries.PatientWithOutCard.toString();
		try{
			ResultSet rs = db.ExecuteSelect(query);
			while(rs.next()){
				patientIdWithOutCC = rs.getString(1);
			}
		}catch(SQLException e){
			e.getStackTrace();
		}finally{
			db.Close();
		}
		System.out.println("Patient :"+patientIdWithOutCC);
	}
	
	@When("^the information should be set for the credit card \"([^\"]*)\"$")
	public void the_information_should_be_set_for_the_credit_card(String kindOfcard) throws Throwable {
		Date date = new Date();
	    SimpleDateFormat validThruMonth,validThruYear;	    
		BrowserDriver myBrowser = new BrowserDriver();
	    myBrowser.loadPage(urlCards);
	    
	    
	    WebElement cardType = BrowserDriver.getCurrentDriver().findElement(By.id("id_card_type"));
	    cardType.sendKeys(kindOfcard);
	    WebElement dataFormat = BrowserDriver.getCurrentDriver().findElement(By.id("id_data_format"));
	    dataFormat.sendKeys("JSON");
	    WebElement numberEntries = BrowserDriver.getCurrentDriver().findElement(By.id("id_no_entries"));
	    numberEntries.clear();
	    numberEntries.sendKeys("1");
	    WebElement button = BrowserDriver.getCurrentDriver().findElement(By.className("btn-success"));
	    button.click();
	    
	    WebElement text = BrowserDriver.getCurrentDriver().findElement(By.id("textarea"));
	    String newJsonText = text.getAttribute("value").replace("[", "").replace("]", "");
	    JSONObject creditCardJson = new JSONObject(newJsonText);
	    creditCardNumber = JsonTools.findKeys(creditCardJson, "CardNumber"); 
	    cardIssuer = JsonTools.findKeys(creditCardJson, "IssuingNetwork").toUpperCase();
	    if(cardIssuer.equals("MASTERCARD")){
	    	cardIssuer = kindOfcard.replaceAll("(?!^)([A-Z])", " $1").toUpperCase();
	    	System.out.println(cardIssuer);
	    }

	    validThruYear = new SimpleDateFormat("YYYY");
	    validThruMonth = new SimpleDateFormat("MM");	
	    
	    int endMonth = Integer.parseInt(validThruMonth.format(date));
	    int endYear = Integer.parseInt(validThruYear.format(date))+3;
	    month = String.valueOf(endMonth);
	    year = String.valueOf(endYear);
	    System.out.println("Card type :"+cardIssuer);
	    System.out.println("Credit Card Number :"+creditCardNumber);
	    System.out.println("VALID THRU :"+validThruMonth.format(date)+"/"+year);
	    myBrowser.close();

	}
	
	@When("^the information should be declined for credit card \"([^\"]*)\"$")
	public void the_information_should_be_declined_for_credit_card(String kinfOfCard) throws Throwable {
		Date date = new Date();
	    SimpleDateFormat validThruMonth,validThruYear;
		if(kinfOfCard.equals("MasterCard")){
			kinfOfCard = kinfOfCard.replaceAll("(?!^)([A-Z])", " $1").toUpperCase();
			creditCardNumber = "5424180279791740";
	    }else if(kinfOfCard.equals("Visa")){
			kinfOfCard = kinfOfCard.replaceAll("(?!^)([A-Z])", " $1").toUpperCase();
			creditCardNumber = "4012000088888886";
	    }
		cardIssuer = kinfOfCard;
	    validThruYear = new SimpleDateFormat("YYYY");
	    validThruMonth = new SimpleDateFormat("MM");	
	    
	    int endMonth = Integer.parseInt(validThruMonth.format(date));
	    int endYear = Integer.parseInt(validThruYear.format(date))+3;
	    month = String.valueOf(endMonth);
	    year = String.valueOf(endYear);
	    System.out.println("Card type :"+cardIssuer);
	    System.out.println("Credit Card Number :"+creditCardNumber);
	    System.out.println("VALID THRU :"+validThruMonth.format(date)+"/"+year);

	    
	}

	@When("^that the Payment method request should be updated$")
	public void that_the_Payment_method_request_should_be_updated() throws Throwable {
		RequestBodyJson = JsonTools.readJsonFile(ResourcePaths.PAYMENT_METHODS_POST);
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "id", patientIdWithOutCC).toString();
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "cardIssuer", cardIssuer).toString();
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "creditCardNumber", creditCardNumber).toString();
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "month", month).toString();
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "year",year).toString();
		base.response = base.serviceApi.create(ApiPaths.PAYMENT_METHODS_POST, requestBody);
		base.responseBody = base.response.getBody().asString();
	}
	
	@When("^the amount should be \"([^\"]*)\"$")
	public void the_amount_should_be(String auxamount) throws Throwable {
		amount = String.valueOf(auxamount);
	}

	
	
	@Then("^response should read to get the payment method Id$")
	public void response_should_read_to_get_the_payment_method_Id() throws Throwable {
	    if(base.responseBody != null){
	    	resultResponse = new JSONObject(base.responseBody)
	    	.put("amount", amount)
	    	.put("patient", patientIdWithOutCC);
		    paymentMethodId = JsonTools.findKeys(resultResponse, "id");
		    Assert.assertTrue(paymentMethodId != null);
	    }
	}
	
	@Then("^the Payment method entity should be executed$")
	public void the_Payment_method_entity_should_be_executed() throws Throwable {
	    requestBody = resultResponse.toString();
	    base.response = base.serviceApi.create(" ", requestBody);
	    base.responseBody = base.response.getBody().asString(); 
	}

	@When("^the Payment transaction should be \"([^\"]*)\"$")
	public void the_Payment_transaction_should_be(String txResult) throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		
		query = "select tx_result from thot.scc_pt_mng_tx_hist  where patient_id ="+ patientIdWithOutCC;
		try{
			ResultSet rs = db.ExecuteSelect(query);
			while(rs.next()){
				txResultQry = rs.getString(1);
			}
		}catch(SQLException e){e.getMessage();}
		finally{db.Close();}
		
		txResult = txResult.toUpperCase();
		responseDecliantion = new JSONObject(base.responseBody);
		if("SUCCESS".equals(txResult)){
			resultReject  = JsonTools.findKeys(responseDecliantion, "result");
			Assert.assertTrue(resultReject.equals("SUCCESS"));
			Assert.assertTrue(resultReject.contains(txResultQry));
		}else if("REJECTED".equals(txResult)){
			resultReject  = JsonTools.findKeys(responseDecliantion, "result");
			Assert.assertTrue(resultReject.equals("REJECTED"));
			Assert.assertTrue(resultReject.contains(txResultQry));
		}else if("THE AMOUNT TO CHARGE MUST BE GREATER THAN ZERO.".equals(txResult)){
			resultReject  = JsonTools.findKeys(responseDecliantion, "message");
			Assert.assertTrue(resultReject.toLowerCase().equals(txResult.toLowerCase()));
		}else if("CHARGED EXCEEDS THE MAX ALLOWABLE LISTED".equals(txResult)){
			resultReject  = JsonTools.findKeys(responseDecliantion, "message");
			if(resultReject.toLowerCase().contains(txResult.toLowerCase())){
				Assert.assertTrue(resultReject, true);
			}else{
				Assert.assertTrue(resultReject, false);
			}
		}else if("REQUEST.ID IS EMPTY".equals(txResult)){
			System.out.println(resultReject);
			resultReject  = JsonTools.findKeys(responseDecliantion, "message");
			Assert.assertTrue(resultReject.toLowerCase().equals(txResult.toLowerCase()));
		}
		System.out.println("Result :"+resultReject);
	}
	
	@Then("^the Max Payment should be set (\\d+)$")
	public void the_Max_Payment_should_be_set(int maxPayment) throws Throwable {
	    DBConnection db = new DBConnection(base.environment);
	    query = "update THOT.credit_cards set max_payment = "+ maxPayment +" where card_key_id = "+paymentMethodId;
	    try{
	    	db.ExecuteUpdate(query);	    	
	    }catch(SQLException e){e.getMessage();}
	    finally{db.Close();}
	}
	
	@When("^payment method Id should be empty$")
	public void payment_method_Id_should_be_empty() throws Throwable {
		if(base.responseBody != null){
	    	resultResponse = new JSONObject(base.responseBody)
	    	.put("amount", amount)
	    	.put("patient", patientIdWithOutCC);
		    paymentMethodId = JsonTools.findKeys(resultResponse, "id");
		    if(paymentMethodId != null){
		    	paymentMethodId = "";
		    	resultResponse = JsonTools.updateKeys(resultResponse, "id", paymentMethodId);
		    	paymentMethodId = "empty";
		    }
		    Assert.assertEquals(paymentMethodId, "empty");
	    }
	}
	
	@When("^the credit card should be invalid$")
	public void the_credit_card_should_be_invalid() throws Throwable {
		Random random = new Random();
		Date date = new Date();
	    SimpleDateFormat validThruMonth,validThruYear;
	    for(int i=1;i<=16;i++){
	    	creditCardNumber = creditCardNumber+String.valueOf(random.nextInt(9));
	    }
	    cardIssuer = "VISA";
	    validThruYear = new SimpleDateFormat("YYYY");
	    validThruMonth = new SimpleDateFormat("MM");	
	    
	    int endMonth = Integer.parseInt(validThruMonth.format(date));
	    int endYear = Integer.parseInt(validThruYear.format(date))+3;
	    month = String.valueOf(endMonth);
	    year = String.valueOf(endYear);
	    System.out.println("Card type :"+cardIssuer);
	    System.out.println("Credit Card Number :"+creditCardNumber.replace("null", ""));
	    System.out.println("VALID THRU :"+validThruMonth.format(date)+"/"+year);
	}
	
	@Then("^validate that the card was added correctly$")
	public void validate_that_the_card_was_added_correctly() throws Throwable {
	    DBConnection db = new DBConnection(base.environment);
	    query = "select card_key_id from thot.credit_card_pt_details where patient_id = "+patientIdWithOutCC;
	    try{
	    	ResultSet rs = db.ExecuteSelect(query);
	    	while(rs.next()){
	    		String auxPM = rs.getString(1);
	    		System.out.println("Card Key Id :"+paymentMethodId);
	    		Assert.assertTrue(paymentMethodId.equals(auxPM));
	    	}
	    }catch(SQLException e){e.getMessage();}
	    finally{db.Close();}
	}

	@When("^the payment method service should be run again$")
	public void the_payment_method_service_should_be_run_again() throws Throwable {
		RequestBodyJson = JsonTools.readJsonFile(ResourcePaths.PAYMENT_METHODS_POST);
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "id", patientIdWithOutCC).toString();
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "cardIssuer", cardIssuer).toString();
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "creditCardNumber", creditCardNumber).toString();
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "month", month).toString();
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "year",year).toString();
		base.response = base.serviceApi.create(ApiPaths.PAYMENT_METHODS_POST, requestBody);
		base.responseBody = base.response.getBody().asString();
	}
	
	@Then("^the message should be \"([^\"]*)\"$")
	public void the_message_should_be(String msg) throws Throwable {
		if(base.responseBody != null){
			resultDuplicateResponse = new JSONObject(base.responseBody);
		}
		String existingCardMsg = JsonTools.findKeys(resultDuplicateResponse, "message");
		System.out.println("Exception should be displayed when trying to add the same card to the patient :"+existingCardMsg);
		Assert.assertTrue(existingCardMsg.contains(msg));
	}
	
	@Then("^the Get method should be executed for payment methods$")
	public void the_Get_method_should_be_executed_for_payment_methods() throws Throwable {
	    base.response = base.serviceApi.retrive(ApiPaths.PAYMENT_METHODS_GET+patientIdWithOutCC);
	    base.responseBody = base.response.getBody().asString();
	}
	
	@Then("^set the flag \"([^\"]*)\" to print the response$")
	public void set_the_flag_to_print_the_response(String flag) throws Throwable {
	    if(flag.contentEquals("Y")){
	    	System.out.println(base.responseBody);
	    }
	}
	
	@Then("^validate that only one card was added to the patient$")
	public void validate_that_only_one_card_was_added_to_the_patient() throws Throwable {
		JSONObject a = new JSONObject(base.responseBody);
		JSONObject b = a.getJSONObject("paymentMethods");
		JSONArray jsonArray = b.getJSONArray("paymentMethod");
		System.out.println("Cards Added to the patient :"+jsonArray.length());
		for(int i=0;i<jsonArray.length();i++){
			JSONObject json_data = jsonArray.getJSONObject(i);
			String id =json_data.getString("id");
			System.out.println("Card Key Id :"+id);
			}
	}




}
