package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;
import io.restassured.response.Response;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

public class Get_IntegratedPrescription_SSPDT_2237 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public Get_IntegratedPrescription_SSPDT_2237(BaseUtil base){
		this.base = base;
	}
	
	
	//Scenario1
	@Given("^I have valid processing pharmacy no & rxNumber$")
	public void i_have_valid_processing_pharmacy_no_rxNumber() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.params.put("rxNumber="+"7018345");
		base.params.put("processingpharmacy="+"555");
	}

	@When("^I send a request to get integrated prescription record$")
	public void i_send_a_request_to_get_integrated_prescription_record() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		String apiPathWithParams =  MiscTools.concatenateParams(ApiPaths.PRESCRIPTION,base.params);
		System.out.println("API path with parameteres:" +apiPathWithParams);
		//Get Request
		base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams);
		//base.response=base.serviceApi.retrive("");
		base.responseBody = base.oaResponse.getBody();
		//this is only for invoice
		//base.responseBody="["+base.responseBody+"]";
		System.out.println("Response body: "+base.responseBody);
	}

	@Then("^integrated prescription should show f(\\d+)Pended status 'N' & pendtype 'H'$")
	public void integrated_prescription_should_show_f_Pended_status_N_pendtype_H(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		/*jsonArrayResponseBody = new JSONArray(base.responseBody);
		System.out.println("Array Length : "+jsonArrayResponseBody.length());
		 
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String pendedflag=JsonTools.findKeys(invoiceinfo, "f14Pended");
        System.out.println("pendedflag : "+pendedflag);
        Assert.assertEquals("null",pendedflag);
        System.out.println("Validated pended flag");*/
	}

	//Scenario2
	@Given("^I have valid processing pharmacy no & rxNumber for pended status 'Y'$")
	public void i_have_valid_processing_pharmacy_no_rxNumber_for_pended_status_Y() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.params.put("rxNumber="+"6485568");
		base.params.put("processingpharmacy="+"298");
	}

	@Then("^integrated prescription should show f(\\d+)Pended status 'Y' & pendtype 'I'$")
	public void integrated_prescription_should_show_f_Pended_status_Y_pendtype_I(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		/*jsonArrayResponseBody = new JSONArray(base.responseBody);
		System.out.println("Array Length : "+jsonArrayResponseBody.length());
		 
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String pendedflag=JsonTools.findKeys(invoiceinfo, "f14Pended");
        System.out.println("pendedflag : "+pendedflag);
        Assert.assertEquals("Y",pendedflag);
        System.out.println("Validated pended flag");*/
	
	}

	//Scenario3
	@Given("^I have valid patient Id$")
	public void i_have_valid_patient_Id() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.params.put("accredoPatientId="+"11369285");
	}
}
