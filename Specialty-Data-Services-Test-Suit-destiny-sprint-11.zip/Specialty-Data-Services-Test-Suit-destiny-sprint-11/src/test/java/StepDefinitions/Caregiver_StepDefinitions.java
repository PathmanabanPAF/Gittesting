package StepDefinitions;

import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalEnums.DefaultValues;
import GlobalEnums.ResponseMessage;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;

public class Caregiver_StepDefinitions  extends BaseUtil{
	private BaseUtil base;
	public String sb, rxId, refill, invId, lot;
	public String requestBody, query;
	int quantity;
	JSONObject caregiverInfo;
	JSONObject jsonResponseBody;
	JSONArray ArrayResponseBody;
	
	public Caregiver_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I have the required Prescription Caregiver information$")
	public void i_have_the_required_Prescription_Supply_information() throws Throwable {
		 base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.CAREGIVER_INF);
	}

	@Given("^I get a valid \"([^\"]*)\" Prescription w/Caregivers$")
	public void i_get_a_valid_Prescription_w_Caregivers(String condition) throws Throwable {
		String query = String.format(prescriptionSqlQueries.RxWithCaregiver.toString(),DefaultValues.valueOf(condition.replaceAll("\\s+", "")));
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		sb = base.prescription.get("sb");rxId = base.prescription.get("rxId");refill = base.prescription.get("refill");
	}

	@Given("^I fill Caregiver values w/a \"([^\"]*)\" Prescription$")
	public void i_fill_Caregiver_values_w_a_Prescription(String condition) throws Throwable {
		String query = String.format(prescriptionSqlQueries.RxWithRefill.toString(),DefaultValues.valueOf(condition.replaceAll("\\s+", "")),"60");
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		sb = base.prescription.get("sb");rxId = base.prescription.get("rxId");refill = base.prescription.get("refill");
		base.requestBodyJson = MiscTools.updateCreateCgRequestWithRx(base.prescription, base.requestBodyJson, base.environment);
		base.requestBodyJson.remove("rxNumber");
	}
	@Given("^I fill Caregiver values w/a Direct \"([^\"]*)\" Prescription$")
	public void i_fill_Caregiver_values_w_a_Direct_Prescription(String condition) throws Throwable {
		String query = String.format(prescriptionSqlQueries.DirectRxWithRefill.toString(),DefaultValues.valueOf(condition.replaceAll("\\s+", "")),"60");
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		sb = base.prescription.get("sb");rxId = base.prescription.get("rxId");refill = base.prescription.get("refill");
		 base.requestBodyJson = MiscTools.updateCreateCgRequestWithRx(base.prescription, base.requestBodyJson, base.environment);
		
		//System.out.println(requestSupplyJson);
	}

	@Given("^I fill Caregiver values w/an Integrated \"([^\"]*)\" Prescription$")
	public void i_fill_Caregiver_values_w_an_Integrated_Prescription(String condition) throws Throwable {
		String query = String.format(prescriptionSqlQueries.IntegratedRxWithRefill.toString(),DefaultValues.valueOf(condition.replaceAll("\\s+", "")),"60");
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		sb = base.prescription.get("sb");rxId = base.prescription.get("rxId");refill = base.prescription.get("refill");
		 base.requestBodyJson = MiscTools.updateCreateCgRequestWithRx(base.prescription, base.requestBodyJson, base.environment);
	}

	@Given("^I fill Caregiver Information w/that Prescription$")
	public void i_fill_Caregiver_Information_w_that_Prescription() throws Throwable {
		base.requestBodyJson = MiscTools.updateCreateCgRequestWithRx(base.prescription, base.requestBodyJson, base.environment);
	}

	@Given("^I fill Caregiver Information w/an existent Caregiver Inventory Id$")
	public void i_fill_Caregiver_Information_w_an_existent_Caregiver_Inventory_Id() throws Throwable {
		Map<String, String> inventory; String query = String.format(prescriptionSqlQueries.GetCaregiverInventory.toString(), sb,rxId, refill);
		inventory = MiscTools.executeSingleRowSelect(base.environment, query);
		System.out.println(inventory.get("vUnit"));
		base.requestBodyJson.put("itemReference", Integer.parseInt(inventory.get("inventoryId")));
		base.requestBodyJson.put("lot", inventory.get("lot"));base.requestBodyJson.put("dosage_unit", inventory.get("dUnit"));
		base.requestBodyJson.put("volumeUnit", inventory.get("vUnit"));base.requestBodyJson.put("name", inventory.get("abbrev"));
	}

	@Then("^new Caregiver should be created$")
	public void new_Caregiver_should_be_created() throws Throwable {
		lot = base.requestBodyJson.getString("lot");
		invId = base.requestBodyJson.getString("itemReference");
		query = String.format(prescriptionSqlQueries.CaregiverExists.toString(), sb,rxId, refill,invId,lot);
		Assert.assertNotNull(MiscTools.executeSingleSelectJson(base.environment, query));
	}
	
	@Then("^new Caregiver should not be created$")
	public void new_Caregiver_should_not_be_created() throws Throwable {
		lot = base.requestBodyJson.getString("lot");
		invId = base.requestBodyJson.getString("itemReference");
		query = String.format(prescriptionSqlQueries.CaregiverExists.toString(), sb,rxId, refill,invId,lot);
		System.out.println(query);
		Assert.assertEquals("{}",MiscTools.executeSingleSelectJson(base.environment, query).toString()); 
	}

	@Then("^new Caregiver should have the expected values$")
	public void new_Caregiver_should_have_the_expected_values() throws Throwable {
		query = String.format(prescriptionSqlQueries.GetCaregiverDetails.toString(),sb, rxId, refill, sb, rxId, refill);
		caregiverInfo = MiscTools.executeSingleSelectJson(base.environment, query);
		JSONAssert.assertEquals(base.requestBodyJson,caregiverInfo,JSONCompareMode.NON_EXTENSIBLE);
		//System.out.println(caregiverInfo);
	}

}
