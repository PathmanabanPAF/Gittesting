package StepDefinitions;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalEnums.ResponseMessage;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Put_Updatephysician_SSPDT_2345 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill, patientId;
	String prescriber, storageType, drugRoute;
	String writtenDate, refillThruDate, expirationDate, shipDate, lotExpDate;
	String errors, currentErrors;
	String therapyType;
	String rangeFilter, rangeFilterDefault;
	String query;
	String oldInfo, requestInfo;
	public String requestBody;
	JSONObject fillInfo;
	JSONObject prescriptionInfo, newPrescriptionInfo, oldPrescriptionInfo;
	JSONObject jsonResponseBody;
	JSONArray requestBodyArray;
	
	public Put_Updatephysician_SSPDT_2345(BaseUtil base){
		this.base = base;
	}
	
	//Scenario1
	@Given("^I have valid Legacy Prescriber Id, NPI_ID, DEA Id, first name, last name, zip$")
	public void i_have_valid_Legacy_Prescriber_Id_NPI_ID_DEA_Id_first_name_last_name_zip() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_UpdatePhysician_TC1);
		System.out.println("Request1: "+base.requestBodyJson);
	}

	@When("^I send a request to update prescription record$")
	public void i_send_a_request_to_update_prescription_record() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		System.out.println("APIpath"+ApiPaths.PRESCRIPTION_UpdatePhysician);
		base.oaResponse = base.oauthServiceApi.update(ApiPaths.PRESCRIPTION_UpdatePhysician,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
		System.out.println(jsonResponseBody);
	}

	@Then("^physician Id should update in Prescriptions table$")
	public void physician_Id_should_update_in_Prescriptions_table() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
			
		String query="SELECT physician_id FROM THOT.prescriptions_table WHERE PRESCRIPTION_ID = 7027062";
		String physicianid=MiscTools.executeSingleSelect(base.environment, String.format(query.toString(),""));
		System.out.println("physicianid:"+physicianid);
		
		if(physicianid.contentEquals("786083"))
		{
			System.out.println("Autofaxflag is not null: "+physicianid);
		}
		else
		{
			System.out.println("Autofaxflag is not null: "+physicianid);
		}
	
	}

	//Scenario2
	@Given("^I have null Legacy Prescriber Id, Valid NPI_ID, DEA Id, first name, last name, zip$")
	public void i_have_null_Legacy_Prescriber_Id_Valid_NPI_ID_DEA_Id_first_name_last_name_zip() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_UpdatePhysician_TC2);
		System.out.println("Request2: "+base.requestBodyJson);
	}
	

	@Then("^physician Id should update in Prescriptions table as per requirement$")
	public void physician_Id_should_update_in_Prescriptions_table_as_per_requirement() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		String query="SELECT physician_id FROM THOT.prescriptions_table WHERE PRESCRIPTION_ID = 7027062";
		String physicianid=MiscTools.executeSingleSelect(base.environment, String.format(query.toString(),""));
		System.out.println("physicianid:"+physicianid);
		
		if(physicianid.contentEquals("505101"))
		{
			System.out.println("Autofaxflag is not null: "+physicianid);
		}
		else
		{
			System.out.println("Autofaxflag is not null: "+physicianid);
		}
	}

	//Scenario3
	@Given("^I have invalid Legacy Prescriber Id, Valid NPI_ID, DEA Id, first name, last name, zip$")
	public void i_have_invalid_Legacy_Prescriber_Id_Valid_NPI_ID_DEA_Id_first_name_last_name_zip() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_UpdatePhysician_TC3);
		System.out.println("Request2: "+base.requestBodyJson);
	}

	@Then("^error message displayed as \"([^\"]*)\"$")
	public void error_message_displayed_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Will get prescription Id");
		String error_msg=JsonTools.findKeys(jsonResponseBody, "message");
		System.out.println("Error message:  "+error_msg);
	}
	
	//Scenario 4

	@Given("^I have null Legacy Prescriber Id, Valid NPI_ID, invalid DEA Id, first name, last name, zip$")
	public void i_have_null_Legacy_Prescriber_Id_Valid_NPI_ID_invalid_DEA_Id_first_name_last_name_zip() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_UpdatePhysician_TC4);
		System.out.println("Request2: "+base.requestBodyJson);
		
	}

	@Then("^physician Id should update in Prescriptions table as per requirements$")
	public void physician_Id_should_update_in_Prescriptions_table_as_per_requirements() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		String query="SELECT physician_id FROM THOT.prescriptions_table WHERE PRESCRIPTION_ID = 7027062";
		String physicianid=MiscTools.executeSingleSelect(base.environment, String.format(query.toString(),""));
		System.out.println("physicianid:"+physicianid);
		
		if(physicianid.contentEquals("505101"))
		{
			System.out.println("Autofaxflag is not null: "+physicianid);
		}
		else
		{
			System.out.println("Autofaxflag is not null: "+physicianid);
		}
	}

	public String Readproperty(String name)
	{
		Properties prop = new Properties();
		InputStream input = null;
		String name1 = null;
		try {

		input = new FileInputStream("C:\\Specialty-Data-Services-Test-Suit-destiny-sprint-11\\input.properties");
		
		// load a properties file
		prop.load(input);

		// get the property value and print it out
		
		if(name.contentEquals("TC1_accredopatientid"))
		{
		 name1=prop.getProperty("TC1_accredopatientid");
		}
		
		//System.out.println(prop.getProperty("dbuser"));
		//System.out.println(prop.getProperty("dbpassword"));

		} catch (IOException ex) {
			System.out.println("Error");
			ex.printStackTrace();
	
	}
		return name1;
}
}
