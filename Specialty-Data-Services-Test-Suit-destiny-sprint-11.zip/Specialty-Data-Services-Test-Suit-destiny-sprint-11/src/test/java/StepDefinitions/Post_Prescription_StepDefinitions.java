package StepDefinitions;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalEnums.DefaultValues;
import GlobalEnums.ResponseMessage;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;

public class Post_Prescription_StepDefinitions extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam,ndc;
	String rangeFilter, rangeFilterDefault;
	String query;
	String personGuid = "";
	String days = "5";
	String orderString = "prescriptionRequest.fillItemRequest.savePrescribedItemsRequest";
	int expectedDocIdNum, actualDocIdNum;
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject prescriptionInfo;
	JSONObject jsonResponseBody;
	
	public Post_Prescription_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I have the required Prescription information$")
	public void i_have_the_required_Prescription_information() throws Throwable {
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.RX_INF);
	}
	
	@Given("^I have the required Fill information$")
	public void i_have_the_required_Fill_information() throws Throwable {
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.FILL_INF);
	}
	
	@Given("^I know the Prescription request structure$")
	public void i_know_the_Prescription_request_structure() throws Throwable {
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.COMPLETE_RX_INF);
	}

	@Given("^I fill Patient Id field with a valid Direct Patient Id$")
	public void i_fill_Patient_Id_field_with_a_valid_Direct_Patient_Id() throws Throwable {
		patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetDirectPatientAbleToRx.toString());
		base.requestBodyJson = MiscTools.updateCreateRxRequestWithPatient(patientId, base.requestBodyJson, base.environment);
	}

	@Given("^I get a valid Direct Patient \"([^\"]*)\"$")
	public void i_get_a_valid_Direct_Patient(String condition) throws Throwable {
		condition = condition.replaceAll("\\s+", "");
		if(condition.equals("withoneDocumentId") || condition.equals("withnoDocumentId")) {days = "50";}else if(condition.equals("withmultipleDocumentIds")) {days = "50";};
		query =  String.format(SqlQueries.GetDirectPatient.toString(),days,DefaultValues.valueOf(condition));
		base.patientId = MiscTools.executeSingleSelect(base.environment,query);
		System.out.println(base.patientId);
	}
	
	@Given("^I get a valid Integrated Patient \"([^\"]*)\"$")
	public void i_get_a_valid_Integrated_Patient(String condition) throws Throwable {
		condition = condition.replaceAll("\\s+", "");
		days = "50";
		if(condition.equals("withoneDocumentId") || condition.equals("withnoDocumentId")) {days = "250";}else if(condition.equals("withmultipleDocumentIds")) {days = "250";};
		query =  String.format(SqlQueries.GetIntegratedPatient.toString(),days,DefaultValues.valueOf(condition));
		System.out.println(query);
		base.patientId = MiscTools.executeSingleSelect(base.environment,query);
	}
	
	@Given("^I get a valid Patient \"([^\"]*)\"$")
	public void i_get_a_valid_Patient(String condition) throws Throwable {
		condition = condition.replaceAll("\\s+", "");
		if(condition.equals("withoneDocumentId") || condition.equals("withnoDocumentId")||condition.equals("withmultipleDocumentIds")) {days = "50";}else if(condition.equals("abletogetarenewalRx")) {days = "200";};
		query =  String.format(SqlQueries.GetPatient.toString(),days, DefaultValues.valueOf(condition));
		//System.out.println(query);
		base.patientId = MiscTools.executeSingleSelect(base.environment,query);
	}

	@Given("^I fill Prescription information w/Patient's data$")
	public void i_fill_Prescription_information_w_Patient_s_data() throws Throwable {
		base.requestBodyJson = MiscTools.updateCreateRxRequestWithPatient(base.patientId, base.requestBodyJson, base.environment);
	}

	@Given("^I fill Patient Id field with a valid Integrated Patient Id$")
	public void i_fill_Patient_Id_field_with_a_valid_Integrated_Patient_Id() throws Throwable {
		patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetIntegratedPatientAbleToRx.toString());
		base.requestBodyJson = MiscTools.updateCreateRxRequestWithPatient(patientId, base.requestBodyJson, base.environment);
	}
	
	@Given("^I fill Patient Id field with a valid Patient Id$")
	public void i_fill_Patient_Id_field_with_a_valid_Patient_Id() throws Throwable {
		patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetPatientAbleToRx.toString());
		base.requestBodyJson = MiscTools.updateCreateRxRequestWithPatient(patientId, base.requestBodyJson, base.environment);
	}

	@Given("^I build a request w/valid Patient's data$")
	public void i_build_a_request_w_valid_Patient_s_data() throws Throwable {
		//base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetDirectPatientAbleToRx.toString());
		base.requestBodyJson = MiscTools.updateSingleCallPrescriptionRequest(base.patientId, base.requestBodyJson, base.environment);
	}

	@Given("^I fill Patient Id field with a invalid Patient Id$")
	public void i_fill_Patient_Id_field_with_a_invalid_Patient_Id() throws Throwable {
		base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetMaxDirectPatient.toString());
		base.patientId = Integer.toString(Integer.parseInt(base.patientId) + 1 + (int)(Math.random() * 10));
		base.requestBody = base.requestBodyJson.put("patient", base.patientId).toString();
	}

//  Now Using the one for shared steps
//	@Given("^I set the Patient Id field as Null$")
//	public void i_set_the_Patient_Id_field_as_Null() throws Throwable {
//		base.requestBody = base.requestBodyJson.put("patient", JSONObject.NULL).toString();
//	}
	
//	@Given("^I get a Direct patient's prescription ready to be Filled$")
//	public void i_get_a_Direct_patient_s_prescription_ready_to_be_Filled() throws Throwable {
//		requestBodyJson = JsonTools.readJsonFile(ResourcePaths.RX_INF);
//		patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetDirectPatientAbleToRx.toString());
//		requestBody = MiscTools.updateCreateRxRequestWithPatient(patientId, requestBodyJson, base.environment);
//		System.out.println(requestBody);
//		System.out.println("va a hacer llamada");
//		base.response = base.serviceApi.create(ApiPaths.PRESCRIPTION, requestBody);
//		System.out.println("termino llamada");
//		base.responseBody = base.response.getBody().asString();
//		System.out.println(base.responseBody);
//    	jsonResponseBody = new JSONObject(base.responseBody);
//    	base.sb = requestBodyJson.getString("processingPharmacy"); base.rxId = jsonResponseBody.getString("x_rxNumber"); base.refill = "0";
//		base.prescription = new HashMap<String, String>();
//		base.prescription.put("sb", base.sb);base.prescription.put("rxId", base.rxId);base.prescription.put("refill", base.refill);
////		base.prescription.put("sb", "555");base.prescription.put("rxId","6484157");base.prescription.put("refill","0");
//		Assert.assertEquals("null", jsonResponseBody.getString("x_errors"));
//		MiscTools.printIdented("Prescription filled: Service Branch->"+base.sb+" Prescription Id->"+base.rxId+" Refill->"+base.refill);
//	}
	
	@Given("^I get a patient's prescription ready to be Filled$")
	public void i_get_a_patient_s_prescription_ready_to_be_Filled() throws Throwable {
		i_get_a_valid_Patient("able to get a Rx");
		i_have_the_required_Prescription_information();
		i_fill_Prescription_information_w_Patient_s_data();
		i_send_a_request_to_create_one_Rx_record();

    	base.sb = base.requestBodyJson.getString("processingPharmacy"); base.rxId = jsonResponseBody.getString("x_rxNumber"); base.refill = "0";
		base.prescription = new HashMap<String, String>();
		base.prescription.put("sb", base.sb);base.prescription.put("rxId", base.rxId);base.prescription.put("refill", base.refill);
		Assert.assertEquals("null", jsonResponseBody.getString("x_errors"));
		MiscTools.printIdented("Prescription filled: Service Branch->"+base.sb+" Prescription Id->"+base.rxId+" Refill->"+base.refill);
	}
	@Given("^I get a Direct patient's prescription ready to be Filled$")
	public void i_get_a_Direct_patient_s_prescription_ready_to_be_Filled() throws Throwable {
		i_get_a_valid_Direct_Patient("able to get a Rx");
		i_have_the_required_Prescription_information();
		i_fill_Prescription_information_w_Patient_s_data();
		i_send_a_request_to_create_one_Rx_record();
		
		//base.responseBody = base.response.getBody().asString();
    	//jsonResponseBody = new JSONObject(base.responseBody);
		
    	base.sb = base.requestBodyJson.getString("processingPharmacy"); base.rxId = jsonResponseBody.getString("x_rxNumber"); base.refill = "0";
		base.prescription = new HashMap<String, String>();
		base.prescription.put("sb", base.sb);base.prescription.put("rxId", base.rxId);base.prescription.put("refill", base.refill);
		Assert.assertEquals("null", jsonResponseBody.getString("x_errors"));
		MiscTools.printIdented("Prescription filled: Service Branch->"+base.sb+" Prescription Id->"+base.rxId+" Refill->"+base.refill);
	}

	@Given("^I get an Integrated patient's prescription ready to be Filled$")
	public void i_get_an_Integrated_patient_s_prescription_ready_to_be_Filled() throws Throwable {
		i_get_a_valid_Integrated_Patient("able to get a Rx");
		i_have_the_required_Prescription_information();
		i_fill_Prescription_information_w_Patient_s_data();
		i_send_a_request_to_create_one_Rx_record();
		
		//base.responseBody = base.response.getBody().asString();
    	//jsonResponseBody = new JSONObject(base.responseBody);
		
    	base.sb = base.requestBodyJson.getString("processingPharmacy"); base.rxId = jsonResponseBody.getString("x_rxNumber"); base.refill = "0";
		base.prescription = new HashMap<String, String>();
		base.prescription.put("sb", base.sb);base.prescription.put("rxId", base.rxId);base.prescription.put("refill", base.refill);
		Assert.assertEquals("null", jsonResponseBody.getString("x_errors"));
		MiscTools.printIdented("Prescription filled: Service Branch->"+base.sb+" Prescription Id->"+base.rxId+" Refill->"+base.refill);
		
//		requestBodyJson = JsonTools.readJsonFile(ResourcePaths.RX_INF);
//		patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetIntegratedPatient.toString());
//		requestBodyJson = MiscTools.updateCreateRxRequestWithPatient(patientId, requestBodyJson, base.environment);
//		base.response = base.serviceApi.create(ApiPaths.PRESCRIPTION, requestBody);
//		base.responseBody = base.response.getBody().asString();
//    	jsonResponseBody = new JSONObject(base.responseBody);
//		sb = requestBodyJson.getString("processingPharmacy"); rxId = jsonResponseBody.getString("x_rxNumber");  refill = "0";
//		base.prescription = new HashMap<String, String>();
//		base.prescription.put("sb", base.sb);base.prescription.put("rxId", base.rxId);base.prescription.put("refill", base.refill);
//		Assert.assertEquals("null", jsonResponseBody.getString("x_errors"));
//		MiscTools.printIdented("Prescription filled: Service Branch->"+base.sb+" Prescription Id->"+base.rxId+" Refill->"+base.refill);
	}
	
	@Given("^I get a valid Direct Prescription and Inventory$")
	public void i_get_a_valid_Direct_Prescription_and_Inventory() throws Throwable {
		query = SqlQueries.GetTherapyAndDrug.toString();
		System.out.println(query);
		Map<String, String> TherapyAndDrug = MiscTools.executeSingleRowSelect(base.environment, query);
		System.out.println(TherapyAndDrug);
		String therapy = TherapyAndDrug.get("therapyType");
		String abbrev = TherapyAndDrug.get("drugAbbrev");
		query = String.format(SqlQueries.GetInv.toString(),abbrev);
		System.out.println(query);
		Map<String, String> inventory  = MiscTools.executeSingleRowSelect(base.environment, query);
		String invId = inventory.get("inventoryId");
		System.out.println(inventory);
		query = String.format(prescriptionSqlQueries.GetDirectRxInv.toString(),therapy,invId);
		System.out.println(query);
		base.prescription = MiscTools.executeSingleRowSelect(base.environment, query);
		System.out.println(base.prescription);
		
	}

	@Given("^I fill Inventory structure w/valid data$")
	public void i_fill_Inventory_structure_w_valid_data() throws Throwable {
		System.out.println(base.prescription);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.NON_COMP_INF);
		base.requestBodyJson = MiscTools.updateInvItemRequest(base.prescription, base.requestBodyJson, base.environment, "Ndc");
	}
	
	@Given("^I use \"([^\"]*)\" to fill Inventory structure$")
	public void i_use_to_fill_Inventory_structure(String by) throws Throwable {
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.NON_COMP_INF);
		base.requestBodyJson = MiscTools.updateInvItemRequest(base.prescription, base.requestBodyJson, base.environment,by);
	}

	@Given("^I update the Fill information with invalid prescription$")
	public void i_update_the_Fill_information_with_invalid_prescription() throws Throwable {
		base.refill = "0";
		requestBodyJson.put("processingPharmacy", base.sb);
		requestBodyJson.put("fillNumber", base.refill);
		requestBody = requestBodyJson.put("rxNumber", base.rxId).toString();
	}

	@Given("^I use an invalid Drug Abbrev for that prescription$")
	public void i_use_an_invalid_Drug_Abbrev_for_that_prescription() throws Throwable {
		base.requestBody = MiscTools.updateFillRxRequestWithInvalidTherapy(base.requestBodyJson, base.environment);
	}

	@Given("^I use an invalid Drug Storage Method$")
	public void i_use_an_invalid_Drug_Storage_Method() throws Throwable {
		base.requestBody = MiscTools.updateFillRxRequestWithInvalidStorage(base.requestBodyJson, base.environment);
	}
	
	@Given("^I leave empty inventory field$")
	public void i_leave_empty_inventory_field() throws Throwable {
		JSONArray emptyArray = new JSONArray("[]");
		requestBodyJson.put("itemRequest",emptyArray);
		requestBody = requestBodyJson.toString();
	}
	
	@Given("^I set as Null prescription fields$")
	public void i_set_as_Null_prescription_fields() throws Throwable {
		requestBodyJson.put("processingPharmacy", JSONObject.NULL);
		requestBodyJson.put("fillNumber", JSONObject.NULL);
		requestBody = requestBodyJson.put("rxNumber", JSONObject.NULL).toString();
	}
	
	@Given("^I use an invalid Rx Id in Inventory section$")
	public void i_use_an_invalid_Rx_Id_in_Inventory_section() throws Throwable {
		requestBody = MiscTools.updateFillRxRequestWithInvalidInvRx(base.prescription,requestBodyJson,base.environment);
	}
	
	@Given("^I update the Fill information with selected prescription$")
	public void i_update_the_Fill_information_with_selected_prescription() throws Throwable {
		base.requestBody = MiscTools.updateFillRxRequestWithPrescription(base.prescription, base.requestBodyJson);
	}
	
	@Given("^I use a Ndc corresponding to a Therapy not related to Patient$")
	public void i_use_a_Ndc_corresponding_to_a_Therapy_not_related_to_Patient() throws Throwable {
		query = String.format(SqlQueries.GetNdcNotRelatedToPatient.toString(), base.patientId);
		ndc = MiscTools.executeSingleSelect(base.environment, query);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "ndc", ndc);
	}

	@Given("^I use a non existent Ndc$")
	public void i_use_a_non_existent_Ndc() throws Throwable {
	    ndc = MiscTools.getNonExistentNdc(base.environment);
	    base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "ndc", ndc);
	}

	@Given("^I use a non existent Ndc in Inventory section$")
	public void i_use_a_non_existent_Ndc_in_Inventory_section() throws Throwable {
		 ndc = MiscTools.getNonExistentNdc(base.environment);
		 base.requestBodyJson = JsonTools. updateKeysPath(base.requestBodyJson, "savePrescribedItemsRequest.ndc", ndc);
	}

	@Given("^I fill Fill information w/valid data$")
	public void i_fill_Fill_information_w_valid_data() throws Throwable {
		query = String.format(prescriptionSqlQueries.GetFillInfo.toString(),base.sb, base.rxId, base.refill);
		base.requestBodyJson = MiscTools.executeSingleSelectJson(base.environment, query);
		base.requestBody = base.requestBodyJson.toString();
	}

	@Given("^I increase Fill Number field$")
	public void i_increase_Fill_Number_field() throws Throwable {
		int newRefill = base.requestBodyJson.getInt("fillNumber");
		base.requestBodyJson.put("fillNumber",newRefill+1);
		base.requestBody = base.requestBodyJson.toString();
	}

	@Given("^I use a Stop Date prior Start Date$")
	public void i_use_a_Stop_Date_prior_Start_Date() throws Throwable {
		String stopDate = MiscTools.getDateMonthName(MiscTools.getRandomInt(-3, -1));
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "rx_stop_date", stopDate);
	}
	
	@Given("^I use a Ship Date in the past$")
	public void i_use_a_Ship_Date_in_the_past() throws Throwable {
		String shipDate = MiscTools.getDateMonthName(MiscTools.getRandomInt(-3, -1));
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "shipDate", shipDate);
	}

	@Given("^I add patient's Document Ids? to the request$")
	public void i_add_patient_s_Document_Ids_to_the_request() throws Throwable {
		query = String.format(SqlQueries.GetPatientsDocumentIds.toString(),base.patientId);
		JSONArray docIds = MiscTools.executeSingleSelectArray(base.environment, query);
		expectedDocIdNum = docIds.length();
		base.requestBodyJson =  JsonTools.updateKeys(base.requestBodyJson, "documentReferences", docIds);
	}
	
	@Given("^I fill current status with \"([^\"]*)\"$")
	public void i_fill_current_status_with(String status) throws Throwable {
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "currentStatus", status);
	}

	@Given("^I fill Current Status w/a valid value$")
	public void i_fill_Current_Status_w_a_valid_value() throws Throwable {
		  query = SqlQueries.GetCurrentStatus.toString();
		  String status = MiscTools.executeSingleSelect(base.environment, query);
          base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "currentStatus", status);
          if(status.equals("PROFILE")) base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "shipDate", "");
	}

	@Given("^I fill Current Status w/an invalid value$")
	public void i_fill_Current_Status_w_an_invalid_value() throws Throwable {
		  String status = MiscTools.getRandomString(5);
          base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "currentStatus", status);
	}

	@Given("^I fill Person Guid field$")
	public void i_fill_Person_Guid_field() throws Throwable {
		personGuid = MiscTools.getAlphaNumericRandomString(8)+"-"+ MiscTools.getAlphaNumericRandomString(4)+"-"+
				MiscTools.getAlphaNumericRandomString(4)+"-"+MiscTools.getAlphaNumericRandomString(4)+"-"+MiscTools.getAlphaNumericRandomString(12);
        base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "personGUID", personGuid);
	}
	
	@Given("^I use a valid Rx Origin Code$")
	public void i_use_a_valid_Rx_Origin_Code() throws Throwable {
		JSONObject rxOriginCode = MiscTools.executeSingleSelectJson(base.environment, SqlQueries.GetRxOrignCode.toString());
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "rxOriginCode", rxOriginCode);
	}

	@Given("^I use an invalid Rx Origin Code$")
	public void i_use_an_invalid_Rx_Origin_Code() throws Throwable {
		JSONObject rxOriginCode = new JSONObject();
		rxOriginCode.put("name", MiscTools.getRandomString(6));rxOriginCode.put("code", MiscTools.getRandomInt(6, 10));
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "rxOriginCode", rxOriginCode);
	}

	@Given("^I use an invalid \"([^\"]*)\" in Rx Origin Code$")
	public void i_use_an_invalid_in_Rx_Origin_Code(String field) throws Throwable {
		JSONObject rxOriginCode = MiscTools.getInvalidByRxOriginCode(field, base.environment);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "rxOriginCode", rxOriginCode);
	}

	@Given("^I use a not matching Code and Name in Rx Origin Code$")
	public void i_use_a_not_matching_Code_and_Name_in_Rx_Origin_Code() throws Throwable {
		JSONObject rxOriginCode = MiscTools.getNotMachingRxOriginCode(base.environment);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "rxOriginCode", rxOriginCode);
	}
	
	@Given("^I use a valid storage type$")
	public void i_use_a_valid_storage_type() throws Throwable {
		String validStorageType = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetStorageType.toString());
		 base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "storageType", validStorageType);
	}

	@Given("^I use an invalid storage type$")
	public void i_use_an_invalid_storage_type() throws Throwable {
		 String invalidStorageType = MiscTools.getNonExistentStorageType(base.environment);
		 base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "storageType", invalidStorageType);
	}
	
	@Given("^I use a valid Processing Pharmacy$")
	public void i_use_a_valid_Processing_Pharmacy() throws Throwable {
		base.sb = MiscTools.executeSingleSelect(base.environment, String.format(SqlQueries.GetPatientSb.toString(), base.patientId));
		System.out.println(base.sb);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson,"processingPharmacy", Integer.parseInt(base.sb));
	}

	@Given("^I use a non existent Processing Pharmacy$")
	public void i_use_a_non_existent_Processing_Pharmacy() throws Throwable {
		base.sb = "0";//MiscTools.executeSingleSelect(base.environment, SqlQueries.GetInvalidSb.toString());
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson,"processingPharmacy", Integer.parseInt(base.sb));
	}

	@Given("^I use a valid Processing Pharmacy not \"([^\"]*)\"$")
	public void i_use_a_valid_Processing_Pharmacy_not(String arg1) throws Throwable {
	    query= String.format(SqlQueries.GetSbNot.toString(),"555");
	    base.sb = MiscTools.executeSingleSelect(base.environment, query);
	    base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson,"processingPharmacy",base.sb);
	    base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson,"prescribedItems",new JSONArray());
	}
	@Given("^I make sure User Id field has valid value$")
	public void i_make_sure_User_Id_field_has_valid_value() throws Throwable {
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson,"userId", "AUTOMATION_SUPU");
	}

	@Given("^I make sure User Id field has invalid value$")
	public void i_make_sure_User_Id_field_has_invalid_value() throws Throwable {
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson,"userId", MiscTools.getRandomString(7));
	}

	@When("^I send a request to create one Rx record$")
	public void i_send_a_request_to_create_one_Rx_record() throws Throwable {
		System.out.println(ApiPaths.PRESCRIPTION+"prescription/");
		base.requestBody = base.requestBodyJson.toString();
		System.out.println(base.requestBody);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.PRESCRIPTION+"prescription/",base.requestBody);
		base.responseBody = base.oaResponse.getBody();
    	System.out.println(base.responseBody);
    	jsonResponseBody = new JSONObject(base.responseBody);
	}
	
	@When("^I send a call to create a Prescription$")
	public void i_send_a_call_to_create_a_Prescription() throws Throwable {
		System.out.println(ApiPaths.PRESCRIPTION);
		base.requestBody = base.requestBodyJson.toString();//JsonTools.orderJson(orderString, base.requestBodyJson);
		System.out.println(base.requestBody);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.PRESCRIPTION,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
    	System.out.println(base.responseBody);
    	jsonResponseBody = new JSONObject(base.responseBody);
	}

	@When("^I send a request to create one R?e?Fill record$")
	public void i_send_a_request_to_create_one_Fill_record() throws Throwable {
		base.requestBody = base.requestBodyJson.toString();
		System.out.println(base.requestBody);
		String apiPath = String.format(ApiPaths.FILL_PRESCRIPTION, base.rxId);
    	base.oaResponse = base.oauthServiceApi.create(apiPath,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
    	System.out.println(apiPath);
    	jsonResponseBody = new JSONObject(base.responseBody);
    	System.out.println(base.responseBody);
	}
	
	@When("^I send a request to add Inventory to Prescription$")
	public void i_send_a_request_to_add_Inventory_to_Prescription() throws Throwable {
		base.requestBodyArray = new JSONArray();
		base.requestBodyArray.put(base.requestBodyJson);
		base.requestBody = base.requestBodyArray.toString();
		String apiPath = MiscTools.getRxPostApiPathFromFill(base.prescription.get("rxId"), base.prescription.get("refill"));
		System.out.println(apiPath);
		System.out.println(base.requestBody);
		base.oaResponse = base.oauthServiceApi.create(apiPath,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
		//base.response = base.serviceApi.create(apiPath, base.requestBody);
    	//base.responseBody = base.response.getBody().asString();
    	
    	System.out.println(base.responseBody);
    	MiscTools.printIdented("Prescription used: Service Branch->"+sb+" Prescription Id->"+rxId+ (refill == null?"":" Refill->"+refill));
	}

	@Then("^a new Rx should be created$")
	public void a_new_Rx_should_be_created() throws Throwable {
		base.sb = jsonResponseBody.getString("x_processingPharmacy");//base.requestBodyJson.getString("processingPharmacy");
		base.rxId = jsonResponseBody.getString("x_rxNumber"); base.refill = "0";
		MiscTools.printIdented("Prescription created: Service Branch->"+base.sb+" Prescription Id->"+base.rxId);
		String query = String.format(SqlQueries.RxExistsQuery.toString(),base.rxId, base.sb);
		assertFalse(MiscTools.executeMultipleRowSelect(base.environment, query).isEmpty());
	}

	@Then("^a new Supply should be created$")
	public void a_new_Supply_should_be_created() throws Throwable {

	}

	//Moved to shared step definitions, no deleted for any issue that can appear
//	@Then("^I should get no prescription errors$")
//	public void i_should_get_no_prescription_errors() throws Throwable {
//	jsonResponseBody = new JSONObject(base.responseBody)
//		currentErrors = jsonResponseBody.getString("x_errors");
//		Assert.assertEquals("null", currentErrors);
//	}

	@Then("^I should get no inventory errors$")
	public void i_should_get_no_inventory_errors() throws Throwable {
		JSONObject itemResponse = jsonResponseBody.getJSONObject("itemResponse");
		currentErrors = itemResponse.getString("x_errors");
		Assert.assertEquals("null", currentErrors);
	}
	
	@Then("^I should get inventory error \"([^\"]*)\"$")
	public void i_should_get_inventory_error(String msgError) throws Throwable {
		errors = ResponseMessage.valueOf(msgError.replaceAll("\\s+", "")).toString();
		JSONObject itemResponse = jsonResponseBody.getJSONObject("itemResponse");
		currentErrors = itemResponse.getString("x_errors");
		requestBodyJson = new JSONObject(requestBody);
		JSONArray empty = new JSONArray();
		requestBodyJson.put("itemRequest", empty);
		requestBody = requestBodyJson.toString();
		Assert.assertEquals(errors, currentErrors);
	}

	@Then("^I should get prescripton error \"([^\"]*)\"$")
	public void i_should_get_prescripton_error(String msgError) throws Throwable {
		errors = ResponseMessage.valueOf(msgError.replaceAll("\\s+", "")).toString();
		currentErrors = jsonResponseBody.getString("x_errors");
		base.requestBodyJson = new JSONObject(base.requestBody);
		base.requestBody = MiscTools.updateRequestNotFilled(base.requestBodyJson);
		Assert.assertEquals(errors, currentErrors);
	}

	@Then("^I should get Prescription does not exist error$")
	public void i_should_get_Prescription_does_not_exist_error() throws Throwable {
		errors = String.format(ResponseMessage.PrescriptionDoesNotExist.toString(), base.sb+"-"+base.rxId+"-"+base.refill);
		currentErrors = jsonResponseBody.getString("x_errors");
		Assert.assertEquals(errors, currentErrors);
	}
	

	@Then("^I should get error no Therapy found$")
	public void i_should_get_error_no_Therapy_found() throws Throwable {
		errors = String.format(ResponseMessage.NoTherapyFoundWithNdc.toString(), ndc);
		currentErrors = jsonResponseBody.getString("x_errors");
		Assert.assertEquals(errors, currentErrors);
	}

	@Then("^new Rx should have the expected values$")
	public void new_Rx_should_have_the_expected_values() throws Throwable {
		JSONObject rxRequestInfo = GetResponses.prescriptionRequestToResponse(base.requestBody,base.rxId,base.environment);
		prescriptionInfo = GetResponses.prescriptionInfoJsonFormat(base.rxId, base.sb, base.environment);
		JSONAssert.assertEquals(rxRequestInfo, prescriptionInfo,  JSONCompareMode.NON_EXTENSIBLE);
	}
	
	@Then("^new Prescription should have the expected values$")
	public void new_Prescription_should_have_the_expected_values() throws Throwable {
		JSONObject rxRequestInfo = GetResponses.fullPrescriptionRequestToResponse(base.requestBody,base.rxId,base.environment);
		prescriptionInfo = GetResponses.fullPrescriptionInfo(base.sb, base.rxId, base.refill, base.environment);
		JSONAssert.assertEquals(rxRequestInfo, prescriptionInfo,  JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^new Supply should have the expected values$")
	public void new_Supply_should_have_the_expected_values() throws Throwable {

	}
	
	@Then("^Comments should be updated as expected$")
	public void comments_should_be_updated_as_expected() throws Throwable {
		String expectedComments = base.requestBodyJson.getString("comments");
		query = String.format(SqlQueries.GetRxComments.toString(), base.sb, base.rxId);
		String actualComments = MiscTools.executeSingleSelect(base.environment, query);
		actualComments = actualComments == null?"null":actualComments;
		Assert.assertEquals(expectedComments, actualComments);
	}

	@Then("^I should get \"([^\"]*)\" as error message$")
	public void i_should_get_as_error_message(String errorMessage) throws Throwable {
		errorMessage= errorMessage.replaceAll("\\s+", "");
		String responseMessage = ResponseMessage.valueOf(errorMessage).toString();
		Assert.assertEquals(base.response.body().jsonPath().getString( "x_errors"),responseMessage);
	}
	
	@Then("^a new Rx should not be created$")
	public void a_new_Rx_should_not_be_created() throws Throwable {
		Object x_rxNumber = JSONObject.NULL;
		if(jsonResponseBody.has("x_rxNumber")) x_rxNumber = jsonResponseBody.get("x_rxNumber");
		Assert.assertEquals(x_rxNumber,null);
	}
	
	@Then("^prescription should be updated as expected$")
	public void prescription_should_be_updated_as_expected() throws Throwable {
		prescriptionInfo = GetResponses.fillInfoJsonFormat(base.rxId, base.sb,base.refill, base.environment);
		JSONAssert.assertEquals(prescriptionInfo,base.requestBodyJson,JSONCompareMode.NON_EXTENSIBLE);
	}
	
	@Then("^prescription should not have any inventory added$")
	public void prescription_should_not_have_any_inventory_added() throws Throwable {
		String query = String.format(SqlQueries.GetActualRxInv.toString(), base.sb, base.rxId, base.refill);
		List<Map<String, String>> rxInventories = MiscTools.executeMultipleRowSelect(base.environment,query);
		assertTrue(rxInventories.isEmpty());
	}

	@Then("^new Rx should have the expected number of images$")
	public void new_Rx_should_have_the_expected_number_of_images() throws Throwable {
		query = String.format(prescriptionSqlQueries.GetRxImagesNumber.toString(), base.sb, base.rxId, base.refill);
		actualDocIdNum = Integer.parseInt(MiscTools.executeSingleSelect(base.environment, query));
		Assert.assertEquals(actualDocIdNum, expectedDocIdNum);
	}

	@Then("^values not provided should be defaulted$")
	public void values_not_provided_should_be_defaulted() throws Throwable {
		JSONObject actualValues = MiscTools.getRxValuesDefaulted(base.sb, base.rxId, base.refill, base.environment);
		JSONObject defaultValues = new JSONObject(DefaultValues.rxCreatedDefaultValues.toString());
		JSONAssert.assertEquals(actualValues,defaultValues,JSONCompareMode.NON_EXTENSIBLE);
	}
	
	@Then("^Person Guid should be saved as expected in PCF Table$")
	public void person_Guid_should_be_saved_as_expected_in_PCF_Table() throws Throwable {
    	String actualPersonGuid = MiscTools.getPersonGuid(base.rxId,base.environment);
    	Assert.assertEquals(personGuid, actualPersonGuid);
	}

	@Then("^Processing Pharmacy should be populated as expected$")
	public void processing_Pharmacy_should_be_populated_as_expected() throws Throwable {
		String requestSb = JsonTools.findKeys(base.requestBodyJson,"processingPharmacy");
	    String expectedSb = MiscTools.getExpectedSb(requestSb, base.patientId,base.environment);
	    Assert.assertEquals(expectedSb,base.sb);
	}
}
