package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;

public class GetPersonGUID_search_SSPDT_931_1786 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public GetPersonGUID_search_SSPDT_931_1786(BaseUtil base){
		this.base = base;
	}
	
	
	
	//Scenario1
	@Given("^I have person GUID, Shipping Fromdate, todate, therapy type & ndc no$")
	public void i_have_person_GUID_Shipping_Fromdate_todate() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String PersonGUID=Readproperty("SSPDT931_personGUID_TC1");
		System.out.println("PersonGUID: "+PersonGUID);
		String shipfromdate=Readproperty("SSPDT931_personGUID_TC1_shipfromdate");
		System.out.println("shipfrom: "+shipfromdate);
		String shiptodate=Readproperty("SSPDT931_personGUID_TC1_shiptodate");
		System.out.println("shipto: "+shiptodate);
		base.params.put("patientId="+PersonGUID);
		base.params.put("shipDateFrom="+shipfromdate);
		base.params.put("shipDateTo="+shiptodate);
		System.out.println("Parameters path: "+base.params);
	}



	@When("^I send a request to get prescription record$")
	public void i_send_a_request_to_get_prescription_record() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		String apiPathWithParams =  MiscTools.concatenateParams(ApiPaths.PRESCRIPTION,base.params);
		System.out.println("API path with parameteres:" +apiPathWithParams);
		//Get Request
		base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams);
		//base.response=base.serviceApi.retrive("");
		base.responseBody = base.oaResponse.getBody();
		//this is only for invoice
		//base.responseBody="["+base.responseBody+"]";
		System.out.println("Response body: "+base.responseBody);
	}

	

	@Then("^retrieve prescription records associated with person GUID$")
	public void retrieve_prescription_records_associated_with_person_GUID() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		/*jsonArrayResponseBody = new JSONArray(base.responseBody);
		System.out.println("Array Length : "+jsonArrayResponseBody.length());
		 
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "accredoPatientId");
        System.out.println("patient id: "+legacyPatientId);
        Assert.assertEquals("12148906",legacyPatientId);
        System.out.println("Validated patient id");*/
	}

	//Scenario2 
	@Given("^I have person GUID mapped to multiple legacy ids, Shipping Fromdate, todate, therapy rype & ndc no$")
	public void i_have_person_GUID_mapped_to_multiple_legacy_ids_Shipping_Fromdate_todate() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		String PersonGUID=Readproperty("SSPDT931_personGUID_TC2");
		System.out.println("PersonGUID2: "+PersonGUID);
		base.params.put("patientId="+PersonGUID);
		String shipfromdate=Readproperty("SSPDT931_personGUID_TC2_shipfromdate");
		String shiptodate=Readproperty("SSPDT931_personGUID_TC2_shiptodate");
		base.params.put("shipDateFrom="+shipfromdate);
		base.params.put("shipDateTo="+shiptodate);
		System.out.println("Parameters path: "+base.params);
	}

	@Then("^retrieve all prescription records associated with person GUID$")
	public void retrieve_all_prescription_records_associated_with_person_GUID() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		/*jsonArrayResponseBody = new JSONArray(base.responseBody);
		System.out.println("Array Length : "+jsonArrayResponseBody.length());
		 
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "accredoPatientId");
        System.out.println("patient id: "+legacyPatientId);
        Assert.assertEquals("11333712",legacyPatientId);
        System.out.println("Validated patient id");*/
	}

	
	//Scenario3
	@Given("^I have invalid person GUID, Shipping Fromdate, todate$")
	public void i_have_invalid_person_GUID_Shipping_Fromdate_todate() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String PersonGUID=Readproperty("SSPDT931_personGUID_TC3");
		System.out.println("PersonGUID2: "+PersonGUID);
		base.params.put("patientId="+PersonGUID);
		String shipfromdate=Readproperty("SSPDT931_personGUID_TC3_shipfromdate");
		String shiptodate=Readproperty("SSPDT931_personGUID_TC3_shiptodate");
		base.params.put("shipDateFrom="+shipfromdate);
		base.params.put("shipDateTo="+shiptodate);
		System.out.println("Parameters path: "+base.params);
	}

	@Then("^should show error message No records found for Person GUID$")
	public void should_show_error_message_No_records_found_for_Person_GUID() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		base.responseBody="["+base.responseBody+"]";
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+messageinfo);
		String legacyPatientId=JsonTools.findKeys(messageinfo, "error");
        System.out.println("Search Results: "+legacyPatientId);
        Assert.assertEquals("Not Found",legacyPatientId);
        System.out.println("Validated Search Results for Sceanrio3");
	}
	
	//Scenario4
	@Given("^I have valid PatientId$")
	public void i_have_valid_PatientId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String PatientId=Readproperty("SSPDT931_AccredoPatientId_TC4");
		System.out.println("PersonGUID2: "+PatientId);
		String shipfromdate=Readproperty("SSPDT931_AccredoPatientId_TC4_shipfromdate");
		String shiptodate=Readproperty("SSPDT931_AccredoPatientId_TC4_shiptodate");
		base.params.put("accredoPatientId="+PatientId);
		base.params.put("shipDateFrom="+shipfromdate);
		base.params.put("shipDateTo="+shiptodate);
	}

	@Then("^should get Prescription REcord for Accredo PatientId$")
	public void should_get_Prescription_REcord_for_Accredo_PatientId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Success");
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		System.out.println("Array Length : "+jsonArrayResponseBody.length());
		 
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "accredoPatientId");
        System.out.println("patient id: "+legacyPatientId);
        Assert.assertEquals("12029834",legacyPatientId);
        System.out.println("Validated patient id");
	}

	//Scenario5
	@Given("^I have invalid Accredo PatientId$")
	public void i_have_invalid_Accredo_PatientId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		//base.params.put("accredoPatientId="+"1202933333");
		//base.params.put("shipDateFrom="+"2017-11-01");
		//base.params.put("shipDateTo="+"2017-11-30");
		String PatientId=Readproperty("SSPDT931_AccredoPatientId_TC5");
		System.out.println("PersonGUID2: "+PatientId);
		String shipfromdate=Readproperty("SSPDT931_AccredoPatientId_TC5_shipfromdate");
		String shiptodate=Readproperty("SSPDT931_AccredoPatientId_TC5_shiptodate");
		base.params.put("accredoPatientId="+PatientId);
		base.params.put("shipDateFrom="+shipfromdate);
		base.params.put("shipDateTo="+shiptodate);
	}

	@Then("^should get error message No records found for Accredo Patient Id$")
	public void should_get_error_message_No_records_found_for_Accredo_Patient_Id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		/*System.out.println("Success");
		base.responseBody="["+base.responseBody+"]";
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+messageinfo);
		String legacyPatientId=JsonTools.findKeys(messageinfo, "error");
        System.out.println("Search Results: "+legacyPatientId);
        Assert.assertEquals("Not Found",legacyPatientId);*/
	}

	//Scenario 6
	
	@Given("^I have valid Accredo PatientId not related to Person GUID$")
	public void i_have_valid_Accredo_PatientId_not_related_to_Person_GUID() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String PatientId=Readproperty("SSPDT931_AccredoPatientId_TC6");
		System.out.println("PersonGUID2: "+PatientId);
		String shipfromdate=Readproperty("SSPDT931_AccredoPatientId_TC6_shipfromdate");
		String shiptodate=Readproperty("SSPDT931_AccredoPatientId_TC6_shiptodate");
		base.params.put("accredoPatientId="+PatientId);
		base.params.put("shipDateFrom="+shipfromdate);
		base.params.put("shipDateTo="+shiptodate);
	}

	@Then("^should get Prescription Record not related to Person GUID$")
	public void should_get_Prescription_Record_not_related_to_Person_GUID() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Success");
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		System.out.println("Array Length : "+jsonArrayResponseBody.length());
		 
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "accredoPatientId");
        System.out.println("patient id: "+legacyPatientId);
        Assert.assertNotEquals("12148906",legacyPatientId);
        System.out.println("Validated patient id");
	}
	
	public String Readproperty(String name)
	{
		Properties prop = new Properties();
		InputStream input = null;
		String name1 = null;
		try {

		input = new FileInputStream("C:\\Specialty-Data-Services-Test-Suit-destiny-sprint-11\\input.properties");
		
		// load a properties file
		prop.load(input);

		// get the property value and print it out
		
		if(name.contentEquals("SSPDT931_personGUID_TC1"))
		{
		 name1=prop.getProperty("SSPDT931_personGUID_TC1");
		}
		else if(name.contentEquals("SSPDT931_personGUID_TC2"))
		{
			 name1=prop.getProperty("SSPDT931_personGUID_TC2");
		}
		else if(name.contentEquals("SSPDT931_personGUID_TC3"))
		{
			 name1=prop.getProperty("SSPDT931_personGUID_TC3");
		}
		else if(name.contentEquals("SSPDT931_AccredoPatientId_TC4"))
		{
			 name1=prop.getProperty("SSPDT931_AccredoPatientId_TC4");
		}
		else if(name.contentEquals("SSPDT931_AccredoPatientId_TC4"))
		{
			 name1=prop.getProperty("SSPDT931_AccredoPatientId_TC4");
		}
		else if(name.contentEquals("SSPDT931_AccredoPatientId_TC5"))
		{
			 name1=prop.getProperty("SSPDT931_AccredoPatientId_TC5");
		}
		else if(name.contentEquals("SSPDT931_AccredoPatientId_TC6"))
		{
			 name1=prop.getProperty("SSPDT931_AccredoPatientId_TC6");
		}
		else if(name.contentEquals("SSPDT931_personGUID_TC1_shipfromdate"))
		{
			 name1=prop.getProperty("SSPDT931_personGUID_TC1_shipfromdate");
		}
		else if(name.contentEquals("SSPDT931_personGUID_TC1_shiptodate"))
		{
			 name1=prop.getProperty("SSPDT931_personGUID_TC1_shiptodate");
		}
		else if(name.contentEquals("SSPDT931_personGUID_TC2_shipfromdate"))
		{
			 name1=prop.getProperty("SSPDT931_personGUID_TC2_shipfromdate");
		}
		else if(name.contentEquals("SSPDT931_personGUID_TC2_shiptodate"))
		{
			 name1=prop.getProperty("SSPDT931_personGUID_TC2_shiptodate");
		}
		else if(name.contentEquals("SSPDT931_personGUID_TC3_shipfromdate"))
		{
			 name1=prop.getProperty("SSPDT931_personGUID_TC3_shipfromdate");
		}
		else if(name.contentEquals("SSPDT931_personGUID_TC3_shiptodate"))
		{
			 name1=prop.getProperty("SSPDT931_personGUID_TC3_shiptodate");
		}
		else if(name.contentEquals("SSPDT931_AccredoPatientId_TC4_shipfromdate"))
		{
			 name1=prop.getProperty("SSPDT931_AccredoPatientId_TC4_shipfromdate");
		}
		else if(name.contentEquals("SSPDT931_AccredoPatientId_TC4_shiptodate"))
		{
			 name1=prop.getProperty("SSPDT931_AccredoPatientId_TC4_shiptodate");
		}
		else if(name.contentEquals("SSPDT931_AccredoPatientId_TC5_shipfromdate"))
		{
			 name1=prop.getProperty("SSPDT931_AccredoPatientId_TC5_shipfromdate");
		}
		else if(name.contentEquals("SSPDT931_AccredoPatientId_TC5_shiptodate"))
		{
			 name1=prop.getProperty("SSPDT931_AccredoPatientId_TC5_shiptodate");
		}
		else if(name.contentEquals("SSPDT931_AccredoPatientId_TC6_shipfromdate"))
		{
			 name1=prop.getProperty("SSPDT931_AccredoPatientId_TC6_shipfromdate");
		}
		else if(name.contentEquals("SSPDT931_AccredoPatientId_TC6_shiptodate"))
		{
			 name1=prop.getProperty("SSPDT931_AccredoPatientId_TC6_shiptodate");
		}
		//System.out.println(prop.getProperty("dbuser"));
		//System.out.println(prop.getProperty("dbpassword"));

		} catch (IOException ex) {
			System.out.println("Error");
			ex.printStackTrace();
	
	}
		return name1;
}

	
}
