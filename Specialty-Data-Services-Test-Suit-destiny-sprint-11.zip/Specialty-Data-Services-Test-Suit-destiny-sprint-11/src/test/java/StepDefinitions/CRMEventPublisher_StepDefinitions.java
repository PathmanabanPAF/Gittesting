package StepDefinitions;


import java.sql.ResultSet;
import java.sql.SQLException;


import org.junit.Assert;
import org.json.JSONObject;


import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.DBConnection;
import GlobalClasses.JsonTools;
import GlobalClasses.ResourcePaths;
import GlobalEnums.SqlQueries;

public class CRMEventPublisher_StepDefinitions extends BaseUtil{
	public String requestBody,query;
	public static String eventId;
	JSONObject RequestBodyJson;
	private BaseUtil base;
	private String projectId;
	private String ruleId;
	private String copayIndicatorEligibilityResult;
	private String CPAIndicatorPatientResponse;
	private String patientResponse, declineReasonResponse;
	public CRMEventPublisher_StepDefinitions(BaseUtil base){this.base = base;};
	public static String geteventId(){return eventId;}
	
	

	@When("^the Request should be executed for insurance update$")
	public void the_Request_should_be_executed_for_insurance_update() throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		try{
			ResultSet rs = db.ExecuteSelect(SqlQueries.MaxEventId.toString());
			while(rs.next()){
				eventId = rs.getString(1).toString();
			}

		}catch(SQLException e){
			e.getMessage();
		}finally{
			db.Close();
		}
				
		System.out.println("Max eventId :"+eventId);
		RequestBodyJson = JsonTools.readJsonFile(ResourcePaths.INSURANCE_UPDATE);
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "eventId", eventId).toString();
		requestBody = JsonTools.updateKeysPath(RequestBodyJson, "patient.id", SubmitSpecialtyOrder_StepDefinitions.getpatientId()).toString();
		requestBody = JsonTools.updateKeys(RequestBodyJson,"serviceBranchId", SubmitSpecialtyOrder_StepDefinitions.getSB()).toString();
		requestBody = JsonTools.updateKeysPath(RequestBodyJson, "prescription.id", SubmitSpecialtyOrder_StepDefinitions.getprescriptionId()).toString();
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "refillNumber", SubmitSpecialtyOrder_StepDefinitions.getrefillNo()).toString();
		base.response = base.serviceApi.create(ApiPaths.INSURANCE_UPDATE, requestBody);
    	base.responseBody = base.response.getBody().asString();
		
	    
	}
	
	@When("^the Request should be executed for therapy update$")
	public void the_Request_should_be_executed_for_therapy_update() throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		try{
			ResultSet rs = db.ExecuteSelect(SqlQueries.MaxEventId.toString());
			while(rs.next()){
				eventId = rs.getString(1).toString();
			}

		}catch(SQLException e){
			e.getMessage();
		}finally{
			db.Close();
		}
		
		System.out.println("Max eventId :"+eventId);
		RequestBodyJson = JsonTools.readJsonFile(ResourcePaths.THERAPY_UPDATE);
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "eventId", eventId).toString();
		requestBody = JsonTools.updateKeysPath(RequestBodyJson, "patient.id", SubmitSpecialtyOrder_StepDefinitions.getpatientId()).toString();
		requestBody = JsonTools.updateKeys(RequestBodyJson,"serviceBranchId", SubmitSpecialtyOrder_StepDefinitions.getSB()).toString();
		requestBody = JsonTools.updateKeysPath(RequestBodyJson, "prescription.id", SubmitSpecialtyOrder_StepDefinitions.getprescriptionId()).toString();
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "refillNumber", SubmitSpecialtyOrder_StepDefinitions.getrefillNo()).toString();
		base.response = base.serviceApi.create(ApiPaths.THERAPY_UPDATE, requestBody);
    	base.responseBody = base.response.getBody().asString();
		
	}
	
	@When("^the Request should be executed for physician update$")
	public void the_Request_should_be_executed_for_physician_update() throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		try{
			ResultSet rs = db.ExecuteSelect(SqlQueries.MaxEventId.toString());
			while(rs.next()){
				eventId = rs.getString(1).toString();
			}

		}catch(SQLException e){
			e.getMessage();
		}finally{
			db.Close();
		}
		
		System.out.println("Max eventId :"+eventId);
		RequestBodyJson = JsonTools.readJsonFile(ResourcePaths.PHYSICIAN_UPDATE);
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "eventId", eventId).toString();
		requestBody = JsonTools.updateKeysPath(RequestBodyJson, "patient.id", SubmitSpecialtyOrder_StepDefinitions.getpatientId()).toString();
		requestBody = JsonTools.updateKeys(RequestBodyJson,"serviceBranchId", SubmitSpecialtyOrder_StepDefinitions.getSB()).toString();
		requestBody = JsonTools.updateKeysPath(RequestBodyJson, "prescription.id", SubmitSpecialtyOrder_StepDefinitions.getprescriptionId()).toString();
		requestBody =  JsonTools.updateKeys(RequestBodyJson, "refillNumber", SubmitSpecialtyOrder_StepDefinitions.getrefillNo()).toString();
		base.response = base.serviceApi.create(ApiPaths.PHYSICIAN_UPDATE, requestBody);
		base.responseBody = base.response.getBody().asString();
	}


	
	@Then("^the EventID should be inserted on the table for \"([^\"]*)\"$")
	public void the_EventID_should_be_inserted_on_the_table_for(String nameWs) throws Throwable {
		DBConnection db = new DBConnection(base.environment); 
		if("insurance".toUpperCase().equals(nameWs.toUpperCase())){
			query = "select status "
					+"from thot.ev_event_control "
					+"where status_message = 'PATIENT_DETAIL_OML_PKG.INSURANCE_UPDATE' and status = 'PROCESSED' and event_id="+ eventId;
		}else if("therapy".toUpperCase().equals(nameWs.toUpperCase())){
			query = "select status "
					+"from thot.ev_event_control "
					+"where status_message = 'PATIENT_DETAIL_OML_PKG.THERAPY UPDATE' and status = 'PROCESSED' and event_id="+ eventId;
		}else if("physician".toUpperCase().equals(nameWs.toUpperCase())){
			query = "select status "
					+"from thot.ev_event_control "
					+"where status_message = 'PATIENT_DETAIL_OML_PKG.PHYSICIAN_UPDATE' and status = 'PROCESSED' and event_id="+ eventId;
		}else if("copay".toUpperCase().equals(nameWs.toUpperCase())){
			query = "select status "
					+"from thot.ev_event_control "
					+"where status_message = 'PATIENT_DETAIL_OML_PKG.SET_CPA_ENROLLMENT' and status = 'PROCESSED' and event_id="+ eventId;
		}
		try{
			ResultSet rs = db.ExecuteSelect(query);
			String status="";
			while(rs.next()){
				status = rs.getString(1);
			}
			Assert.assertEquals(status, "PROCESSED");

		}catch(SQLException e){
			e.getMessage();
		}finally{
			db.Close();
		}
   
	}

	@Then("^the \"([^\"]*)\" chart note should be created for \"([^\"]*)\"$")
	public void the_chart_note_should_be_created_for(String type, String nameWs) throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		query = "select text from thot.charts where commnote_type = "+type+" and xuser = 'WS_EVNT_PROC' and patient_id ="+SubmitSpecialtyOrder_StepDefinitions.getpatientId();
		try{
			ResultSet rs = db.ExecuteSelect(query);
			String status="";
			while(rs.next()){
				status = rs.getString(1);
			}
			if("insurance".toUpperCase().equals(nameWs.toUpperCase())){
//				assert(status.contains("REASON FOR REQUEST: CHANGE - THERAPY"));
				Assert.assertEquals(status,"REASON FOR REQUEST: CHANGE - THERAPY");
			}else if("therapy".toUpperCase().equals(nameWs.toUpperCase())){
//				assert(status.contains("Comments: INSURANCE CHANGE NOTIFICATION"));
				Assert.assertEquals(status, "Comments: INSURANCE CHANGE NOTIFICATION");
			}else if("physician".toUpperCase().equals(nameWs.toUpperCase())){
//				assert(status.contains("REASON FOR REQUEST: CHANGE - DOCTOR"));
				Assert.assertEquals(status,"REASON FOR REQUEST: CHANGE - DOCTOR");
			}else if("copay".toUpperCase().equals(nameWs.toUpperCase())){
//				assert(status.contains("REASON FOR REQUEST: CHANGE - DOCTOR"));
				Assert.assertEquals(status,"CopayAssistance");
			}
		}catch(SQLException e){
			e.getMessage();
		}finally{
			db.Close();
		}
	}

	@Then("^a OS Task status should be \"([^\"]*)\" with reason code \"([^\"]*)\" for \"([^\"]*)\"$")
	public void a_OS_Task_status_should_be_with_reason_code_for(String taskStatus, String reasonCode, String nameWs) throws Throwable {
		String taskStatusResult = null;
		DBConnection db = new DBConnection(base.environment);
		if("insurance".equals(nameWs)){
			query = "select 'SUCCESS' from thot.wq_task_details_v where patient_id = "+SubmitSpecialtyOrder_StepDefinitions.getpatientId()+
					" and  task_status = '"+taskStatus.toUpperCase()+"' and reason_code = '"+reasonCode+"' and wq_workqueue = 'ORDER SCHEDULING' and updated_by = 'WS_EVNT_PROC' order by update_date desc";
		}else if("therapy".equals(nameWs)){
			query = "select 'SUCCESS' from thot.wq_task_details_v where patient_id = "+SubmitSpecialtyOrder_StepDefinitions.getpatientId()+
					" and  task_status = '"+taskStatus.toUpperCase()+"' and reason_code = '"+reasonCode+"' and wq_workqueue = 'ORDER SCHEDULING' and updated_by = 'WS_EVNT_PROC' order by update_date desc";
		}else if("physician".equals(nameWs)){
			query = "select 'SUCCESS' from thot.wq_task_details_v where patient_id = "+SubmitSpecialtyOrder_StepDefinitions.getpatientId()+
					" and  task_status = '"+taskStatus.toUpperCase()+"' and reason_code = '"+reasonCode+"' and wq_workqueue = 'ORDER SCHEDULING' and updated_by = 'WS_EVNT_PROC' order by update_date desc";
		}
		try{
			ResultSet rs = db.ExecuteSelect(query);
			while(rs.next()){
				taskStatusResult = rs.getString(1);
			}
			
			System.out.println("Result :"+taskStatusResult);
			Assert.assertTrue("SUCCESS".equals(taskStatusResult.toUpperCase()));

		}catch(SQLException e){
			e.getMessage();
		}finally{
			db.Close();
		}
	}
	
	@When("^set the information for CPA$")
	public void set_the_information_for_CPA() throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		
		//Project ID CPA
		query ="select project_id from thot.custom_rules where project_name like'%COPAY INDICATOR%'";
		ResultSet rs = db.ExecuteSelect(query);
		try{
			while(rs.next()){
				projectId = rs.getString(1);
			}
		}catch(SQLException e){e.getMessage();}
		
		//Rule Id for CPA
		query ="select rule_id from thot.custom_rules_dtl crd, thot.custom_rules_set crs where crd.set_id = crs.set_id "
				+"and crd.project_id = "+projectId+" and crs.rule = 'THERAPY TYPE'";
		rs = db.ExecuteSelect(query);
		try{
			while(rs.next()){
				ruleId = rs.getString(1);
			}
		}catch(SQLException e){e.getMessage();}
		
		//Indicator Eligibility Result for CPA
		query ="select attribute7 from thot.custom_rules_values where rule_id = "+ruleId+" and attribute3 = 'A' and value = 'HUMA'";
		rs = db.ExecuteSelect(query);
		try{
			while(rs.next()){
				copayIndicatorEligibilityResult = rs.getString(1);
			}
		}catch(SQLException e){e.getMessage();}
		//Insert Indicator Eligibility Result for CPA
		if(copayIndicatorEligibilityResult == null){
			query ="insert into thot.custom_rules_values (rule_id,value,rule,attribute1,attribute2,attribute3,attribute4,attribute5,attribute6,attribute7,created_by,created_date,updated_by,updated_date) "
					+"values ("+ ruleId +",'HUMA','THERAPY TYPE','T','1','A',null,null,null,'PATIENT IS ELIGIBLE FOR OFFER OF COPAY ASSISTANCE',user,sysdate,user,sysdate)";
			try{
				db.ExecuteInsert(query);
			}catch(SQLException e){e.getMessage();}
		}
	}

	
	@When("^the Request should be executed for COPAY assistance$")
	public void the_Request_should_be_executed_for_Copay_assistance() throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		try{
			ResultSet rs = db.ExecuteSelect(SqlQueries.MaxEventId.toString());
			while(rs.next()){
				eventId = rs.getString(1).toString();
			}
		}catch(SQLException e){
			e.getMessage();
		}finally{
			db.Close();
		}
		
		System.out.println("Max eventId :"+eventId);
		
		requestBody = JsonTools.updateKeys(RequestBodyJson, "eventId", eventId).toString();
		requestBody = JsonTools.updateKeysPath(RequestBodyJson, "patient.id", SubmitSpecialtyOrder_StepDefinitions.getpatientId()).toString();
		requestBody = JsonTools.updateKeys(RequestBodyJson,"serviceBranchId", SubmitSpecialtyOrder_StepDefinitions.getSB()).toString();
		requestBody = JsonTools.updateKeysPath(RequestBodyJson, "prescription.id", SubmitSpecialtyOrder_StepDefinitions.getprescriptionId()).toString();
		requestBody = JsonTools.updateKeys(RequestBodyJson, "refillNumber", SubmitSpecialtyOrder_StepDefinitions.getrefillNo()).toString();
		base.response = base.serviceApi.create(ApiPaths.COPAY, requestBody);
		base.responseBody = base.response.getBody().asString();
	}
	
	@When("^the copay assistance should \"([^\"]*)\"$")
	public void the_copay_assistance_should(String patientResponse) throws Throwable {
		this.patientResponse = patientResponse.toUpperCase().replaceAll("\\s+", "");
		RequestBodyJson = JsonTools.readJsonFile(ResourcePaths.COPAY);
		if(this.patientResponse.equals("ACCEPTED")){
			requestBody = JsonTools.updateKeys(RequestBodyJson, "enrolled", "Y").toString();
			requestBody = JsonTools.updateKeys(RequestBodyJson, "transferred", "Y").toString();
		}else if(this.patientResponse.equals("DECLINED")){
			requestBody = JsonTools.updateKeys(RequestBodyJson, "enrolled", "N").toString();
			requestBody = JsonTools.updateKeys(RequestBodyJson, "transferred", "N").toString();
			requestBody = JsonTools.updateKeys(RequestBodyJson, "declineReason", "DECLINE REASONS AUTOMATION").toString();
			declineReasonResponse = JsonTools.findKeys(RequestBodyJson, "declineReason");
		}
		
	}


	@Then("^validate the patient response and response date$")
	public void validate_the_patient_response_and_response_date() throws Throwable {
	    DBConnection db = new DBConnection(base.environment);
	    query = "select cpa_ind_pat_resp from thot.patient_therapies where  patient_id = "+ SubmitSpecialtyOrder_StepDefinitions.getpatientId() +" and stop_date is null and updated_by = 'WS_EVNT_PROC' and trunc(cpa_ind_resp_date) = trunc(sysdate)";
	    try{
	    	ResultSet rs = db.ExecuteSelect(query);
	    	while(rs.next()){
	    		CPAIndicatorPatientResponse = rs.getString(1);
	    	}
	    }catch(SQLException e){e.getMessage();}
	    finally{
	    	db.Close();
	    }
	    if(this.patientResponse =="ACCEPTED"){
	    	Assert.assertTrue(CPAIndicatorPatientResponse.toUpperCase().equals("A"));
	    }else if(this.patientResponse =="DECLINED"){
	    	
	    }
	    
	}
	
	@Then("^the decline reason should be insert on the table$")
	public void the_decline_reason_should_be_insert_on_the_table() throws Throwable {
	    DBConnection db = new DBConnection(base.environment);
	    try{
	    	query = "select decline_reason from thot.patient_copay_information where patient_id="+SubmitSpecialtyOrder_StepDefinitions.getpatientId().toString();
	    	ResultSet rs =  db.ExecuteSelect(query);
	    	while(rs.next()){
	    		String declineReason = rs.getString(1);
	    		System.out.println("Decline Reason :"+declineReasonResponse);
	    		Assert.assertTrue(declineReason.equals(declineReasonResponse));
	    	}
	    }catch(SQLException e){
	    	e.getMessage();
	    }finally{
	    	db.Close();
	    }
	}


	    

}
