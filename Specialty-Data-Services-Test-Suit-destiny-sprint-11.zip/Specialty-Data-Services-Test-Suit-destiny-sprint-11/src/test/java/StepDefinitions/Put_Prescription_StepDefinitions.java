package StepDefinitions;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalEnums.ResponseMessage;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Put_Prescription_StepDefinitions extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill, patientId;
	String prescriber, storageType, drugRoute;
	String writtenDate, refillThruDate, expirationDate, shipDate, lotExpDate;
	String errors, currentErrors;
	String therapyType;
	String rangeFilter, rangeFilterDefault;
	String query;
	String oldInfo, requestInfo;
	public String requestBody;
	JSONObject fillInfo;
	JSONObject prescriptionInfo, newPrescriptionInfo, oldPrescriptionInfo;
	JSONObject jsonResponseBody;
	JSONArray requestBodyArray;
	
	public Put_Prescription_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I get Rx fields values$")
	public void i_get_Rx_fields_values() throws Throwable {
		base.sb = base.prescription.get("sb"); base.rxId =base.prescription.get("rxId"); base.refill =base.prescription.get("refill");
		base.requestBodyJson = MiscTools.getRxUpdatableFields(base.prescription, base.environment);
	}

	@Given("^I get new values for Rx fields$")
	public void i_get_new_values_for_Rx_fields() throws Throwable {
		base.sb = base.prescription.get("sb"); base.rxId =base.prescription.get("rxId"); base.refill =base.prescription.get("refill");
		base.requestBodyJson = MiscTools.getRxUpdatableFields(base.prescription, base.environment);
		oldInfo = base.requestBodyJson.toString();
		base.requestBodyJson = MiscTools.getNewRxValues( base.requestBodyJson, base.environment);
		requestInfo = base.requestBodyJson.toString();
	}
	
	@Given("^I get new values for Fill fields$")
	public void i_get_new_values_for_Fill_fields() throws Throwable {
		sb = base.prescription.get("sb"); rxId =base.prescription.get("rxId");refill =base.prescription.get("refill");
		base.requestBodyJson = MiscTools.getNewFillValues(base.prescription, base.environment);
		oldInfo = base.requestBodyJson.toString();
		base.requestBodyJson.getJSONObject("fill").put("directions",MiscTools.getRandomString(10));
		requestInfo = base.requestBodyJson.toString();
	}

	@Given("^I use a Prescriber not related to(?: Prescription's|) Patient$")
	public void i_use_a_Prescriber_not_related_to_Prescription_s_Patient() throws Throwable {
		//patientId = base.requestBodyJson.getString("patient");
		patientId = JsonTools.findKeys(base.requestBodyJson,"patient");
		prescriber = MiscTools.getPrescriberNotInPatient(patientId, base.environment);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "prescriber", prescriber);
		//base.requestBodyJson.put("prescriber", prescriber);
	}
	
	@Given("^I use a Therapy Type not related to(?: Prescription's|) Patient$")
	public void i_use_a_Therapy_Type_not_related_to_Prescription_s_Patient() throws Throwable {
		patientId = JsonTools.findKeys(base.requestBodyJson,"patient");
		therapyType = MiscTools.getTTNotInPatient(patientId, base.environment);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "therapyID", therapyType);
	}
	
	@Given("^I use an invalid Patient for Prescription$")
	public void i_use_an_invalid_Patient_for_Prescription() throws Throwable {
	    patientId = base.requestBodyJson.getString("patient");
	    query = String.format(SqlQueries.GetPatientIdDifferentThan.toString(),patientId);
	    patientId = MiscTools.executeSingleSelect(base.environment, query);
	    base.requestBodyJson.put("patient",patientId);
	}
	
	@Given("^I use an invalid Patient$")
	public void i_use_an_invalid_Patient() throws Throwable {
		 patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetInvalidPatient.toString());
		 base.requestBodyJson.put("patient",patientId);
	}

	@Given("^I set Rx Refill Thru Date prior Rx Written Date$")
	public void i_set_Rx_Refill_Thru_Date_prior_Rx_Written_Date() throws Throwable {
		refillThruDate = JsonTools.findKeys(base.requestBodyJson,"expirationDate");
		writtenDate = MiscTools.addDaysToDate(refillThruDate,1);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "writtenDate",writtenDate);
	}
	
	@Given("^I use a Written Date greater that Ship Date$")
	public void i_use_a_Written_Date_greater_that_Ship_Date() throws Throwable {
		query = String.format(prescriptionSqlQueries.GetRxShipDate.toString(), base.sb, base.rxId, base.refill);
		shipDate = MiscTools.executeSingleSelect(base.environment, query);
		writtenDate = MiscTools.addDaysToDate(shipDate,1);
		base.requestBodyJson.put("writtenDate",writtenDate);
	}

	@Given("^I use an Expiration Date prior Current Date$")
	public void i_use_an_Expiration_Date_prior_Current_Date() throws Throwable {
		expirationDate = MiscTools.addDaysToToday(-1, "yyyy-MM-dd");
		base.requestBodyJson.put("expirationDate",expirationDate);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "expirationDate",expirationDate);
	}
	
	@Given("^I use Refill Thru Date more than a year past Rx Written Date$")
	public void i_use_Refill_Thru_Date_more_than_a_year_past_Rx_Written_Date() throws Throwable {
		writtenDate = JsonTools.findKeys(base.requestBodyJson,"writtenDate");
		refillThruDate = MiscTools.addDaysToDate(writtenDate,370);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "refillThruDate",refillThruDate);
	}

	@Given("^I use a Ship Date prior Rx Written Date$")
	public void i_use_a_Ship_Date_prior_Rx_Written_Date() throws Throwable {
		//shipDate = MiscTools.GetShipDatePriorRxWritteDate(base.sb, base.rxId, base.refill,base.environment);
		query = String.format(prescriptionSqlQueries.GetRxWrittenDate.toString(), base.sb, base.rxId, base.refill);
		writtenDate = MiscTools.executeSingleSelect(base.environment, query);
		shipDate = writtenDate.equals("")?MiscTools.getPastMonthDateMonthName():MiscTools.addDaysToDate(writtenDate,-90);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "shipDate",shipDate);
	}
	
	@Given("^I use an Expiration Date greater than Lot Expiration Date$")
	public void i_use_an_Expiration_Date_greater_than_Lot_Expiration_Date() throws Throwable {
		query = String.format(prescriptionSqlQueries.GetRxLotExpDate.toString(), base.sb, base.rxId, base.refill);
		System.out.println(query);
		lotExpDate = MiscTools.executeSingleSelect(base.environment, query);
		System.out.println("----_"+lotExpDate);
		expirationDate = MiscTools.addDaysToDate(lotExpDate,1);
		base.requestBodyJson.put("expirationDate",expirationDate);
	}

	@Given("^I set Prescription status field as \"([^\"]*)\"$")
	public void i_set_Prescription_status_field_as(String status) throws Throwable {
		base.requestBodyJson.put("currentStatus", status.toUpperCase());
	}

	@Given("^I fill Storage Type field w/an invalid value$")
	public void i_fill_Storage_Type_field_w_an_invalid_value() throws Throwable {
		storageType = MiscTools.getNonExistentStorageType(base.environment);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "storage_type", storageType);	
	}
	
	@Given("^I fill Drug Route field w/an invalid value$")
	public void i_fill_Drug_Route_field_w_an_invalid_value() throws Throwable {
		 drugRoute = MiscTools.getNonExistentDrugRoute(base.environment);
		 base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "drug_route", drugRoute);
	}
	
	@Given("^I fill Substitutions field w/an invalid value$")
	public void i_fill_Substitutions_field_w_an_invalid_value() throws Throwable {
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, "substitutions", Integer.toString(MiscTools.getRandomInt(10, 15)));
	}

	@When("^I send a request to update Prescription information$")
	public void i_send_a_request_to_update_Prescription_information() throws Throwable {
		MiscTools.printIdented("Prescription used: Service Branch->"+base.sb+" Prescription Id->"+base.rxId+ (base.refill == null?"":" Refill->"+base.refill));
		base.requestBodyArray = new JSONArray();
		base.requestBodyArray.put(base.requestBodyJson);
		base.requestBody = base.requestBodyArray.toString();
		System.out.println(base.requestBody);
		System.out.println(ApiPaths.PRESCRIPTION+base.rxId);
		base.oaResponse = base.oauthServiceApi.update(ApiPaths.PRESCRIPTION+base.rxId,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
		//base.response = base.serviceApi.update(ApiPaths.PRESCRIPTION+rxId, base.requestBody);
    	//base.responseBody = base.response.getBody().asString();
		System.out.println(base.responseBody);
	}

	@When("^I send a request to update Fill information$")
	public void i_send_a_request_to_update_Fill_information() throws Throwable {
		MiscTools.printIdented("Prescription used: Service Branch->"+sb+" Prescription Id->"+rxId+ (refill == null?"":" Refill->"+refill));
		base.requestBody = base.requestBodyJson.toString();
		String apiPath = String.format(ApiPaths.UPDATE_FILL, rxId,refill);
		System.out.println(apiPath);
		System.out.println(base.requestBody);
		base.oaResponse = base.oauthServiceApi.update(apiPath,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
//		base.response = base.serviceApi.update(apiPath, base.requestBody);
//    	base.responseBody = base.response.getBody().asString();
		System.out.println(base.responseBody);
	}

	@Then("^Prescription should have the new values$")
	public void prescription_should_have_the_new_values() throws Throwable {
		newPrescriptionInfo = MiscTools.getRxUpdatableFields(base.prescription, base.environment);
		oldPrescriptionInfo = new JSONObject(requestInfo);
		//System.out.println("---->old"+oldInfo);
		//System.out.println("---->new"+requestInfo);
		JSONAssert.assertEquals(oldPrescriptionInfo,newPrescriptionInfo,JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^Prescription should not be updated$")
	public void prescription_should_not_be_updated() throws Throwable {
		newPrescriptionInfo = MiscTools.getRxUpdatableFields(base.prescription, base.environment);
		oldPrescriptionInfo = new JSONObject(oldInfo);
		JSONAssert.assertEquals(oldPrescriptionInfo,newPrescriptionInfo,JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^Fill should have the new values$")
	public void fill_should_have_the_new_values() throws Throwable {
		newPrescriptionInfo = MiscTools.getNewFillValues(base.prescription, base.environment);
		oldPrescriptionInfo = new JSONObject(requestInfo);
//		System.out.println("---->old"+oldPrescriptionInfo);
//		System.out.println("---->new"+newPrescriptionInfo);
		JSONAssert.assertEquals(oldPrescriptionInfo,newPrescriptionInfo,JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^Fill should not be updated$")
	public void fill_should_not_be_updated() throws Throwable {
		newPrescriptionInfo = MiscTools.getNewFillValues(base.prescription, base.environment);
		oldPrescriptionInfo = new JSONObject(oldInfo);
		JSONAssert.assertEquals(oldPrescriptionInfo,newPrescriptionInfo,JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^I should get Rx Error \"([^\"]*)\"$")
	public void i_should_get_Rx_Error(String expectedError) throws Throwable {
		expectedError = expectedError.replaceAll("\\s+", "");
		expectedError = String.format(ResponseMessage.valueOf(expectedError).toString(),base.sb+"-"+base.rxId+"-"+base.refill);
		String actualError = MiscTools.getErrorFromRes(base.responseBody);
		Assert.assertEquals(expectedError, actualError);
	}
}
