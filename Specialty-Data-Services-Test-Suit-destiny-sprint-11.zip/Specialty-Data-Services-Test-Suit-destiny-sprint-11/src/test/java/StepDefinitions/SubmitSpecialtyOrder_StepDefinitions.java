package StepDefinitions;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.groovy.util.ReleaseInfo;
import org.junit.Assert;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import GlobalEnums.SqlQueries;
import GlobalClasses.ApiPaths;
import GlobalClasses.ApiTools;
import GlobalClasses.BaseUtil;
import GlobalClasses.DBConnection;
import GlobalClasses.ResourcePaths;
import GlobalClasses.WSCredentials;
import GlobalClasses.XmlTools;
import GlobalEnums.StatusCode;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;




public class SubmitSpecialtyOrder_StepDefinitions extends BaseUtil{
	public String requestBody;
	private static String environment;				private static String calendarMessage;
	private static String patientId;				private static String nsOrdDispNo;
	private static String SB;						private static String kindOfRx;		
	private static String prescriptionId;			private static String nsOrdInvno;
	private static String refillNo;					private static String NBDReasonCode;
	private static String claimCenterNo;    		private static String therapyType;
	private static String shipDate;					private static String newShipdate;
	private static String NBD;						private static String estDeliveryDate;
	private static String shippingId;				private static String shipper = "";
	private static String shipperMethod;			private static String signatureRequired;
	private static String saturdayDelivery;			private static String shipperOverride;
	private static String shipperOverrReasonCode;	private static String residentialDelivery;
	private static String shMethodOverrReasonCode;  private static String cancelOrderValue = "N";
	private static String eventProducer = null;		private static String saturdayOverrideReason = "New Referral";
	private static String newShipdateProtocol;      private static String protocolId;
	private static String ruleSetHeaderId;			private static String ruleSetDetailId;
	
	private static String dateType;			private static String code;
	private static String protocolDesc;		private static String area;
	private static String tat;				private static String action;
	private BaseUtil base;					
	
	CallableStatement callableStatement;
	String query;
	String plSQLJob;
	String isMedcoRx;
	
	public SubmitSpecialtyOrder_StepDefinitions(BaseUtil base){this.base = base;}
	public static String getenvironment(){return environment;}
	public static String getpatientId(){return patientId;}
	public static String getSB(){return SB;}
	public static String getkindOfRx(){return kindOfRx;}
	public static String getnsOrdDispNo(){return nsOrdDispNo;}
	public static String getprescriptionId(){return prescriptionId;}
	public static String getnsOrdInvno(){return nsOrdInvno;}
	public static String getrefillNo(){return refillNo;}
	public static String getclaimCenterNo(){return claimCenterNo;}
	public static String gettherapyType(){return therapyType;}
	public static String getshipDate(){return shipDate;}
	public static String getnewShipdate(){return newShipdate;}
	public static String getNBDReasonCode(){return NBDReasonCode;}
	public static String getNBD(){return NBD;}
	public static String getestDeliveryDate(){return estDeliveryDate;}
	public static String getshippingId(){return shippingId;}
	public static String getshipperMethod(){return shipperMethod;}
	public static String getsignatureRequired(){return signatureRequired;}
	public static String getsaturdayDelivery(){return saturdayDelivery;}
	public static String getshipperOverride(){return shipperOverride;}
	public static String getshipperOverrReasonCode(){return shipperOverrReasonCode;}
	public static String getshMethodOverrReasonCode(){return shMethodOverrReasonCode;}
	public static String getshipper(){return shipper;}
	public static String getresidentialDelivery(){return residentialDelivery;}
	public static String getcancelOrderValue(){return cancelOrderValue;}
	public static String getsaturdayOverrideReason(){return saturdayOverrideReason;}
	public static String getcalendarMessage(){return calendarMessage;}
	public static String geteventProducer(){return eventProducer;}
	
	
	@Given("^The scenarios must be run on \"([^\"]*)\" environment$")
	public void the_scenarios_must_be_run_on_environment(String environment) throws Throwable {
		base.environment = environment;
	}

	
	@Given("^I get a \"([^\"]*)\" Prescription with Profile Lock Status$")
	public void i_get_a_Prescription_with_Profile_Lock_Status(String arg1) throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		if(arg1.equals("Direct")){
			query = SqlQueries.RxPLDirect12b.toString();
		}else if(arg1.equals("Integrated")){
			query = SqlQueries.RxPLIntegrated12b.toString();
		}
	    try{
			ResultSet rs = db.ExecuteSelect(query);
			while(rs.next()){
				 
				patientId = rs.getString(1);
				SB = rs.getString(2);
				therapyType = rs.getString(3);
				prescriptionId = rs.getString(4);
				refillNo = rs.getString(5);
				shipDate = rs.getString(6);
				NBD = rs.getString(7);
				shippingId = rs.getString(8);
				
				System.out.println("Patient :"+patientId);
				System.out.println("Rx :"+SB+"-"+prescriptionId+"-"+refillNo);
				
			}
		}catch(SQLException e){
			e.getStackTrace();
		}
	    
	    query = "SELECT * FROM (SELECT CODE FROM THOT.FT_LOOKUPS WHERE TYPE ='NBD_REASON_CODES' AND CODE IN ("
				+"'CONFIRMED WITH PATIENT AND PHYSICIAN',"
				+"'PATIENT CONFIRMED',"
				+"'DOCTOR CONFIRMED',"
				+"'DOCTOR CONFIRMED-PATIENT CONFIRMATION NOT REQUIRED',"
				+"'PATIENT CONFIRMED-DOCTOR CONFIRMATION NOT REQUIRED CONFIRMED THROUGH FQE',"
				+"'CONFIRMED BY WEB/IVR',"
				+"'NOT CONFIRMED')ORDER BY SYS.DBMS_RANDOM.RANDOM) WHERE ROWNUM =1";
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
				NBDReasonCode = rs.getString(1);
				System.out.println("Reason code :"+NBDReasonCode);
			}
			}catch(SQLException e){
				e.getStackTrace();
			}finally{
				db.Close();
			}

	}

	@Given("^the CSF flag should be \"([^\"]*)\"$")
	public void the_CSF_flag_should_be(String isRouting) throws Throwable {
		
		DBConnection db = new DBConnection(base.environment);
		query = "SELECT CLAIM_CENTER_NO FROM THOT.PATIENT_INSURANCE WHERE PATIENT_ID = "+ patientId +" AND CLAIM_CENTER_SEQ = 1";
		try{
	    	
			ResultSet rs = db.ExecuteSelect(query);
			while(rs.next()){
				claimCenterNo = rs.getString(1);
			}
			
		    if("Disabled".equals(isRouting)){
		    	db.ExecuteUpdate("UPDATE THOT.SERVICE_BRANCHES SET CSF_FLAG = 'N', DISASTER_FLAG = 'N', DISPENSING_BRANCH_FLAG = 'N' WHERE ID IN (65, 831, 296, 297, 298, 555)");
				db.ExecuteUpdate("UPDATE THOT.CLAIM_CENTERS SET CCTYPE = 'INS-INDEMN', ROUTING_FLAG = 'N'  WHERE NO =" + claimCenterNo);
				db.ExecuteUpdate("UPDATE THOT.THERAPY_TYPES TT SET TT.RT_FLAG = 'N' WHERE THERAPY_TYPE = '"+therapyType+"'");
				db.ExecuteUpdate("UPDATE THOT.CSF_OPERATING_HOURS SET CUTOFF_FF_HRS = NULL, CUTOFF_FF_HRS = NULL WHERE SVCBR_ID = "+SB);
		    	
		    }else if("Enabled".equals(isRouting)){
		    	query = "select ns_ord_invno from RXH_CUSTOM.mi_prescription_xref where svcbr_id = "+SB+" and prescription_id = "+prescriptionId+" and refill_no = "+refillNo;
				db.ExecuteSelect(query);
				while(rs.next()){
					nsOrdInvno = rs.getString(1);
					if(nsOrdInvno != null){
						kindOfRx = "Integrated".toUpperCase();
					}else{
						kindOfRx = "Direct".toUpperCase();
					}
				}
				
				if(kindOfRx == "Integrated".toUpperCase()){
					query = "SELECT NS_ORD_DISP_NO FROM RXH_CUSTOM.MI_PHARMACY_XREF WHERE ACDO_RX_SVCBR = "+SB;
					db.ExecuteSelect(query);
					while(rs.next()){
						nsOrdDispNo = rs.getString(1);
					}
					if(SB == "296" || SB == "297"){
						db.ExecuteUpdate("UPDATE THOT.SERVICE_BRANCHES SET CSF_FLAG = 'Y', DISASTER_FLAG = 'N', DISPENSING_BRANCH_FLAG = 'Y' WHERE ID = 555");
						db.ExecuteUpdate("UPDATE THOT.CLAIM_CENTERS SET CCTYPE = 'INS-INDEMN', ROUTING_FLAG = 'Y'  WHERE NO =" + claimCenterNo);
						db.ExecuteUpdate("UPDATE THOT.THERAPY_TYPES TT SET TT.RT_FLAG = 'Y' WHERE THERAPY_TYPE = '"+therapyType+"'");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (555, TRUNC(SYSDATE), 9999)");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (555, TRUNC(SYSDATE+1), 9999)");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (555, TRUNC(SYSDATE+2), 9999)");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (555, TRUNC(SYSDATE+3), 9999)");
						db.ExecuteUpdate("UPDATE THOT.CSF_OPERATING_HOURS SET CUTOFF_FF_HRS = 23, CUTOFF_FF_HRS = 23 WHERE SVCBR_ID = "+SB);
						db.ExecuteDelete("DELETE FROM THOT.SERVICE_BRANCH_CLAIM_CENTER WHERE SVCBR_ID IN ("+SB+")AND  claim_center_NO ="+claimCenterNo);
						db.ExecuteInsert("INSERT INTO THOT.SERVICE_BRANCH_CLAIM_CENTER (svcbr_id,claim_center_no) VALUES (555,"+claimCenterNo+")");
						db.ExecuteUpdate("UPDATE RXH_CUSTOM.MI_N000_N004_RECORD SET NS_ORD_POSSIBLE_DISP_NO_1 = 13, NS_ORD_POSSIBLE_DISP_NO_2 = NULL, NS_ORD_POSSIBLE_DISP_NO_3 = NULL");
					}else if (SB == "555"){
						db.ExecuteUpdate("UPDATE THOT.SERVICE_BRANCHES SET CSF_FLAG = 'Y', DISASTER_FLAG = 'N', DISPENSING_BRANCH_FLAG = 'Y' WHERE ID = 296");
						db.ExecuteUpdate("UPDATE THOT.CLAIM_CENTERS SET CCTYPE = 'INS-INDEMN', ROUTING_FLAG = 'Y'  WHERE NO =" + claimCenterNo);
						db.ExecuteUpdate("UPDATE THOT.THERAPY_TYPES TT SET TT.RT_FLAG = 'Y' WHERE THERAPY_TYPE = '"+therapyType+"'");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (296, TRUNC(SYSDATE), 9999)");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (296, TRUNC(SYSDATE+1), 9999)");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (296, TRUNC(SYSDATE+2), 9999)");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (296, TRUNC(SYSDATE+3), 9999)");
						db.ExecuteUpdate("UPDATE THOT.CSF_OPERATING_HOURS SET CUTOFF_FF_HRS = 23, CUTOFF_FF_HRS = 23 WHERE SVCBR_ID = "+SB);
						db.ExecuteDelete("DELETE FROM THOT.SERVICE_BRANCH_CLAIM_CENTER WHERE SVCBR_ID IN ("+SB+")AND  claim_center_NO ="+claimCenterNo);
						db.ExecuteInsert("INSERT INTO THOT.SERVICE_BRANCH_CLAIM_CENTER (svcbr_id,claim_center_no) VALUES (296,"+claimCenterNo+")");
						db.ExecuteUpdate("UPDATE RXH_CUSTOM.MI_N000_N004_RECORD SET NS_ORD_POSSIBLE_DISP_NO_1 = 66, NS_ORD_POSSIBLE_DISP_NO_2 = NULL, NS_ORD_POSSIBLE_DISP_NO_3 = NULL");
					}else{
						db.ExecuteUpdate("UPDATE THOT.SERVICE_BRANCHES SET CSF_FLAG = 'Y', DISASTER_FLAG = 'N', DISPENSING_BRANCH_FLAG = 'Y' WHERE ID = 296");
						db.ExecuteUpdate("UPDATE THOT.CLAIM_CENTERS SET CCTYPE = 'INS-INDEMN', ROUTING_FLAG = 'Y'  WHERE NO =" + claimCenterNo);
						db.ExecuteUpdate("UPDATE THOT.THERAPY_TYPES TT SET TT.RT_FLAG = 'Y' WHERE THERAPY_TYPE = '"+therapyType+"'");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (296, TRUNC(SYSDATE), 9999)");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (296, TRUNC(SYSDATE+1), 9999)");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (296, TRUNC(SYSDATE+2), 9999)");
						db.ExecuteUpdate("INSERT INTO THOT.CSF_SITE_CAPACITY (SVCBR_ID, CALENDAR_DATE, SITE_CAPACITY) VALUES (296, TRUNC(SYSDATE+3), 9999)");
						db.ExecuteUpdate("UPDATE THOT.CSF_OPERATING_HOURS SET CUTOFF_FF_HRS = 23, CUTOFF_FF_HRS = 23 WHERE SVCBR_ID = "+SB);
						db.ExecuteDelete("DELETE FROM THOT.SERVICE_BRANCH_CLAIM_CENTER WHERE SVCBR_ID IN ("+SB+")AND  claim_center_NO ="+claimCenterNo);
						db.ExecuteInsert("INSERT INTO THOT.SERVICE_BRANCH_CLAIM_CENTER (svcbr_id,claim_center_no) VALUES (296,"+claimCenterNo+")");
						db.ExecuteUpdate("UPDATE RXH_CUSTOM.MI_N000_N004_RECORD SET NS_ORD_POSSIBLE_DISP_NO_1 = 66, NS_ORD_POSSIBLE_DISP_NO_2 = NULL, NS_ORD_POSSIBLE_DISP_NO_3 = NULL");
					}
					
					
				}else{
					
				}
		    }
		}catch(SQLException e){
			e.getStackTrace();
		}finally{
			db.Close();
		}

	}
	
	@When("^I need to consume the \"([^\"]*)\" service$")
	public void i_need_to_consume_the_service(String service) throws Throwable {
		service = service.replaceAll("\\s+", "");
		String[] credentials = WSCredentials.webServicesCredentials(service,base.environment);
        base.serviceApi = new ApiTools(credentials[0],credentials[1],credentials[2]);
	}


	@When("^will receive the order delivery dates$")
	public void will_receive_the_order_delivery_dates() throws Throwable {

		try{
			DBConnection db = new DBConnection(base.environment);
			plSQLJob = " {call WS_OWNER.WS_SHIPPING_RULES_STG_PKG.get_Ship_Dates_wrap(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			callableStatement = db.connection.prepareCall(plSQLJob);
			
			callableStatement.setString(1, eventProducer);
			callableStatement.setInt(2, Integer.parseInt(SB));
			callableStatement.setInt(3, Integer.parseInt(prescriptionId));
			callableStatement.setInt(4, Integer.parseInt(refillNo));
			callableStatement.registerOutParameter(5, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(6, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(7, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(8, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(9, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(10, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(11, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(12, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(13, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(14, java.sql.Types.INTEGER);
			callableStatement.registerOutParameter(15, java.sql.Types.VARCHAR);

			try{
				callableStatement.execute();			
			}catch (SQLException e){
				e.getMessage();
				e.getSQLState();
			}
			
			ResultSet rsCursor1 = ((OracleCallableStatement)callableStatement).getCursor(5);
			
			List<String> newNBDList = new ArrayList<String>();
			List<String> newShipDateList = new ArrayList<String>();
			List<String> newDateTypeList = new ArrayList<String>();
			while (rsCursor1.next()) {
				newNBDList.add(rsCursor1.getString("est_delivery_date"));
				newShipDateList.add(rsCursor1.getString("ship_date"));
				newDateTypeList.add(rsCursor1.getString("date_type"));
			}
			for(int i=0;i<newNBDList.size();i++){
				if(i==0){
					estDeliveryDate = newNBDList.get(i);
					estDeliveryDate = estDeliveryDate.replaceAll("-", "");
					System.out.println("NBD Calculated :"+estDeliveryDate);
					
				}
			}
			for(int i=0;i<newShipDateList.size();i++){
				if(i==0){
					newShipdate = newShipDateList.get(i);
					newShipdate = newShipdate.replaceAll("-", "");
					System.out.println("Ship date Calculated :"+newShipdate);
				}
			}
			for(int i=0;i<newDateTypeList.size();i++){
				if(i==0){
					System.out.println("Data Type :"+newDateTypeList.get(i));	
				}
			}
			String rsCalendarMsg = ((OracleCallableStatement)callableStatement).getString(6);
			System.out.println("CalendarMsg :"+rsCalendarMsg);
			String rsEarliestDate = ((OracleCallableStatement)callableStatement).getString(7);
			System.out.println("EarliestDate :"+rsEarliestDate);
			String rsFurthestDate = ((OracleCallableStatement)callableStatement).getString(8);
			System.out.println("FurthestDate :"+rsFurthestDate);
			String rsConditional = ((OracleCallableStatement)callableStatement).getString(9);
			System.out.println("Conditional :"+rsConditional);
			String rsNoStop = ((OracleCallableStatement)callableStatement).getString(10);
			System.out.println("NoStop :"+rsNoStop);
			String rsHardStop = ((OracleCallableStatement)callableStatement).getString(11);
			System.out.println("HardStop :"+rsHardStop);
			String rsOverrideCode = ((OracleCallableStatement)callableStatement).getString(12);
			System.out.println("OverrideCoder :"+rsOverrideCode);
			
			
			
			ResultSet rsCursor2 = ((OracleCallableStatement)callableStatement).getCursor(13);
			while (rsCursor2.next()) {
				System.out.println(rsCursor2.getString("v_code") + ":" + rsCursor2.getString("v_protocol_desc") + ":" + rsCursor2.getString("v_area")+ ":" + rsCursor2.getString("v_tat") + ":" + rsCursor2.getString("v_action")); 
			}
//			// Start Protocols
//			List<String> newNBDProtocolList = new ArrayList<String>();
//			List<String> newShipDateProtocolList = new ArrayList<String>();
//			List<String> newDateTypeProtocolList = new ArrayList<String>();
//			while (rsCursor1.next()) {
//				newNBDProtocolList.add(rsCursor1.getString("est_delivery_date"));
//				newShipDateProtocolList.add(rsCursor1.getString("ship_date"));
//				newDateTypeProtocolList.add(rsCursor1.getString("date_type"));
//			}
//			System.out.println();
//			for(int i=0;i<newNBDProtocolList.size();i++){
//				if(i==0){
//					estDeliveryDate = newNBDProtocolList.get(i);
//					estDeliveryDate = estDeliveryDate.replaceAll("-", "");
//					System.out.println("NBD Calculated :"+estDeliveryDate);
//					
//				}
//			}
//			for(int i=0;i<newShipDateList.size();i++){
//				if(i==0){
//					newShipdateProtocol = newShipDateProtocolList.get(i);
//					newShipdateProtocol = newShipdateProtocol.replaceAll("-", "");
//					System.out.println("Ship date Calculated :"+newShipdateProtocol);
//				}
//			}
//			for(int i=0;i<newDateTypeProtocolList.size();i++){
//				if(i==0){
//					System.out.println("Data Type :"+newDateTypeProtocolList.get(i));	
//				}
//			}
			
			// End Protocols
//			String rsRetcode = ((OracleCallableStatement)callableStatement).getString(11);
//			System.out.println("Retcode :"+rsRetcode);
//			String rsErrors = ((OracleCallableStatement)callableStatement).getString(12);
//			System.out.println("Errors :"+rsErrors);
			
		
		}catch(SQLException e){
			e.getMessage();
		}finally{
			if (callableStatement != null) {
				callableStatement.close();
			}
		}
		
	}
	@Then("^The status response should be \"([^\"]*)\"$")
	public void the_status_response_should_be(String statusDescription) throws Throwable {
		requestBody = XmlTools.readXmlFileComplete(ResourcePaths.SUBMIT_SPECIALTY_ORDER);
		if(base.environment.equals("TEST")){
			requestBody = XmlTools.updateXmlNodeValue(requestBody, "UserId", "QCRM01");
		}else if(base.environment.equals("UAT")){
			requestBody = XmlTools.updateXmlNodeValue(requestBody, "UserId", "UCRM01");
		}
		
		if(estDeliveryDate == null && newShipdate == null){
			estDeliveryDate = "20170425";
			newShipdate = "20170424";
		}
		System.out.println("NBD :"+estDeliveryDate  + "ShipDate :"+newShipdate);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "SvcbrId", SB);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "PrescriptionId", prescriptionId);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "RefillNo", refillNo);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "EstimatedDeliveryDate", estDeliveryDate);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "DeliveryDate", newShipdate);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "NbdReasonCode",NBDReasonCode);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "CancelOrder",cancelOrderValue);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "SaturdayOverrideReason",saturdayOverrideReason);
		if(shipper.equals("FEDEX")){
			if(shipper != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "Shipper", shipper);}
			if(shipperMethod != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ShipperMethod", shipperMethod);}
			if(signatureRequired != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "SignatureRequired", signatureRequired);}
			if(saturdayDelivery != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "SaturdayDelivery", saturdayDelivery);}
			if(shipperOverride != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ProtectShipper", shipperOverride);}
			if(shipperOverrReasonCode != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ShipperOverride", shipperOverrReasonCode);}
			if(shMethodOverrReasonCode != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ShipperMethodOverride", shMethodOverrReasonCode);}
			if(residentialDelivery != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ResidentialDelivery", residentialDelivery);}
		}

		base.response = base.serviceApi.create(ApiPaths.SUBMIT_ORDER, requestBody);
		base.responseBody = base.response.getBody().asString();
		statusDescription = statusDescription.replaceAll("\\s+", "");
		StatusCode status = StatusCode.valueOf(statusDescription);
		System.out.println("Status :"+status);
		System.out.println(base.responseBody);
		base.response.then().statusCode(status.getStatusCode());
	}
	
	
	@Given("^I get a \"([^\"]*)\" Prescription with shipping ID Created$")
	public void i_get_a_Prescription_with_shipping_ID_Created(String kindOfRx) throws Throwable {
		DBConnection db= new DBConnection(base.environment);
		if(kindOfRx.equals("Direct")){
			query = SqlQueries.RxDirect12b.toString();
		}else if(kindOfRx.equals("Integrated")){
			query = SqlQueries.RxIntegrated12b.toString();
		}else if(kindOfRx.equals("DirectRefill")){
			query = SqlQueries.RxDirect12bRefill.toString();	
		}else if(kindOfRx.equals("IntegratedRefill")){
			query = SqlQueries.RxIntegrated12bRefill.toString();
		}
		
		try{
			ResultSet rs = db.ExecuteSelect(query);
			while(rs.next()){
				 
				patientId = rs.getString(1);
				SB = rs.getString(2);
				therapyType = rs.getString(3);
				prescriptionId = rs.getString(4);
				refillNo = rs.getString(5);
				shipDate = rs.getString(6);
				NBD = rs.getString(7);
				shippingId = rs.getString(8);
				
				System.out.println("Patient :"+patientId);
				System.out.println("Rx :"+SB+"-"+prescriptionId+"-"+refillNo);
				
			}
		}catch(SQLException e){
			e.getStackTrace();
		}
	    
	    query = "SELECT * FROM (SELECT CODE FROM THOT.FT_LOOKUPS WHERE TYPE ='NBD_REASON_CODES' AND CODE IN ("
				+"'CONFIRMED WITH PATIENT AND PHYSICIAN',"
				+"'PATIENT CONFIRMED',"
				+"'DOCTOR CONFIRMED',"
				+"'DOCTOR CONFIRMED-PATIENT CONFIRMATION NOT REQUIRED',"
				+"'PATIENT CONFIRMED-DOCTOR CONFIRMATION NOT REQUIRED CONFIRMED THROUGH FQE',"
				+"'CONFIRMED BY WEB/IVR',"
				+"'NOT CONFIRMED')ORDER BY SYS.DBMS_RANDOM.RANDOM) WHERE ROWNUM =1";
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
				NBDReasonCode = rs.getString(1);
				System.out.println("Reason code :"+NBDReasonCode);
			}
			}catch(SQLException e){
				e.getStackTrace();
			}finally{
				db.Close();
			}
	    
	}
	
	
	@Given("^I need to change the shipping information$")
	public void i_need_to_change_the_shipping_information() throws Throwable {
		DBConnection db= new DBConnection(base.environment);
		query =SqlQueries.Shipping.toString() + shippingId;
		try{
			ResultSet rs = db.ExecuteSelect(query);
			while(rs.next()){
				shipper = rs.getString(2);
				shipperMethod = rs.getString(3);
				signatureRequired = rs.getString(4);
				saturdayDelivery = rs.getString(5);
				shipperOverride = rs.getString(6);
				shipperOverrReasonCode = rs.getString(7);
				shMethodOverrReasonCode = rs.getString(8);
				residentialDelivery = rs.getString(9);
				
			}
		}catch(SQLException e){
			e.getMessage();
		}finally{
			db.Close();
		}
		
		if(shipper != "FEDEX"){
			shipper = "FEDEX";	
		}
		if(shipperMethod != "05"){
			shipperMethod = "05";
		}
		if(signatureRequired != "N"){
			signatureRequired = "N";
		}
		if(saturdayDelivery != "N"){
			saturdayDelivery = "N";
		}
		if(shipperOverride != "Y"){
			shipperOverride = "Y";
		}
		if(residentialDelivery != "Y"){
			residentialDelivery = "Y";
		}
	}
	
	
	@Then("^after the Shipping ID must be deleted$")
	public void after_the_Shipping_ID_must_be_deleted() throws Throwable {
		if(shipper.equals("FEDEX")){
			residentialDelivery = "Y";
			shipperOverride = "N";
			if(shipper != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "Shipper", shipper);}
			if(shipperMethod != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ShipperMethod", shipperMethod);}
			if(signatureRequired != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "SignatureRequired", signatureRequired);}
			if(saturdayDelivery != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "SaturdayDelivery", saturdayDelivery);}
			if(shipperOverride != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ProtectShipper", shipperOverride);}
			if(shipperOverrReasonCode != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ShipperOverride", shipperOverrReasonCode);}
			if(shMethodOverrReasonCode != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ShipperMethodOverride", shMethodOverrReasonCode);}
			if(residentialDelivery != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ResidentialDelivery", residentialDelivery);}
		} 
	}

	@Then("^The web service should be executed again and response should be \"([^\"]*)\"$")
	public void the_web_service_should_be_executed_again_and_response_should_be(String statusDescription) throws Throwable {
		base.response = base.serviceApi.create(ApiPaths.SUBMIT_ORDER, requestBody);
		base.responseBody = base.response.getBody().asString();
		System.out.println(base.responseBody);
		statusDescription = statusDescription.replaceAll("\\s+", "");
		StatusCode status = StatusCode.valueOf(statusDescription);
		System.out.println("Status :"+status);
		base.response.then().statusCode(status.getStatusCode());
	    
	}
	
	@Given("^I get a \"([^\"]*)\" Prescription with Profile Lock and \"([^\"]*)\" therapy$")
	public void i_get_a_Prescription_with_Profile_Lock_and_therapy(String kindOfRx, String therapy) throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		if(kindOfRx.toUpperCase().equals("DIRECT")){
			query = SqlQueries.RxPLDirectHUMA.toString();
		}else if(kindOfRx.toUpperCase().equals("INTEGRATED")){
			query = SqlQueries.RxPLIntegratedHUMA.toString();
		}else if(kindOfRx.toUpperCase().equals("COPAY")){
			query = SqlQueries.RxPLCopayHUMA.toString();
		}else if(kindOfRx.toUpperCase().replaceAll("\\s+", "").equals("COPAYINTEGRATED")){
			query = SqlQueries.RxPLIntegratedCopayHUMA.toString();
		}
		try{
			ResultSet rs = db.ExecuteSelect(query);
			while(rs.next()){
				 
				patientId = rs.getString(1);
				SB = rs.getString(2);
				therapyType = rs.getString(3);
				prescriptionId = rs.getString(4);
				refillNo = rs.getString(5);
				shipDate = rs.getString(6);
				NBD = rs.getString(7);
				shippingId = rs.getString(8);
				
				System.out.println("Patient :"+patientId);
				System.out.println("Rx :"+SB+"-"+prescriptionId+"-"+refillNo);
				
			}
		}catch(SQLException e){
			e.getStackTrace();
		}
	    
	    query = "SELECT * FROM (SELECT CODE FROM THOT.FT_LOOKUPS WHERE TYPE ='NBD_REASON_CODES' AND CODE IN ("
				+"'CONFIRMED WITH PATIENT AND PHYSICIAN',"
				+"'PATIENT CONFIRMED',"
				+"'DOCTOR CONFIRMED',"
				+"'DOCTOR CONFIRMED-PATIENT CONFIRMATION NOT REQUIRED',"
				+"'PATIENT CONFIRMED-DOCTOR CONFIRMATION NOT REQUIRED CONFIRMED THROUGH FQE',"
				+"'CONFIRMED BY WEB/IVR',"
				+"'NOT CONFIRMED')ORDER BY SYS.DBMS_RANDOM.RANDOM) WHERE ROWNUM =1";
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
				NBDReasonCode = rs.getString(1);
				System.out.println("Reason code :"+NBDReasonCode);
			}
			}catch(SQLException e){
				e.getStackTrace();
			}finally{
				db.Close();
			}

	}

	
	@When("^set Cancel order tag with \"([^\"]*)\" value$")
	public void set_Cancel_order_tag_with_value(String cancelOrder) throws Throwable {
		cancelOrderValue = cancelOrder;    
	}
	
	@Then("^a OS Task \"([^\"]*)\" with Task status should be \"([^\"]*)\" with reason code \"([^\"]*)\"$")
	public void a_OS_Task_with_Task_status_should_be_with_reason_code(String isCreated, String taskStatus, String reasonCode) throws Throwable {

		DBConnection db = new DBConnection(base.environment);
			query = "select 'SUCCESS' from thot.wq_task_details_v where patient_id = "+SubmitSpecialtyOrder_StepDefinitions.getpatientId()+
					" and  task_status = '"+taskStatus.toUpperCase()+"' and reason_code = '"+reasonCode+"' and wq_workqueue = 'ORDER SCHEDULING' order by update_date desc";
		try{
			ResultSet rs = db.ExecuteSelect(query);
			String taskStatusResult="";
			while(rs.next()){
				taskStatusResult = rs.getString(1);
			}
			if(isCreated.toUpperCase().equals("CREATED")){
				Assert.assertEquals("SUCCESS", taskStatusResult);
			}else if(isCreated.toUpperCase().equals("NOTCREATED")){
				Assert.assertEquals("", taskStatusResult);
			}
		}catch(SQLException e){
			e.getMessage();
		}finally{
			db.Close();
		}
	}
	
	@When("^I need to set SaturdayOverrideReason$")
	public void i_need_to_set_SaturdayOverrideReason() throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		 query = "SELECT * FROM (SELECT  FTL.ATTRIBUTE1 OVERRIDE_REASON "
		    		+"FROM THOT.FT_LOOKUPS FTL "
		    		+"WHERE FTL.TYPE = 'SHC_OVERRIDE_REASONS' ORDER BY SYS.DBMS_RANDOM.RANDOM)WHERE ROWNUM =1";
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
					saturdayOverrideReason = rs.getString(1);
					System.out.println("Sat Override Reason :"+saturdayOverrideReason);
				}
			}catch(SQLException e){
				e.getStackTrace();
			}finally{
				db.Close();
			}
	    
	}

	@Then("^the prescription should be inserted on the delivery_ship_dates table \"([^\"]*)\"$")
	public void the_prescription_should_be_inserted_on_the_delivery_ship_dates_table(String kindOfRx) throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		if(kindOfRx.equals("Direct")){
			query = "select 1 from THOT.DELIVERY_SHIP_DATES  where svcbr_id = "+ SB +" and prescription_id = "+prescriptionId +" and refill_no = "+refillNo;
		}else if (kindOfRx.equals("Integrated")){
			query = "select 1 from THOT.SHC_INTEGRATED_DELY_SHIP_DATES  where svcbr_id = "+ SB +" and prescription_id = "+prescriptionId +" and refill_no = "+refillNo;
		}
		try{
			ResultSet rs = db.ExecuteSelect(query);
			String deliveryShipdates = "";
			while(rs.next()){
				deliveryShipdates = rs.getString(1);
			}
			if(deliveryShipdates.contains("1")){
				Assert.assertEquals("1", deliveryShipdates);
			}
		}catch(SQLException e){
			e.getMessage();
		}finally{
			db.Close();
		}
	    
	}
	
	@Given("^I have the following Prescription \"([^\"]*)\"$")
	public void i_have_the_following_Prescription(String prescription) throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		String[] prescriptionArray = prescription.split("-");
		query = "select patient_id,svcbr_id,therapy_type,prescription_id,refill_no,prescr_ship_date,est_delivery_date, shipping_id from thot.prescriptions_table "+
				"WHERE svcbr_id = "+prescriptionArray[0]+" AND prescription_id = "+prescriptionArray[1]+" AND refill_no = "+prescriptionArray[2];
		try{
			ResultSet rs = db.ExecuteSelect(query);
			while(rs.next()){
				 
				patientId = rs.getString(1);
				SB = rs.getString(2);
				therapyType = rs.getString(3);
				prescriptionId = rs.getString(4);
				refillNo = rs.getString(5);
				shipDate = rs.getString(6);
				NBD = rs.getString(7);
				shippingId = rs.getString(8);
				
				System.out.println("Patient :"+patientId);
				System.out.println("Rx :"+SB+"-"+prescriptionId+"-"+refillNo);
				
			}
		}catch(SQLException e){
			e.getStackTrace();
		}
	    
	}
	
	@Given("^the prescription should set the protocol \"([^\"]*)\"$")
	public void the_prescription_should_set_the_protocol(String protocol) throws Throwable {

		DBConnection db = new DBConnection(base.environment);
		if(protocol.equals("DAYS SUPPLY LIMIT")){
			
		}else if(protocol.equals("MAX REFILLS")){
			
		}else if(protocol.equals("REFILL TOO SOON")){
			
		}else if(protocol.equals("IN-STATE DISPENSING")){
			
		}else if(protocol.equals("DVR SIGNATURE REQUIRED")){
			
		}else if(protocol.equals("SMA_PAYOR_THERAPY_VALIDATIONS")){
			
		}else if(protocol.equals("PHYSICIAN ENROLLMENT VERIFICATION REQUIRED")){
			
		}else if(protocol.equals("NDC EXCLUSION")){
			query ="select pd.protocol_id from thot.pe_protocol_definition pd where pd.protocol_name ='"+protocol+"'";
			try{
				ResultSet rs =  db.ExecuteSelect(query);
				while(rs.next()){
					protocolId = rs.getString(1);
				}
			}catch(SQLException e){
				e.getMessage();
			}
			
			query = "SELECT ph.ruleset_header_id FROM THOT.PE_RULESET_HEADER PH WHERE  ph.protocol_id ="+ protocolId;
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
					ruleSetHeaderId = rs.getString(1);
				}				
			}catch(SQLException e){
				e.getMessage();
			}
			
			query = "select ruleset_detail_id from thot.pe_ruleset_details where stop_date is null and ruleset_header_id ="+ruleSetHeaderId;
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
					ruleSetDetailId = rs.getString(1);
				}
			}catch(SQLException e){
				e.getMessage();
			}
			
			query = "SELECT CLAIM_CENTER_NO FROM THOT.PATIENT_INSURANCE WHERE PATIENT_ID = "+ patientId +" AND CLAIM_CENTER_SEQ = 1";
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
					claimCenterNo = rs.getString(1);
				}
			}catch(SQLException e){
				e.getMessage();
			}
			
			query ="select rdp.parameter_id, rdp.parameter_value, rdp.parameter_include from thot.pe_ruleset_details_params rdp where rdp.ruleset_header_id = "+ruleSetHeaderId+" and rdp.ruleset_detail_id = "+ruleSetDetailId+" and rdp.parameter_value in('"+claimCenterNo+"')";
			try{
				ResultSet rs = db.ExecuteSelect(query);
				if(!rs.next()){
					db.ExecuteInsert("insert into thot.pe_ruleset_details_params values("+ruleSetHeaderId+", "+ruleSetDetailId+", 1,'"+claimCenterNo+"','Y',user,sysdate,user,sysdate)");
				}
			}catch(SQLException e){
				e.getMessage();
			}
			
			query ="select rdp.parameter_id, rdp.parameter_value, rdp.parameter_include from thot.pe_ruleset_details_params rdp where rdp.ruleset_header_id = "+ruleSetHeaderId+" and rdp.ruleset_detail_id = "+ruleSetDetailId+" and rdp.parameter_value in('"+therapyType+"')";
			try{
				ResultSet rs = db.ExecuteSelect(query);
				if(!rs.next()){
					db.ExecuteInsert("insert into thot.pe_ruleset_details_params values("+ruleSetHeaderId+", "+ruleSetDetailId+", 2,'"+therapyType+"','Y',user,sysdate,user,sysdate)");
				}
			}catch(SQLException e){
				e.getMessage();
			}
		}else if(protocol.equals("MEDICAL FACILITY ADDRESS REQUIRED")){
			
		}
	    
	}
	
	
	@Then("^the Payment for patient was rejected$")
	public void the_Payment_for_patient_was_rejected() throws Throwable {
	    DBConnection db = new DBConnection(base.environment);
	    String rejectReason = XmlTools.getXmlNodeValue(base.responseBody, "PaymentDeclinationReason");
	    query ="select pr.reject_reason from thot.pt_pay_rejection pr where pr.created_by = 'QCRM01' and trunc(pr.reject_date) = trunc(sysdate-1) and pr.patient_id="+patientId;
	    try{ 
	    	ResultSet rs = db.ExecuteSelect(query);
	    	while(rs.next()){
	    		Assert.assertEquals(rejectReason.toUpperCase(), rs.getString(1).toUpperCase());
	    	}
	    }catch(SQLException e){e.getMessage();}

	}
	
	
	@When("^the Request should be executed for submit order$")
	public void the_Request_should_be_executed_for_submit_order() throws Throwable {
		requestBody = XmlTools.readXmlFileComplete(ResourcePaths.SUBMIT_SPECIALTY_ORDER);
		if(base.environment.equals("TEST")){
			requestBody = XmlTools.updateXmlNodeValue(requestBody, "UserId", "QCRM01");
		}else if(base.environment.equals("UAT")){
			requestBody = XmlTools.updateXmlNodeValue(requestBody, "UserId", "UCRM01");
		}
		
		if(estDeliveryDate == null && newShipdate == null){
			estDeliveryDate = "20170425";
			newShipdate = "20170424";
		}
		
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "SvcbrId", SB);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "PrescriptionId", prescriptionId);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "RefillNo", refillNo);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "EstimatedDeliveryDate", estDeliveryDate);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "DeliveryDate", newShipdate);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "NbdReasonCode",NBDReasonCode);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "CancelOrder",cancelOrderValue);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "SaturdayOverrideReason",saturdayOverrideReason);
		if(shipper.equals("FEDEX")){
			if(shipper != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "Shipper", shipper);}
			if(shipperMethod != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ShipperMethod", shipperMethod);}
			if(signatureRequired != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "SignatureRequired", signatureRequired);}
			if(saturdayDelivery != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "SaturdayDelivery", saturdayDelivery);}
			if(shipperOverride != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ProtectShipper", shipperOverride);}
			if(shipperOverrReasonCode != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ShipperOverride", shipperOverrReasonCode);}
			if(shMethodOverrReasonCode != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ShipperMethodOverride", shMethodOverrReasonCode);}
			if(residentialDelivery != null){requestBody = XmlTools.updateXmlNodeValue(requestBody, "ResidentialDelivery", residentialDelivery);}
		}
		
		System.out.println(requestBody);
		base.response = base.serviceApi.create(ApiPaths.SUBMIT_ORDER, requestBody);
    
	}
	


}
