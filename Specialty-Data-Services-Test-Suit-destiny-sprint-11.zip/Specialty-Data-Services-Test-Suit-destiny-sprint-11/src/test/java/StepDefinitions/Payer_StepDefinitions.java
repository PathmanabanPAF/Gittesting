package StepDefinitions;

import org.json.JSONArray;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.MiscTools;
import GlobalEnums.SqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Payer_StepDefinitions extends BaseUtil{
	private BaseUtil base;
	public String payerId;
	public String payerName;
	
	public Payer_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I get a valid Payer Id$")
	public void i_get_a_valid_Payer_Id() throws Throwable {
		payerId = MiscTools.executeSingleSelect(base.environment, SqlQueries.ClaimCenterId.toString());
	}

	@Given("^I get a valid Payer Name$")
	public void i_get_a_valid_Payer_Name() throws Throwable {
	   payerName = MiscTools.executeSingleSelect(base.environment, SqlQueries.ClaimCenterName.toString());
	   //"MEDCO HOME DELIVERY";
		//"MASS MUTUAL";
	}
	
	@Given("^I get an invalid Payer Name$")
	public void i_get_an_invalid_Payor_Name() throws Throwable {
		payerName = MiscTools.getRandomString(7).toUpperCase();
	}
	@Given("^I get an invalid Payer Id$")
	public void i_get_an_invalid_Payer_Id() throws Throwable {
		payerId = MiscTools.executeSingleSelect(base.environment, SqlQueries.MaxClaimCenter.toString());
		payerId = Integer.toString(Integer.parseInt(payerId) + 1 + (int)(Math.random() * 10));
	}

	@Given("^I get an empty Payer Id$")
	public void i_get_an_empty_Payer_Id() throws Throwable {
		payerId = "";
	}
	@Given("^I get an empty Payer Name$")
	public void i_get_an_empty_Payer_Name() throws Throwable {
		payerName = "";
	}

	@When("^I send a request to retrieve Payer information$")
	public void i_send_a_request_to_retrieve_Payer_information() throws Throwable {
//		base.response = base.serviceApi.retrive(ApiPaths.PAYERBYID+payerId);
//    	base.responseBody = base.response.getBody().asString();
//    	MiscTools.printIdented("Payor Id used: "+payerId);
		base.oaResponse = base.oauthServiceApi.retrive(ApiPaths.PAYERBYID+payerId);
		base.responseBody = base.oaResponse.getBody();
		MiscTools.printIdented("Payor Id used: "+payerId);
	}
	@When("^I send a request to retrieve oauth Payor information$")
	public void i_send_a_request_to_retrieve_oauth_Payor_information() throws Throwable {
		base.oaResponse = base.oauthServiceApi.retrive(ApiPaths.PAYERBYID+payerId);
		MiscTools.printIdented("Payor Id used: "+payerId);
	}

	@When("^I send a request to Payer information$")
	public void i_send_a_request_to_Payer_information() throws Throwable {
		base.oaResponse = base.oauthServiceApi.retrive(ApiPaths.PAYERBYID+payerId);
		base.responseBody = base.oaResponse.getBody();
		MiscTools.printIdented("Payor Id used: "+payerId);
	}

	@When("^I send a request to retrieve all matching Payers information$")
	public void i_send_a_request_to_retrieve_all_matching_Payers_information() throws Throwable {
		base.response = base.serviceApi.retrive(ApiPaths.PAYERBYNAME+payerName);
		base.responseBody = base.response.getBody().asString();
    	MiscTools.printIdented("Payor Name used: "+payerName);
	}

	@Then("^I should get the Payer information$")
	public void i_should_get_the_Payer_information() throws Throwable {
		JSONObject jsonPayorInfo = GetResponses.createPayorResposeById(payerId, base.environment);
		JSONObject jsonResponseBody = new JSONObject(base.responseBody);
		JSONAssert.assertEquals(jsonPayorInfo,jsonResponseBody,JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^I should get all matching Payers information$")
	public void i_should_get_all_matching_Payers_information() throws Throwable {
		JSONArray arrayJsonPayorInfo = GetResponses.createPayorResposeByName(payerName, base.environment);
		JSONArray jsonArrayResponseBody = new JSONArray(base.responseBody);
		JSONAssert.assertEquals(arrayJsonPayorInfo,jsonArrayResponseBody,JSONCompareMode.NON_EXTENSIBLE);
	}
}
