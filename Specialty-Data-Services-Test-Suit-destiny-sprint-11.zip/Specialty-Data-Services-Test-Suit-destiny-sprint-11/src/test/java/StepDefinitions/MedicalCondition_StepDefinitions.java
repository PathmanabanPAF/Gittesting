package StepDefinitions;

import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.MiscTools;
import GlobalEnums.SqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MedicalCondition_StepDefinitions extends BaseUtil{
	private BaseUtil base;
	public JSONObject jsonMedConInfo;
	public JSONObject jsonResponseBody;
	
	public MedicalCondition_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I get a valid Direct Patient w/Diagnoses Id$")
	public void i_get_a_valid_Direct_Patient_w_Diagnoses_Id() throws Throwable {
		base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetDirectPatientWithDiagnoses.toString());
	}

	@Given("^I get a valid Integrated Patient w/Diagnoses Id$")
	public void i_get_a_valid_Integrated_Patient_w_Diagnoses_Id() throws Throwable {
		base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetIntegratedPatientWithDiagnoses.toString());
	}

	@Given("^I get a valid Direct Patient w/o Diagnoses Id$")
	public void i_get_a_valid_Direct_Patient_w_o_Diagnoses_Id() throws Throwable {
		base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetDirectPatientWithoutDiagnoses.toString());
	}

	@Given("^I get a valid Integrated Patient w/o Diagnoses Id$")
	public void i_get_a_valid_Integrated_Patient_w_o_Diagnoses_Id() throws Throwable {
		base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetIntegratedPatientWithoutDiagnoses.toString());
	}

	@When("^I send a request to retrieve Patient's Medical Condition$")
	public void i_send_a_request_to_retrieve_Pnt_s_Med_Cond() throws Throwable {
		base.response = base.serviceApi.retrive(ApiPaths.MEDICAL_CONDITION+base.patientId);
    	base.responseBody = base.response.getBody().asString();
    	MiscTools.printIdented("Patient Id used: "+base.patientId);
	}

	@Then("^I should get the correct Patient's Medical Condition Information$")
	public void i_should_get_the_correct_Pnt_s_Med_Cond_Info() throws Throwable {
		jsonMedConInfo = GetResponses.createMedicalConditionResponse(base.patientId, base.environment);
		jsonResponseBody = new JSONObject(base.responseBody);
		JSONAssert.assertEquals(jsonMedConInfo,jsonResponseBody,JSONCompareMode.NON_EXTENSIBLE);
	}
}
