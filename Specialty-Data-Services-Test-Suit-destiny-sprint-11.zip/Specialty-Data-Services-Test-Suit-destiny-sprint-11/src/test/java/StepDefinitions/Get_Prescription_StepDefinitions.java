package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;

import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONArray;
import org.junit.Assert;

public class Get_Prescription_StepDefinitions extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject prescriptionInfo, responsePrescriptionInfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public Get_Prescription_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I get a valid Prescription Id$")
	public void i_get_a_valid_Prescription_Id() throws Throwable {
		base.prescription = MiscTools.executeSingleRowSelect(base.environment, String.format(prescriptionSqlQueries.GetValidRx.toString(),""));
		base.sb = base.prescription.get("sb");base.rxId =base.prescription.get("rxId");
		base.params = new JSONArray();base.params.put("rxNumber="+base.rxId);base.params.put("processingpharmacy="+base.sb);
	}

	@Given("^I get a valid Direct Prescription Id$")
	public void i_get_a_valid_Direct_Prescription_Id() throws Throwable {
		base.prescription = MiscTools.executeSingleRowSelect(base.environment, String.format(SqlQueries.DirectRx.toString(),""));
		base.sb = base.prescription.get("sb");base.rxId =base.prescription.get("rxId");
		base.params = new JSONArray();base.params.put("rxNumber="+base.rxId);base.params.put("processingpharmacy="+base.sb);
	}
	
	@Given("^I get a valid Prescription Id and Refill$")
	public void i_get_a_valid_Prescription_Id_and_Refill() throws Throwable {
		query = String.format(prescriptionSqlQueries.RxWithRefill.toString(), "", days);
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		base.sb = base.prescription.get("sb"); base.rxId =base.prescription.get("rxId");base.refill =base.prescription.get("refill");
		base.params.put("rxNumber="+base.rxId);base.params.put("processingpharmacy="+base.sb);base.params.put("fillNumber="+base.refill);
	}

	@Given("^I get a valid Direct Prescription Id and Refill$")
	public void i_get_a_valid_Direct_Prescription_Id_and_Refill() throws Throwable {
		query = String.format(prescriptionSqlQueries.RxWithRefill.toString(), "", days);
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		base.sb = base.prescription.get("sb"); base.rxId =base.prescription.get("rxId");base.refill =base.prescription.get("refill");
		base.params.put("rxNumber="+base.rxId);base.params.put("processingpharmacy="+base.sb);base.params.put("fillNumber="+base.refill);
	}
	
	@Given("^I get a valid Integrated Prescription Id$")
	public void i_get_a_valid_Integrated_Prescription_Id() throws Throwable {
		base.prescription = MiscTools.executeSingleRowSelect(base.environment, String.format(SqlQueries.IntegratedRx.toString(),""));
		base.sb = base.prescription.get("sb");base.rxId = base.prescription.get("rxId");
		base.params.put("rxNumber="+base.rxId);base.params.put("processingpharmacy="+base.sb);
	}
	
	@Given("^I get a valid Integrated Prescription Id and Refill$")
	public void i_get_a_valid_Integrated_Prescription_Id_and_Refill() throws Throwable {
		base.prescription = MiscTools.executeSingleRowSelect(base.environment, String.format(SqlQueries.IntegratedRx.toString(),DefaultValues.selectRefill.toString()));
		base.sb = base.prescription.get("sb");base.rxId = base.prescription.get("rxId");base.refill =base.prescription.get("refill");
		base.params.put("rxNumber="+base.rxId);base.params.put("processingpharmacy="+base.sb);base.params.put("fillNumber="+base.refill);
	}
	
	@Given("^I get a valid (?:Prescription |)\"([^\"]*)\"(?: Prescription|)$")
	public void i_get_a_valid_Prescription(String condition) throws Throwable {
		if(condition.equals("Renewals")) {days = "30";}else if(condition.equals("Pac Error")) {days = "365";};
		query = String.format(prescriptionSqlQueries.RxWithRefill.toString(), DefaultValues.valueOf(condition.replaceAll("\\s+", "")),days);
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);	
		System.out.println(query);
		System.out.println(base.prescription);
		base.sb = base.prescription.get("sb"); base.rxId =base.prescription.get("rxId");base.refill =base.prescription.get("refill");
		base.params = new JSONArray();base.params.put("rxNumber="+base.rxId);base.params.put("processingpharmacy="+base.sb);base.params.put("fillNumber="+base.refill);
	}

	@Given("^I get a valid Direct (?:Prescription |)\"([^\"]*)\"(?: Prescription|)$")
	public void i_get_a_valid_Direct_Prescription(String condition) throws Throwable {
		if(condition.equals("Renewals")) {days = "30";}else if(condition.equals("Pac Error")) {days = "365";};
		query = String.format(prescriptionSqlQueries.DirectRxWithRefill.toString(), DefaultValues.valueOf(condition.replaceAll("\\s+", "")),days);
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		System.out.println(query);
		base.sb = base.prescription.get("sb"); base.rxId =base.prescription.get("rxId");base.refill = base.prescription.get("refill");
		base.params = new JSONArray();base.params.put("rxNumber="+base.rxId);base.params.put("processingpharmacy="+base.sb);base.params.put("fillNumber="+base.refill);
	}

	@Given("^I get a valid Integrated \"([^\"]*)\" Prescription$")
	public void i_get_a_valid_Integrated_Prescription(String condition) throws Throwable {
		if(condition.equals("Renewals")) days = "100";
		query = String.format(prescriptionSqlQueries.IntegratedRxWithRefill.toString(), DefaultValues.valueOf(condition.replaceAll("\\s+", "")),days);
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		//base.prescription.put("sb", "555");base.prescription.put("rxId","6478486");base.prescription.put("refill","0");
		base.sb = base.prescription.get("sb"); base.rxId =base.prescription.get("rxId");base.refill =base.prescription.get("refill");
		base.params.put("rxNumber="+base.rxId);base.params.put("processingpharmacy="+base.sb);base.params.put("fillNumber="+base.refill);
	}
	
	@Given("^I get a valid Direct Prescription \"([^\"]*)\" substituted$")
	public void i_get_a_valid_Direct_Prescription_substituted(String condition) throws Throwable {
		query = String.format(prescriptionSqlQueries.GetRxDrugSubstituted.toString(), DefaultValues.valueOf(condition.replaceAll("\\s+", "")));
		base.prescription = MiscTools.executeSingleRowSelect(base.environment, query);
		base.sb = base.prescription.get("sb"); base.rxId =base.prescription.get("rxId");base.refill =base.prescription.get("refill");
		base.params.put("rxNumber="+base.rxId);base.params.put("processingpharmacy="+base.sb);base.params.put("fillNumber="+base.refill);
	}

	@Given("^I get an invalid Prescription Id$")
	public void i_get_an_invalid_Prescription_Id() throws Throwable {
		String query = "select id from service_branches where rownum = 1 order by id desc";
		base.sb = MiscTools.executeSingleSelect(base.environment, query);
		base.sb = Integer.toString(Integer.parseInt(base.sb) + 1 + (int)(Math.random() * 10));
		base.rxId = Integer.toString(1000 + (int)(Math.random() * 10000));
		base.params.put("rxNumber="+base.rxId);base.params.put("processingpharmacy="+base.sb);
	}

	@Given("^I get an empty Prescription Id$")
	public void i_get_an_empty_Prescription_Id() throws Throwable {
		base.sb = "";base.rxId = "";
	}

	@Given("^I do not have Prescription Parameters$")
	public void i_do_not_have_Prescription_Parameters() throws Throwable {
		base.sb = "";base.rxId = "";
		
	}
	
	@Given("^I use an invalid Fill Number$")
	public void i_use_an_invalid_Fill_Number() throws Throwable {
		base.refill = Integer.toString(MiscTools.getMaxRefill(base.sb, base.rxId, base.environment) + 1);
		base.params.put("fillNumber="+base.refill);
	}

	@Given("^I set Fill Number parameter as empty$")
	public void i_set_Fill_Number_parameter_as_empty() throws Throwable {
		base.refill = "";
		base.params.put("fillNumber="+base.refill);
	}

	@Given("^I use a specific Date Range$")
	public void i_use_a_specific_Date_Range() throws Throwable {
		int days = MiscTools.getRandomInt(1,365);
		startDate = MiscTools.getDateMonthName(days*-1);
		stopDate = MiscTools.getDateMonthName(MiscTools.getRandomInt(1,days-1)*-1);
		base.params.put("shipDateFrom="+MiscTools.changeDateFormat(startDate));
		base.params.put("shipDateTo="+MiscTools.changeDateFormat(stopDate));
		rangeFilter = "Y";
	}
	
	@Given("^I utilize a specific Date Range$")
	public void i_utilize_a_specific_Date_Range() throws Throwable {
		int days = MiscTools.getRandomInt(1,90);
		startDate = MiscTools.getDateMonthName(days*-1);
		stopDate = MiscTools.getDateMonthName(MiscTools.getRandomInt(1,days-1)*-1);
		base.params.put("shipDateFrom="+MiscTools.changeDateFormat(startDate));
		base.params.put("shipDateTo="+MiscTools.changeDateFormat(stopDate));
		rangeFilter = "Y";
	}

	@Given("^I use a specific Therapy$")
	public void i_use_a_specific_Therapy() throws Throwable {
		base.therapyType = MiscTools.executeSingleSelectTherapy(base.environment, String.format(SqlQueries.GetAvailableRxTT.toString(),startDate, stopDate,  startDate, stopDate));
		base.params.put("therapyID="+base.therapyType);therapyParam = "Y";
		if( rangeFilter == "Y" && base.therapyType.isEmpty()){
			base.params = new JSONArray();
			i_use_a_specific_Date_Range();
			i_use_a_specific_Therapy();	
		}	
	}

	@Given("^I utilize a specific Therapy$")
	public void i_utilize_a_specific_Therapy() throws Throwable {
		base.therapyType = MiscTools.executeSingleSelectTherapy(base.environment, String.format(prescriptionSqlQueries.GetIntegratedRxAvailableTT.toString(),startDate, stopDate));
		base.params.put("therapyID="+base.therapyType);therapyParam = "Y";
	}
	
	@Given("^I employ a specific Therapy$")
	public void i_employ_a_specific_Therapy() throws Throwable {
		base.therapyType = MiscTools.executeSingleSelectTherapy(base.environment, String.format(prescriptionSqlQueries.GetAnyAvailableRxTT.toString(),startDate, stopDate,  startDate, stopDate));
		base.params.put("therapyID="+base.therapyType);therapyParam = "Y";  
	}

	@Given("^I do not use a specific Date Range$")
	public void i_do_not_use_a_specific_Date_Range() throws Throwable {
		startDate = MiscTools.getPastMonthDateMonthName();
		stopDate = MiscTools.getTodayDateMonthName();
		rangeFilter = "";
	}

	@Given("^I do not use a specific Therapy$")
	public void i_do_not_use_a_specific_Therapy() throws Throwable {
		base.therapyType = "";
	}
	
	@Given("^I do not use Fill Number parameter$")
	public void i_do_not_use_Fill_Number_parameter() throws Throwable {
	  refill = "";
	}
	@Given("^I use an invalid specific Therapy$")
	public void i_use_an_invalid_specific_Therapy() throws Throwable {
		base.therapyType = MiscTools.getRandomString(4).toUpperCase();
		therapyParam = "Y";base.params.put("therapyID="+base.therapyType);
	}

	@Given("^I set Date Range parameters as empty$")
	public void i_set_Date_Range_parameters_as_empty() throws Throwable {
		startDate = MiscTools.getPastMonthDateMonthName();
		stopDate = MiscTools.getTodayDateMonthName();
		base.params.put("shipDateFrom=");
		base.params.put("shipDateTo=");
		rangeFilterDefault = "Y";
	}

	@Given("^I set Therapy parameter as empty$")
	public void i_set_Therapy_parameter_as_empty() throws Throwable {
		base.therapyType = "";therapyParam = "Y";
		base.params.put("therapyID="+base.therapyType);
	}

	@Given("^I get a valid Direct Patient w/Prescriptions Id$")
	public void i_get_a_valid_Direct_Patient_w_Prescriptions_Id() throws Throwable {
		therapyFilter = MiscTools.addTherapyFilter(base.therapyType,base.environment);
		query = String.format(SqlQueries.GetDirectPatientWithRx.toString(), startDate, stopDate, therapyFilter==""?"":therapyFilter, 
				therapyFilter==""?"": String.format(prescriptionSqlQueries.GetTTSub.toString(), startDate, stopDate));
		base.patientId = MiscTools.executeSingleSelect(base.environment, query);
		System.out.println(query);
		System.out.println("ya salio alv");
	}

	@Given("^I get a valid Integrated Patient w/Prescriptions Id$")
	public void i_get_a_valid_Integrated_Patient_w_Prescriptions_Id() throws Throwable {
		therapyFilter = MiscTools.addTherapyFilter(base.therapyType,base.environment);
		query = String.format(prescriptionSqlQueries.GetIntegratedPatientWithRx.toString(), startDate, stopDate, therapyFilter==""?"":therapyFilter);
		base.patientId = MiscTools.executeSingleSelect(base.environment, query);
	}
	
	@Given("^I get a valid Patient w/Prescriptions Id$")
	public void i_get_a_valid_Patient_w_Prescriptions_Id() throws Throwable {
		therapyFilter = MiscTools.addTherapyFilter(base.therapyType,base.environment);
		query = String.format(prescriptionSqlQueries.GetPatientWithRx.toString(), startDate, stopDate, therapyFilter==""?"":therapyFilter, 
				therapyFilter==""?"": String.format(prescriptionSqlQueries.GetTTSub.toString(), startDate, stopDate));
		base.patientId = MiscTools.executeSingleSelect(base.environment, query);
	}

	@Given("^I get a valid Direct Patient w/o Prescriptions in Range Id$")
	public void i_get_a_valid_Direct_Patient_w_o_Prescriptions_in_Range_Id() throws Throwable {
		query = String.format(prescriptionSqlQueries.GetDirectPatientWithoutRx.toString(), startDate, stopDate);
		base.patientId = MiscTools.executeSingleSelect(base.environment, query);
	}

	@Given("^I get a valid Patient w/o Prescriptions in Range Id$")
	public void i_get_a_valid_Patient_w_o_Prescriptions_in_Range_Id() throws Throwable {
		query = String.format(prescriptionSqlQueries.GetPatientWithoutRx.toString(), startDate, stopDate);
		base.patientId = MiscTools.executeSingleSelect(base.environment, query);
	}

	@When("^I send a request to retrieve Prescription information$")
	public void i_send_a_request_to_retrieve_Prescription_information() throws Throwable {
		String apiPathWithParams =  MiscTools.concatenateParams(ApiPaths.PRESCRIPTION,base.params);
		System.out.println(apiPathWithParams);
    	base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams);
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
    	MiscTools.printIdented("Prescription used: Service Branch->"+base.sb+" Prescription Id->"+base.rxId+ (base.refill == null?"":" Refill->"+base.refill));
	}
	
	@When("^I send a request to retrieve Patient's Prescriptions$")
	public void i_send_a_request_to_retrieve_Patient_s_Prescriptions() throws Throwable {
		String apiPath = MiscTools.concatenateParams(ApiPaths.PRESCRIPTION+base.patientId,base.params);
		System.out.println(apiPath);
		base.oaResponse = base.oauthServiceApi.retrive(apiPath);
		base.responseBody = base.oaResponse.getBody();
    	MiscTools.printIdented("Criteria used: Patient Id->"+base.patientId + (therapyParam=="Y"?" Therapy Type ->"+ base.therapyType:"")+
    			(rangeFilter=="Y"?" Date Range ->"+ startDate+" To "+stopDate:"") + (rangeFilterDefault=="Y"?" Date Range ->":""));
    	base.params = new JSONArray();
	}
	
	@When("^I send a request to retrieve Prescription GUID$")
	public void i_send_a_request_to_retrieve_Prescription_GUID() throws Throwable {
		String apiPath = ApiPaths.PRESCRIPTION_MySQL+base.rxId;
		System.out.println(apiPath);
    	base.oaResponse = base.oauthServiceApi.retrive(apiPath);
		base.responseBody = base.oaResponse.getBody();
    	System.out.println(base.responseBody);
	}

	@Then("^I should get the Prescription information$")
	public void i_should_get_the_Prescription_information() throws Throwable {
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		JSONArray arrayPrescriptionInfo = GetResponses.newCreatePrescriptionRespose(base.prescription, base.environment);
		prescriptionInfo = arrayPrescriptionInfo.getJSONObject(0);
		responsePrescriptionInfo = jsonArrayResponseBody.getJSONObject(0);
		JSONAssert.assertEquals(prescriptionInfo.toString(), responsePrescriptionInfo.toString(), JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^I should get Patient's Prescriptions$")
	public void i_should_get_Patient_s_Prescriptions() throws Throwable {
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		JSONArray arrayPrescriptionInfo = GetResponses.createPrescriptionRespose(base.patientId, startDate, stopDate, therapyFilter==""?"":therapyFilter, base.environment);
		System.out.println("Response:--->"+jsonArrayResponseBody.length());
		System.out.println("Expected:--->"+arrayPrescriptionInfo.length());
		JSONObject responsePrescriptionInfo = MiscTools.prescrionsArrayToJson(jsonArrayResponseBody);
		prescriptionInfo = MiscTools.prescrionsArrayToJson(arrayPrescriptionInfo);
		
		JSONAssert.assertEquals(prescriptionInfo.toString(), responsePrescriptionInfo.toString(), JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^Prescription \"([^\"]*)\" \"([^\"]*)\" should have correct values$")
	public void prescription_should_have_correct_values(String expectedRx, String actualRx) throws Throwable {
		JSONAssert.assertEquals(expectedRx.toString(), actualRx.toString(), JSONCompareMode.NON_EXTENSIBLE);
	}

	@Then("^Prescription should have (\\d+) Processing Users?$")
	public void prescription_should_have_Processing_User(int expectedProcessigUsers) throws Throwable {
		JSONArray resProcessingUsers = new JSONArray(JsonTools.findKeys(jsonArrayResponseBody.getJSONObject(0), "processingUsers"));
	    int actualProcessigUsers = resProcessingUsers.length();
	    assertEquals(expectedProcessigUsers,actualProcessigUsers);
	}

	@Then("^Prescription should not have Processing Users$")
	public void prescription_should_not_have_Processing_Users() throws Throwable {
	  JSONArray resProcessingUsers = new JSONArray(JsonTools.findKeys(jsonArrayResponseBody.getJSONObject(0), "processingUsers"));
	  JSONArray noUsers = new JSONArray(DefaultValues.ProcessigUserEmpty.toString());
	  JSONAssert.assertEquals(noUsers,resProcessingUsers,JSONCompareMode.NON_EXTENSIBLE);
	}
	
	@Then("^I should get the correct Received Date$")
	public void i_should_get_the_correct_Received_Date() throws Throwable {
		 String expectedReceivedDate = JsonTools.findKeys(prescriptionInfo,"rxDateReceived");
		 String actualReceivedDate = JsonTools.findKeys(responsePrescriptionInfo,"rxDateReceived");
 
		 Assert.assertEquals(expectedReceivedDate,actualReceivedDate);
	}

	@Then("^\"([^\"]*)\" field should have the expected value$")
	public void field_should_have_the_expected_value(String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
		String expectedReceivedDate = JsonTools.findKeys(jsonPrescriptionInfo.getJSONObject(0).getJSONObject("prescription"), field);
		String actualReceivedDate = JsonTools.findKeys(jsonArrayResponseBody.getJSONObject(0).getJSONObject("prescription"), field);
		System.out.println(expectedReceivedDate);
		Assert.assertEquals(expectedReceivedDate,actualReceivedDate);
	}

	@Then("^I should get the correct Transfer User$")
	public void i_should_get_the_correct_Transfer_User() throws Throwable {
		 String expectedTranferUser = JsonTools.findKeys(prescriptionInfo,"transferUser");
		 
		 String actualTransferUser =  JsonTools.findKeys(responsePrescriptionInfo,"transferUser");
		 Assert.assertEquals(expectedTranferUser,actualTransferUser);
	}

	@Then("^I should get the correct Transfer Date$")
	public void i_should_get_the_correct_Transfer_Date() throws Throwable {
		 String expectedTranferDate = JsonTools.findKeys(prescriptionInfo,"transferDate");
		 String actualTransferDate =  JsonTools.findKeys(responsePrescriptionInfo,"transferDate");
		 Assert.assertEquals(expectedTranferDate,actualTransferDate);
	}
	@Then("^Prescription Transfer Information should be null$")
	public void prescription_Transfer_Information_should_be_null() throws Throwable {
		 String actualTransfer =  JsonTools.findKeys(jsonArrayResponseBody.getJSONObject(0),"transfer");
		 Assert.assertEquals("null",actualTransfer);
	}
	
	@Then("^Prescription Information should not contain a Transfer User$")
	public void prescription_Information_should_not_contain_a_Transfer_User() throws Throwable {
	    Assert.assertEquals("null",JsonTools.findKeys(jsonArrayResponseBody.getJSONObject(0),"transferUser"));
	}

	@Then("^Prescription Information should not contain a Transfer Date$")
	public void prescription_Information_should_not_contain_a_Transfer_Date() throws Throwable {
		Assert.assertEquals("null",JsonTools.findKeys(jsonArrayResponseBody.getJSONObject(0),"transferDate"));
	}

	@Then("^I should get the correct Renewals attributes$")
	public void i_should_get_the_correct_Renewals_attributes() throws Throwable {
		String expectedRenewalAttributes = JsonTools.findKeys(prescriptionInfo,"renewal");
		String actualRenewalAttributes =  JsonTools.findKeys(responsePrescriptionInfo,"renewal");
		Assert.assertEquals(expectedRenewalAttributes,actualRenewalAttributes);
	}

	@Then("^Prescription GUID should exist in PCF DB$")
	public void prescription_GUID_should_exist_in_PCF_DB() throws Throwable {
		i_send_a_request_to_retrieve_Prescription_GUID();
		Assert.assertTrue(MiscTools.prescriptionGuidExists(base.sb,base.rxId,base.responseBody));
	}

}
