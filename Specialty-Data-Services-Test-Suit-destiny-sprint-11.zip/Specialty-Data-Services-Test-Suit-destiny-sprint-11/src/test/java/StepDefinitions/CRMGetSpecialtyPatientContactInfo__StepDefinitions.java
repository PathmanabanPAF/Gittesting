package StepDefinitions;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.junit.Assert;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.DBConnection;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import GlobalEnums.SqlQueries;
import GlobalEnums.StatusCode;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CRMGetSpecialtyPatientContactInfo__StepDefinitions extends BaseUtil{
	public String requestBody;
	private static String patientId;
	private static String SB;
	private static String prescriptionId;
	private static String refillNo;
	private static String therapyType;
	private static String shipDate;
	private static String NBD;
	private static String shippingId;
	private static String createdDate;
	private BaseUtil base;
	String query;
	
	public CRMGetSpecialtyPatientContactInfo__StepDefinitions(BaseUtil base){this.base = base;}
	public static String getpatientId(){return patientId;}
	public static String getSB(){return SB;}
	public static String getprescriptionId(){return prescriptionId;}
	public static String getrefillNo(){return refillNo;}
	public static String gettherapyType(){return therapyType;}
	
	@Given("^I get a \"([^\"]*)\" Patient$")
	public void i_get_a_Patient(String kindOfPatient) throws Throwable {
		DBConnection db = new DBConnection(base.environment);
		
		if(kindOfPatient.equals("Direct")){
			query = SqlQueries.RxPLDirect12b.toString();
	
		}else if(kindOfPatient.equals("Integrated")){
			query = SqlQueries.RxPLIntegrated12b.toString();
		}
	    try{
			ResultSet rs = db.ExecuteSelect(query);
			while(rs.next()){
				 
				patientId = rs.getString(1);
				SB = rs.getString(2);
				therapyType = rs.getString(3);
				prescriptionId = rs.getString(4);
				refillNo = rs.getString(5);
				shipDate = rs.getString(6);
				NBD = rs.getString(7);
				shippingId = rs.getString(8);
				
				System.out.println("Patient :"+patientId);
			}
		}catch(SQLException e){
			e.getStackTrace();
		}finally{
			db.Close();
		}
	}
	
	@Given("^I need the created date value$")
	public void i_need_the_created_date_value() throws Throwable {
		DBConnection db = new DBConnection(base.environment);
	    query = "select created_date from thot.patients_table where id ="+ patientId;
	    try{
			ResultSet rs = db.ExecuteSelect(query);
			while(rs.next()){
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				createdDate = sdf.format(rs.getDate(1)).toString();
			}
	    }catch(SQLException e){
	    	e.getMessage();
	    }finally{
	    	db.Close();
	    }
	}

	   
	@When("^the request XML is already updated for GetSpecialtyPatientContactInfo Service$")
	public void the_request_XML_is_already_updated_for_GetSpecialtyPatientContactInfo_Service() throws Throwable {
		requestBody = XmlTools.readXmlFileComplete(ResourcePaths.GET_SPECIALTY_PATIENT_CONTACT_INFO);
		if(base.environment.equals("TEST")){
			requestBody = XmlTools.updateXmlNodeValue(requestBody, "UserId", "QCRM01");
		}else if(base.environment.equals("UAT")){
			requestBody = XmlTools.updateXmlNodeValue(requestBody, "UserId", "UCRM01");
		}
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "PatientId", patientId);
		
	}
	
	@Then("^the request should be sent to the web service$")
	public void the_request_should_be_sent_to_the_web_service() throws Throwable {
		base.response = base.serviceApi.create(ApiPaths.GET_SPECIALTY_PATIENT, requestBody);
    	base.responseBody = base.response.getBody().asString();
	}
	
	@Then("^The response status should be \"([^\"]*)\" after consume the service$")
	public void the_response_status_should_be_after_consume_the_service(String statusDescription) throws Throwable {
		statusDescription = statusDescription.replaceAll("\\s+", "");
		if(statusDescription.equals("Success")){
			StatusCode status = StatusCode.valueOf(statusDescription);
			System.out.println("Status :"+status);
			base.response.then().statusCode(status.getStatusCode());
		}else if(statusDescription.equals("BadRequest")){
			StatusCode status = StatusCode.valueOf(statusDescription);
			System.out.println("Status :"+status);
			base.response.then().statusCode(status.getStatusCode());
		}
		
	}
	
	@Then("^the created date should be appear on Customer tag on the XML$")
	public void the_created_date_should_be_appear_on_Customer_tag_on_the_XML() throws Throwable {
	    String customerSince = XmlTools.getXmlNodeValue(base.responseBody, "CustomerSince");
	    Assert.assertEquals(customerSince,createdDate);
	}
	
	@When("^the patient \"([^\"]*)\" for GetSpecialtyPatientContactInfo Service$")
	public void the_patient_for_GetSpecialtyPatientContactInfo_Service(String patientIssue) throws Throwable {
		patientIssue = patientIssue.replaceAll("\\s+", "");
		requestBody = XmlTools.readXmlFileComplete(ResourcePaths.GET_SPECIALTY_PATIENT_CONTACT_INFO);
		if(base.environment.equals("TEST")){
			requestBody = XmlTools.updateXmlNodeValue(requestBody, "UserId", "QCRM01");
		}else if(base.environment.equals("UAT")){
			requestBody = XmlTools.updateXmlNodeValue(requestBody, "UserId", "UCRM01");
		}
		if(patientIssue.equals("notexist")){
			requestBody = XmlTools.updateXmlNodeValue(requestBody, "PatientId", patientId+1);
			System.out.println("Non existing patient :"+patientId+1);
		}else if(patientIssue.equals("isnull")){
			patientId = null;
			requestBody = XmlTools.updateXmlNodeValue(requestBody, "PatientId", patientId);
			System.out.println("Send null like patient value :"+patientId);
		}
	}
	
	@Then("^the status message should be \"([^\"]*)\"$")
	public void the_status_message_should_be(String statusDescription) throws Throwable {
		statusDescription = statusDescription.replaceAll("\\s+", "");
		String statusMessage = XmlTools.getXmlNodeValue(base.responseBody, "StatusMessage");
		String statusCode = XmlTools.getXmlNodeValue(base.responseBody, "StatusCode");
		if(statusDescription.equals("Badrequest")){
			if(statusMessage.equals(statusDescription)){
				Assert.assertEquals("400", statusCode);
			}
		}else if(statusDescription.equals("NotFound")){
			if(statusMessage.equals(statusDescription)){
				Assert.assertEquals("404", statusCode);
			}
		}
		
	}






}
