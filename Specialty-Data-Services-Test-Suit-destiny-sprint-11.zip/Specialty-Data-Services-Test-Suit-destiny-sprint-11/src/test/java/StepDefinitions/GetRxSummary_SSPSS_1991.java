package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

public class GetRxSummary_SSPSS_1991 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	public String ExpecMedsOnHandAnswer;
	public int prevAssmntCount, postAssmntCount;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;
	Response res;
	
	public GetRxSummary_SSPSS_1991(BaseUtil base){
		this.base = base;
	}
	
	//Scenario1
	@Given("^I have valid Patientid, Prescription Id with Channel IVR$")
	public void i_have_valid_Patientid_Prescription_Id_with_Channel_IVR() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException(); 
		//requestBody = XmlTools.readXmlFileComplete(ResourcePaths.GetRxSummary_TC1);
		//System.out.println("file:"+requestBody);
		
		RestAssured.baseURI= "https://trcws-qa.express-scripts.com";
		res=given().header("Content-Type", "application/xml").
		header("Authorization","Bearer "+"UUNSTTAxOldlbGNvbWUx").
		body("<Request>\r\n" + 
				"  <TestMode>N</TestMode>\r\n" + 
				"  <OrgId>ACDO</OrgId>\r\n" + 
				"  <Channel>IVR</Channel>\r\n" + 
				"  <Role>IVRU</Role>\r\n" + 
				"  <UserId>IVRQA</UserId>\r\n" + 
				"  <Format>XML</Format>\r\n" + 
				"	<RxSummaryCriteria>\r\n" + 
				"          <Type>Pt</Type>\r\n" + 
				"		<PatientIds>\r\n" + 
				"			<PatientId>11352432</PatientId>\r\n" + 
				"		</PatientIds> \r\n" + 
				"	</RxSummaryCriteria>\r\n" + 
				"</Request>").when().
		post("/orderInfo/getSpecialtyRxSummary").then().statusCode(200).extract().response();
		
		System.out.println("res: "+res.getStatusCode());
		System.out.println("res: "+res);
		  
		  }

	@When("^I send a request to POST GetOrdersummary$")
	public void i_send_a_request_to_POST_GetOrdersummary() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	//throw new PendingException();
		
		String response =res.asString();
		System.out.println(response);
		
		//JsonPath js= new JsonPath(response);
		
		//String test=js.get("StatusMessage");
		
		/*base.oaResponse = base.oauthServiceApi.create(ApiPaths.GetRxsummary, requestBody);
		base.responseBody = base.response.getBody().asString();
		System.out.println(base.responseBody);*/
	}
	
	@Then("^the response status success with XML$")
	public void the_response_status_success_with_XML() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@Then("^I should get RxSummary$")
	public void i_should_get_RxSummary() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	//throw new PendingException();
	}

	//Scenario2
	@Given("^I have valid Patientid, Prescription Id with Channel WEB$")
	public void i_have_valid_Patientid_Prescription_Id_with_Channel_WEB() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	//throw new PendingException();
		//requestBody = XmlTools.readXmlFile(ResourcePaths.GetRxSummary_TC2);
		RestAssured.baseURI= "https://trcws-qa.express-scripts.com";
		res=given().header("Content-Type", "application/xml").
		header("Authorization","Bearer "+"UUNSTTAxOldlbGNvbWUx").
		body("<Request>\r\n" + 
				"  <TestMode>N</TestMode>\r\n" + 
				"  <OrgId>ACDO</OrgId>\r\n" + 
				"  <Channel>WEB</Channel>\r\n" + 
				"  <Role>IVRU</Role>\r\n" + 
				"  <UserId>IVRQA</UserId>\r\n" + 
				"  <Format>XML</Format>\r\n" + 
				"	<RxSummaryCriteria>\r\n" + 
				"          <Type>Pt</Type>\r\n" + 
				"		<PatientIds>\r\n" + 
				"			<PatientId>11352432</PatientId>\r\n" + 
				"		</PatientIds> \r\n" + 
				"	</RxSummaryCriteria>\r\n" + 
				"</Request>").when().
		post("/orderInfo/getSpecialtyRxSummary").then().statusCode(200).extract().response();
		
		System.out.println("res: "+res.getStatusCode());
		System.out.println("res: "+res);
	}

	//Scenario3
	@Given("^I have valid Patientid, Prescription Id with Channel AOM$")
	public void i_have_valid_Patientid_Prescription_Id_with_Channel_AOM() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	//throw new PendingException();
		//requestBody = XmlTools.readXmlFile(ResourcePaths.GetRxSummary_TC3);
		RestAssured.baseURI= "https://trcws-qa.express-scripts.com";
		res=given().header("Content-Type", "application/xml").
		header("Authorization","Bearer "+"UUNSTTAxOldlbGNvbWUx").
		body("<Request>\r\n" + 
				"  <TestMode>N</TestMode>\r\n" + 
				"  <OrgId>ACDO</OrgId>\r\n" + 
				"  <Channel>AOM</Channel>\r\n" + 
				"  <Role>IVRU</Role>\r\n" + 
				"  <UserId>IVRQA</UserId>\r\n" + 
				"  <Format>XML</Format>\r\n" + 
				"	<RxSummaryCriteria>\r\n" + 
				"          <Type>Pt</Type>\r\n" + 
				"		<PatientIds>\r\n" + 
				"			<PatientId>11352432</PatientId>\r\n" + 
				"		</PatientIds> \r\n" + 
				"	</RxSummaryCriteria>\r\n" + 
				"</Request>").when().
		post("/orderInfo/getSpecialtyRxSummary").then().statusCode(200).extract().response();
		
		System.out.println("res: "+res.getStatusCode());
		System.out.println("res: "+res);
	}

	public String Readproperty(String name)
	{
		Properties prop = new Properties();
		InputStream input = null;
		String name1 = null;
		try {

		input = new FileInputStream("C:\\Specialty-Data-Services-Test-Suit-destiny-sprint-11\\input_SSquad.properties");
		
		// load a properties file
		prop.load(input);

		// get the property value and print it out
		
		if(name.contentEquals("SSPSS1255_TC1_patientId"))
		{
		 name1=prop.getProperty("SSPSS1255_TC1_patientId");
		}
		else if(name.contentEquals("SSPSS1255_TC1_shipfromdate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC1_shipfromdate");
		}
		else if(name.contentEquals("SSPSS1255_TC1_shiptodate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC1_shiptodate");
		}
		else if(name.contentEquals("SSPSS1255_TC2_patientId"))
		{
			 name1=prop.getProperty("SSPSS1255_TC2_patientId");
		}
		else if(name.contentEquals("SSPSS1255_TC2_shipfromdate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC2_shipfromdate");
		}
		else if(name.contentEquals("SSPSS1255_TC2_shiptodate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC2_shiptodate");
		}
		else if(name.contentEquals("SSPSS1255_TC3_patientId"))
		{
			 name1=prop.getProperty("SSPSS1255_TC3_patientId");
		}
		else if(name.contentEquals("SSPSS1255_TC3_shipfromdate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC3_shipfromdate");
		}
		else if(name.contentEquals("SSPSS1255_TC3_shiptodate"))
		{
			 name1=prop.getProperty("SSPSS1255_TC3_shiptodate");
		}
		else if(name.contentEquals("SSPSS1255_TC4_patientId"))
		{
			 name1=prop.getProperty("SSPSS1255_TC4_patientId");
		}
		//System.out.println(prop.getProperty("dbuser"));
		//System.out.println(prop.getProperty("dbpassword"));

		} catch (IOException ex) {
			System.out.println("Error");
			ex.printStackTrace();
	
	}
		return name1;
}

}
