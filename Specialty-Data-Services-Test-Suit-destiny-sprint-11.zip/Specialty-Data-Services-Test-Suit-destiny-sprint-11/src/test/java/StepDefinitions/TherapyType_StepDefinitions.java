package StepDefinitions;

import GlobalClasses.*;
import GlobalEnums.SqlQueries;

import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TherapyType_StepDefinitions extends BaseUtil {
	private BaseUtil base;

	public TherapyType_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I get a valid Therapy Type$")
	public void i_get_a_valid_Therapy_Type() throws Throwable {
		base.therapyType = MiscTools.executeSingleSelect(base.environment, SqlQueries.TherapyType.toString());
	}
	
	@Given("^I get an invalid Therapy Type$")
	public void i_get_an_invalid_Therapy_Type() throws Throwable {
		base.therapyType = MiscTools.getRandomString(4).toUpperCase();
	}
	
	@Given("^I get an empty Therapy Type$")
	public void i_get_an_empty_Therapy_Type() throws Throwable {
		base.therapyType = "";
	}
	
	@Given("^I get a valid Nurse Visit Therapy Type$")
	public void i_get_a_valid_Nurse_Visit_Therapy_Type() throws Throwable {
		String query = "select therapy_type from thot.therapy_types where nv_flag = 'Y' and rownum < 2";
		base.therapyType = MiscTools.executeSingleSelect(base.environment, query);
	}

	@When("^I send a request to retrieve Therapy Type details$")
	public void i_send_a_request_to_retrieve_Therapy_Type_details() throws Throwable {
		MiscTools.printIdented("Therapy Type used: "+base.therapyType);
		base.response = base.serviceApi.retrive(ApiPaths.GET_THERAPY_TYPE+therapyType);
    	base.responseBody = base.response.getBody().asString();
	}
	
	@Then("^I should get the Therapy Type information\\.$")
	public void i_should_get_the_Therapy_Type_information() throws Throwable {
		JSONObject therapyTypeInfo = new JSONObject(GetResponses.createTherapyTypeRespose(base.therapyType, base.environment));
		JSONObject jsonResponseBody = new JSONObject(base.responseBody);
 		JSONAssert.assertEquals(therapyTypeInfo,jsonResponseBody,JSONCompareMode.NON_EXTENSIBLE);	
	}
}
