package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;
import io.restassured.response.Response;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

public class GetDrugdetails_SSPDT_2336 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public GetDrugdetails_SSPDT_2336(BaseUtil base){
		this.base = base;
	}

	//Scenario 1
	@Given("^I have valid drug name, detail level attribute$")
	public void i_have_valid_drug_name_detail_level_attribute() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.params.put("detailLevel="+"DETAILS");
		base.params.put("name="+"MEDROXY");
	}

	@When("^I send a request to retrieve drug details$")
	public void i_send_a_request_to_retrieve_drug_details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		String apiPathWithParams =  MiscTools.concatenateParams(ApiPaths.DRUGAPI,base.params);
		System.out.println("API path with parameteres:" +apiPathWithParams);
		base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams);
		//base.response=base.serviceApi.retrive("");
		base.responseBody = base.oaResponse.getBody();
		//base.responseBody="["+base.responseBody+"]";
		System.out.println("Response body: "+base.responseBody);
	}

	@Then("^Drug details displayed with full details$")
	public void drug_details_displayed_with_full_details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //	throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "chapterId");
        System.out.println("chapterId: "+legacyPatientId);
        Assert.assertEquals("11030100",legacyPatientId);
        System.out.println("Validated chapter id");
	}

	//Scenario2 
	@Given("^I have valid drug name alone$")
	public void i_have_valid_drug_name_alone() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		//base.params.put("detailLevel="+"DETAILS");
		base.params.put("name="+"MEDROXY");
	}

	@Then("^Drug details displayed with ndc, brandName, genericName, labelName & ManufacturerName$")
	public void drug_details_displayed_with_ndc_brandName_genericName_labelName_ManufacturerName() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "genericName");
        System.out.println("chapterId: "+legacyPatientId);
        Assert.assertEquals("MEDROXYPROGESTERONE",legacyPatientId);
        System.out.println("Validated Drug Generic Name");
	}
	
	//Scenario3
	@Given("^I have valid drug name - H(\\d+) brings Drug info and H(\\d+) doesn't$")
	public void i_have_valid_drug_name_H_brings_Drug_info_and_H_doesn_t(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		base.params.put("detailLevel="+"DETAILS");
		base.params.put("specialty="+"N");
		base.params.put("name="+"PRILOSEC");
		base.params.put("ndc="+"00186062501");
	}

	@When("^I send a request to retrieve drug details - H(\\d+) brings Drug info and H(\\d+) doesn't$")
	public void i_send_a_request_to_retrieve_drug_details_H_brings_Drug_info_and_H_doesn_t(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String apiPathWithParams =  MiscTools.concatenateParams(ApiPaths.DRUGAPI,base.params);
		System.out.println("API path with parameteres:" +apiPathWithParams);
		base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams);
		//base.response=base.serviceApi.retrive("");
		base.responseBody = base.oaResponse.getBody();
		//base.responseBody="["+base.responseBody+"]";
		System.out.println("Response body: "+base.responseBody);
	}


	@Then("^Drug details displayed with H(\\d+) details$")
	public void drug_details_displayed_with_H_details(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //Validate Scenario3 response
	}

	

}
