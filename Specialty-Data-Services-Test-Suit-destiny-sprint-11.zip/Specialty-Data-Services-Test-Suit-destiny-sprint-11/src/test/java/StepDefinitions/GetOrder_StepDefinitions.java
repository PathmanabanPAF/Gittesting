
package StepDefinitions;

import java.util.Map;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import GlobalClasses.*;

public class GetOrder_StepDefinitions extends BaseUtil {
	
	public String sb,rx, refill, patientId;
	public String requestBody;
	private BaseUtil base;
	
	public GetOrder_StepDefinitions(BaseUtil base){
		this.base = base;
	}

//	@Given("^I get a prescription with following criteria$")
//	public void i_get_a_prescription_with_following_criteria(String criteriaString) throws Throwable {
//		base.prescription = MiscTools.getCriteriaPrescription(criteriaString, base.environment);
//		sb = prescription.get("sb");
//		rx = prescription.get("rx");
//		refill = prescription.get("refill");
//		MiscTools.printIdented("Prescription used: "+sb+"-"+rx+"-"+refill);
//	}
	
	@Given("^I set up one request with it$")
	public void i_set_up_one_request_with_it() throws Throwable {
		requestBody = XmlTools.readXmlFile(ResourcePaths.ORDER_REQ);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "LocationNbr", base.prescription.get("sb"));
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "Id",base.prescription.get("rx"));
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "RefillNbr", base.prescription.get("refill"));
	}

	@When("^I send a request to retrieve order details$")
	public void i_send_a_request_to_retrieve_order_details() throws Throwable {
		base.response = base.serviceApi.create(ApiPaths.GET_ORDER, requestBody);
		base.responseBody = base.response.getBody().asString();
	}
}
