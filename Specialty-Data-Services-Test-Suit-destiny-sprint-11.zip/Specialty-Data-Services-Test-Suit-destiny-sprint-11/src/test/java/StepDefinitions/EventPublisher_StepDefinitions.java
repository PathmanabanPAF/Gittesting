package StepDefinitions;

import java.util.Map;

import static org.junit.Assert.*;
import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalEnums.SqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONObject;

public class EventPublisher_StepDefinitions extends BaseUtil{
	private BaseUtil base;
	public String requestBody;
	public String eventId, patientId;
	public int prevChartCount;
	JSONObject requestBodyJson;
	public String chartCountquery;
	
	public EventPublisher_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I a get direct patient eligible for CPA$")
	public void i_a_get_direct_patient_eligible_for_CPA(String arg1) throws Throwable {
	    
	}

	@Given("^I get an integrated patient eligible for CPA$")
	public void i_get_an_integrated_patient_eligible_for_CPA(String arg1) throws Throwable {
	   
	}


	@Given("^I set up a new request with it$")
	public void i_set_up_a_new_request_with_it() throws Throwable {
		String sb, rxId, refill;
		sb = "1";rxId ="2";refill = "3";
		requestBodyJson = JsonTools.readJsonFile(ResourcePaths.COPAY_ASST_REQ);
		requestBodyJson = JsonTools.updateKeys(requestBodyJson,"eventId", "123456");
		requestBodyJson = JsonTools.updateKeysPath(requestBodyJson,"prescription.serviceBranchId", sb);
		requestBodyJson = JsonTools.updateKeysPath(requestBodyJson,"prescription.id", rxId);
		requestBodyJson = JsonTools.updateKeysPath(requestBodyJson,"prescription.refillNumber", refill);
		System.out.println(requestBodyJson);
		requestBody = requestBodyJson.toString();
	}

	@When("^I send my request to get Copay Assistance Declination$")
	public void i_send_my_request_to_get_Copay_Assistance_Declination() throws Throwable {
//		base.response = base.serviceApi.create(ApiPaths.COPAY_ASST, requestBody);
//    	base.responseBody = base.response.getBody().asString();
		patientId = "11166548";
		chartCountquery = String.format(SqlQueries.ChartCount.toString(), patientId);
		prevChartCount = Integer.parseInt(MiscTools.executeSingleSelect(base.environment,chartCountquery));
	}

	@Then("^event should be successfully processed$")
	public void event_should_be_successfully_processed() throws Throwable {
		eventId = "0";
	 String query ="select event_id, status,status_message from thot.ev_event_control where event_id='"+eventId+"'";
	 Map<String, String> event =MiscTools.executeSingleRowSelect(base.environment, query);
	 assertFalse(event.isEmpty());
	}

	@Then("^the patient's Therapy should be updated$")
	public void the_patient_s_Therapy_should_be_updated() throws Throwable {
		patientId = "4495551";
		String query ="select cpa_ind_elig_msg from patient_therapies where rownum < 2 and therapy_type = 'HUMA' "
				+ " and stop_date is null and status = 'ACTIVE' and patient_id ="+patientId;
		String cpaMessage = MiscTools.executeSingleSelect(base.environment, query);
		assertEquals("PATIENT IS ELIGIBLE FOR COPAY", cpaMessage);
	}

	@Then("^a Chart Note should be created$")
	public void a_Chart_Note_should_be_created() throws Throwable {
		
		int postChartCount = Integer.parseInt(MiscTools.executeSingleSelect(base.environment,chartCountquery));
		//assertTrue(postChartCount>prevChartCount);
	}

}
