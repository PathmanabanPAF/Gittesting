package StepDefinitions;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import static org.junit.Assert.*;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import GlobalClasses.*;
import GlobalEnums.DefaultValues;

public class Manufacturer_StepDefinitions extends BaseUtil{
	private BaseUtil base;
	public String manufacturerId;
	public String manufacturerName;
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject manufacturerInfo;
	JSONArray jsonResponseBody;
	
	public Manufacturer_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I get a valid Manufacturer Id$")
	public void i_get_a_valid_Manufacturer_Id() throws Throwable {
		String query = "select id from manufacturers where rownum < 2";
		manufacturerId = MiscTools.executeSingleSelect(base.environment, query);
	}
	
	@Given("^I get a valid Manufacturer with multiple phones Id$")
	public void i_get_a_valid_Manufacturer_with_multiple_phones_Id() throws Throwable {
		String query = "select id from manufacturers m where (select count(phone_seq)"+
				" from thot.phones where name_type ='F' and name_id = m.id) > 1 and rownum < 2";
		manufacturerId = MiscTools.executeSingleSelect(base.environment, query);
	}

	@Given("^I get an invalid Manufacturer Id$")
	public void i_get_an_invalid_Manufacturer_Id() throws Throwable {
		String query = "select id from manufacturers where rownum < 2 order by id desc";
		manufacturerId = MiscTools.executeSingleSelect(base.environment, query);
		manufacturerId = Integer.toString(Integer.parseInt(manufacturerId) + 10);
	}
	
	@Given("^I get an empty Manufacturer Id$")
	public void i_get_an_empty_Manufacturer_Id() throws Throwable {
	    manufacturerId = "";
	}
	
	@Given("^I have the required Manufacturer information$")
	public void i_have_the_required_Manufacturer_information() throws Throwable {
		requestBodyJson = JsonTools.readJsonFile(ResourcePaths.MANUFACTURER_REQ);
		manufacturerName = "AUTO"+MiscTools.getRandomString(5).toUpperCase();
		requestBody = JsonTools.updateKeys(requestBodyJson, "name", manufacturerName).toString();
	}
	@Given("^I leave blank the field \"([^\"]*)\"$")
	public void i_leave_blank_the_field(String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
		requestBody = JsonTools.updateKeys(requestBodyJson, field, "").toString();
	}

	@Given("^I set the field \"([^\"]*)\" as Null$")
	public void i_set_the_field_as_Null(String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
		requestBody = JsonTools.updateKeys(requestBodyJson, field, "null").toString();
	}

	@Given("^I fill some numeric fields with String Values$")
	public void i_fill_some_numeric_fields_with_String_Values() throws Throwable {
		requestBody = JsonTools.updateKeys(requestBodyJson, "invoicerId", MiscTools.getRandomString(4)).toString();
		requestBody = JsonTools.updateKeys(requestBodyJson, "marketingId", MiscTools.getRandomString(4)).toString();
		requestBody = JsonTools.updateKeys(requestBodyJson, "zipCode", MiscTools.getRandomString(4)).toString();
		requestBody = JsonTools.updateKeys(requestBodyJson, "phoneExtension", MiscTools.getRandomString(4)).toString();
	}

	@When("^I send a request to retrieve Manufacturer details$")
	public void i_send_a_request_to_retrieve_Manufacturer_details() throws Throwable {
//		base.response = base.serviceApi.retrive(ApiPaths.MANUFACTURER+manufacturerId);
//    	base.responseBody = base.response.getBody().asString();
		base.oaResponse = base.oauthServiceApi.retrive(ApiPaths.MANUFACTURER+manufacturerId);
    	MiscTools.printIdented("Manufacturer Id used: "+manufacturerId);
	}
	
	@When("^I send a request to create one Manufacturer record$")
	public void i_send_a_request_to_create_one_Manufacturer_record() throws Throwable {
		base.response = base.serviceApi.create(ApiPaths.MANUFACTURER, requestBody);
    	base.responseBody = base.response.getBody().asString();
	}
	
	@Then("^I should get the Manufacturer information$")
	public void i_should_get_the_Manufacturer_information() throws Throwable {
		manufacturerInfo = new JSONObject(GetResponses.createManufacturerRespose(manufacturerId, base.environment));
		jsonResponseBody = new JSONArray(base.responseBody);
		JSONAssert.assertEquals(manufacturerInfo,jsonResponseBody.getJSONObject(0),JSONCompareMode.NON_EXTENSIBLE);
	}
	
	@Then("^\"([^\"]*)\" field should be created with default value$")
	public void should_be_created_with_default_value(String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
		String actValue = JsonTools.findKeys(jsonResponseBody.getJSONObject(0),field);
		String expcValue = DefaultValues.valueOf(field).toString();
		Assert.assertEquals(expcValue,actValue);
	}

	@Then("^Manufacturer information should contain more than one phone$")
	public void manufacturer_information_should_contain_more_than_one_phone() throws Throwable {
		JSONArray jsonResponseBody = new JSONArray(base.responseBody); 
		JSONArray jsonArrayPhones =	 new JSONArray(JsonTools.findKeys(jsonResponseBody.getJSONObject(0),"phone"));
		int resPhoneCount = jsonArrayPhones.length();
		assertTrue(resPhoneCount > 1);
	}

	@Then("^a new Manufacturer should be created$")
	public void a_new_Manufacturer_should_be_created() throws Throwable {
		JSONArray jsonResponseBody = new JSONArray(base.responseBody);
		manufacturerId = jsonResponseBody.getJSONObject(0).getString("manufacturerId");
		String query = "select * from manufacturers where id = "+ manufacturerId;
		assertFalse(MiscTools.executeSingleRowSelect(base.environment, query).isEmpty());
	}
	
	@Then("^a new Manufacturer should NOT be created$")
	public void a_new_Manufacturer_should_NOT_be_created() throws Throwable {
		JSONObject jsonResponseBody = new JSONObject(base.responseBody);
		assertTrue(jsonResponseBody.has("error"));
	}
	
	@Then("^new Manufacturer should have the expected values$")
	public void new_Manufacturer_should_have_the_expected_values() throws Throwable {
		base.response = base.serviceApi.retrive(ApiPaths.MANUFACTURER+manufacturerId);
		manufacturerInfo = new JSONObject(GetResponses.manufacturerRequestToResponse(requestBody,manufacturerId));
		jsonResponseBody = new JSONArray(base.response.getBody().asString());
		JSONAssert.assertEquals(manufacturerInfo,jsonResponseBody.getJSONObject(0),JSONCompareMode.NON_EXTENSIBLE);
		
	}
}
