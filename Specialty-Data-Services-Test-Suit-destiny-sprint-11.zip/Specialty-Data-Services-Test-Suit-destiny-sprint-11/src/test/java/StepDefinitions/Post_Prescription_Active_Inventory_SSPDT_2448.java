package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;

public class Post_Prescription_Active_Inventory_SSPDT_2448 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public Post_Prescription_Active_Inventory_SSPDT_2448(BaseUtil base){
		this.base = base;
	}
	
	//Scenario 1
	@Given("^I have valid Legacy Prescriber Id, patient id & active inventory$")
	public void i_have_valid_Legacy_Prescriber_Id_patient_id_active_inventory() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_API_TC1_Active_Inventory);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@When("^I send a request to create prescription record$")
	public void i_send_a_request_to_create_prescription_record() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		System.out.println("APIpath"+ApiPaths.PRESCRIPTION);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.PRESCRIPTION_NEW,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
	}

	@Then("^Prescription Id created and given inventory should associated with it$")
	public void prescription_Id_created_and_given_inventory_should_associated_with_it() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		String prescriptionid=JsonTools.findKeys(jsonResponseBody, "x_rxNumber");
		System.out.println("Prescription Id:  "+prescriptionid);
	}

	@Given("^I have valid Legacy Prescriber Id, patient id & invalid inventory$")
	public void i_have_valid_Legacy_Prescriber_Id_patient_id_invalid_inventory() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_API_TC2_Active_Inventory);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^validation happensstating not a valid Inventory$")
	public void validation_happensstating_not_a_valid_Inventory() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.responseBody="["+base.responseBody+"]";
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+messageinfo);
		String search=JsonTools.findKeys(messageinfo, "error");
        System.out.println("Search Results: "+search);
	}

	//SSPDT2368 Sceanrio1
	@Then("^Prescription Id created and event published successfully$")
	public void prescription_Id_created_and_event_published_successfully() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
	//verify Rx in API logs	
	}

	//SSPDT2368 Sceanrio2
	@Then("^Prescription Id created and event getting error$")
	public void prescription_Id_created_and_event_getting_error() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
	//verify Rx in API logs	
	}


}
