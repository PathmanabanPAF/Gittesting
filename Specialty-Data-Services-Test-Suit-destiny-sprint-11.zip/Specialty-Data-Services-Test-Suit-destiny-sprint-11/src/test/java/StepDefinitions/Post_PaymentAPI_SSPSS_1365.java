package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;
import io.restassured.response.Response;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

public class Post_PaymentAPI_SSPSS_1365 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;
	String accredopatientid,cardid;

	public Post_PaymentAPI_SSPSS_1365(BaseUtil base){
		this.base = base;
	}
	
	//Scenario1 :  Validate Status Code 200 with Valid accredo Patient id, Cardkey id & TX_Amount
	@Given("^I valid accredo Patient id, Card key id & TX_Amount$")
	public void i_valid_accredo_Patient_id_Card_key_id_TX_Amount() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		accredopatientid=Readproperty("accredopatientid");
		System.out.println("accredopatientid: "+accredopatientid);
		cardid=Readproperty("cardid");
		System.out.println("rxnumber: "+cardid);
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Payment_API_TC1);
		System.out.println("XML:"+base.requestBodyJson);
		JsonTools.updateKeys(base.requestBodyJson, "patient", accredopatientid);
		JsonTools.updateKeys(base.requestBodyJson, "id", cardid);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@When("^I send a request to create one payment record$")
	public void i_send_a_request_to_create_one_payment_record() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("APIpath"+ApiPaths.PAYMENT_API);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.PAYMENT_API,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
	}

	@Then("^I should get new Tx_Conf_Number for payment processed$")
	public void i_should_get_new_Tx_Conf_Number_for_payment_processed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		//throw new PendingException();
		String copnfirmationno=JsonTools.findKeys(jsonResponseBody, "number");
		System.out.println("Confimation No:  "+copnfirmationno);
	
	}
	
	//Scenario2 :  Validate Status Code 200 with Valid accredo Patient id, Cardkey id & TX_Amount
	@Given("^I empty accredo Patient id, Card key id & TX_Amount$")
	public void i_empty_accredo_Patient_id_Card_key_id_TX_Amount() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Payment_API_TC2);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^I should get error message as \"([^\"]*)\"$")
	public void i_should_get_error_message_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Success");
		base.responseBody="["+base.responseBody+"]";
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+messageinfo);
		String legacyPatientId=JsonTools.findKeys(messageinfo, "message");
        System.out.println("Search Results: "+legacyPatientId);
      
	}

	@Given("^I invalid accredo Patient id, Card key id & TX_Amount$")
	public void i_invalid_accredo_Patient_id_Card_key_id_TX_Amount() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Payment_API_TC3);
		System.out.println("XML:"+base.requestBodyJson);
	}


	@Then("^the response status should be (\\d+) error$")
	public void the_response_status_should_be_error(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		int status =base.oaResponse.getStatusCode().value();
		System.out.println("STATUS"+status);
		int expected_status=409;
		Assert.assertEquals(expected_status, status);
	}


	@Then("^I should get error message shown as \"([^\"]*)\"$")
	public void i_should_get_error_message_shown_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Success");
		base.responseBody="["+base.responseBody+"]";
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+messageinfo);
		String legacyPatientId=JsonTools.findKeys(messageinfo, "message");
        System.out.println("Search Results: "+legacyPatientId);
	}

	public String Readproperty(String name)
	{
		Properties prop = new Properties();
		InputStream input = null;
		String name1 = null;
		try {

		input = new FileInputStream("C:\\Specialty-Data-Services-Test-Suit-destiny-sprint-11\\input_SSquad.properties");
		
		// load a properties file
		prop.load(input);

		// get the property value and print it out
		
		if(name.contentEquals("accredopatientid"))
		{
		 name1=prop.getProperty("accredopatientid");
		}
		else
		if(name.contentEquals("cardid"))
		{
		name1=prop.getProperty("cardid");
		}
		//System.out.println(prop.getProperty("dbuser"));
		//System.out.println(prop.getProperty("dbpassword"));

		} catch (IOException ex) {
			System.out.println("Error");
			ex.printStackTrace();
	
	}
		return name1;
}
	
}
