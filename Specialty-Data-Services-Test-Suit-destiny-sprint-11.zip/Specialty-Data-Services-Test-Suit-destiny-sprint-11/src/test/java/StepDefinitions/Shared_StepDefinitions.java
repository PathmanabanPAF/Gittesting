package StepDefinitions;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import GlobalClasses.ApiPaths;
import GlobalClasses.ApiTools;
import GlobalClasses.ApiToolsV2;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.WSCredentials;
import GlobalClasses.XmlTools;
import GlobalEnums.Path;
import GlobalEnums.ResponseMessage;
import GlobalEnums.SqlQueries;
import GlobalEnums.StatusCode;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Shared_StepDefinitions extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String invId,lot, qty;
	String query;

	public Shared_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I am working in \"([^\"]*)\" environment$")
	public void i_am_working_in_environment(String env) throws Throwable {
	    base.environment = env;
	}
	
	@Given("^I am targeting \"([^\"]*)\" service$")
	public void i_am_targeting_service(String service) throws Throwable {
		service = service.replaceAll("\\s+", "");
		String[] credentials = WSCredentials.webServicesCredentials(service,base.environment);
        base.serviceApi = new ApiTools(credentials[0],credentials[1],credentials[2]);
        base.params = new JSONArray();
	}
	
	@Given("^I am targeting \"([^\"]*)\" secured service$")
	public void i_am_targeting_secured_service(String service) throws Throwable {
		service = service.replaceAll("\\s+", "");
        base.oauthServiceApi = new ApiToolsV2(service, base.environment);
        base.params = new JSONArray();
	}
	
	@Given("^I get a prescription with following criteria$")
	public void i_get_a_prescription_with_following_criteria(String criteriaString) throws Throwable {
		base.prescription = MiscTools.getCriteriaPrescription(criteriaString, base.environment);
		MiscTools.printIdented("Prescription used: "+base.prescription.get("sb")+"-"+base.prescription.get("rx")+"-"+base.prescription.get("refill"));
	}
	
//	@Given("^I get a valid Direct Patient Id$")
//	public void i_get_a_valid_Direct_Patient_Id() throws Throwable {
//		base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetDirectPatient.toString());
//	}
	
	@Given("^I get a valid Integrated Patient Id$")
	public void i_get_a_valid_Integrated_Patient_Id() throws Throwable {
	
	}

	@Given("^I get an invalid Patient Id$")
	public void i_get_an_invalid_Patient_Id() throws Throwable {
		base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetMaxDirectPatient.toString());
		base.patientId = Integer.toString(Integer.parseInt(base.patientId) + 1 + (int)(Math.random() * 10));
	}

	@Given("^I get a empty Patient Id$")
	public void i_get_a_empty_Patient_Id() throws Throwable {
	    base.patientId = "";
	}
	
	@Given("^I fill Prescription fields with an invalid Prescription$")
	public void i_fill_Prescription_fields_with_an_invalid_Prescription() throws Throwable {
		sb = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetInvalidSb.toString());
		rxId = Integer.toString(1000 + (int)(Math.random() * 10000));
		base.requestBodyJson.put("processingPharmacy", sb);
		base.requestBodyJson.put("rxNumber", rxId);
	}

	@Given("^I fill Prescription fields with an invalid \"([^\"]*)\" Prescription$")
	public void i_fill_Prescription_fields_with_an_invalid_Prescription(String condition) throws Throwable {
		query = prescriptionSqlQueries.valueOf("GetInvalid"+condition.replaceAll("\\s+", "")+"Rx").toString();
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		System.out.println(base.prescription);
		sb = base.prescription.get("sb");rxId = base.prescription.get("rxId");refill = base.prescription.get("refill");
		base.requestBodyJson.put("processingPharmacy", sb);base.requestBodyJson.put("rxNumber", rxId);base.requestBodyJson.put("fillNumber", refill);
	}

	@Given("^I set \"([^\"]*)\" field as null$")
	public void i_set_field_as_null(String field) throws Throwable {
		if(!field.contains("_")) field = MiscTools.toCamelCase(field);
	    field = field.replaceAll("Id", "ID");field = field.replaceAll("Daw", "DAW");field = field.replaceAll("userID", "userId");
	    base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, field, JSONObject.NULL);
	}
	
	@Given("^I set \"([^\"]*)\" field as empty$")
	public void i_set_field_as_empty(String field) throws Throwable {
		if(!field.contains("_")) field = MiscTools.toCamelCase(field);
	    field = field.replaceAll("Id", "ID");field = field.replaceAll("Daw", "DAW");field = field.replaceAll("userID", "userId");
	    field = field.replaceAll("Guid", "GUID");
	    base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, field, "");
	}

	@Given("^I use a more than (\\d+) length \"([^\"]*)\"$")
	public void i_use_a_more_than_length(int length, String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
	    field = field.replaceAll("Id", "ID");
	    String newValue = MiscTools.getRandomString(length + 1);
	    base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, field, newValue);
	}

	@Given("^I fill Inventory field with an invalid Inventory Id$")
	public void i_fill_Inventory_field_with_an_invalid_Inventory_Id() throws Throwable {
		String invId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetInvalidInventoryId.toString());
		base.requestBodyJson.put("itemReference",Integer.parseInt(invId));
	}
	
	@Given("^I fill \"([^\"]*)\" field with a negative value$")
	public void i_fill_field_with_a_negative_value(String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
		int quantity = (MiscTools.getRandomInt(1, 10)*-1);
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, field, Integer.toString(quantity));
		//base.requestBodyJson.put(field, quantity);
		
	}
	
	@Given("^I fill \"([^\"]*)\" w/a valid date$")
	public void i_fill_w_a_valid_date(String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
		String date = MiscTools.addDaysToToday(MiscTools.getRandomInt(1, 60), "yyyy-MM-dd");
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, field, date);
	}
	
	@Given("^I fill \"([^\"]*)\" w/a prior today date$")
	public void i_fill_w_a_prior_today_date(String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
		String date = MiscTools.addDaysToToday(MiscTools.getRandomInt(-10, -1), "yyyy-MM-dd");
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, field, date);
	}

	@Given("^I use a \"([^\"]*)\" prior Today$")
	public void i_use_a_prior_Today(String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
		String date = MiscTools.addDaysToToday(MiscTools.getRandomInt(-10, -1), "yyyy-MM-dd");
		base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, field, date);
	}

	@Given("^I fill \"([^\"]*)\" field w/an invalid value$")
	public void i_fill_field_w_an_invalid_value(String field) throws Throwable {
		if(!field.contains("_")) field = MiscTools.toCamelCase(field);
	    field = field.replaceAll("Id", "ID");field = field.replaceAll("Daw", "DAW");field = field.replaceAll("userID", "userId");
	    String invalidValue = MiscTools.getRandomString(3);
	    base.requestBodyJson = JsonTools.updateKeys(base.requestBodyJson, field, invalidValue);
	}

	@Given("^I make sure \"([^\"]*)\" is not in the request$")
	public void i_make_sure_is_not_in_the_request(String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
		if(base.requestBodyJson == null){
			base.requestBodyArray = MiscTools.removeFromRequest(field,base.requestBodyArray);
			base.requestBody = base.requestBodyArray.toString();
		}else{
			base.requestBodyJson = JsonTools.deleteKey(base.requestBodyJson, field);
			base.requestBody = base.requestBodyJson.toString();
		}
	}

	@Given("^I make sure \"([^\"]*)\" is in the request$")
	public void i_make_sure_is_in_the_request(String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
		base.requestBodyJson.put(field, MiscTools.getRandomString(7));
		base.requestBody = base.requestBodyJson.toString();
	}

	@Given("^I use an invalid Phone Number format$")
	public void i_use_an_invalid_Phone_Number_format() throws Throwable {
		base.requestBodyJson = MiscTools.putInvalidPhoneFormat(base.requestBodyJson);
	}

	@Given("^I fill Quantity field w/a more than available Quantity$")
	public void i_fill_Quantity_field_w_a_more_than_available_Quantity() throws Throwable {
		invId = base.requestBodyJson.getString("itemReference");sb = base.prescription.get("sb");
		lot = base.requestBodyJson.getString("lot");
		query = String.format(SqlQueries.GetInvAvailableQty.toString(),invId,lot, sb);
		qty = MiscTools.executeSingleSelect(base.environment, query);
		int more = MiscTools.getRandomInt(1, 3);
		System.out.println("this is more ------"+more);
		base.requestBodyJson.put("quantity", Integer.parseInt(qty)+more);
	}
	
	@When("^I send a request to create one (?:Fill|Caregiver|Supply) record using old Url$")
	public void i_send_a_request_to_create_one_Fill_record_using_old_Url() throws Throwable {
		base.requestBodyArray = new JSONArray();
		base.requestBodyArray.put(base.requestBodyJson);
		base.requestBody = base.requestBodyArray.toString();
		String apiPath = MiscTools.getOldRxApiPathFromFill(base.prescription.get("refill"));
		System.out.println(apiPath);
//		base.response = base.serviceApi.create(apiPath, base.requestBody);
//    	base.responseBody = base.response.getBody().asString();
		base.oaResponse = base.oauthServiceApi.create(apiPath,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
    	System.out.println(base.responseBody);
    	MiscTools.printIdented("Prescription used: Service Branch->"+sb+" Prescription Id->"+rxId+ (refill == null?"":" Refill->"+refill)); 
	}
	
	@When("^I send a request to create one (?:Supply|Caregiver) record$")
	public void i_send_a_request_to_create_one_Caregiver_record() throws Throwable {
		base.requestBodyArray = new JSONArray();
		base.requestBodyArray.put(base.requestBodyJson);
		base.requestBody = base.requestBodyArray.toString();
		System.out.println(base.requestBody);
		String apiPath = MiscTools.getRxPostApiPathFromFill(base.prescription.get("rxId"), base.prescription.get("refill"));
		System.out.println(apiPath);
		base.oaResponse = base.oauthServiceApi.create(apiPath,base.requestBody);
		base.responseBody = base.oaResponse.getBody();
    	System.out.println(base.responseBody);
    	MiscTools.printIdented("Prescription used: Service Branch->"+sb+" Prescription Id->"+rxId+ (refill == null?"":" Refill->"+refill)); 
	}
	

	@When("^I send a request to \"([^\"]*)\" \"([^\"]*)\" information$")
	public void i_send_a_request_to_information(String arg1, String path) throws Throwable {
		String apiPath  = Path.valueOf(path).toString();
		String apiPathWithParams =  MiscTools.concatenateParams(apiPath,base.params);
		System.out.println(apiPathWithParams);
    	base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams);
		base.responseBody = base.oaResponse.getBody();
    	MiscTools.printIdented("Prescription used: Service Branch->"+base.sb+" Prescription Id->"+base.rxId+ (base.refill == null?"":" Refill->"+base.refill));
	}

	@Then("^the response status should be \"([^\"]*)\"$")
	public void the_response_status_should_be(String statusDescription) throws Throwable {
		statusDescription = statusDescription.replaceAll("\\s+", "");
		StatusCode status = StatusCode.valueOf(statusDescription);
		int statusCode = base.response == null ? base.oaResponse.getStatusCode().value():base.response.getStatusCode();
		Assert.assertEquals(status.getStatusCode(), statusCode);
		//base.response.then().statusCode(status.getStatusCode());
	}
	
	@Then("^the response status should not be \"([^\"]*)\"$")
	public void the_response_status_should_not_be(String statusDescription) throws Throwable {
		statusDescription = statusDescription.replaceAll("\\s+", "");
		StatusCode status = StatusCode.valueOf(statusDescription);
		int statusCode = base.response == null ? base.oaResponse.getStatusCode().value():base.response.getStatusCode();
		System.out.println("Status Code: "+statusCode);
		Assert.assertNotEquals(status.getStatusCode(), statusCode);
		//base.response.then().statusCode(status.getStatusCode());
	}
	
	@Then("^the response message should be \"([^\"]*)\"$")
	public void the_response_message_should_be(String resMessage) throws Throwable {
		resMessage = resMessage.replaceAll("\\s+", "");
		String responseMessage = ResponseMessage.valueOf(resMessage).toString();
		String message = base.response == null?MiscTools.getMsgFromRes(base.oaResponse.getBody()):MiscTools.getMsgFromRes(base.responseBody);
		message = message.replaceAll("Please check the error is ", "");
		Assert.assertEquals(responseMessage, message);
	}

	@Then("^the response status message should be \"([^\"]*)\"$")
	public void the_response_status_message_should_be(String resMessage) throws Throwable {
		resMessage = resMessage.replaceAll("\\s+", "");
		String responseMessage = ResponseMessage.valueOf(resMessage).toString();
		String message = base.response == null?MiscTools.getMsgFromRes(base.oaResponse.getBody()):MiscTools.getMsgFromRes(base.responseBody);
		Assert.assertEquals(responseMessage, message);
	}
	
	@Then("^\"([^\"]*)\" field should be present in response$")
	public void field_should_be_present_in_response(String field) throws Throwable {
		field = MiscTools.toCamelCase(field);
		Assert.assertTrue(MiscTools.responseHasKey(field, base.responseBody));
	}

	@Then("^I should get error \"([^\"]*)\"$")
	public void i_should_get_error(String expectedError) throws Throwable {
		expectedError = expectedError.replaceAll("\\s+", "");
		expectedError = ResponseMessage.valueOf(expectedError).toString();
		String actualError = MiscTools.getErrorFromRes(base.responseBody);
		Assert.assertEquals(expectedError, actualError);
	}
	
	@Then("^I should get error \"([^\"]*)\" in \"([^\"]*)\"$")
	public void i_should_get_error_in(String expectedError, String path) throws Throwable {
		expectedError = expectedError.replaceAll("\\s+", "");
		expectedError = ResponseMessage.valueOf(expectedError).toString();
		String actualError = MiscTools.getErrorFromRes(base.responseBody);
		Assert.assertEquals(expectedError, actualError);
	}

	@Then("^I should get no errors$")
	public void i_should_get_no_errors() throws Throwable {
		String actualError = MiscTools.getErrorFromRes(base.responseBody);
		Assert.assertEquals("null", actualError);
	}

	@Then("^I should get no prescription errors$")
	public void i_should_get_no_prescription_errors() throws Throwable {
		JSONObject jsonResponseBody = new JSONObject(base.responseBody);
		String currentErrors = jsonResponseBody.getString("x_errors");
		Assert.assertEquals("null", currentErrors);
	}
	
	@Then("^the response body should be empty$")
	public void the_response_should_be_empty() throws Throwable {
		Assert.assertEquals("[]",base.response.body().jsonPath().getString("message"));
	}
	
	@Then("^\"([^\"]*)\" tag value in XML response should be \"([^\"]*)\"$")
	public void tag_value_in_XML_response_should_be(String tagName, String ExptagValue) throws Throwable {
		tagName = tagName.replaceAll("\\s+", "");
		String tagValue = XmlTools.getXmlNodeValue(base.responseBody, tagName);
		Assert.assertEquals(ExptagValue,tagValue);
	}

	@Then("^\"([^\"]*)\" field in response should not be \"([^\"]*)\"$")
	public void field_in_response_should_not_be(String field, String expectedValue) throws Throwable {
		JSONObject jsonResponseBody = new JSONObject(base.responseBody);
		String actualValue = jsonResponseBody.getString(field);
		Assert.assertNotEquals(expectedValue, actualValue);
	}

	@Then("^\"([^\"]*)\" field in response should be \"([^\"]*)\"$")
	public void field_in_response_should_be(String field, String expectedValue) throws Throwable {
		JSONObject jsonResponseBody = new JSONObject(base.responseBody);
		String actualValue = jsonResponseBody.getString(field);
		Assert.assertEquals(expectedValue, actualValue);
	}

	@Then("^I should get error Quantity is more than available$")
	public void i_should_get_error_Quantity_is_more_than_available() throws Throwable {
		String expectedError = ResponseMessage.QtyIsMorathatAvailble.toString();
		expectedError = String.format(expectedError, invId, qty);
		String actualError = MiscTools.getErrorFromRes(base.responseBody);
		Assert.assertEquals(expectedError, actualError);
	}

}
