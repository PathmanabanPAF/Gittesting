package StepDefinitions;

import org.junit.Assert;

import static org.junit.Assert.*;
import GlobalClasses.ApiPaths;
import GlobalClasses.AssessmentQuestions;
import GlobalClasses.BaseUtil;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SubmitOrder_StepDefinitions extends BaseUtil{
	
	public String requestBody;
	public String ExpecMedsOnHandAnswer;
	public int prevAssmntCount, postAssmntCount;
	private BaseUtil base;
	
	public SubmitOrder_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
//	@Given("^I get a prescription with the following criteria$")
//	public void i_get_a_prescription_with_the_following_criteria(String criteriaString) throws Throwable {
//		String[] criteria  = MiscTools.toList(criteriaString);
//		String query = SqlQueries.valueOf(StringUtils.join(criteria, "")).toString();
//		
////		prescription = MiscTools.executeSingleRowSelect(base.environment, query);
////		sb = prescription.get("SVCBR_ID");
////		rx = prescription.get("PRESCRIPTION_ID");
////		refill = prescription.get("REFILL_NO");
////		patientId = prescription.get("PATIENT_ID");
////		MiscTools.printIdented("Prescription used: "+sb+"-"+rx+"-"+refill);
//	}

	@Given("^I set up a request with it$")
	public void i_set_up_a_request_with_it() throws Throwable {
		requestBody = XmlTools.readXmlFile(ResourcePaths.ORDER_ASM_REQ);
		MiscTools.deliveryDaysSetup(base.prescription,base.environment);
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "SvcbrId",  base.prescription.get("sb"));
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "PrescriptionId", base.prescription.get("rx"));
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "RefillNo",  base.prescription.get("refill"));
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "EstimatedDeliveryDate", MiscTools.getTomorrowDate());
		requestBody = XmlTools.updateXmlNodeValue(requestBody, "DeliveryDate", MiscTools.getTodayDate());
		ExpecMedsOnHandAnswer = XmlTools.getXmlNodeValue(requestBody, "MedsOnHand");
	}

	@When("^I send my request to create an assessment$")
	public void i_send_my_request_to_create_an_assessment() throws Throwable {
		String query = "select count(session_id) from ADM.dm_sessions where patient_id = "+ base.prescription.get("patient_id");
		prevAssmntCount = Integer.parseInt(MiscTools.executeSingleSelect(base.environment, query));
		base.response = base.serviceApi.create(ApiPaths.SUBMIT_ORDER, requestBody);
		base.responseBody = base.response.getBody().asString();
		System.out.println(base.responseBody);
	}

	@Then("^the assessment should be created$")
	public void the_assessment_should_be_created() throws Throwable {
		String query = "select count(session_id) from ADM.dm_sessions where patient_id = "+ base.prescription.get("patient_id");
		postAssmntCount = Integer.parseInt(MiscTools.executeSingleSelect(base.environment, query));
		assertTrue(prevAssmntCount< postAssmntCount);
	}

	@Then("^the prescription should be updated$")
	public void the_prescription_should_be_updated() throws Throwable {
		String orderStatus = XmlTools.getXmlNodeValue(base.responseBody, "OrderStatus");
		Assert.assertEquals("UPDATED",orderStatus);
		String query = "select est_delivery_date from prescriptions where svcbr_id = "+base.prescription.get("sb").toString()+"and prescription_id ="+base.prescription.get("rx").toString()+"and refill_no =" +base.prescription.get("refill").toString();
		assertNotNull(MiscTools.executeSingleSelect(base.environment, query));
	}

	@Then("^the assessment should NOT be created$")
	public void the_assessment_should_NOT_be_created() throws Throwable {
		String query = "select count(session_id) from ADM.dm_sessions where patient_id = "+base.prescription.get("patient_id").toString();
		postAssmntCount = Integer.parseInt(MiscTools.executeSingleSelect(base.environment, query));
		assertEquals(prevAssmntCount, postAssmntCount);
	}

	@Then("^prescription's refill should be created$")
	public void prescription_s_refill_should_be_created() throws Throwable {
		String orderStatus = XmlTools.getXmlNodeValue(base.responseBody, "OrderStatus");
		assertEquals("REFILLED",orderStatus);
		String query = "select max(refill_no) as \"MaxRefill\" from prescriptions where svcbr_id = "+base.prescription.get("sb").toString()+" and prescription_id = "+base.prescription.get("rx").toString();
		String currentRefill = MiscTools.executeSingleSelect(base.environment, query);
		assertTrue(Integer.parseInt(base.prescription.get("refill"))< Integer.parseInt(currentRefill));
	}
	@Then("^drugs on hand answer should match request data$")
	public void drugs_on_hand_answer_should_match_request_data() throws Throwable {
	    String sessionId = MiscTools.getLastAssessment(base.environment, base.prescription.get("patient_id"));
	    String actualMedsOnHandAnswer = MiscTools.getAssessmentAnswer(base.environment, sessionId,AssessmentQuestions.MED_ON_HAND);
	    assertEquals(ExpecMedsOnHandAnswer, actualMedsOnHandAnswer);
	}

}
