package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;
import io.restassured.response.Response;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

public class Post_V3_Payments_SSPSS_1411 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;
	String accredopatientid,billingseq;
	
	public Post_V3_Payments_SSPSS_1411(BaseUtil base){
		this.base = base;
	}

	@Given("^I have valid accredo Patient id, Valid Payment method & valid Card type$")
	public void i_have_valid_accredo_Patient_id_Valid_Payment_method_valid_Card_type() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		accredopatientid=Readproperty("TC1_accredopatientid");
		System.out.println("Accredo patientid: "+accredopatientid);
		billingseq=Readproperty("TC1_billingaddresssq");
		System.out.println("Billing seq: "+billingseq);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Payment_API_V3_TC1);
		JsonTools.updateKeys(base.requestBodyJson, "accredoPatientId", accredopatientid);
		JsonTools.updateKeys(base.requestBodyJson, "billingAddressSequence", billingseq);
		System.out.println("json file: "+base.requestBodyJson);
		//String tc1_xml=Readproperty("SSPSS_TC1_xml");
		//System.out.println("XML:"+tc1_xml);
		//tc1_xml="{"+tc1_xml+"}";
		
	}

	@When("^I send a request to create one payment V(\\d+) record$")
	public void i_send_a_request_to_create_one_payment_V_record(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("APIpath"+ApiPaths.PAYMENT_API_V3);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.PAYMENT_API_V3,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
	}

	@Then("^I should get new Card_key_id for payment processed$")
	public void i_should_get_new_Card_key_id_for_payment_processed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String paymentmethodid=JsonTools.findKeys(jsonResponseBody, "paymentMethodId");
		System.out.println("Confimation No:  "+paymentmethodid);
	}
	
	//Sceanrio2
	@Given("^I have valid accredo patient, invalid Credit card number$")
	public void i_have_valid_accredo_patient_invalid_Credit_card_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Payment_API_V3_TC2);
		System.out.println("json file: "+base.requestBodyJson);
	}

	
	@Then("^the response status (\\d+) Conflict$")
	public void the_response_status_Conflict(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		int status =base.oaResponse.getStatusCode().value();
		System.out.println("Not STATUS"+status);
		int expected_status=409;
		Assert.assertEquals(expected_status, status);
	}


	//Scenario3

	@Given("^I have valid accredo patient, invalid payment type$")
	public void i_have_valid_accredo_patient_invalid_payment_type() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Payment_API_V3_TC3);
		System.out.println("json file: "+base.requestBodyJson);
	}

	public String Readproperty(String name)
	{
		Properties prop = new Properties();
		InputStream input = null;
		String name1 = null;
		try {

		input = new FileInputStream("C:\\Specialty-Data-Services-Test-Suit-destiny-sprint-11\\input_SSquad.properties");
		
		// load a properties file
		prop.load(input);

		// get the property value and print it out
		
		if(name.contentEquals("TC1_accredopatientid"))
		{
		 name1=prop.getProperty("TC1_accredopatientid");
		}
		else
		if(name.contentEquals("TC1_billingaddresssq"))
		{
		name1=prop.getProperty("TC1_billingaddresssq");
		}
		
		//System.out.println(prop.getProperty("dbuser"));
		//System.out.println(prop.getProperty("dbpassword"));

		} catch (IOException ex) {
			System.out.println("Error");
			ex.printStackTrace();
	
	}
		return name1;
}

}
