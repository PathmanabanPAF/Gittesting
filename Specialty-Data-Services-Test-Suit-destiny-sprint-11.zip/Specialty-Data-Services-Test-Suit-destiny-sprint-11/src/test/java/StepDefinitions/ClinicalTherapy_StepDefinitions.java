package StepDefinitions;

import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.MiscTools;
import GlobalEnums.SqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class ClinicalTherapy_StepDefinitions extends BaseUtil{
	private BaseUtil base;
	public JSONObject jsonClinicalTherapyInfo;
	public JSONObject jsonResponseBody;
	
	public ClinicalTherapy_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I get a valid Direct Patient w/Therapies Id$")
	public void i_get_a_valid_Direct_Patient_w_Therapies_Id() throws Throwable {
		base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetDirectPatientWithTherapies.toString());
	}

	@Given("^I get a valid Itegrated Patient w/Therapies Id$")
	public void i_get_a_valid_Itegrated_Patient_w_Therapies_Id() throws Throwable {
		base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetIntegratedPatientWithTherapies.toString());
	}

	@Given("^I get a valid Direct Patient w/o Therapies Id$")
	public void i_get_a_valid_Direct_Patient_w_o_Therapies_Id() throws Throwable {
		base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetDirectPatientWithoutTherapies.toString());
	}

	@Given("^I get a valid Itegrated Patient w/o Therapies Id$")
	public void i_get_a_valid_Itegrated_Patient_w_o_Therapies_Id() throws Throwable {
		base.patientId = MiscTools.executeSingleSelect(base.environment, SqlQueries.GetIntegratedPatientWithoutTherapies.toString());
	}

	@When("^I send a request to retrieve Patient's Therapies$")
	public void i_send_a_request_to_retrieve_Patient_s_Therapies() throws Throwable {
		base.response = base.serviceApi.retrive(ApiPaths.CLINICAL_THERAPY+base.patientId);
    	base.responseBody = base.response.getBody().asString();
    	MiscTools.printIdented("Patient Id used: "+base.patientId);
	}

	@When("^I should get the correct Patient's Clinical Therapy Information$")
	public void i_should_get_the_correct_Patient_s_Clinical_Therapy_Information() throws Throwable {
		jsonClinicalTherapyInfo = GetResponses.createClinicalTherapyResponse(base.patientId, base.environment);
		jsonResponseBody = new JSONObject(base.responseBody);
		JSONAssert.assertEquals(jsonClinicalTherapyInfo,jsonResponseBody,JSONCompareMode.NON_EXTENSIBLE);
	}
}
