package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;

public class Regression_Destiny extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;
	String inventoryid,rxnumber,rxstdate,rxwrittendate,rxexpdate,shipdate,filldate,accredopatient_id;

	public Regression_Destiny(BaseUtil base){
		this.base = base;
	}
	
	
	//Scenario1
	@Given("^I have valid accredo patient id, prescription details$")
	public void i_have_valid_accredo_patient_id_prescription_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_new);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@When("^I send a request to insert new prescription record$")
	public void i_send_a_request_to_insert_new_prescription_record() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("APIpath"+ApiPaths.PRESCRIPTION);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.PRESCRIPTION_NEW,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
	}
	
	@Then("^the response status should be \"([^\"]*)\" with (\\d+)$")
	public void the_response_status_should_be_with(String arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		int status =base.oaResponse.getStatusCode().value();
		System.out.println("STATUS"+status);
		int expected_status=201;
		Assert.assertEquals(expected_status, status);
	}


	@Then("^should get new RxNumber$")
	public void should_get_new_RxNumber() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Will get prescription Id");
		String prescriptionid=JsonTools.findKeys(jsonResponseBody, "x_rxNumber");
		System.out.println("Prescription Id:  "+prescriptionid);
	}


	//Scenario2
	@Given("^I have valid accredo patient id, fill details$")
	public void i_have_valid_accredo_patient_id_fill_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Prescription_fill);
		//String prescriptionid=JsonTools.findKeys(base.requestBodyJson, "processingPharmacy");
		//JsonTools.updateKeys(base.requestBodyJson, "processingPharmacy", "123");
		System.out.println("XML:"+base.requestBodyJson);
	}

	@When("^I send a request to insert new fill record$")
	public void i_send_a_request_to_insert_new_fill_record() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("APIpath"+ApiPaths.PRESCRIPTION);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.PRESCRIPTION_FILL,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
	}
	
	//Scenario3 
   //Updating inventory Id 
	@Given("^I have valid accredo patient id, prescriped item details$")
	public void i_have_valid_accredo_patient_id_prescriped_item_details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		inventoryid=Readproperty("Regression3_Inventory_id");
		System.out.println("inventory: "+inventoryid);
		rxnumber=Readproperty("Regression3_RxNumber");
		System.out.println("rxnumber: "+rxnumber);
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.prescription_prescribed_item);
		JsonTools.updateKeys(base.requestBodyJson, "rxNumber", rxnumber);
		JsonTools.updateKeys(base.requestBodyJson, "itemReference", inventoryid);
		System.out.println("XML:"+base.requestBodyJson);
		
	}

	@When("^I send a request to insert new prescriped item record$")
	public void i_send_a_request_to_insert_new_prescriped_item_record() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		//Updating Resource
		System.out.println("APIpath"+ApiPaths.PRESCRIPTION_PRESCRIPED_ITEM+"/"+rxnumber+"/prescribedItems/");
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.PRESCRIPTION_PRESCRIPED_ITEM+"/"+rxnumber+"/prescribedItems/","["+base.requestBodyJson.toString()+"]");
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
	}

	//Scenario4

	@Given("^I have valid accredo patient id, prescription details, fill details, add item details$")
	public void i_have_valid_accredo_patient_id_prescription_details_fill_details_add_item_details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		/*accredopatient_id=Readproperty("accredopatient_id");
		System.out.println("accredopatient_id: "+accredopatient_id);
		rxstdate=Readproperty("rx_start_date");
		System.out.println("rxdate: "+rxstdate);
		rxwrittendate=Readproperty("writtenDate");
		System.out.println("rxnumber: "+rxwrittendate);
		rxexpdate=Readproperty("expirationDate");
		System.out.println("rxnumber: "+rxexpdate);
		shipdate=Readproperty("shipdate");
		System.out.println("shipdate: "+shipdate);
		filldate=Readproperty("filldate");
		System.out.println("filldate: "+filldate);
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.prescription_singlecall);
		JsonTools.updateKeys(base.requestBodyJson, "legacyPatientID", accredopatient_id);
		JsonTools.updateKeys(base.requestBodyJson, "rx_start_date", rxstdate);
		JsonTools.updateKeys(base.requestBodyJson, "writtenDate", rxwrittendate);
		JsonTools.updateKeys(base.requestBodyJson, "expirationDate", rxexpdate);
		JsonTools.updateKeys(base.requestBodyJson, "shipDate", shipdate);
		JsonTools.updateKeys(base.requestBodyJson, "fillDate", filldate);*/
		//System.out.println("XML:"+base.requestBodyJson);
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.prescription_singlecall);
		System.out.println("XML:"+base.requestBodyJson);
		
	}

	@When("^I send a request to insert new prescription record for single call prescription$")
	public void i_send_a_request_to_insert_new_prescription_record_for_single_call_prescription() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		System.out.println("APIpath"+ApiPaths.PRESCRIPTION);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.PRESCRIPTION,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);

	}
	
	public String Readproperty(String name)
	{
		Properties prop = new Properties();
		InputStream input = null;
		String name1 = null;
		try {

		input = new FileInputStream("C:\\Specialty-Data-Services-Test-Suit-destiny-sprint-11\\input.properties");
		
		// load a properties file
		prop.load(input);

		// get the property value and print it out
		
		if(name.contentEquals("Regression3_Inventory_id"))
		{
		 name1=prop.getProperty("Regression3_Inventory_id");
		}
		else
		if(name.contentEquals("Regression3_RxNumber"))
		{
		name1=prop.getProperty("Regression3_RxNumber");
		}
		else
		if(name.contentEquals("rx_start_date"))
		{
		name1=prop.getProperty("rx_start_date");
		}
		else
		if(name.contentEquals("writtenDate"))
		{
		name1=prop.getProperty("writtenDate");
		}
		else
		if(name.contentEquals("expirationDate"))
		{
		name1=prop.getProperty("expirationDate");
		}
		else
		if(name.contentEquals("shipdate"))
		{
		name1=prop.getProperty("shipdate");
		}
		else
		if(name.contentEquals("filldate"))
		{
		name1=prop.getProperty("filldate");
		}
		else
		if(name.contentEquals("accredopatient_id"))
		{
		name1=prop.getProperty("accredopatient_id");
		}
		//System.out.println(prop.getProperty("dbuser"));
		//System.out.println(prop.getProperty("dbpassword"));

		} catch (IOException ex) {
			System.out.println("Error");
			ex.printStackTrace();
	
	}
		return name1;
}

	
}
