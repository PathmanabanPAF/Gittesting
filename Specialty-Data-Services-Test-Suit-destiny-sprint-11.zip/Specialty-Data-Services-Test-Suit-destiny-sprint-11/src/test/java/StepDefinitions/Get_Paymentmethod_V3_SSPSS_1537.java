package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;
import io.restassured.response.Response;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

public class Get_Paymentmethod_V3_SSPSS_1537 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject accredopatientid, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;
	String PatientId1;

	public Get_Paymentmethod_V3_SSPSS_1537(BaseUtil base){
		this.base = base;
	}
	
	//Scenario1
	@Given("^I have valid accredo Patient id$")
	public void i_have_valid_accredo_Patient_id() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		PatientId1=Readproperty("TC1_accredopatientid");
		System.out.println("Patientid: "+PatientId1);
	}

	@When("^I send a request to get paymentV(\\d+) information for given patientid$")
	public void i_send_a_request_to_get_paymentV_information_for_given_patientid(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		String apiPathWithParams =  MiscTools.concatenateParams(ApiPaths.PAYMENT_API_Get_V3,base.params);
		System.out.println("API path with parameteres:" +apiPathWithParams);
		//Get Request
    	base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams+PatientId1);
		//base.response=base.serviceApi.retrive("");
		base.responseBody = base.oaResponse.getBody();
		base.responseBody="["+base.responseBody+"]";
		System.out.println("Response body: "+base.responseBody);
	}

	@Then("^I should get paymentV(\\d+) information for given patientid$")
	public void i_should_get_paymentV_information_for_given_patientid(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		accredopatientid=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+accredopatientid);
		String legacyPatientId=JsonTools.findKeys(accredopatientid, "accredoPatientId");
        System.out.println("patient id: "+legacyPatientId);
	}

	//Scenario2
	@Given("^I have invalid accredo patient$")
	public void i_have_invalid_accredo_patient() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		PatientId1=Readproperty("TC2_accredopatientid");
		System.out.println("Patientid: "+PatientId1);
	}

	@Then("^I should get error message \"([^\"]*)\"$")
	public void i_should_get_error_message(String arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+messageinfo);
		String search=JsonTools.findKeys(messageinfo, "message");
        System.out.println("Search Results: "+search);
	}

	//Scenario3
	@Given("^I have empty accredo patient$")
	public void i_have_empty_accredo_patient() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		PatientId1=Readproperty("TC3_accredopatientid");
		System.out.println("Patientid: "+PatientId1);
	}
	
	@Then("^the response status (\\d+) error$")
	public void the_response_status_error(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		int status =base.oaResponse.getStatusCode().value();
		System.out.println("Not STATUS"+status);
		int expected_status=404;
		Assert.assertEquals(expected_status, status);
	}

	@Then("^I should get error message shown \"([^\"]*)\"$")
	public void i_should_get_error_message_shown(String arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		messageinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+messageinfo);
		String search=JsonTools.findKeys(messageinfo, "message");
        System.out.println("Search Results: "+search);
	}

	public String Readproperty(String name)
	{
		Properties prop = new Properties();
		InputStream input = null;
		String name1 = null;
		try {

		input = new FileInputStream("C:\\Specialty-Data-Services-Test-Suit-destiny-sprint-11\\input_SSquad.properties");
		
		// load a properties file
		prop.load(input);

		// get the property value and print it out
		
		if(name.contentEquals("TC1_accredopatientid"))
		{
		 name1=prop.getProperty("TC1_accredopatientid");
		}
		else if(name.contentEquals("TC2_accredopatientid"))
		{
			 name1=prop.getProperty("TC2_accredopatientid");
		}
		else if(name.contentEquals("TC3_accredopatientid"))
		{
			 name1=prop.getProperty("TC3_accredopatientid");
		}
				//System.out.println(prop.getProperty("dbuser"));
		//System.out.println(prop.getProperty("dbpassword"));

		} catch (IOException ex) {
			System.out.println("Error");
			ex.printStackTrace();
	
	}
		return name1;
}

}
