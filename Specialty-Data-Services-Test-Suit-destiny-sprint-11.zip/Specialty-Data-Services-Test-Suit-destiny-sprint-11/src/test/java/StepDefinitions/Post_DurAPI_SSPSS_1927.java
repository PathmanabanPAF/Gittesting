package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;

public class Post_DurAPI_SSPSS_1927 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public Post_DurAPI_SSPSS_1927(BaseUtil base){
		this.base = base;
	}
	
	//Scenario1
	@Given("^I have valid DUR id, overrride code, alert message CD$")
	public void i_have_valid_DUR_id_overrride_code_alert_message_CD() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.AutoResolve_PostDUR_Testc1);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^I should get CD alerts auto-resolved$")
	public void i_should_get_CD_alerts_auto_resolved() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
	}
	
	//Scenario2
	@Given("^I have valid DUR id, overrride code, alert message DA$")
	public void i_have_valid_DUR_id_overrride_code_alert_message_DA() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.AutoResolve_PostDUR_Testc2);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^I should get DA alerts auto-resolved$")
	public void i_should_get_DA_alerts_auto_resolved() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
	}

	//Scenario3
	@Given("^I have valid DUR id, overrride code, alert message SX$")
	public void i_have_valid_DUR_id_overrride_code_alert_message_SX() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.AutoResolve_PostDUR_Testc3);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^I should get SX alerts auto-resolved$")
	public void i_should_get_SX_alerts_auto_resolved() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
	}
	
	//Scenario4
	@Given("^I have valid DUR id, overrride code, alert message PG$")
	public void i_have_valid_DUR_id_overrride_code_alert_message_PG() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.AutoResolve_PostDUR_Testc4);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^I should get PG alerts auto-resolved$")
	public void i_should_get_PG_alerts_auto_resolved() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
	}

	//Scenario5
	@Given("^I have valid DUR id, overrride code, alert message DC$")
	public void i_have_valid_DUR_id_overrride_code_alert_message_DC() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.AutoResolve_PostDUR_Testc5);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@Then("^I should get DC alerts auto-resolved$")
	public void i_should_get_DC_alerts_auto_resolved() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
	}
}
