package StepDefinitions;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import GlobalClasses.ApiTools;
import GlobalClasses.BaseUtil;
import GlobalClasses.DBConnection;
import GlobalClasses.WSCredentials;

import java.sql.*;

import org.json.JSONException;
import org.json.JSONObject;

import com.jayway.restassured.response.Response;

public class StepDefinitions  {
	private static String patientIdGet;
	private static String patientIdWithCC;
	private static String patientIdWithOutCC;
	private static String cardKeyId;
	private static String method;
	private static final String creditCard = "4556182014817213";
	public static String[] arraycredentials;
	private BaseUtil base;
	String query;
	String apiPath;
	String requestBody;
	String responseBody;
	Response response;
	String status;
	String auxPatientValue = "N";
	
	public StepDefinitions(BaseUtil base){this.base = base;};
	
	public static String getPatientIdWithOutCC(){return patientIdWithOutCC;	}
	public static String getcreditCard(){return creditCard;}
	public static String getpatientIdGet(){return patientIdGet;}
	public static String getcardKeyId(){return cardKeyId;}
	public static String getpatientIdWithCC(){return patientIdWithCC;}
	public static String getMethod(){return method;}
	public static String[] getarraycredentials(){return arraycredentials;}
		
	@Given("^Some scenarios must be run on \"([^\"]*)\" environment$")
	public void some_scenarios_must_be_run_on_environment(String env) throws Throwable {
		base.environment = env;
	}
	
	

	
	@Given("^I get a patient without a credit card$")
	public void i_get_a_patient_without_a_credit_card() throws Throwable {
	    // Getting patient without Credit/Debit Card
		if(method == null || method.isEmpty()){
			DBConnection  db = new DBConnection(base.environment);
			query = "SELECT PT.ID FROM THOT.PATIENTS_TABLE PT WHERE PT.CREATED_DATE > (SYSDATE-90) AND PT.ID NOT IN ( SELECT CC.PATIENT_ID FROM THOT.CREDIT_CARD_PT_DETAILS CC)AND ROWNUM =1";
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
					patientIdWithOutCC = rs.getString(1);
				}
			}catch(SQLException e){
				e.getStackTrace();
			}finally{
				db.Close();
			}
		}else if("Get".equals(method)){
			DBConnection  db = new DBConnection(base.environment);
			query = "SELECT PT.ID FROM THOT.PATIENTS_TABLE PT WHERE PT.CREATED_DATE > (SYSDATE-90) AND PT.ID NOT IN ( SELECT CC.PATIENT_ID FROM THOT.CREDIT_CARD_PT_DETAILS CC)AND ROWNUM =1";
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
					patientIdGet = rs.getString(1);
				}
				
			}catch(SQLException e){
				e.getStackTrace();
			}finally{
				db.Close();
			}
			
		}else if("Delete".equals(method)){
			DBConnection  db = new DBConnection(base.environment);
			query = "SELECT PT.ID FROM THOT.PATIENTS_TABLE PT WHERE PT.CREATED_DATE > (SYSDATE-90) AND PT.ID NOT IN ( SELECT CC.PATIENT_ID FROM THOT.CREDIT_CARD_PT_DETAILS CC)AND ROWNUM =1";
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
					patientIdGet = rs.getString(1);
				}
				
			}catch(SQLException e){
				e.getStackTrace();
			}finally{
				db.Close();
			}
		}
			
	}
	@When("^I request from the service the \"([^\"]*)\"$")
	public void i_request_from_the_service_the(String service) throws Throwable {
		arraycredentials = WSCredentials.webServicesCredentials(service,base.environment);
	}


	
	@When("^in order to proceed to \"([^\"]*)\" a Credit/Debit Card$")
	public void in_order_to_proceed_to_a_Credit_Debit_Card(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		ApiTools paymentMethodApi = new ApiTools(arraycredentials[0],arraycredentials[1],arraycredentials[2]);
		method = arg1;
		if("Add".equals(method)){
			System.out.println("Patient :"+patientIdWithOutCC);
			apiPath = "/v1/AccredoPega";
			requestBody = new JSONObject()
			.put("patient", new JSONObject()
	        	.put("id", patientIdWithOutCC)
	        		)
			.put("paymentMethod", new JSONObject()
	        	.put("paymentMethodType","PERSONAL CREDIT")
	        	.put("cardIssuer","VISA")
				.put("creditCardNumber", creditCard)
				.put("usageType","AUTO-CHARGE")
				.put("expiration", new JSONObject()
	             	.put("month","12")
	             	.put("year","2020")
	             )
			).toString();
			
			response = paymentMethodApi.create(apiPath, requestBody);
		}else if("Get".equals(method)){
			apiPath = "/v1/AccredoPega/patients/"+ patientIdWithOutCC;
			response = paymentMethodApi.retrive(apiPath);
			responseBody = response.getBody().asString();
			
		}else if("Update".equals(method)){
			System.out.println("Card Key Id :"+cardKeyId);
			apiPath = "/v1/AccredoPega/cards/+cardKeyId";
		}else if("Delete".equals(method)){
			System.out.println("Patient :"+patientIdWithOutCC);
			apiPath = "/v1/AccredoPega/patients/"+ patientIdWithOutCC +"/cards/"+cardKeyId;
			
			requestBody = new JSONObject()
			.put("patient", new JSONObject()
	        	.put("id", patientIdWithOutCC)
	        		).toString();
			response = paymentMethodApi.delete(apiPath, requestBody);
			responseBody = response.getBody().asString();
		}
		
		
		
		
		

	}

	@Then("^The response status should be \"([^\"]*)\"$")
	public void the_response_status_should_be(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if(method.equals("Add") || method == null){
			DBConnection  db = new DBConnection(base.environment);
			this.query = "SELECT 'Success' FROM THOT.CREDIT_CARD_PT_DETAILS WHERE PATIENT_ID = "+patientIdWithOutCC;
			db.ExecuteSelect(query);
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
					status = rs.getString(1);
				}
				
			}catch(SQLException e){
				e.getStackTrace();
			}finally{
				db.Close();
			}
//			if(status.equals(arg1)){
//				System.out.println("Status :"+status);
//			}else{
//				status = "Fail";
//				System.out.println("Status :"+status);
//			}
//			if("Fail".equals(arg1)){
//				method = "Get";
//			}
		}else if(method.equals("Get")){
			int code = response.statusCode();
			if(code == 200){
				if(response.getBody().asString().length() < 50){
					status = "Fail";
					System.out.println("Status :"+status);
				}else{
					status = "Success";
					System.out.println("Status :"+status);	
				}
			}else{
				status = "Fail";
				System.out.println("Status :"+status);
			}
			if("Fail".equals(arg1)){
				method = "Update";
			}
			
		}else if(method.equals("Update")){
			int code = response.statusCode();
			if(code == 200){
				if(response.getBody().asString().contains("{}")){
					status = "Success";
					System.out.println("Status :"+status);
				}else{
					status = "Fail";
					System.out.println("Status :"+status);	
				}
			}
			if("Fail".equals(arg1)){
				method = "Delete";
			}
		}else if(method.equals("Delete")){
			
			try{
				
				int code = response.getStatusCode();
				if(code == 200){
					if(response.getBody().asString().contains("{}")){
						status = "Success";
						System.out.println("Status :"+status);
					}else{
						status = "Fail";
						System.out.println("Status :"+status);	
					}
				}else if(code == 500){
					status = "Fail";
					System.out.println("Status :"+status);
				}
				
				
				
				
				responseBody = response.getBody().asString();
				JSONObject responseBodyJson = new JSONObject(responseBody);
				String responseFail = responseBody.toString();
				if(responseBodyJson.toString().contains("Credit card already exists for this patient")){
					System.out.println("Credit card already exists for this patient");
				}else if(responseBodyJson.toString().contains("Card number is not valid")){
					System.out.println("Card number is not valid");
				}else if(responseBodyJson.toString().contains(responseFail)){
					System.out.println("The Patient doesn't have a valid Credit/Debit Card--");
					status = "Fail";
					System.out.println("Status :"+status);
				}else if(responseBodyJson.toString().contains("Card id does not exist")){
					System.out.println("The Card id does not exist");
				}else if(responseBodyJson.toString().contains(" The card is already deactivated")){
					System.out.println("The card is already deactivated");
				}
			}catch(JSONException eJson){
				eJson.getMessage();
			}
			
			
			
			
		};
		
		
	}

//////////////////////////////////////////////////////////////////// Negative Scenario 	
	
	@Given("^I get a patient with a credit card$")
	public void i_get_a_patient_with_a_credit_card() throws Throwable {
		if("Add".equals(method)){
			DBConnection  db = new DBConnection(base.environment);
			if(auxPatientValue != "Y"){
				query = "SELECT PATIENT_ID,CARD_KEY_ID FROM (SELECT PATIENT_ID, CARD_KEY_ID FROM THOT.CREDIT_CARD_PT_DETAILS WHERE  CREATION_DATE > (SYSDATE-90) ORDER BY SYS.DBMS_RANDOM.RANDOM) WHERE ROWNUM =1";
			}else{
				query = "SELECT PATIENT_ID,CARD_KEY_ID FROM THOT.CREDIT_CARD_PT_DETAILS WHERE PATIENT_ID ="+patientIdWithOutCC; 
				auxPatientValue = "Y";
			}	
				try{
					ResultSet rs = db.ExecuteSelect(query);
					while(rs.next()){
						patientIdWithCC = rs.getString(1);
						cardKeyId = rs.getString(2);
					}
				
				}catch(SQLException e){
					e.getStackTrace();
				}finally{
					db.Close();
				}
			}
		if(method.equals("Get") && patientIdWithOutCC != null){
			System.out.println("Patient :"+patientIdWithOutCC);
			
		}else if(method.equals("Update") && patientIdWithOutCC != null){
			DBConnection  db = new DBConnection(base.environment);
			query = "SELECT CARD_KEY_ID FROM THOT.CREDIT_CARD_PT_DETAILS WHERE PATIENT_ID ="+patientIdWithOutCC;
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
					cardKeyId = rs.getString(1);
				}
				
			}catch(SQLException e){
				e.getStackTrace();
			}finally{
				db.Close();
			}
		}else if(method.equals("Delete")){
			DBConnection  db = new DBConnection(base.environment);
			query = "SELECT CARD_KEY_ID FROM THOT.CREDIT_CARD_PT_DETAILS WHERE PATIENT_ID ="+patientIdWithOutCC;
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
					cardKeyId = rs.getString(1);
				}
				
			}catch(SQLException e){
				e.getStackTrace();
			}finally{
				db.Close();
			}
		}
	}
	
	
	@When("^I request the \"([^\"]*)\" service$")
	public void i_request_the_service(String service) throws Throwable {
		arraycredentials = WSCredentials.webServicesCredentials(service,base.environment);
	}
	
	@When("^in order to try to \"([^\"]*)\" a Credit/Debit Card$")
	public void in_order_to_try_to_a_Credit_Debit_Card(String arg1) throws Throwable {
		method = arg1;
		ApiTools paymentMethodApi = new ApiTools(arraycredentials[0],arraycredentials[1],arraycredentials[2]);
		if("Add".equals(method)){
			apiPath = "/v1/AccredoPega";
			System.out.println("Patient :"+patientIdWithOutCC);
			requestBody = new JSONObject()
			.put("patient", new JSONObject()
	        	.put("id", patientIdWithCC)
	        		)
			.put("paymentMethod", new JSONObject()
	        	.put("paymentMethodType","PERSONAL CREDIT")
	        	.put("cardIssuer","VISA")
				.put("creditCardNumber", creditCard)
				.put("usageType","AUTO-CHARGE")
				.put("expiration", new JSONObject()
	             	.put("month","12")
	             	.put("year","2020")
	             )
			).toString();
			
			response = paymentMethodApi.create(apiPath, requestBody);
			
		}else if("Get".equals(method)){
			System.out.println("Patient :"+patientIdWithOutCC);
			apiPath = "/v1/AccredoPega/patients/"+ patientIdWithOutCC;
			response = paymentMethodApi.retrive(apiPath);
			responseBody = response.getBody().asString();
		}else if("Update".equals(method)){
			apiPath = "/v1/AccredoPega/cards/+cardKeyId";
		}else if("Delete".equals(method)){
			apiPath = "/v1/AccredoPega/patients/"+ patientIdWithCC +"/cards/"+cardKeyId;
		}
		
		
		try{
			responseBody = response.getBody().asString();
			JSONObject responseBodyJson = new JSONObject(responseBody);
			if(responseBodyJson.toString().contains("Credit card already exists for this patient")){
				System.out.println("Credit card already exists for this patient");
			}else if(responseBodyJson.toString().contains("Card number is not valid")){
				System.out.println("Card number is not valid");
			}
		}catch(JSONException eJson){
			eJson.getMessage();
		}
		
	   
	}
	
	//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//-------------------------------------------------------------------------------SSPAT-38-------------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	
	@When("^using the method \"([^\"]*)\" a Credit/Debit Card$")
	public void using_the_method_a_Credit_Debit_Card(String arg1) throws Throwable {
		ApiTools paymentMethodApi = new ApiTools(arraycredentials[0],arraycredentials[1],arraycredentials[2]);
		method = arg1;
		if("Add".equals(method)){
			System.out.println("Patient :"+patientIdWithOutCC);
			apiPath = "/v1/AccredoPega";
			requestBody = new JSONObject()
			.put("patient", new JSONObject()
	        	.put("id", patientIdWithOutCC)
	        		)
			.put("paymentMethod", new JSONObject()
	        	.put("paymentMethodType","PERSONAL CREDIT")
	        	.put("cardIssuer","VISA")
				.put("creditCardNumber", creditCard)
				.put("usageType","AUTO-CHARGE")
				.put("expiration", new JSONObject()
	             	.put("month","12")
	             	.put("year","2020")
	             )
			).toString();
			
			response = paymentMethodApi.create(apiPath, requestBody);
			
		}else if("Get".equals(method)){
			//System.out.println("Patient without Credit Card :"+patientIdGet );
			apiPath = "/v1/AccredoPega/patients/"+ patientIdGet;
			response = paymentMethodApi.retrive(apiPath);
			
		}else if("Update".equals(method)){
			System.out.println("Card Key Id :"+cardKeyId);
		}else if("Delete".equals(method)){
			System.out.println("Patient :"+patientIdWithOutCC);
			apiPath = "/v1/AccredoPega/patients/"+ patientIdWithOutCC +"/cards/"+cardKeyId;
		}
		
		try{
			responseBody = response.getBody().asString();;
			JSONObject responseBodyJson = new JSONObject(responseBody);
			String responseFail = responseBody.toString();
			if(responseBodyJson.toString().contains("Credit card already exists for this patient")){
				System.out.println("Credit card already exists for this patient");
			}else if(responseBodyJson.toString().contains("Card number is not valid")){
				System.out.println("Card number is not valid");
			}else if(responseBodyJson.toString().contains(responseFail)){
				System.out.println("The Patient doesn't have a valid Credit/Debit Card");
			}
		}catch(JSONException eJson){
			eJson.getMessage();
		}
		

	}
	
	//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//-------------------------------------------------------------------------------SSPAT-20-------------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	@When("^to be able to \"([^\"]*)\" a Credit/Debit Card$")
	public void to_be_able_to_a_Credit_Debit_Card(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		ApiTools paymentMethodApi = new ApiTools(arraycredentials[0],arraycredentials[1],arraycredentials[2]);
		method = arg1;
		if("Add".equals(method)){
			System.out.println("Patient :"+patientIdWithOutCC);
			apiPath = "/v1/AccredoPega";
			requestBody = new JSONObject()
			.put("patient", new JSONObject()
	        	.put("id", patientIdWithOutCC)
	        		)
			.put("paymentMethod", new JSONObject()
	        	.put("paymentMethodType","PERSONAL CREDIT")
	        	.put("cardIssuer","VISA")
				.put("creditCardNumber", creditCard)
				.put("usageType","AUTO-CHARGE")
				.put("expiration", new JSONObject()
	             	.put("month","12")
	             	.put("year","2020")
	             )
			).toString();
			
			response = paymentMethodApi.create(apiPath, requestBody);
			
		}else if("Get".equals(method)){
			
			System.out.println("Patient 1 :"+patientIdWithOutCC);
			apiPath = "/v1/AccredoPega/patients/"+ patientIdWithOutCC;
			response = paymentMethodApi.retrive(apiPath);
			responseBody = response.getBody().asString();
			
		}else if("Update".equals(method)){
			apiPath = "/v1/AccredoPega/cards/"+cardKeyId;
			requestBody = new JSONObject()
			.put("patient", new JSONObject()
	        	.put("id", patientIdWithOutCC)
	        		)
			.put("paymentMethod", new JSONObject()
	        	.put("paymentMethodType","PERSONAL CREDIT")
	        	.put("cardIssuer","VISA")
				.put("creditCardNumber", creditCard)
				.put("usageType","AUTO-CHARGE")
				.put("expiration", new JSONObject()
	             	.put("month","10")
	             	.put("year","2022")
	             )
			).toString();
			response = paymentMethodApi.update(apiPath, requestBody);

		}else if("Delete".equals(method)){
			System.out.println("Patient :"+patientIdWithOutCC);
		}
		

	}

	@Then("^with not enough information or data$")
	public void with_not_enough_information_or_data() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Testing a Negative Scenario");
		
	}

	@Given("^that I get a patient without a credit card$")
	public void that_I_get_a_patient_without_a_credit_card() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^a request to the service is made for the \"([^\"]*)\"$")
	public void a_request_to_the_service_is_made_for_the(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		arraycredentials = WSCredentials.webServicesCredentials(arg1,base.environment);
	}

	@When("^using the method \"([^\"]*)\" for a new Credit/Debit Card$")
	public void using_the_method_for_a_new_Credit_Debit_Card(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		ApiTools paymentMethodApi = new ApiTools(arraycredentials[0],arraycredentials[1],arraycredentials[2]);
		method = arg1;
		if("Add".equals(method)){
			System.out.println("Patient :"+patientIdWithOutCC);
			apiPath = "/v1/AccredoPega";
			requestBody = new JSONObject()
			.put("patient", new JSONObject()
	        	.put("id", patientIdWithOutCC)
	        		)
			.put("paymentMethod", new JSONObject()
	        	.put("paymentMethodType","PERSONAL CREDIT")
	        	.put("cardIssuer","VISA")
				.put("creditCardNumber", creditCard)
				.put("usageType","AUTO-CHARGE")
				.put("expiration", new JSONObject()
	             	.put("month","12")
	             	.put("year","2020")
	             )
			).toString();
			
			response = paymentMethodApi.create(apiPath, requestBody);
			
		}else if("Get".equals(method)){
			apiPath = "/v1/AccredoPega/patients/"+ patientIdGet;
			response = paymentMethodApi.retrive(apiPath);
			
		}else if("Update".equals(method)){
			apiPath = "/v1/AccredoPega/cards/"+cardKeyId +"1";
			System.out.println("Patient :"+patientIdWithOutCC);
			System.out.println("Card Key Id :"+cardKeyId +"1");
			
			apiPath = "/v1/AccredoPega/cards/"+cardKeyId;
			requestBody = new JSONObject()
			.put("patient", new JSONObject()
	        	.put("id", patientIdWithOutCC)
	        		)
			.put("paymentMethod", new JSONObject()
	        	.put("paymentMethodType","PERSONAL CREDIT")
	        	.put("cardIssuer","VISA")
				.put("creditCardNumber", creditCard)
				.put("usageType","AUTO-CHARGE")
				.put("expiration", new JSONObject()
	             	.put("month","10")
	             	.put("year","2022")
	             )
			).toString();
			response = paymentMethodApi.update(apiPath, requestBody);
			
		}
	}

	@Then("^the service response status should be \"([^\"]*)\"$")
	public void the_service_response_status_should_be(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		int code;
		if(method.equals("Add")){
			DBConnection  db = new DBConnection(base.environment);
			this.query = "SELECT 'Success' FROM THOT.CREDIT_CARD_PT_DETAILS WHERE PATIENT_ID = "+patientIdWithOutCC;
			db.ExecuteSelect(query);
			try{
				ResultSet rs = db.ExecuteSelect(query);
				while(rs.next()){
					status = rs.getString(1);
				}
				
			}catch(SQLException e){
				e.getStackTrace();
			}finally{
				db.Close();
			}
			
			if(status.equals(arg1)){
				System.out.println("Status :"+status);
			}else{
				status = "Fail";
				System.out.println("Status :"+status);
			}
		}else if(method.equals("Get")){
			code = response.statusCode();
			if(code == 200){
				if(response.getBody().asString().length() < 50){
					status = "Fail";
					System.out.println("Status :"+status);
				}else{
					status = "Success";
					System.out.println("Status :"+status);	
				}
			}else{
				status = "Fail";
				System.out.println("Status :"+status);
				
			}
		}else if(method.equals("Update")){
			try{
				responseBody = response.getBody().asString();;
				JSONObject responseBodyJson = new JSONObject(responseBody);
				String responseFail = responseBody.toString();
				if(responseBodyJson.toString().contains("Credit card already exists for this patient")){
					System.out.println("Credit card already exists for this patient");
				}else if(responseBodyJson.toString().contains("Card number is not valid")){
					System.out.println("Card number is not valid");
				}else if(responseBodyJson.toString().contains(responseFail)){
					System.out.println("The Patient doesn't have a valid Credit/Debit Card--");
					status = "Fail";
					System.out.println("Status :"+status);
				}else if(responseBodyJson.toString().contains("Card id does not exist")){
					System.out.println("The Card id does not exist");
				}
			}catch(JSONException eJson){
				eJson.getMessage();
			}
		}
	}


	//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//-------------------------------------------------------------------------------SSPAT-1139-----------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		
}
