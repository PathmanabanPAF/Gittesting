package StepDefinitions;

import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalEnums.DefaultValues;
import GlobalEnums.ResponseMessage;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;

public class Supply_StepDefinitions  extends BaseUtil{
	private BaseUtil base;
	public String sb, rxId, refill, invId;
	public String requestBody;
	int quantity;
	JSONObject supplyInfo;
	JSONObject jsonResponseBody;
	JSONArray requestBodyArray, ArrayResponseBody;
	
	public Supply_StepDefinitions(BaseUtil base){
		this.base = base;
	}
	
	@Given("^I have the required Prescription Supply information$")
	public void i_have_the_required_Prescription_Supply_information() throws Throwable {
		base.requestBodyArray = new JSONArray();
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.SUPPLY_INF);
	}
	
	@Given("^I get a valid \"([^\"]*)\" Prescription w/Ancillaries$")
	public void i_get_a_valid_Prescription_w_Ancillaries(String condition) throws Throwable {
		String query = String.format(prescriptionSqlQueries.RxWithAncillary.toString(),DefaultValues.valueOf(condition.replaceAll("\\s+", "")));
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		sb = base.prescription.get("sb");rxId = base.prescription.get("rxId");refill = base.prescription.get("refill");
	}
	
	@Given("^I get a Supply from an \"([^\"]*)\" Prescription$")
	public void i_get_a_Supply_from_an_Prescription(String condition) throws Throwable {
		String query = String.format(prescriptionSqlQueries.GetSupply.toString(),DefaultValues.valueOf(condition.replaceAll("\\s+", "")));
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		base.sb = base.prescription.get("sb");base.rxId = base.prescription.get("rxId");base.refill = base.prescription.get("refill");
		base.invId = base.prescription.get("inventoryId");base.lot = base.prescription.get("lot");
		System.out.println(base.prescription);
	}

	@Given("^I get new values for Supply fields$")
	public void i_get_new_values_for_Supply_fields() throws Throwable {
		base.requestBodyJson = MiscTools.supplyRequestUpdate(base.prescription,base.requestBodyJson, base.environment);
	}

	@Given("^I fill Prescription fields with that Prescription$")
	public void i_fill_Prescription_fields_with_that_Prescription() throws Throwable {
		base.requestBodyJson = MiscTools.updateCreateSupplyRequestWithRx(base.prescription,base.requestBodyJson, base.environment);
	}

	@Given("^I fill Prescription fields with a valid \"([^\"]*)\" Prescription$")
	public void i_fill_Prescription_fields_with_a_valid_Prescription(String condition) throws Throwable {
		String query = String.format(prescriptionSqlQueries.RxWithRefill.toString(),DefaultValues.valueOf(condition.replaceAll("\\s+", "")),"60");
		System.out.println(query);
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		sb = base.prescription.get("sb");rxId = base.prescription.get("rxId");refill = base.prescription.get("refill");
		base.requestBodyJson = MiscTools.updateCreateSupplyRequestWithRx(base.prescription,base.requestBodyJson, base.environment);
	}

	@Given("^I fill Prescription fields with a valid Direct \"([^\"]*)\" Prescription$")
	public void i_fill_Prescription_fields_with_a_valid_Direct_Prescription(String condition) throws Throwable {
		String query = String.format(prescriptionSqlQueries.DirectRxWithRefill.toString(),DefaultValues.valueOf(condition.replaceAll("\\s+", "")),"60");
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		sb = base.prescription.get("sb");rxId = base.prescription.get("rxId");refill = base.prescription.get("refill");
		base.requestBodyJson = MiscTools.updateCreateSupplyRequestWithRx(base.prescription,base.requestBodyJson, base.environment);
	}
	
	@Given("^I fill Prescription fields with a valid Integrated \"([^\"]*)\" Prescription$")
	public void i_fill_Prescription_fields_with_a_valid_Integrated_Prescription(String condition) throws Throwable {
		String query = String.format(prescriptionSqlQueries.IntegratedRxWithRefill.toString(),DefaultValues.valueOf(condition.replaceAll("\\s+", "")),"60");
		System.out.println(query);
		base.prescription = MiscTools.executeSingleRowSelect(base.environment,query);
		System.out.println(base.prescription);
		sb = base.prescription.get("sb");rxId = base.prescription.get("rxId");refill = base.prescription.get("refill");
		base.requestBodyJson = MiscTools.updateCreateSupplyRequestWithRx(base.prescription,base.requestBodyJson, base.environment);
	}
	
	@Given("^I leave empty Inventory field$")
	public void i_leave_empty_Inventory_field() throws Throwable {
		base.requestBodyJson.put("itemReference","");
	}

	@Given("^I fill Inventory field with an already added Inventory Id$")
	public void i_fill_Inventory_field_with_an_already_added_Inventory_Id() throws Throwable {
		Map<String, String> inventory;
		inventory = MiscTools.executeSingleRowSelect(base.environment, String.format(prescriptionSqlQueries.GetAncillaryInventory.toString(), sb,rxId, refill));
		base.requestBodyJson.put("itemReference", Integer.parseInt(inventory.get("inventoryId")));
		base.requestBodyJson.put("lot", inventory.get("lot"));
	}

	@Given("^I set as null Prescription fields$")
	public void i_set_as_null_Prescription_fields() throws Throwable {
		base.requestBodyJson.put("processingPharmacy", JSONObject.NULL);
		base.requestBodyJson.put("rxNumber", JSONObject.NULL);
		base.requestBodyJson.put("fillNumber", JSONObject.NULL);
	}
	
	@Given("^I set as null Quantity field$")
	public void i_set_as_null_Quantity_field() throws Throwable {
		base.requestBodyJson.put("quantity", JSONObject.NULL);
	}
//	@When("^I send a request to create one Supply record$")
//	public void i_send_a_request_to_create_one_Supply_record() throws Throwable {
//	
//	}
	@When("^I send a request to create one Dispensed Item record$")
	public void i_send_a_request_to_create_one_Dispensed_Item_record() throws Throwable {
		requestBodyArray.put( base.requestBodyJson);
		requestBody = requestBodyArray.toString();
		System.out.println(requestBody);
		String apiPath = String.format(ApiPaths.DISPENSED_ITEMS,rxId,refill); 
		System.out.println(apiPath);
		base.response = base.serviceApi.create(apiPath, requestBody);
    	base.responseBody = base.response.getBody().asString();
    	System.out.println(base.responseBody);
    	ArrayResponseBody = new JSONArray(base.responseBody);
    	MiscTools.printIdented("Prescription used: Service Branch->"+sb+" Prescription Id->"+rxId+ (refill == null?"":" Refill->"+refill));
	}

//	@When("^I send a request to create one Prescribed Item record$")
//	public void i_send_a_request_to_create_one_Prescribed_Item_record() throws Throwable {
//		requestBodyArray.put( base.requestBodyJson);
//		requestBody = requestBodyArray.toString();
//		String apiPath = String.format(ApiPaths.PRESCRIBED_ITEMS,rxId); 
//		System.out.println(apiPath);
//		System.out.println(requestBody);
//		base.response = base.serviceApi.create(apiPath, requestBody);
//    	base.responseBody = base.response.getBody().asString();
//    	System.out.println(base.responseBody);
//    	ArrayResponseBody = new JSONArray();
//    	MiscTools.printIdented("Prescription used: Service Branch->"+sb+" Prescription Id->"+rxId+ (refill == null?"":" Refill->"+refill));
//	}
//	
	@When("^I send a request to update Supply record$")
	public void i_send_a_request_to_update_Supply_record() throws Throwable {
		base.requestBodyArray.put( base.requestBodyJson);
		base.requestBody = base.requestBodyArray.toString();
		System.out.println(base.requestBody);
		String apiPath = MiscTools.getRxPutApiPathFromFill(base.rxId,base.refill,base.invId); 
		System.out.println(apiPath);
		base.response = base.serviceApi.update(apiPath, base.requestBody);
    	base.responseBody = base.response.getBody().asString();
    	System.out.println(base.responseBody);
    	ArrayResponseBody = new JSONArray(base.responseBody);
    	MiscTools.printIdented("Prescription used: Service Branch->"+base.sb+" Prescription Id->"+base.rxId+ (base.refill == null?"":" Refill->"+base.refill));
	}

	@When("^I send a request to update Supply record using old Url$")
	public void i_send_a_request_to_update_Supply_record_using_old_Url() throws Throwable {
		base.requestBodyArray.put( base.requestBodyJson);
		base.requestBody = base.requestBodyArray.toString();
		System.out.println(base.requestBody);
		String apiPath = MiscTools.getOldRxPutApiPathFromFill(base.prescription,base.invId,base.requestBodyJson.getString("itemType"),base.requestBodyJson.getString("lot")); 
		System.out.println(apiPath);
		base.response = base.serviceApi.update(apiPath, base.requestBody);
    	base.responseBody = base.response.getBody().asString();
    	System.out.println(base.responseBody);
    	MiscTools.printIdented("Prescription used: Service Branch->"+base.sb+" Prescription Id->"+base.rxId+ (base.refill == null?"":" Refill->"+base.refill));
	}

	@Then("^Supply should have the new values$")
	public void supply_should_have_the_new_values() throws Throwable {

	}

	@Then("^I should get no Ancillary errors$")
	public void i_should_get_no_Ancillary_errors() throws Throwable {
		Assert.assertEquals("null",ArrayResponseBody.getJSONObject(0).getString( "x_errors"));
	}

	@Then("^new Ancillary should have the expected values$")
	public void new_Ancillary_should_have_the_expected_values() throws Throwable {

	}

	@Then("^I should get Ancillary error \"([^\"]*)\"$")
	public void i_should_get_Ancillary_error(String errorMessage) throws Throwable {
		errorMessage= errorMessage.replaceAll("\\s+", "");
		String responseMessage = ResponseMessage.valueOf(errorMessage).toString();
		Assert.assertEquals(responseMessage,ArrayResponseBody.getJSONObject(0).getString( "x_errors"));
	}

}
