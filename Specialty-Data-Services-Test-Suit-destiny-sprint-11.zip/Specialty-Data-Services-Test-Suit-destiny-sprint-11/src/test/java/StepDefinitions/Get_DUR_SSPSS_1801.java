package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;
import io.restassured.response.Response;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

public class Get_DUR_SSPSS_1801 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public Get_DUR_SSPSS_1801(BaseUtil base){
		this.base = base;
	}

	
	//Scenario 1
	@Given("^I have valid Prescription id, Refill no, branch Id & Searchtype$")
	public void i_have_valid_Prescription_id_Refill_no_branch_Id_Searchtype() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.params.put("accredoRefillNo="+"0");
		base.params.put("accredoServiceBranchId="+"555");
		base.params.put("searchType="+"LegacyRx");
		base.params.put("accredoPrescriptionId="+"7033933");
	}

	@When("^I send a request to get DUR History$")
	public void i_send_a_request_to_get_DUR_History() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		String apiPathWithParams =  MiscTools.concatenateParams(ApiPaths.DURAPI,base.params);
		System.out.println("API path with parameteres:" +apiPathWithParams);

		//Get Request
    	base.oaResponse = base.oauthServiceApi.retrive(apiPathWithParams);
		//base.response=base.serviceApi.retrive("");
		base.responseBody = base.oaResponse.getBody();
		//base.responseBody="["+base.responseBody+"]";
		System.out.println("Response body: "+base.responseBody);
	}

	@Then("^I should get DUR History irrespective of default dates$")
	public void i_should_get_DUR_History_irrespective_of_default_dates() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "durCreationDate");
        System.out.println("durCreationDate id: "+legacyPatientId);
        Assert.assertEquals("2018-03-19 15:40:37",legacyPatientId);
        System.out.println("Validated DUR Creation date by Prescription Id");
	}

	//Scenario 2
	@Given("^I have valid Patient id & Searchtype$")
	public void i_have_valid_Patient_id_Searchtype() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.params.put("searchType="+"Pt");
		base.params.put("accredoPatientId="+"10951343");
	}
	
	@Then("^I should get DUR History by Patient Id$")
	public void i_should_get_DUR_History_by_Patient_Id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "accredoPatientId");
        System.out.println("accredoPatientId"+legacyPatientId);
        Assert.assertEquals("10951343",legacyPatientId);
        System.out.println("Validated DUR History by Patient id");
	}
	
	//Scenario 3
	@Given("^I have valid DUR id & Searchtype$")
	public void i_have_valid_DUR_id_Searchtype() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		base.params.put("searchType="+"DUR");
		base.params.put("accredoDurId="+"10613285");
	}
	
	@Then("^I should get DUR History by DUR id$")
	public void i_should_get_DUR_History_by_DUR_id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		jsonArrayResponseBody = new JSONArray(base.responseBody);
		invoiceinfo=jsonArrayResponseBody.getJSONObject(0);
		System.out.println("Json object: "+invoiceinfo);
		String legacyPatientId=JsonTools.findKeys(invoiceinfo, "accredoDurId");
        System.out.println("accredoDurId"+legacyPatientId);
        Assert.assertEquals("10613285",legacyPatientId);
        System.out.println("Validated DUR History by DUR id");
	}

}
