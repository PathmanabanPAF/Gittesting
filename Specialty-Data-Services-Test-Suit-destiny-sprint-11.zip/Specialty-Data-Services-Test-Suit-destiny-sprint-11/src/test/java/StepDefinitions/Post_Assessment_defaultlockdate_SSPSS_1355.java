package StepDefinitions;

//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertEquals;
import io.restassured.response.Response;

import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import GlobalClasses.ApiPaths;
import GlobalClasses.BaseUtil;
import GlobalClasses.GetResponses;
import GlobalClasses.JsonTools;
import GlobalClasses.MiscTools;
import GlobalClasses.ResourcePaths;
import GlobalClasses.XmlTools;
import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

public class Post_Assessment_defaultlockdate_SSPSS_1355 extends BaseUtil{
	private BaseUtil base;
	String sb, rxId, refill;
	String startDate, stopDate;
	String errors, currentErrors;
	String therapyFilter, therapyParam;
	String rangeFilter, rangeFilterDefault;
	String query, days = "10";
	public String requestBody;
	JSONObject requestBodyJson;
	JSONObject invoiceinfo, responsePrescriptionInfo,messageinfo;
	JSONObject jsonResponseBody;
	JSONArray jsonArrayResponseBody;
	JSONArray jsonPrescriptionInfo;

	public Post_Assessment_defaultlockdate_SSPSS_1355(BaseUtil base){
		this.base = base;
	}



	@Given("^I have patientid, therapy type, Category code, Section code and Assessment items$")
	public void i_have_patientid_therapy_type_Category_code_Section_code_and_Assessment_items() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		//SET PSWITCH FLAG AS Y
		MiscTools.executeUpdate_commit(base.environment, String.format(prescriptionSqlQueries.SETPSWITCHY.toString(),""));
		//MiscTools.executeUpdate(base.environment, String.format(prescriptionSqlQueries.COMMITQUERY.toString(),""));
		//System.out.println("Query executed successfully");
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Assessment_API);
		System.out.println("XML:"+base.requestBodyJson);
	}
		

	@When("^I send a request to create one session record$")
	public void i_send_a_request_to_create_one_session_record() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		System.out.println("APIpath"+ApiPaths.ASSESSMENTS);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.ASSESSMENTS,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
	}

	@Then("^I should get new session id with default date as system date$")
	public void i_should_get_new_session_id_with_default_date_as_system_date() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		String OrderGUID=JsonTools.findKeys(jsonResponseBody, "sessionId");
		System.out.println("Order GUID:  "+OrderGUID);
		int sessionid=Integer.parseInt(OrderGUID);
		String query="SELECT locked_date FROM adm.dm_session_assessments WHERE session_id = "+sessionid;
		String lockeddate=MiscTools.executeSingleSelect(base.environment, String.format(query.toString(),""));
		if(lockeddate.contentEquals("NULL"))
		{
			System.out.println("lockeddate is null: "+lockeddate);
		}
		else
		{
			System.out.println("lockeddate is not null: "+lockeddate);
		}
	}
	
	
	//Scenario2
	
		@Given("^I have patientid, therapy type, Category code, Section code and Assessment items with PSwitch flag N$")
		public void i_have_patientid_therapy_type_Category_code_Section_code_and_Assessment_items_with_PSwitch_flag_N() throws Throwable {
			// Write code here that turns the phrase above into concrete actions
			//throw new PendingException();
			MiscTools.executeUpdate_commit(base.environment, String.format(prescriptionSqlQueries.SETPSWITCHN.toString(),""));
			//MiscTools.executeUpdate(base.environment, String.format(prescriptionSqlQueries.COMMITQUERY.toString(),""));
			//System.out.println("Query executed successfully");
			base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Assessment_API);
			System.out.println("XML:"+base.requestBodyJson);
		}

		@Then("^I should get new session id with default date as NULL$")
		public void i_should_get_new_session_id_with_default_date_as_NULL() throws Throwable {
			// Write code here that turns the phrase above into concrete actions
			//throw new PendingException();
			String OrderGUID=JsonTools.findKeys(jsonResponseBody, "sessionId");
			System.out.println("Order GUID:  "+OrderGUID);
			int sessionid=Integer.parseInt(OrderGUID);
			String query="SELECT locked_date FROM adm.dm_session_assessments WHERE session_id = "+sessionid;
			String lockeddate=MiscTools.executeSingleSelect(base.environment, String.format(query.toString(),""));
			System.out.println("LOcked Date: "+lockeddate);
			
		    /*if(lockeddate.contentEquals(""))
			{
				System.out.println("lockeddate is null: "+lockeddate);
			}
			else
			{
				System.out.println("lockeddate is not null: "+lockeddate);
			}*/
		}



	//Scenario1 @CreateOrderwithvalidpatientId
	/*@Given("^I have patientid, Product GUID, Fillno and Product type$")
	public void i_have_patientid_Product_GUID_Fillno_and_Product_type() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		System.out.println("Parameters path: "+base.params);
		base.requestBodyJson = JsonTools.readJsonFile(ResourcePaths.Order_API);
		System.out.println("XML:"+base.requestBodyJson);
	}

	@When("^I send a request to create one Order record$")
	public void i_send_a_request_to_create_one_Order_record() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
		
		System.out.println("APIpath"+ApiPaths.ORDERS);
		base.oaResponse = base.oauthServiceApi.create(ApiPaths.ORDERS,base.requestBodyJson.toString());
		base.responseBody = base.oaResponse.getBody();
		System.out.println(base.responseBody);
		jsonResponseBody = new JSONObject(base.responseBody);
	}

	@Then("^I should get Order GUID and ConfirmationNo$")
	public void i_should_get_Order_GUID_and_ConfirmationNo() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		System.out.println("Will get Order id & confirmation no");
		String OrderGUID=JsonTools.findKeys(jsonResponseBody, "orderGuid");
		System.out.println("Order GUID:  "+OrderGUID);
		String Confirmationno=JsonTools.findKeys(jsonResponseBody, "confirmationNo");
		System.out.println("Confirmation No:  "+Confirmationno);
		
	}*/
	
	



}
