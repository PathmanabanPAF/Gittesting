package GlobalEnums;

public enum SqlQueries {

	HumaProfile("select p.svcbr_id as \"sb\",p.prescription_id as \"rx\",p.refill_no as \"refill\", p.patient_id as \"patient_id\" from prescriptions p left join rxh_custom.mi_prescription_xref rx"+
			" on p.svcbr_id = rx.svcbr_id and p.prescription_id = rx.prescription_id and p.refill_no = rx.refill_no where p.therapy_type = 'HUMA' and p.rx_status = 'PROFILE'"+
			" and p.profile_lock_initials is not null and (select count (diag_seq) from THOT.patient_diagnoses where patient_id =  p.patient_id) > 0 and p.refill_thru_date > sysdate + 5"+
			" and p.patient_addr_seq is not null and p.creation_date < (sysdate - 90) and rownum < 2 and rx.svcbr_id is null and rx.prescription_id is null and rx.refill_no is null and p.rx_stop_date >= p.rx_start_date"),
	NotHumaProfile("select p.svcbr_id as \"sb\",p.prescription_id as \"rx\",p.refill_no as \"refill\", p.patient_id as \"patient_id\" from prescriptions p left join rxh_custom.mi_prescription_xref rx"+
			" on p.svcbr_id = rx.svcbr_id and p.prescription_id = rx.prescription_id and p.refill_no = rx.refill_no where p.therapy_type <> 'HUMA' and p.rx_status = 'PROFILE'"+
			" and p.profile_lock_initials is not null and (select count (diag_seq) from THOT.patient_diagnoses where patient_id =  p.patient_id) > 0 and p.refill_thru_date > sysdate + 5"+
			" and p.patient_addr_seq is not null and p.creation_date < (sysdate - 90) and rownum < 2 and rx.svcbr_id is null and rx.prescription_id is null and rx.refill_no is null and p.rx_stop_date >= p.rx_start_date"),
	HumaActive("select p.svcbr_id as \"sb\",p.prescription_id as \"rx\",p.refill_no as \"refill\", p.patient_id as \"patient_id\" from prescriptions p left join rxh_custom.mi_prescription_xref rx"+
			" on p.svcbr_id = rx.svcbr_id and p.prescription_id = rx.prescription_id and p.refill_no = rx.refill_no where p.therapy_type = 'HUMA' and p.rx_status = 'ACTIVE' and p.pharmacist_initials is not null"+ 
			" and p.technician_initials is not null and p.refill_no < p.max_refills and (select max(refill_no) from prescriptions where patient_id =  p.patient_id and svcbr_id = p.svcbr_id and prescription_id = p.prescription_id) = p.refill_no"+
			" and (select count (therapy_type) from thot.patient_diagnoses where patient_id =  p.patient_id) > 0 and p.patient_addr_seq is not null and p.creation_date > (sysdate - 60) and rownum < 2"+
			" and rx.svcbr_id is null and rx.prescription_id is null and rx.refill_no is null"),
	HumaNewY("select distinct r.svcbr_id as \"sb\",r.prescription_id as \"rx\",r.refill_no as \"refill\", p.patient_id as \"patient_id\" from rx_audit r join prescriptions p"+
			" on r.svcbr_id = p.svcbr_id  and r.prescription_id = p.prescription_id and r.refill_no=p.refill_no where r.field_name <> 'Clinical Transfer' and p.therapy_type = 'HUMA'"+
			" and p.refill_no= 0 and p.rx_status = 'PROFILE' and rownum < 2 and r.creation_date > sysdate - 60 "+
			" and r.svcbr_id || '-' || r.Prescription_ID || '-' || r.refill_no NOT in (select svcbr_id || '-' || prescription_id || '-' || refill_no"+
			" from rx_audit where field_name = 'Clinical Transfer' and creation_date > sysdate - 60) and (select count (prescription_id) from prescriptions pr join patients pa on pr.patient_id = pa.id"+
			" where pa.id = p.patient_id and pr.therapy_type = p.therapy_type) = 1"),
	NotHumaNewY("select distinct r.svcbr_id as \"sb\",r.prescription_id as \"rx\",r.refill_no as \"refill\", p.patient_id as \"patient_id\" from rx_audit r left join prescriptions p on p.svcbr_id = r.svcbr_id  and p.prescription_id = r.prescription_id"+
			" and p.refill_no=r.refill_no and p.therapy_type <> 'HUMA' where r.field_name <> 'Clinical Transfer'and r.clinical_data_flag = 'Y'  and p.refill_no= 0 and p.rx_status = 'PROFILE' and r.creation_date > sysdate - 60"+
			" and r.svcbr_id || '-' || r.prescription_id || '-' || r.refill_no not in (select svcbr_id || '-' || prescription_id || '-' || refill_no from rx_audit where field_name = 'Clinical Transfer' and clinical_data_flag = 'Y' "+
			" and creation_date > sysdate - 60) and (select count (prescription_id) from prescriptions pr join patients pa on pr.patient_id = pa.id where pa.id = p.patient_id and pr.therapy_type = p.therapy_type)=1"+
			" and rownum = 1"),
	NotHumaNewN("select distinct r.svcbr_id as \"sb\",r.prescription_id as \"rx\",r.refill_no as \"refill\", p.patient_id as \"patient_id\" from rx_audit r join prescriptions p on r.svcbr_id = p.svcbr_id  and r.prescription_id = p.prescription_id"+
			" and r.refill_no=p.refill_no where p.therapy_type <> 'HUMA' and p.refill_no= 0 and p.rx_status in ('PROFILE','PENDING') and r.creation_date > sysdate - 60 and rownum < 2 "+
			" and r.svcbr_id || '-' || r.Prescription_ID || '-' || r.refill_no in (select svcbr_id || '-' || Prescription_ID || '-' || refill_no from rx_audit where field_name = 'Clinical Transfer' and clinical_data_flag = 'N' and creation_date > sysdate - 60)"),
	HumaNewN("select distinct r.svcbr_id as \"sb\",r.prescription_id as \"rx\",r.refill_no as \"refill\", p.patient_id as \"patient_id\" from rx_audit r join prescriptions p on r.svcbr_id = p.svcbr_id  and r.prescription_id = p.prescription_id"+
			" and r.refill_no=p.refill_no where p.therapy_type = 'HUMA' and p.refill_no= 0 and p.rx_status in ('PROFILE','PENDING') and r.creation_date > sysdate - 60 and rownum < 2 "+
			" and r.svcbr_id || '-' || r.Prescription_ID || '-' || r.refill_no in (select svcbr_id || '-' || Prescription_ID || '-' || refill_no from rx_audit where field_name = 'Clinical Transfer' and and clinical_data_flag = 'N' creation_date > sysdate - 60)"),
	HumaRefillY("select p.svcbr_id as \"sb\",p.prescription_id as \"rx\",p.refill_no as \"refill\", p.patient_id as \"patient_id\" from prescriptions p where p.therapy_type = 'HUMA' and p.refill_no > 0 and p.rx_status in ('PROFILE','PENDING')"+
			" and p.creation_date > sysdate - 60 and rownum < 2"),
	NotHumaRefillY("select p.svcbr_id as \"sb\",p.prescription_id as \"rx\",p.refill_no as \"refill\", p.patient_id as \"patient_id\" from prescriptions p where p.therapy_type <> 'HUMA' and p.refill_no > 0 and p.rx_status in ('PROFILE','PENDING')"+
			" and p.creation_date > sysdate - 60 and rownum < 2"),
	HumaRenewalY("select p.svcbr_id as \"sb\",p.prescription_id as \"rx\",p.refill_no as \"refill\", p.patient_id as \"patient_id\" from prescriptions p where p.therapy_type = 'HUMA' and p.refill_no = 0 and p.rx_status in ('PROFILE','PENDING')"+
			" and p.creation_date > sysdate - 60 and rownum < 2"),
	NotHumaRenewalY("select p.svcbr_id as \"sb\",p.prescription_id as \"rx\",p.refill_no as \"refill\", p.patient_id as \"patient_id\" from prescriptions p where p.therapy_type <> 'HUMA' and p.refill_no = 0 and p.rx_status in ('PROFILE','PENDING')"+
			" and p.creation_date > sysdate - 60 and rownum < 2"),
	ReassessmentTask("SELECT w.task_id from thot.wq_tasks w, thot.ft_task_types tt, thot.ft_workqueues wq, thot.ft_task_statuses ts, adm.dm_sessions s, adm.dm_session_assessments sa where wq.workqueue_id = w.workqueue_id"+
			" and wq.workqueue_id = tt.workqueue_id and wq.workqueue_id = ts.workqueue_id and w.task_type_id = tt.task_type_id and w.task_status_id = ts.task_status_id and wq.name = 'THERAPY MGT' and tt.task_type = 'REASSESSMENT'"+
			" and ts.task_status not like 'COMPLETED%' and w.task_date <= trunc(sysdate) + NVL(7,7) and nvl(w.attribute07,'NULL') != 'UPMC - CLINICAL PROG' and not exists (select 1 from thot.pt_trc_phones_dtl trt"+
			" where trt.trc_id in ('AA', 'BB', 'CC') and trt.therapy_type = s.therapy_type) and sa.task_role = 'NURSE' and s.session_id = sa.session_id  and w.source_id1 = s.session_id and w.source_id3 = sa.session_assessment_id"+
			" and rownum < 2"),
	RxExistsQuery("select * from prescriptions where prescription_id = %s and svcbr_id = %s"),
	GetInvUnit("select gdu.unit as \"dosageUnit\" from tdrugs td, gdrug_units gdu where td.gabbrev = gdu.abbrev and td.abbrev = '%s' and rownum = 1"),
	RxQuery("SELECT rx.prescription_id       AS \"rxNumber\""+
               " ,rx.svcbr_id              AS \"processingPharmacy\""+
               " ,rx.rx_written_date       AS \"writtenDate\""+
               " ,rx.expiration_date       AS \"expirationDate\""+
               " ,rx.max_refills           AS \"fillsAllowed\""+
               " ,rx.rx_status             AS \"currentStatus\""+
               " ,decode(rx.refill_no"+
                     " , 0, 'Prescribed'"+
                     " , 'Dispensed')      AS \"item\""+
               " ,decode(rxv.source_type"+
                     " ,'nd','noncompounded_detail'"+
                     " ,'cd','compounding_detail'"+
                     " ,'cr','compounding_record'"+
                     " ,'pc','prescription_container'"+
                     " ,'cg','caregiver_detail'"+
                     " ,'ap','ancillary_prescriptions') AS \"itemType\""+ 
               " , i.id                    AS \"itemReference\""+
               " , i.description           AS \"name\""+
               " , i.ndc_no                AS \"ndc\""+
               " , i.strength              AS \"strength\""+ 
               " , i.strength_unit         AS \"strengthUnits\""+ 
               " ,rxv.qty                  AS \"quantity\""+
               " , i.sale_unit             AS \"quantityUnits\""+ 
               " ,rx.no_days_shipment_last AS \"daysSupply\""+
               " ,rx.no_days_shipment_last AS \"cycleDays\""+
               " ,pd.dosage                AS \"dosageAmount\""+ 
               " ,pd.dosage_unit           AS \"dosageUnits\""+
               " ,pd.frequency             AS \"doseFrequency\""+
               " ,'Y'                      AS \"specialtyIndicator\""+ 
               " ,rx.label_instruct        AS \"directions\""+
               " ,rx.special_instruct      AS \"note\""+
               " ,rx.daw_code              AS \"substitutions\""+ 
               " ,rx.md_daw_flag           AS \"prescriberDAW\""+
               " ,rx.pt_daw_flag           AS \"patientDAW\""+ 
               " ,rx.physician_id          AS \"prescriber\""+
               " ,rx.patient_id            AS \"patient\""+
               " ,rx.refill_no             AS \"fillNumber\""+
               " ,rx.prescr_ship_date      AS \"fillDate\""+
               " ,rx.prescr_ship_date      AS \"shipdate\""+
               " ,rx.svcbr_id              AS \"fillingPharmacy\""+                
               " ,'processingPharmacist'   AS \"userType\""+
               " ,WS_OWNER.sds_util_pkg.get_processingPharmacist(rx.technician_initials) AS \"userName\""+ 
               " ,rx.rort_date             AS \"processingTime\""+
           " FROM thot.prescriptions_table rx"+
               " ,thot.prescription_items_v rxv"+
               " ,thot.prescription_drugs pd"+
               " ,thot.caregiver_drugs cg"+
               " ,thot.inventory i"+
          " WHERE rx.svcbr_id = %s"+//555--processingPharmacy
               " AND rx.prescription_id =%s"+//3838015---rxNumber
               " AND rx.svcbr_id = rxv.svcbr_id"+
               " AND rx.prescription_id = rxv.prescription_id"+
               " AND rx.refill_no = rxv.refill_no"+
               " AND pd.svcbr_id(+) = rxv.svcbr_id"+
               " AND pd.prescription_id(+) = rxv.prescription_id"+
               " AND pd.refill_no(+) = rxv.refill_no"+
               " AND pd.line_id(+) = rxv.line_id"+
               " AND cg.svcbr_id(+) = rxv.svcbr_id"+
               " AND cg.prescription_id(+) = rxv.prescription_id"+
               " AND cg.refill_no(+) = rxv.refill_no"+
               " AND rxv.inventory_id = i.id"+
          " ORDER BY rx.refill_no"),
  
        ChartCount("select count(chart_id) as from charts where xuser = 'WS_EVNT_PROC' "+
			" and text like '%%CopayAssistance Program%%' and patient_id =%s"),
		GetPatientSb("select svcbr_id from patients where id =%s"),
		GetRxTT("select tt.therapy_descr from prescriptions p, therapy_types tt where p.therapy_type = tt.therapy_type and p.svcbr_id = %s and p.prescription_id = %s and p.refill_no = %s"),
		GetInventoryForRx("select inventory_id as \"inventoryId\", ic.tdrug_abbrev as \"dAbbrev\" from icsl_view ic, tdrugs td where ic.status = 'A' and ic.qoh > 0 and ic.tdrug_abbrev = td.abbrev and ic.svcbr_id = %s and td.name = '%s' and rownum = %s"),
		GetMaxDirectPatient("select max(id) from patients"),
		DirectRx("select svcbr_id as \"sb\",prescription_id as \"rxId\" %s from (select pd.svcbr_id,pd.prescription_id,pd.refill_no from (select p.id, rx.svcbr_id,rx.prescription_id,"+
			" rx.refill_no from patients p, thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i  where p.id = rx.patient_id"+
			" and rx.svcbr_id = rxv.svcbr_id"+
			" and rx.prescription_id = rxv.prescription_id"+
			" and rx.refill_no = rxv.refill_no"+
			" and  pd.svcbr_id(+) = rxv.svcbr_id"+ 
			" and pd.prescription_id(+) = rxv.prescription_id"+
			" and pd.refill_no(+) = rxv.refill_no"+
			" and pd.line_id(+) = rxv.line_id"+
			" and cg.svcbr_id(+) = rxv.svcbr_id"+
			" and cg.prescription_id(+) = rxv.prescription_id"+ 
			" and cg.refill_no(+) = rxv.refill_no"+
			" and rxv.inventory_id = i.id(+)"+
			" and p.id = rx.patient_id and  rx.creation_date > (sysdate - 10)) pd"+
			" left join rxh_custom.mi_patients_xref pi on pd.id = pi.id"+
			" where pi.id is null and rownum < 30 order by dbms_random.random) where rownum < 2"),
			GetRxDefaults("select times_printed as \"timesPrinted\", rx_printok as \"rxPrintOk\", dvr_printok as \"dvrPrintOk\",label_printok as \"labelPrintOk\","+
			" pos as \"pos\" ,employment_flag as \"employmentFlag\", auto_accident_flag as \"autoAccidentFlag\" ,other_accident_flag as \"otherAccidentFlag\","+
			" ancillary_prescriptions_count as \"ancillaryPrescriptionsCount\",compounding_detail_count as \"compoundingDetailCount\",noncompounded_detail_count as \"noncompoundedDetailCount\","+
			" caregiver_detail_count as \"caregiverDetailCount\" ,rx_dme_count as \"rx_dme_count\" ,rxauth_count as \"rxauthCount\" ,rxcmn_count as \"rxcmnCount\" ,rx_checked_flag as \"rxCheckedFlag\","+
			" ca_checked_flag as \"caCheckedFlag\",dc_checked_flag as \"dcCheckedFlag\",di_checked_flag as \"diCheckedFlag\",dz_checked_flag as \"dzCheckedFlag\" ,pe_checked_flag as \"peCheckedFlag\","+
			" pm_checked_flag as \"pmCheckedFlag\",pr_checked_flag as \"prCheckedFlag\",td_checked_flag as \"tdCheckedFlag\",dur_response_flag as \"durResponseFlag\",completed_flag as \"completed_flag\","+
			" refill_flag as \"refillFlag\",auto_srs_flag as \"autoSrsFlag\",web_lock as \"webLock\""+ 
			" from prescriptions where svcbr_id = %s and prescription_id = %s and refill_no = %s"),
		GetRxReadyFill("select \"sb\",\"rxId\", \"refill\" from (select p.svcbr_id as \"sb\",p.prescription_id as \"rxId\", p.refill_no as \"refill\""+
						" from prescriptions p where p.creation_date > (sysdate - 5) and p.est_delivery_date is null and p.rx_status= 'PENDING' and p.profile_lock_initials is null and technician_initials is null"+
						" and (select count (id) from rxh_custom.mi_patients_xref ip where ip.id = p.patient_id) = %s"+
						" and not exists (select rx.svcbr_id,rx.prescription_id, rx.refill_no from rxh_custom.mi_prescription_xref rx"+
					  	" where rx.svcbr_id = p.svcbr_id and rx.prescription_id = p.prescription_id and  rx.refill_no= p.refill_no)"+
			    		" and not exists( select rx.prescription_id, rx.svcbr_id, rx.refill_no from thot.prescriptions_table rx,"+
						" thot.prescription_items_v rxv,thot.prescription_drugs pd,thot.caregiver_drugs cg,thot.inventory i where rx.svcbr_id = p.svcbr_id"+
			        	" and rx.prescription_id = p.prescription_id and rx.refill_no = p.refill_no and rx.svcbr_id = rxv.svcbr_id and rx.prescription_id = rxv.prescription_id"+
			        	" and rx.refill_no = rxv.refill_no and pd.svcbr_id(+) = rxv.svcbr_id and pd.prescription_id(+) = rxv.prescription_id and pd.refill_no(+) = rxv.refill_no and pd.line_id(+) = rxv.line_id"+
					  	" and cg.svcbr_id(+) = rxv.svcbr_id and cg.prescription_id(+) = rxv.prescription_id and cg.refill_no(+) = rxv.refill_no and rxv.inventory_id = i.id)order by dbms_random.random) where rownum < 2"),
		GetActualRxInv("select * from thot.prescription_items_v rxv,thot.prescription_drugs pd where rxv.svcbr_id = pd.svcbr_id and rxv.prescription_id = pd.prescription_id and rxv.refill_no = pd.refill_no"+
             " and rxv.svcbr_id = %s and rxv.prescription_id = %s and rxv.refill_no = %s"),
		GetPatientAbleToRx("select id from (select p.id from patients p, patient_physician pp, patient_therapies pt where p.id = pp.patient_id and p.id = pt.patient_id and p.created_date > (sysdate - 10) and"
			+ " pp.active_flag = 'A' and pt.stop_date is null and pt.stop_reason is null and exists(select patient_id from thot.patient_measurement where patient_id = p.id) order by dbms_random.random) where rownum < 2"),
        GetDirectPatientAbleToRx("select id from (select pd.id from (select p.id from patients p, patient_physician pp, patient_therapies pt where p.id = pp.patient_id and p.id = pt.patient_id and p.created_date > (sysdate - 5) and pp.active_flag = 'A'"
			+" and pt.stop_date is null and pt.stop_reason is null and exists(select patient_id from thot.patient_measurement where patient_id = p.id)) pd left join rxh_custom.mi_patients_xref pi on pd.id = pi.id where pi.id is null and rownum < 30 order "
			+" by dbms_random.random) where rownum < 2"),
		GetPatient("select id from (select p.id from patients p where created_date > (sysdate- %s) %s order  by dbms_random.random) where rownum < 2"),
		GetDirectPatient("select id from (select p.id from patients p left join rxh_custom.mi_patients_xref pi on p.id = pi.id  where p.created_date > (sysdate -%s)"+
			" and pi.id is null %s and rownum < 30 order by dbms_random.random) where rownum < 2"),
		GetDirectPatientWithRx("select id from (select pd.id from (select p.id from patients p, thot.prescriptions_table rx where p.id = rx.patient_id and rx.prescr_ship_date between '%s' and '%s' %s %s) pd"
			+" left join rxh_custom.mi_patients_xref pi on pd.id = pi.id where pi.id is null and rownum < 30 order by dbms_random.random) where rownum < 2"),
		GetIntegratedPatientWithRx("select id from (select rx.patient_id from rxh_custom.mi_prescription_xref rx where p.id = rx.patient_id"
			+" and rx.prescr_ship_date between '%s' and '%s' %s %s"
			+" and rownum < 30 order by dbms_random.random) where rownum < 2"),
		GetFillInventories("select rxd.frequency as \"doseFrequency\",rxv.source_type as \"itemType\", rxd.dosage as \"dosage\", rxd.dosage_unit as \"dosage_unit\", rxv.prescription_id as \"rxNumber\", rxv.refill_no as \"fillNumber\","+ 
				" rxv.inventory_id as \"itemReference\", rxd.drug_abbrev as \"name\",rxv.qty as \"quantity\",rxv.svcbr_id as \"processingPharmacy\" from thot.prescription_items_v rxv, prescription_drugs rxd"+
				" where rxv.svcbr_id = rxd.svcbr_id and rxv.prescription_id = rxd.prescription_id and rxv.refill_no = rxd.refill_no and rxv.svcbr_id = %s and rxv.prescription_id = %s and rxv.refill_no = %s"),
		GetPhysicianFromPatient("select physician_id from patient_physician where active_flag = 'A' and rownum <2  and patient_id = %s"),
		GetPhysicianFromRx("select physician_id from thot.prescriptions_table where svcbr_id = %s and prescription_id =%s"),
		GetTTFromPatient("select therapy_type from patient_therapies where stop_date is null and stop_reason is null and patient_id = %s and therapy_type in "
			+ "(select distinct attribute1 from thot.ft_lookups where type = 'SDS_PRESCRIPTION_API' and code = 'NDC_THERAPY_MAPPING')"),
		GetNdcFromPatientTherapy("select * from (select ftl.attribute3 from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API' and ftl.code = 'NDC_THERAPY_MAPPING' and exists ( select therapy_type from "
			+ " patient_therapies where stop_date is null and stop_reason is null and patient_id = %s and therapy_type = ftl.attribute1)"
			+ " and exists (select inv.id from thot.inventory inv,thot.icslocs ic,thot.inventory_therapies ith"
			+ " where inv.ndc_no = ftl.attribute3 and inv.id = ic.inventory_id and ic.inventory_id = ith.inventory_id and ic.svcbr_id = 555" 
				+ "and ic.loc_type = 'S' and ic.loc_id = ic.svcbr_id and ic.status = 'A' and ic.available_qty > 3 "
				+ "and inv.strength is not null  and ith.therapy_type = (select ftl.attribute1 from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API'"
				+ "and ftl.code = 'NDC_THERAPY_MAPPING' and attribute3 =inv.ndc_no))"
			+ "order  by dbms_random.random) where rownum < 2"),
		GetRxDrugFromNdc("select ftl.attribute4 from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API' and ftl.code = 'NDC_THERAPY_MAPPING' and attribute3 = '%s'"),
		GetTherapyFromNdc("select attribute1 from thot.ft_lookups where type = 'SDS_PRESCRIPTION_API' and code = 'NDC_THERAPY_MAPPING' and attribute3 = '%s'"),
		GetNdcNotRelatedToPatient("select * from (select ftl.attribute3 from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API' and ftl.code = 'NDC_THERAPY_MAPPING' and ftl.attribute1 not in ( select "
				+ " therapy_type from patient_therapies where stop_date is null and stop_reason is null and patient_id = %s) order  by dbms_random.random) where rownum < 2"),
		IntegratedRx("select svcbr_id as \"sb\",prescription_id as \"rxId\" %s from (select rx.svcbr_id,rx.prescription_id, rx.refill_no"+
				" from rxh_custom.mi_prescription_xref rx ,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i"+
				" where rx.svcbr_id = rxv.svcbr_id"+
				" and rx.prescription_id = rxv.prescription_id"+
				" and rx.refill_no = rxv.refill_no"+
				" and  pd.svcbr_id(+) = rxv.svcbr_id"+ 
				" and pd.prescription_id(+) = rxv.prescription_id"+
				" and pd.refill_no(+) = rxv.refill_no"+
				" and pd.line_id(+) = rxv.line_id"+
				" and cg.svcbr_id(+) = rxv.svcbr_id"+ 
				" and cg.prescription_id(+) = rxv.prescription_id"+ 
				" and cg.refill_no(+) = rxv.refill_no"+
				" and rxv.inventory_id = i.id(+) and rx.creation_date > (sysdate - 10)"+ 
				" order by dbms_random.random)"+
				" where rownum < 2"),
		GetIntegratedPatient("select id from (select p.id from patients p inner join rxh_custom.mi_patients_xref pi on p.id = pi.id where created_date > (sysdate-%s) %s order by dbms_random.random) where rownum < 2"),
		GetIntegratedPatientAbleToRx("select id from (select pd.id from (select p.id from patients p, patient_physician pp, patient_therapies pt where p.id = pp.patient_id and p.id = pt.patient_id and p.created_date > (sysdate - 50) and pp.active_flag = 'A'"+
				" and pt.stop_date is null and pt.stop_reason is null and exists(select patient_id from thot.patient_measurement where patient_id = p.id)) pd inner join rxh_custom.mi_patients_xref pi on pd.id = pi.id where rownum < 30 order by dbms_random.random) where rownum < 2"),
		GetDirectPatientWithDiagnoses("select id from (select p.id from patients p where p.created_date > (sysdate - 40) and exists (select id from patient_diagnoses  pd where pd.patient_id = p.id)"+
			" and not exists (select id from rxh_custom.mi_patients_xref ip where ip.id = p.id)order by dbms_random.random) where rownum < 2"),
		GetDirectPatientWithoutDiagnoses("select id from (select p.id from patients p where p.created_date > (sysdate - 40) and not exists (select id from patient_diagnoses  pd where pd.patient_id = p.id)"+
			" and not exists (select id from rxh_custom.mi_patients_xref ip where ip.id = p.id)order by dbms_random.random) where rownum < 2"),
		GetIntegratedPatientWithDiagnoses("select id from (select p.id from rxh_custom.mi_patients_xref p where p.creation_date > (sysdate - 40) "+
			" and exists (select id from patient_diagnoses  pd where pd.patient_id = p.id)order by dbms_random.random) where rownum < 2"),
		GetIntegratedPatientWithoutDiagnoses("select id from (select p.id from rxh_custom.mi_patients_xref p where p.creation_date > (sysdate - 40) "+ 
			" and not exists (select id from patient_diagnoses  pd where pd.patient_id = p.id)order by dbms_random.random) where rownum < 2"),
		GetDirectPatientWithTherapies("select id from (select p.id from patients p where p.created_date > (sysdate - 5) and exists (select id from patient_therapies  pt where pt.patient_id = p.id) "+
			" and not exists (select id from rxh_custom.mi_patients_xref ip where ip.id = p.id) order by dbms_random.random) where rownum < 2"),
		GetIntegratedPatientWithTherapies("select id from (select p.id from rxh_custom.mi_patients_xref p where p.creation_date > (sysdate - 5) and exists (select id from patient_therapies  pt where pt.patient_id = p.id)) where rownum < 2"),
		GetDirectPatientWithoutTherapies("select id from (select p.id from patients p where p.created_date > (sysdate - 5) and not exists (select id from patient_therapies  pt where pt.patient_id = p.id) "+
			" and not exists (select id from rxh_custom.mi_patients_xref ip where ip.id = p.id)order by dbms_random.random) where rownum < 2"),
		GetIntegratedPatientWithoutTherapies("select id from (select p.id from rxh_custom.mi_patients_xref p where p.creation_date > (sysdate - 5) and exists (select id from patient_therapies  pt where pt.patient_id = p.id)) where rownum < 2"),
		TherapyType("select therapy_type from (select therapy_type as from thot.therapy_types order by sys.dbms_random.random)where rownum < 2"),
		TherapyTypeExists("select therapy_type from thot.therapy_types where therapy_type = '%s'"),
		GetAvailableRxTT("select therapy_type from (select therapy_type from (select tt.therapy_type, rx.patient_id  from thot.therapy_types tt, thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i,patients p "
				+ "where tt.therapy_type = rx.therapy_type"+
				" and p.id = rx.patient_id "+
				" and rx.svcbr_id = rxv.svcbr_id"+
				" and rx.prescription_id = rxv.prescription_id"+
				" and rx.refill_no = rxv.refill_no "+
				" and  pd.svcbr_id(+) = rxv.svcbr_id "+
				" and pd.prescription_id(+) = rxv.prescription_id"+
				" and pd.refill_no(+) = rxv.refill_no "+
				" and pd.line_id(+) = rxv.line_id "+
				" and cg.svcbr_id(+) = rxv.svcbr_id "+
				" and cg.prescription_id(+) = rxv.prescription_id"+ 
				" and cg.refill_no(+) = rxv.refill_no "+
				" and rxv.inventory_id = i.id(+)"+
			" and rx.prescr_ship_date between '%s' and '%s' and (select count(distinct rx.therapy_type) from thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i  where p.id = rx.patient_id"+ 
			" and rx.svcbr_id = rxv.svcbr_id"+
			" and rx.prescription_id = rxv.prescription_id"+
			" and rx.refill_no = rxv.refill_no "+
			" and  pd.svcbr_id(+) = rxv.svcbr_id "+
			" and pd.prescription_id(+) = rxv.prescription_id"+
			" and pd.refill_no(+) = rxv.refill_no "+
			" and pd.line_id(+) = rxv.line_id "+
			" and cg.svcbr_id(+) = rxv.svcbr_id "+
			" and cg.prescription_id(+) = rxv.prescription_id"+ 
			" and cg.refill_no(+) = rxv.refill_no "+
			" and rxv.inventory_id = i.id(+) and patient_id = rx.patient_id and prescr_ship_date  between '%s' and '%s')> 2)pd"
			+ "  left join rxh_custom.mi_patients_xref pi on pd.patient_id = pi.id where pi.id is null and rownum < 30 order by dbms_random.random) where rownum < 2"),
		ClaimCenterId("select no from (select no from claim_centers order by dbms_random.random)where rownum < 2"),
		ClaimCenterName("select name from (select name from claim_centers order by dbms_random.random)where rownum < 2"),
		ClaimCenterIdsByName("select no as \"id\" from claim_centers where name = '%s'"),
		MaxClaimCenter("select max(no) from thot.claim_centers"),
		ClaimCenterQuery("select no as \"id\",name as \"name\", status as \"status\", tax_id1 as \"taxId1\", tax_id2 as \"taxId2\", ccgroup as \"group\""+
			" from thot.claim_centers where no = %s"),
		ClaimCenterBilling("select autosequence_flag as \"autoSequence\","+
			" routing_flag as \"pharmacyRoutingEnabled\","+
			" signature_required as \"deliverySignatureRequired\","+
			" default_ic_format as \"invoiceFormat\","+
			" ic_profile as \"invoiceProfile\","+
			" edi_format as \"ediFormat\","+
			" edi_route as \"ediRoute\","+
			" edi_id as \"ediId\","+
			" edi_version as \"ediVersion\","+
			" billing_terms as \"billingTerms\","+
			" kit_type as \"kitType\","+
			" comments as \"comments\","+
			" preprinted_hcfa_flag as \"preprintedHCFAFlag\","+
			" print_zero_price_flag as \"printZeroPricedItems\","+
			" rx_match_date as \"prescriptionMatchDate\","+
			" prior_authorization_required as \"priorAuthorization\","+
			" bill_authorization as \"billAuthorization\","+
			" units_threshold as \"unitsThreshold\","+
			" days_threshold as \"daysThreshold\","+
			" bill30_flag as \"consolidatedBilling30DaysFlag\","+
			" national_remit_addr_flag as \"printNationalRemitAddress\","+
			" filing_deadline1 as \"timelyFilingDeadline\","+
			" ncpdp_prescriber_name_flag as \"ncpdpPrescriberNameFlag\","+
			" ncpdp_cardholder_flag as \"ncpdpCardholderFlag\","+
			" ncpdp_patient_address_flag as \"ncpdpPatientAddressFlag\","+
			" ncpdp_copay_flag as \"ncpdpCopayFlag\","+
			" ncpdp_rx_origin_code as \"ncpdpOriginCode\","+
			" ncpdp_qty_rx_flag as \"ncpdpQuantityPrescriptionFlag\","+
			" ncpdp_reversal_dur as \"ncpdpReversalDUR\","+
			" ncpdp_reversal_bin as \"ncpdpReversalBin\","+
			" ncpdp_reversal_provider as \"ncpdpReversalProvider\","+
			" ncpdp_medicaid_indc_flag as \"ncpdpReportMedicaidFlag\","+
			" ncpdp_provider_indc_flag as \"ncpdpProviderFlag\","+
			" ncpdp_patient_benefits_flag as \"ncpdpPatientBenefitsFlag\","+
			" ncpdp_person_code_send_flag as \"ncpdpReportPersonCodeFlag\","+
			" ncpdp_prescriber_data_flag as \"ReportPrescriberDataFlag\","+
			" ncpdp_prescriber_fname_flag as \"ReportPrescriberFirstNameFlag\","+
			" ncpdp_prescriber_phone_flag as \"ReportPrescriberAddressFlag\","+
			" ncpdp_prescriber_phone_flag as \"ncpdpReportPrescriberPhoneFlag\","+
			" ncpdp_bill_entity_flag as \"ncpdpReportBillingEntityType\","+
			" ncpdp_svc_provider_id_qual as \"ServiceProviderIdQualifier\","+
			" ncpdp_prescriber_id_qual as \"ncpdpPrescriberIdQualifier\","+
			" ncpdp_diag_code_qualifier as  \"ncpdpDiagnosesCodeQualifier\","+
			" ncpdp_software_vendor_cert as \"ncpdpSoftwareVendorCert\","+
			" ncpdp_reversal_cob as \"ncpdpReversalCOB\","+
			" ncpdp_pharm_provider_code as \"ncpdpPharmacyProviderCode\","+
			" ncpdp_pharmacy_srvc_type as \"ncpdpPharmacyServiceType\","+
			" ncpdp_pay_to_code as \"ncpdpPayToCode\""+
			" from thot.claim_centers where no = %s"),
		ClaimCenterPlan("select fndn_copay_assist as \"foundationCopayAssist\","+
		    " lock_pricing as \"lockPricing\","+
		    " mfg_copay_assist as \"manufacturerCopayAssist\","+
		    " cctype as \"name\","+
		    " pricing_id as \"pricingId\","+
		    " renewal_autofax as \"renewalAutoFax\","+
		    " payor_status as \"status\","+
		    " ccsubtype as \"subType\""+
		    " from thot.claim_centers where no = %s"),
		ClaimCenterAddresses("select addr1 as \"addr1\", addr2 as \"addr2\",attn as \"attn\", city as \"city\", state as \"state\", zip as \"postalCode\","+  
			" country as \"country\", status as \"status\""+
			" from thot.addresses a where name_type = 'C' and name_id = %s"),
		ClaimCenterPhones("select phonea||'-'||phoneb||'-'||phonec as \"number\",phone_ext as \"extension\", phone_type as \"classifications\", phone_seq as \"phoneSeq\""+
			" from thot.phones a where name_type = 'C' and name_id = %s"),
		ClaimCenterCustomTags("select phone_type||'-'||phone_comment as \"customTags\""+
				" from thot.phones a where name_type = 'C' and phone_seq = %s and name_id = %s"),
	RxDirect("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx where rx.rx_status in ('PENDING','ACTIVE') and rx.shipment_id is not null "
				+"and rx.pharmacist_initials is not null and rx.shipping_id is not null and trunc(rx.refill_thru_date) >= trunc(sysdate) and rx.creation_date > trunc(sysdate-90) order by sys.dbms_random.random)"
				+"where 1=1 and rownum =1"),
	RxIntegrated("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx inner join rxh_custom.mi_prescription_xref mi on rx.svcbr_id = mi.svcbr_id and rx.prescription_id = mi.prescription_id "
				+"where rx.rx_status in ('PENDING','ACTIVE') and rx.shipment_id is not null "
				+"and rx.pharmacist_initials is not null and rx.shipping_id is not null and trunc(rx.refill_thru_date) >= trunc(sysdate) and rx.creation_date > trunc(sysdate-90) order by sys.dbms_random.random) "
				+"where 1=1 and rownum =1"),
	RxDirect12b("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx where rx.rx_status in ('PENDING','ACTIVE') and rx.shipment_id is not null "
				+"and rx.therapy_type in (select g_char_value from thot.groupr where type = 'RU' and name   = 'THERAPY SHIPPING CALENDAR') "
				+"and rx.pharmacist_initials is not null and rx.shipping_id is not null and trunc(rx.refill_thru_date) >= trunc(sysdate) and rx.creation_date > trunc(sysdate-90) order by sys.dbms_random.random) "
				+"where 1=1 and rownum =1"),
	RxDirect12bRefill("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx where rx.rx_status in ('PENDING','ACTIVE') and rx.shipment_id is not null "
				+"and rx.therapy_type in (select g_char_value from thot.groupr where type = 'RU' and name   = 'THERAPY SHIPPING CALENDAR') "
				+"and rx.pharmacist_initials is not null  and rx.technician_initials is not null and rx.shipping_id is not null and trunc(rx.refill_thru_date) >= trunc(sysdate) and rx.creation_date > trunc(sysdate-90) order by sys.dbms_random.random) "
				+"where 1=1 and rownum =1"),
	RxIntegrated12b("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx inner join rxh_custom.mi_prescription_xref mi on rx.svcbr_id = mi.svcbr_id and rx.prescription_id = mi.prescription_id "
				+"where rx.rx_status in ('PENDING','ACTIVE') and rx.shipment_id is not null "
				+"and rx.therapy_type in (select g_char_value from thot.groupr where type = 'RW' and name   = 'THERAPY SH CALENDAR INTEGRATED') "
				+"and rx.pharmacist_initials is not null and rx.shipping_id is not null and trunc(rx.refill_thru_date) >= trunc(sysdate) and rx.creation_date > trunc(sysdate-90) order by sys.dbms_random.random) "
				+"where 1=1 and rownum =1"),
	RxIntegrated12bRefill("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx inner join rxh_custom.mi_prescription_xref mi on rx.svcbr_id = mi.svcbr_id and rx.prescription_id = mi.prescription_id "
				+"where rx.rx_status in ('PENDING','ACTIVE') and rx.shipment_id is not null "
				+"and rx.therapy_type in (select g_char_value from thot.groupr where type = 'RW' and name   = 'THERAPY SH CALENDAR INTEGRATED') "
				+"and rx.pharmacist_initials is not null and rx.technician_initials is not null and rx.shipping_id is not null and trunc(rx.refill_thru_date) >= trunc(sysdate) and rx.creation_date > trunc(sysdate-90) order by sys.dbms_random.random) "
				+"where 1=1 and rownum =1"),
		RxPLDirectHUMA("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx where rx.rx_status = 'PROFILE' and profile_lock_initials is not null "
				+"and rx.therapy_type = 'HUMA' and trunc(rx.refill_thru_date) >= trunc(sysdate) and rx.creation_date > trunc(sysdate-390) order by sys.dbms_random.random) "
				+"where 1=1 and rownum =1"),
	RxPLIntegratedHUMA("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx inner join rxh_custom.mi_prescription_xref mi on rx.svcbr_id = mi.svcbr_id and rx.prescription_id = mi.prescription_id "
				+"where rx.rx_status in ('PROFILE') and profile_lock_initials is not null "
				+"and rx.therapy_type = 'HUMA' and trunc(rx.refill_thru_date) >= trunc(sysdate) and rx.creation_date > trunc(sysdate-390) order by sys.dbms_random.random) "
				+"where 1=1 and rownum =1"),
		RxPLDirect12b("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx where rx.rx_status = 'PROFILE' and profile_lock_initials is not null "
				+"and rx.therapy_type in (select g_char_value from thot.groupr where type = 'RU' and name   = 'THERAPY SHIPPING CALENDAR') "
				+"and rx.creation_date > trunc(sysdate-190) and trunc(rx.refill_thru_date) >= trunc(sysdate) order by sys.dbms_random.random) "
				+"where 1=1 and rownum =1"),
	RxPLIntegrated12b("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx inner join rxh_custom.mi_prescription_xref mi on rx.svcbr_id = mi.svcbr_id and rx.prescription_id = mi.prescription_id "
				+"where rx.rx_status in ('PROFILE') and profile_lock_initials is not null "
				+"and rx.therapy_type in (select g_char_value from thot.groupr where type = 'RW' and name   = 'THERAPY SH CALENDAR INTEGRATED') "
				+"and rx.creation_date > trunc(sysdate-90) and trunc(rx.refill_thru_date) >= trunc(sysdate) order by sys.dbms_random.random) "
				+"where 1=1 and rownum =1"),
	RxProtocols("select patient_id, svcbr_id, prescription_id, refill_no from (select * from thot.shc_protocols where 1=1  order by sys.dbms_random.random) where rownum =1"),
	RxPLCopayHUMA("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx where rx.rx_status in ('PROFILE') and profile_lock_initials is not null "
				+"and rx.therapy_type = 'HUMA' "
				+"and rx.patient_id in(SELECT distinct(patient_id) FROM THOT.patient_insurance where copay is not null and copay > 1 group by patient_id having COUNT (CLAIM_CENTER_NO) < 2) "
				+"and rx.creation_date > trunc(sysdate-190) order by sys.dbms_random.random) where 1=1 and rownum =1"),
	RxPLIntegratedCopayHUMA("select * from (select  rx.patient_id,rx.svcbr_id,rx.therapy_type,rx.prescription_id,rx.refill_no,rx.prescr_ship_date,rx.est_delivery_date, "
				+"rx.shipping_id  from thot.prescriptions_table rx where inner join rxh_custom.mi_prescription_xref mi on rx.svcbr_id = mi.svcbr_id and rx.prescription_id = mi.prescription_id "
				+"and rx.rx_status in ('PROFILE') and profile_lock_initials is not null and rx.therapy_type in (select g_char_value from thot.groupr where type = 'RW' and name   = 'THERAPY SH CALENDAR INTEGRATED') "
				+"and rx.therapy_type = 'HUMA' "
				+"and rx.patient_id in(SELECT distinct(patient_id) FROM THOT.patient_insurance where copay is not null and copay > 1 group by patient_id having COUNT (CLAIM_CENTER_NO) < 2) "
				+"and rx.creation_date > trunc(sysdate-190) order by sys.dbms_random.random) where 1=1 and rownum =1"),
	Shipping("select id,shipper,shipper_method,signature_required,saturday_delivery,shipper_override, shipper_overr_reason_code, sh_method_overr_reason_code,residential from thot.shipping where id ="),
	MaxEventId("select max(to_number(c.event_id))+1 from thot.ev_event_control c where 1=1 and c.event_id not like '%-%' order by to_number(c.event_id) desc"),
	PatientWithOutCard("select pt.id,pt.* from thot.patients_table pt where pt.created_date > (sysdate-190) and pt.id not in ( select cc.patient_id from thot.credit_card_pt_details cc) "
					  +"and pt.addr1 is not null and pt.city is not null and pt.state is not null and pt.zip1 is not null and rownum =1"),
		ClaimCenterAddresses2("select distinct city as \"city\", state as \"state\", zip as \"postalCode\","+  
			" country as \"country\", status as \"status\", attn as \"attn\", addr1 as \"addr1\", addr2 as \"addr2\""+
			" from thot.addresses a where name_type = 'C' and name_id = %s"),
		ClaimCenterPhones2("select distinct phonea||'-'||phoneb||'-'||phonec as \"number\",phone_ext as \"extension\", phone_type as \"classifications\", phone_seq as \"phoneSeq\","+
			"  phone_comment as \"phoneComment\" from thot.phones a where name_type = 'C' and name_id = %s"),
		ClaimCenterStreet("select addr1 as \"addr1\", addr2 as \"addr2\",attn as \"attn\" from thot.addresses a where name_type = 'C' and addr_seq = %s and name_id = %s"),
		GetTrcGroup("select trc_group from ( select trc_group from thot.aom_trc_therapies group by trc_group order by dbms_random.random) where rownum < 2"),
		GetTrcPg("select trc_pg from (select trc_pg from thot.aom_trc_phones where trc_group = '%s' order by dbms_random.random) where rownum < 2"),
		GetTrcGroupPhones("select  trc_group as \"trcGroup\", trc_code as \"trcCode\" from ( select trc_group, trc_code  from thot.aom_trc_phones group by trc_group, trc_code order by dbms_random.random) where rownum < 2"),
		TrcAomPhones("select trc_group as \"trcGroup\", trc_pg as \"trcPg\", trc_phone as \"trcPhone\", trc_code as \"trcCode\" from thot.aom_trc_phones"+
			" where trc_group = '%s'"),
		TrcAomPhonesInfo("select trc_pg as \"trcPg\", trim(to_char(trc_phone, '000g000g0000','nls_numeric_characters=.-')) as \"trcPhone\", trc_code as \"trcCode\", created_by as \"userName\" from thot.aom_trc_phones "
			+ "where trc_group = '%s' order by creation_date desc"),
		GetMedicalCondition("select pd.icd9_code as \"conditionCode\", pd.icd_version as \"codingSystem\", d.description as \"description\",to_char(pd.start_date, 'YYYY-MM-DD') as \"onsetDate\","+
			" to_char(pd.stop_date, 'YYYY-MM-DD') as \"abatementDate\" from patient_diagnoses pd join diagnoses d on pd.icd9_code = d.icd9_code where pd.patient_id = %s"),
		GetClinicalTherapy("select pt.therapy_id as \"therapy\",to_char(pt.start_date, 'YYYY-MM-DD')as \"startDate\", to_char(pt.stop_date, 'YYYY-MM-DD') as \"endDate\", pt.stop_reason as \"stopReason\", pt.status as \"status\""+
			" from patient_therapies pt where pt.patient_id = %s"),
		GetTrcAomTherapyType("select therapy_type from (select therapy_type from thot.aom_trc_therapies order by dbms_random.random) where rownum < 2"),
		GetTrcAomByTherapyType("select at.trc_group as \"trcGroup\", at.therapy_type as \"therapyType\", at.eligible as \"eligible\" from thot.aom_trc_therapies at where at.therapy_type = '%s'"),
		CreateRx("select svcbr_id as \"processingPharmacy\", prescription_id as \"rxNumber\", refill_no as \"fillNumber\",to_char(rx_written_date,'YYYY-MM-DD') as \"writtenDate\", to_char(refill_thru_date,'YYYY-MM-DD') as \"refillThruDate\","+
			" to_char(expiration_date,'YYYY-MM-DD') as \"expirationDate\", max_refills as \"fillsAllowed\", rx_status as \"currentStatus\","+
			" patient_id as \"legacyPatientID\", created_by as  \"userId\", order_taken_code as \"orderTaken\" from prescriptions where svcbr_id = %s and prescription_id = %s"),
		GetFillRequestStruct("select svcbr_id as \"fillingPharmacy\",to_char(rx_start_date,'YYYY-MM-DD') as \"rx_start_date\",daw_code as \"substitutions\",md_daw_flag as \"prescriberDAW\",to_char(prescr_ship_date,'YYYY-MM-DD') as \"shipDate\",pt_daw_flag as \"patientDAW\","+
			" no_days_shipment_last as \"daysSupply\",label_instruct as \"directions\", created_by as \"userId\",technician_initials as \"technicianInitials\",refill_no as \"fillNumber\","+
			" to_char(rx_stop_date,'YYYY-MM-DD') as \"rx_stop_date\",drug_route as \"drug_route\",to_char(prescr_ship_date,'YYYY-MM-DD') as \"fillDate\",storage_type as \"storageType\",svcbr_id as \"processingPharmacy\","+
			" next_delivery_note as \"notes\", special_instruct as \"note\" from prescriptions where svcbr_id = %s and prescription_id = %s and refill_no = %s"),
		GetCity("select city from (select city from thot.zip_codes %s order by dbms_random.random) where rownum < 2"),
		TrcIdExists("select trc_id from pt_trc_phones_hdr where trc_id = '%s'"),
		CityExists("select city from thot.zip_codes where city = '%s'"),
		StorageTypeExists("select storage_type from storage_methods where storage_type = '%s'"),
		GetStorageType("select * from (select storage_type from storage_methods order by dbms_random.random) where rownum = 1"),
		DrugRouteExists("select drug_route from drug_routes where drug_route = '%s'"),
		TrcGroupExists("select trc_group from thot.aom_trc_therapies where trc_group = ''"),
		GetSupplyInventory("select inventory_id as \"inventoryId\", lot as \"lot\" from (select inventory_id, lot as from icsl_view where category = 'SNC' and status = 'A' and qoh > 0 and qoh > reserved_qty and loc_id = svcbr_id and "
				+ "svcbr_id = %s and gdrug_abbrev is null and tdrug_abbrev is null order by dbms_random.random) where rownum < 2"),
		GetSupplyInventoryNotIn("select inventory_id as \"inventoryId\", lot as \"lot\" from icsl_view iv, inventory i where iv.category = 'SNC' and i.id = iv.inventory_id and iv.status = 'A' and iv.qoh > 0 and iv.qoh > iv.reserved_qty and iv.loc_id = iv.svcbr_id and iv.svcbr_id = %s "
				+ "and i.tdrug_abbrev is null and i.gdrug_abbrev is null and iv.inventory_id <> %s and iv.lot <> '%s'"),
		GetCgInventory2("select inventory_id as \"inventoryId\", lot as \"lot\", abbrev as \"rxDrug\", strength as \"strength\", strength_unit as \"strengthUnits\", ndc_no as \"ndc\", sale_unit as \"quantityUnits\" from (select iv.inventory_id,lot, td.abbrev, i.strength , i.strength_unit, "
				+ "i.ndc_no, i.sale_unit from icsl_view iv, tdrugs td, inventory i where iv.status = 'A' and iv.qoh > 3 and iv.qoh > iv.reserved_qty "
				+" and iv.inventory_id = i.id and iv.loc_id = iv.svcbr_id and iv.svcbr_id = %s and iv.tdrug_abbrev = td.abbrev and loc_type = 'S' and ( select inventory_id from caregiver_detail where svcbr_id = iv.svcbr_id and prescription_id = %s and refill_no = %s and inventory_id = iv.inventory_id ) "
				+ " is null and rownum < 10 order by dbms_random.random) where rownum < 2"),
		GetCgInventory("select inventory_id as \"inventoryId\", lot as \"lot\", abbrev as \"rxDrug\" from (select iv.inventory_id,lot, td.abbrev from icsl_view iv, tdrugs td, inventory i where iv.status = 'A' and iv.qoh > 0 and iv.qoh > iv.reserved_qty "
				+" and iv.loc_id = iv.svcbr_id and iv.svcbr_id = %s and iv.tdrug_abbrev = td.abbrev and loc_type = 'S' and ( select inventory_id from caregiver_detail where svcbr_id = iv.svcbr_id and prescription_id = %s and refill_no = %s and inventory_id = iv.inventory_id ) "
				+" is null and rownum < 10 order by dbms_random.random) where rownum < 2"),
		GetRxLocAndTherapy("select it_sb_loc_type as \"locType\", it_sb_loc_id as \"locId\", rx.therapy_type as \"ther\"  ,substr(t.therapy_descr,1,5) as \"therapy\" from thot.prescriptions_table rx, therapy_types t where t.therapy_type = rx.therapy_type and rx.svcbr_id = %s and rx.prescription_id = %s and refill_no = %s"),
		GetTherapyLike("select substr(t.therapy_descr,1,5) as \"therapy\" from therapy_types t where t.therapy_type = '%s'"),
		GetNonCompInventory("select iv.inventory_id as \"inventoryId\",iv.lot as \"lot\", iv.tdrug_abbrev as \"rxDrug\" ,  i.strength as \"strength\" , i.strength_unit as \"strengthUnits\", i.ndc_no as \"ndc\", i.sale_unit as \"quantityUnits\""
				+" from icsl_view iv, inventory i where iv.inventory_id = i.id and iv.tdrug_abbrev like '%%%s%%' and iv.svcbr_id = %s and iv.loc_type = '%s' and iv.loc_id = %s and iv.status = 'A' and iv.available_qty > 0"),
		GetNonCompInventory2("SELECT inv.id as \"inventoryId\", inv.ndc_no as \"ndc\", inv.strength as \"strength\", ic.lot as \"lot\", inv.strength_unit as \"strengthUnits\", inv.sale_unit as \"quantityUnits\""
				+", iv.tdrug_abbrev as \"rxDrug\" FROM thot.inventory inv,thot.icslocs ic,thot.inventory_therapies ith,  icsl_view iv  WHERE inv.id = ic.inventory_id and iv.inventory_id = inv.id AND ic.inventory_id = ith.inventory_id(+)"
				     +"AND inv.ndc_no in (select ndc_no from inventory i where (select count(id) from inventory where ndc_no = i.ndc_no and strength = i.strength)> 1)"
				     +"AND ic.svcbr_id = %s  AND ic.loc_type = '%s' AND ic.loc_id = %s"
				     +"and ic.status = 'A' and ic.available_qty > 0"
				   +" and ith.therapy_type = '%s' order by ic.available_qty desc "),
		GetInvDetails("select inv.id as  \"invId\",inv.strength as \"strength\", inv.strength_unit as \"strengthUnits\", inv.sale_unit as \"quantityUnits\", ic.lot as \"lot\" from thot.inventory inv,thot.icslocs ic,thot.inventory_therapies ith where "
				+ " inv.ndc_no = '%s' and inv.id = ic.inventory_id and ic.inventory_id = ith.inventory_id and ic.svcbr_id = %s and ic.loc_type = 'S' and ic.loc_id = ic.svcbr_id and ic.status = 'A' and ic.available_qty > 3 and inv.strength is not null "
				+ " and ith.therapy_type = (select ftl.attribute1 from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API' and ftl.code = 'NDC_THERAPY_MAPPING' and attribute3 =inv.ndc_no) order by ic.available_qty desc"),
		GetMaxRefill("select max(refill_no) as \"MaxRefill\" from prescriptions where svcbr_id = %s and prescription_id = %s"),
		GetInvalidSb("select max(id)+  round(dbms_random.value() * 10) + 1 from service_branches"),
		GetInvalidInventoryId("select max(id)+  round(dbms_random.value() * 10) + 1 from inventory"),
		GetTTNotInTrc("select '%s' as \"trcId\",therapy_type as \"therapyType\", 'automation_supu' as \"userName\" from (select tt.therapy_type from thot.therapy_types tt  where tt.therapy_type %s in (select therapy_type from pt_trc_phones_dtl)"
				+ "order by sys.dbms_random.random)where rownum = %s"),
		GetTrcId("select trc_id from (select trc_id from  pt_trc_phones_hdr order by dbms_random.random) where rownum <2"),
		TherapyTypeAddedToTrc("select count(therapy_type) from pt_trc_phones_dtl where trc_id = '%s' and therapy_type in ('%s')"),
		GetPatientIdDifferentThan("select id from (select p.id from patients p where p.id <> %s and p.created_date > (sysdate - 5) and rownum < 30 order by dbms_random.random) where rownum < 2"),
		GetPatientPrescribers("select physician_id as \"prescriber\" from patient_physician where patient_id = %s"),
		GetPrescriberIdNotIn("select id from (select id from physicians where id not in ('%s') and update_date > (sysdate - 160) order by dbms_random.random) where rownum < 2"),
		GetPatientTherapies("select therapy_type as \"therapyType\" from patient_therapies where patient_id = %s"),
		GetTherapyTypeNotIn("select therapy_type from (select therapy_type from therapy_types where therapy_type not in ('%s') order by dbms_random.random) where rownum < 2"),
		GetInvalidPatient("select max(id)+  round(dbms_random.value() * 10) + 1 from patients"),
		GetTTNotAddedToTrcAom("select therapy_type from (select tt.therapy_type from thot.therapy_types tt  where tt.therapy_type not in (select therapy_type from thot.aom_trc_therapies)order by sys.dbms_random.random)where rownum < 2"),
		GetTTAddedToTrcAom("select therapy_type from (select tt.therapy_type from thot.therapy_types tt  where tt.therapy_type in (select therapy_type from thot.aom_trc_therapies)order by sys.dbms_random.random)where rownum < 2"),
		GetOrderTakenDifferentThan("select attribute1 from ft_lookups where type = 'SDS_PRESCRIPTION_API' and code = 'RX_ORIGIN_CODE_MAPPING' and attribute1 <> '%s'"),
		GetOrderTaken("select attribute1 from ft_lookups where type = 'SDS_PRESCRIPTION_API' and code = 'RX_ORIGIN_CODE_MAPPING'"),
		GetStatusDifferentThan("select status from (select status from (select 'PENDING' as status from dual union select 'ACTIVE' as status from dual union select 'HOLD' as status from dual) where status <> '%s'"
				+ "order by sys.dbms_random.random)where rownum < 2"),
		GetCurrentStatus("select status from (select status from (select 'PENDING' as status from dual union select 'ACTIVE' as status from dual union select 'HOLD' as status from dual union select 'PROFILE' as status from dual)"
				+ "order by sys.dbms_random.random)where rownum < 2"),
		GetRxOrignCode("select * from (select attribute2 as \"code\", attribute3 as \"name\" from ft_lookups where type = 'SDS_PRESCRIPTION_API' and code = 'RX_ORIGIN_CODE_MAPPING'order by sys.dbms_random.random)where rownum < 2"),
		GetRxOriginCodeNotMatchingName("select * from (select attribute3 from ft_lookups where type = 'SDS_PRESCRIPTION_API' and code = 'RX_ORIGIN_CODE_MAPPING' and attribute2 <>  %s order by sys.dbms_random.random)where rownum < 2"),
		GetRxOrignCodeFrom("select * from (select attribute2 as \"code\", attribute3 as \"name\" from ft_lookups where type = 'SDS_PRESCRIPTION_API' and code = 'RX_ORIGIN_CODE_MAPPING' and attribute1 = '%s' order by sys.dbms_random.random)where rownum < 2"),
		GetPatientWithTTNotIn("select id from (select p.id from patients p where id <> %s and p.created_date > (sysdate - 5) and exists (select id from patient_therapies pt where pt.patient_id = p.id) and exists (select physician_id as from"
				+ " patient_physician where patient_id = p.id) order by dbms_random.random) where rownum < 2"),
		GetPatientsTT("select therapy_type from thot.patient_therapies  pt where pt.patient_id = %s"),
		GetRxDrug("select drug_abbrev from prescription_drugs where svcbr_id = %s and prescription_id = %s and refill_no = %s"),
		GetCgDrug("select abbrev from(select abbrev from tdrugs order by dbms_random.random) where rownum < 2"),
		GetMaxTaskCreationDate("select max(creation_date) from thot.wq_tasks where workqueue_id = (select workqueue_id from thot.ft_workqueues where name = 'ORDER_ENTRY') and creation_date <= '%s' and svcbr_id  = %s "
				+ "and prescription_id = %s and refill_no = %s"),
		GetIntegratedReceivedDate("select to_char(to_date(nrec.ns_rx_receive_date,'yyyymmdd'),'YYYY-MM-DD') from rxh_custom.mi_prescription_xref rx, rxh_custom.mi_n000_n004_record nrec where rx.svcbr_id = %s and rx.prescription_id = %s"
				+ " %s and rx.ns_ord_invno = nrec.ns_ord_invno and rx.ns_ord_invno_sub = nrec.ns_ord_invno_sub and rx.ns_ord_pharm_loca_no = nrec.ns_ord_pharm_loca_no"),
		GetDirectReceivedDate("select to_char(MIN(d.date_scanned), 'YYYY-MM-DD') from thot.af_prescriptions_images rx, doc_owner.ims_documents d where rx.svcbr_id = %s and "
				+ " rx.prescription_id = %s %s and rx.document_id =d.document_id"),
		GetDrugRoute("select drug_route from(select drug_route from drug_routes order by dbms_random.random) where rownum < 2"),
		GetFrequency("select freq from (select freq from  thot.frequencies where status = 'A' order by dbms_random.random) where rownum < 2"),
		GetFreqUnit("select freqUnit from (select freqUnit from (select 'noDoses' as freqUnit from dual union select 'noDays' as freqUnit from dual) order by sys.dbms_random.random)where rownum < 2"),
		GetInvAvailableQty("select available_qty from icsl_view ic where inventory_id = %s  and lot = '%s' and loc_type = 'S' and svcbr_id = %s"),
		TrcPgExists("select trc_pg from thot.aom_trc_phones where trc_group = '%s' and trc_pg = '%s'"),
		SupplyWithInvExists("select inventory_id from thot.ancillary_prescriptions where svcbr_id = %s and prescription_id= %s and refill_no = %s and inventory_id = %s and lot = '%s'"),
		CaregiverWithInvExists("select inventory_id from thot.caregiver_detail where svcbr_id = %s and prescription_id= %s and refill_no = %s and inventory_id = %s and lot = '%s'"),
		NonCompInvAdded("select inventory_id from thot.prescription_items_v where svcbr_id = %s and prescription_id= %s and refill_no = %s and inventory_id = %s and lot = '%s'"),
		GetTherapyAndDrug("select therapy_type as \"therapyType\", drug_abbrev as \"drugAbbrev\"  from (select rx.therapy_type, pd.drug_abbrev from thot.prescriptions_table rx, "
				+ " thot.prescription_drugs pd where 1 = 1 and rx.svcbr_id = pd.svcbr_id and rx.prescription_id = pd.prescription_id and rx.refill_no = pd.refill_no and "
				+ " rx.rx_status not in ('VOID','DC','PROFILE') and rx.technician_initials is null  and rx.pharmacist_initials is null and rx.profile_lock_initials is null "
				+ " and rx.rxlock = 'N' and rx.creation_date > (sysdate - 6) and pd.creation_date > (sysdate - 6) order by dbms_random.random) where rownum < 2"),
		GetInv("select iv.inventory_id as \"inventoryId\",i.ndc_no as \"ndc\", iv.svcbr_id as \"sb\", iv.strength as \"strength\" from icsl_view iv, inventory i where 1 = 1 and iv.inventory_id = i.id and iv.status = 'A'"
				+" and iv.available_qty > 0 and iv.loc_id = iv.svcbr_id and iv.tdrug_abbrev = '%s'"),
		NdcExists("select ndc_no from inventory where ndc_no = '%s'"),
		GetPrescriberInfo("select dea_id as \"deaId\", npi_id as \"npiId\", first as \"first\", last as \"last\" from thot.physicians where id = %s"),
		GetRxComments("select rx_status_comment from thot.prescriptions_table where svcbr_id = %s and prescription_id = %s and refill_no = 0"),
		GetPatientsDocumentIds("select document_id from doc_owner.ims_documents docs where patient_id = %s"),
		GetSbNot("select * from(select id from service_branches where id <> %s order by dbms_random.random) where rownum < 2");

	    private final String query;       

	    private SqlQueries(String q) {
	    	this.query = q;
	    }
	    public String toString() {
	        return query;
	    }
}
