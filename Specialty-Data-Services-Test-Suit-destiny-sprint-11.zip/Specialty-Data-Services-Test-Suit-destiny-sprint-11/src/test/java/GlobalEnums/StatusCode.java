package GlobalEnums;

public enum StatusCode {
	
	Success(200),
	Created(201),
	Unauthorized(401),
	BadRequest(400),
	NotFound(404),
	MethodNotAllowed(405),
	InternalError(500);

	    private final int statusCode;       

	    private StatusCode(int sc) {
	    	this.statusCode = sc;
	    }
	    public int getStatusCode() {
	        return statusCode;
	    }
}
