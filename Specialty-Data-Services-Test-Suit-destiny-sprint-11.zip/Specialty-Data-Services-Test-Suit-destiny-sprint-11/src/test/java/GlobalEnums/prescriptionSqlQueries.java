package GlobalEnums;

public enum prescriptionSqlQueries {
	
		GetPatientPrescriptions("select rx.prescription_id       as \"rxNumber\""+
	                      ",rx.svcbr_id              as \"processingPharmacy\""+
	                      ",rx.rx_written_date       as \"writtenDate\""+
	                      ",rx.expiration_date       as \"expirationDate\""+
	                      ",rx.max_refills           as \"fillsAllowed\""+
	                      ",rx.rx_status             as \"currentStatus\""+
	                      ",rx.therapy_type          as \"therapyID\""+
	                      ",decode(rx.refill_no"+
	                      ", 0, 'Prescribed'"+
	                      ", 'Dispensed')      as \"item\""+
	                      ", i.description           as \"name\""+
	                      ",rx.physician_id          as \"prescriber\""+
	                      ",rx.patient_id            as \"patient\""+
	                      ",rx.rx_status_date        as \"timestamp\""+                                           
	                      ",rx.void_reason           as \"comments\""+                                            
	                      ",rx.est_delivery_date     as \"needByDate\""+                                          
	                      ",rx.nbd_confirmation      as \"needByDateConfirmation\""+                             
	                      ",rx.nbd_reason_code       as \"needByDateReasonCode\""+                           
	                      ",rx.patient_addr_seq      as \"scheduledAddressReference\""+                           
	                      ",rx.refill_flag           as \"autoRefillIndicator\""+                         
	                      ",rx.next_delivery_date    as \"scheduledFillDate\""+                               
	                      ",rx.next_delivery_date    as \"fillReminderDate\""+
	                      ",rx.order_taken_code      as \"sourceName\""+                                  
	                      ",WS_OWNER.sds_util_pkg.get_rxOriginCode(rx.order_taken_code) as \"rxOriginCode\""+
	                " from thot.prescriptions_table rx"+
	                    ",thot.prescription_items_v rxv"+
	                    ",thot.prescription_drugs pd"+
	                    ",thot.caregiver_drugs cg"+
	                    ",thot.inventory i"+
	               " where rx.svcbr_id = rxv.svcbr_id"+
	                 " and rx.prescription_id = rxv.prescription_id"+
	                 " and rx.refill_no = rxv.refill_no"+
	                 " and pd.svcbr_id(+) = rxv.svcbr_id"+
	                 " and pd.prescription_id(+) = rxv.prescription_id"+
	                 " and pd.refill_no(+) = rxv.refill_no"+
	                 " and pd.line_id(+) = rxv.line_id"+
	                 " and cg.svcbr_id(+) = rxv.svcbr_id"+
	                 " and cg.prescription_id(+) = rxv.prescription_id"+
	                 " and cg.refill_no(+) = rxv.refill_no"+
	                 " and rxv.inventory_id = i.id(+)"+
	                " and rx.patient_id = %s"+
	                " and rx.prescr_ship_date between '%s' and '%s' %s "+
	              " order by rx.refill_no, rx.prescription_id, rx.refill_no"),
	    GetDistinctPatientPrescriptions("select distinct rx.prescription_id as \"rxId\",rx.svcbr_id as \"sb\" from thot.prescriptions_table rx where 1 =1 and rx.patient_id = %s "
	    		+ " and rx.prescr_ship_date between  '%s' and '%s' %s order by  rx.prescription_id"),
	    GetPrescriptionInfo("select rx.prescription_id as \"rxNumber\",rx.svcbr_id as \"processingPharmacy\",rx.rx_written_date as \"writtenDate\",rx.expiration_date"+      
				" as \"expirationDate\",rx.max_refills as \"fillsAllowed\",rx.rx_status as \"currentStatus\",rx.therapy_type"+          
				" as \"therapyID\",decode(rx.refill_no, 0, 'Prescribed', 'Dispensed') as \"item\", i.description as \"name\",rx.physician_id"+        
				" as \"prescriber\",rx.patient_id as \"patient\",rx.rx_status_date as \"timestamp\",rx.void_reason as \"comments\",rx.est_delivery_date"+  
				" as \"needByDate\",rx.nbd_confirmation as \"needByDateConfirmation\",rx.nbd_reason_code as \"needByDateReasonCode\",rx.patient_addr_seq"+    
				" as \"scheduledAddressReference\",rx.refill_flag as \"autoRefillIndicator\",rx.next_delivery_date    as \"scheduledFillDate\",rx.next_delivery_date"+  
				" as \"fillReminderDate\",rx.order_taken_code as \"sourceName\",WS_OWNER.sds_util_pkg.get_rxOriginCode(rx.order_taken_code)"+
				" as \"rxOriginCode\" from thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd,thot.caregiver_drugs cg,thot.inventory i"+
				" where rx.svcbr_id = rxv.svcbr_id and rx.prescription_id = rxv.prescription_id and rx.refill_no = rxv.refill_no and pd.svcbr_id(+) = rxv.svcbr_id"+
				" and pd.prescription_id(+) = rxv.prescription_id and pd.refill_no(+) = rxv.refill_no and pd.line_id(+) = rxv.line_id"+
				" and cg.svcbr_id(+) = rxv.svcbr_id and cg.prescription_id(+) = rxv.prescription_id and cg.refill_no(+) = rxv.refill_no"+ 
				" and rxv.inventory_id = i.id(+)"+
				" and rx.svcbr_id = %s and rx.prescription_id = %s and rx.prescr_ship_date between  '%s' and '%s'"+
				" order by rx.refill_no, rx.prescription_id, rx.refill_no"),
		GetPrescriptionInfoWithoutRange("select rx.prescription_id as \"rxNumber\",rx.svcbr_id as \"processingPharmacy\",rx.rx_written_date as \"writtenDate\",rx.expiration_date"+      
				" as \"expirationDate\",rx.max_refills as \"fillsAllowed\",rx.rx_status as \"currentStatus\",rx.therapy_type"+          
				" as \"therapyID\","+//decode(rx.refill_no, 0, 'Prescribed', 'Dispensed') as \"item\","
				" rx.physician_id"+        
				" as \"prescriber\",rx.patient_id as \"patient\",rx.rx_status_date as \"timestamp\",rx.void_reason as \"comments\",rx.est_delivery_date"+  
				" as \"needByDate\",rx.nbd_confirmation as \"needByDateConfirmation\",rx.nbd_reason_code as \"needByDateReasonCode\",rx.patient_addr_seq"+    
				" as \"scheduledAddressReference\",rx.refill_flag as \"autoRefillIndicator\",rx.next_delivery_date as \"scheduledFillDate\",rx.next_delivery_date"+  
				" as \"fillReminderDate\",rx.order_taken_code as \"sourceName\",WS_OWNER.sds_util_pkg.get_rxOriginCode(rx.order_taken_code)"+
				" as \"rxOriginCode\",rx.copy_xfer_flag as \"transferFlag\",rx.svcbr_copied_from as \"cProcessingPharmacy\", rx.presc_copied_from as \"cRxNumber\",rx.refill_copied_from as \"cFillNumber\","+
				" to_char(rx.creation_date, 'dd-Mon-yyyy') as \"creationDate\" , rx.created_by as \"transferUser\""+
				" from thot.prescriptions_table rx where"+
				" rx.svcbr_id = %s and rx.prescription_id = %s %s"+
				" order by rx.refill_no, rx.prescription_id, rx.refill_no"),
		GetPrescriptionInfoWithoutRange2("select rx.prescription_id as \"rxNumber\",rx.svcbr_id as \"processingPharmacy\", to_char(rx.rx_written_date, 'YYYY-MM-DD')as \"writtenDate\",to_char(rx.expiration_date, 'YYYY-MM-DD')"      
				+ " as \"expirationDate\",rx.max_refills as \"fillsAllowed\",rx.rx_status as \"currentStatus\",rx.therapy_type as \"therapyID\", rx.physician_id as \"prescriber\",rx.patient_id as \"patient\","
				+ " rx.copy_xfer_flag as \"transferFlag\",rx.svcbr_copied_from as \"cProcessingPharmacy\", rx.presc_copied_from as \"cRxNumber\",rx.refill_copied_from as \"cFillNumber\", to_char(rx.creation_date, 'YYYY-MM-DD') "
				+ " as \"creationDate\" , rx.created_by as \"transferUser\", rx.refill_flag as \"autoRefillIndicator\", rx.order_taken_code as \"sourceName\",WS_OWNER.sds_util_pkg.get_rxOriginCode(rx.order_taken_code)"
				+ " as \"rxOriginCode\" from thot.prescriptions_table rx where rx.svcbr_id = %s and rx.prescription_id = %s %s order by rx.refill_no, rx.prescription_id, rx.refill_no"),
	    GetRxFills("select  rx.svcbr_id as \"fillingPharmacy\","+
				" rx.refill_no as \"fillNumber\","+
				" rx.prescr_ship_date as \"shipdate\","+ 
				" null as \"localId\","+
				" rx.prescr_ship_date as \"fillDate\","+ 
				" rx.svcbr_id as \"processingPharmacy\""+
				" from thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd,thot.caregiver_drugs cg,thot.inventory i"+
				" where rx.svcbr_id = rxv.svcbr_id and rx.prescription_id = rxv.prescription_id and rx.refill_no = rxv.refill_no and pd.svcbr_id(+) = rxv.svcbr_id"+ 
				" and pd.prescription_id(+) = rxv.prescription_id and pd.refill_no(+) = rxv.refill_no and pd.line_id(+) = rxv.line_id"+
				" and cg.svcbr_id(+) = rxv.svcbr_id and cg.prescription_id(+) = rxv.prescription_id and cg.refill_no(+) = rxv.refill_no"+ 
				" and rxv.inventory_id = i.id(+) and rx.svcbr_id = %s"+
				" and rx.prescription_id = %s and rx.prescr_ship_date between  '%s' and '%s'"+
				" order by  rx.prescription_id"),
		GetRxFillsWithoutRange("select rx.refill_no as \"fillNumber\",  to_char(rx.prescr_ship_date, 'YYYY-MM-DD') as \"shipdate\", null as \"localId\","
				+ " to_char(rx.prescr_ship_date, 'YYYY-MM-DD') as \"fillDate\", rx.svcbr_id as \"processingPharmacy\", rx.svcbr_id as \"fillingPharmacy\",  to_char(rx.next_delivery_date, 'YYYY-MM-DD') as \"scheduledFillDate\","
				+ " to_char(rx.next_delivery_date, 'YYYY-MM-DD') as \"fillReminderDate\", to_char(rx.rx_status_date, 'YYYY-MM-DD') as \"timestamp\",rx.void_reason as \"comments\" , "  
				+ " to_char(rx.est_delivery_date, 'YYYY-MM-DD') as \"needByDate\",rx.nbd_confirmation as \"needByDateConfirmation\",rx.nbd_reason_code as \"needByDateReasonCode\", "
				+ "rx.patient_addr_seq \"scheduledAddressReference\", rx.next_delivery_note \"notes\" from "
				+ " thot.prescriptions_table rx where rx.svcbr_id = %s and rx.prescription_id = %s %s order by  rx.prescription_id"),
		GetTTSub(" and (select count(distinct rx.therapy_type) from thot.prescriptions_table rx where p.id = rx.patient_id and patient_id = p.id and prescr_ship_date  between '%s' and '%s')> 1"),
		GetDRSub(" and (select count(rx.prescription_id) from thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i  where p.id = rx.patient_id"+ 
						" and rx.svcbr_id = rxv.svcbr_id"+
						" and rx.prescription_id = rxv.prescription_id"+
						" and rx.refill_no = rxv.refill_no "+
						" and  pd.svcbr_id(+) = rxv.svcbr_id "+
						" and pd.prescription_id(+) = rxv.prescription_id"+
						" and pd.refill_no(+) = rxv.refill_no "+
						" and pd.line_id(+) = rxv.line_id "+
						" and cg.svcbr_id(+) = rxv.svcbr_id "+
						" and cg.prescription_id(+) = rxv.prescription_id"+ 
						" and cg.refill_no(+) = rxv.refill_no "+
						" and rxv.inventory_id = i.id(+) and patient_id = p.id and prescr_ship_date not between '%s' and '%s')> 1"),
		GetDirectPatientWithoutRx("select id from (select pd.id from (select p.id from patients p, thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i  where p.id = rx.patient_id"+ 
						" and rx.svcbr_id = rxv.svcbr_id"+
						" and rx.prescription_id = rxv.prescription_id"+
						" and rx.refill_no = rxv.refill_no "+
						" and  pd.svcbr_id(+) = rxv.svcbr_id "+
						" and pd.prescription_id(+) = rxv.prescription_id"+
						" and pd.refill_no(+) = rxv.refill_no "+
						" and pd.line_id(+) = rxv.line_id "+
						" and cg.svcbr_id(+) = rxv.svcbr_id "+
						" and cg.prescription_id(+) = rxv.prescription_id"+ 
						" and cg.refill_no(+) = rxv.refill_no "+
						" and rxv.inventory_id = i.id(+)"+
						" and p.id = rx.patient_id and rx.prescr_ship_date not between '%s' and '%s'"+
						") pd"+
						" left join rxh_custom.mi_patients_xref pi on pd.id = pi.id"+ 
						" where pi.id is null and rownum < 30 order by dbms_random.random) where rownum < 2"),
		GetPatientWithoutRx("select id from (select p.id from patients p, thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i  where p.id = rx.patient_id"+ 
						" and rx.svcbr_id = rxv.svcbr_id"+
						" and rx.prescription_id = rxv.prescription_id"+
						" and rx.refill_no = rxv.refill_no "+
						" and  pd.svcbr_id(+) = rxv.svcbr_id "+
						" and pd.prescription_id(+) = rxv.prescription_id"+
						" and pd.refill_no(+) = rxv.refill_no "+
						" and pd.line_id(+) = rxv.line_id "+
						" and cg.svcbr_id(+) = rxv.svcbr_id "+
						" and cg.prescription_id(+) = rxv.prescription_id"+ 
						" and cg.refill_no(+) = rxv.refill_no "+
						" and rxv.inventory_id = i.id(+)"+
						" and p.id = rx.patient_id and rx.prescr_ship_date not between '%s' and '%s'"+
						" and rownum < 30 order by dbms_random.random) where rownum < 2"),
		GetIntegratedRxAvailableTT("select therapy_type from (select p.therapy_type from rxh_custom.mi_prescription_xref rx,thot.prescriptions_table p,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i"+
						 " where  rx.svcbr_id = p.svcbr_id"+
						 " and rx.prescription_id = p.prescription_id"+
						 " and rx.svcbr_id = rxv.svcbr_id"+
						 " and rx.prescription_id = rxv.prescription_id"+
						 " and rx.refill_no = rxv.refill_no"+
						 " and  pd.svcbr_id(+) = rxv.svcbr_id"+ 
						 " and pd.prescription_id(+) = rxv.prescription_id"+
						 " and pd.refill_no(+) = rxv.refill_no"+
						 " and pd.line_id(+) = rxv.line_id"+
						 " and cg.svcbr_id(+) = rxv.svcbr_id"+ 
						 " and cg.prescription_id(+) = rxv.prescription_id"+
						 " and cg.refill_no(+) = rxv.refill_no"+
						 " and rxv.inventory_id = i.id(+)"+
						 " and p.prescr_ship_date between '%s' and '%s'"+
						 " order by dbms_random.random)"+
						 " where rownum < 2"),
		GetIntegratedPatientWithRx("select patient_id as refill  from (select rx.patient_id"+
						 " from rxh_custom.mi_prescription_xref p, thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i"+
						 " where rx.svcbr_id = rxv.svcbr_id"+
						 " and p.prescription_id = rx.prescription_id"+
						 " and p.svcbr_id = rx.svcbr_id"+
						 " and p.prescription_id = rxv.prescription_id"+
						 " and p.refill_no = rxv.refill_no"+
						 " and  pd.svcbr_id(+) = rxv.svcbr_id "+
						 " and pd.prescription_id(+) = rxv.prescription_id"+
						 " and pd.refill_no(+) = rxv.refill_no"+
						 " and pd.line_id(+) = rxv.line_id"+
						 " and cg.svcbr_id(+) = rxv.svcbr_id "+
						 "and cg.prescription_id(+) = rxv.prescription_id "+
						 " and cg.refill_no(+) = rxv.refill_no"+
						 " and rxv.inventory_id = i.id(+) "+
						 " and rx.prescr_ship_date between '%s' and '%s' %s"+
						 " order by dbms_random.random)"+
						 " where rownum < 2"),
		GetPatientWithRx("select id from (select p.id from patients p, thot.prescriptions_table rx where p.id = rx.patient_id and rx.prescr_ship_date between '%s' and '%s' %s %s"
						+ " and rownum < 30 order by dbms_random.random) where rownum < 2"),
		GetAnyAvailableRxTT("select therapy_type from (select tt.therapy_type, rx.patient_id  from thot.therapy_types tt, thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i,patients p "
						+ "where tt.therapy_type = rx.therapy_type"+
						" and p.id = rx.patient_id "+
						" and rx.svcbr_id = rxv.svcbr_id"+
						" and rx.prescription_id = rxv.prescription_id"+
						" and rx.refill_no = rxv.refill_no "+
						" and  pd.svcbr_id(+) = rxv.svcbr_id "+
						" and pd.prescription_id(+) = rxv.prescription_id"+
						" and pd.refill_no(+) = rxv.refill_no "+
						" and pd.line_id(+) = rxv.line_id "+
						" and cg.svcbr_id(+) = rxv.svcbr_id "+
						" and cg.prescription_id(+) = rxv.prescription_id"+ 
						" and cg.refill_no(+) = rxv.refill_no "+
						" and rxv.inventory_id = i.id(+)"+
					" and rx.prescr_ship_date between '%s' and '%s' and (select count(distinct rx.therapy_type) from thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i  where p.id = rx.patient_id"+ 
					" and rx.svcbr_id = rxv.svcbr_id"+
					" and rx.prescription_id = rxv.prescription_id"+
					" and rx.refill_no = rxv.refill_no "+
					" and  pd.svcbr_id(+) = rxv.svcbr_id "+
					" and pd.prescription_id(+) = rxv.prescription_id"+
					" and pd.refill_no(+) = rxv.refill_no "+
					" and pd.line_id(+) = rxv.line_id "+
					" and cg.svcbr_id(+) = rxv.svcbr_id "+
					" and cg.prescription_id(+) = rxv.prescription_id"+ 
					" and cg.refill_no(+) = rxv.refill_no "+
					" and rxv.inventory_id = i.id(+) and patient_id = rx.patient_id and prescr_ship_date  between '%s' and '%s')> 2 and rownum < 30 order by dbms_random.random) where rownum < 2"),
		GetValidRx("select svcbr_id as \"sb\",prescription_id as \"rxId\" %s"+ 
				   " from (select p.id, rx.svcbr_id,rx.prescription_id, rx.refill_no"+ 
				   " from patients p, thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i"+  
				   " where p.id = rx.patient_id and rx.svcbr_id = rxv.svcbr_id and rx.prescription_id = rxv.prescription_id and rx.refill_no = rxv.refill_no"+
				   " and  pd.svcbr_id(+) = rxv.svcbr_id and pd.prescription_id(+) = rxv.prescription_id and pd.refill_no(+) = rxv.refill_no and pd.line_id(+) = rxv.line_id"+
				   " and cg.svcbr_id(+) = rxv.svcbr_id and cg.prescription_id(+) = rxv.prescription_id and cg.refill_no(+) = rxv.refill_no and rxv.inventory_id = i.id(+)"+
				   " and p.id = rx.patient_id and  rx.creation_date > (sysdate - 10)"+
				   " and rownum < 30 order by dbms_random.random) where rownum < 2"),
		DirectRxIteration2("select svcbr_id as \"sb\",prescription_id as \"rxId\" %s from (select pd.svcbr_id,pd.prescription_id,pd.refill_no from (select p.id, rx.svcbr_id,rx.prescription_id,"+
				" rx.refill_no from patients p, thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i  where p.id = rx.patient_id"+
				" and rx.svcbr_id = rxv.svcbr_id"+
				" and rx.prescription_id = rxv.prescription_id"+
				" and rx.refill_no = rxv.refill_no"+
				" and  pd.svcbr_id(+) = rxv.svcbr_id"+ 
				" and pd.prescription_id(+) = rxv.prescription_id"+
				" and pd.refill_no(+) = rxv.refill_no"+
				" and pd.line_id(+) = rxv.line_id"+
				" and cg.svcbr_id(+) = rxv.svcbr_id"+
				" and cg.prescription_id(+) = rxv.prescription_id"+ 
				" and cg.refill_no(+) = rxv.refill_no"+
				" and rxv.inventory_id = i.id(+)"+
				"%s"+
				" and p.id = rx.patient_id and  rx.creation_date > (sysdate - 10)) pd"+
				" left join rxh_custom.mi_patients_xref pi on pd.id = pi.id"+
				" where pi.id is null and rownum < 30 order by dbms_random.random) where rownum < 2"),
		DirectRxWithRefill("select svcbr_id as \"sb\",prescription_id as \"rxId\", refill_no as \"refill\" from (select pd.svcbr_id,pd.prescription_id,pd.refill_no from (select rx.patient_id, rx.svcbr_id,rx.prescription_id, "
				+ "rx.refill_no from thot.prescriptions_table rx  where 1=1 %s and  rx.creation_date > (sysdate - %s)) pd left join rxh_custom.mi_patients_xref pi on patient_id = pi.id where pi.id is null order by dbms_random.random) where rownum < 2"),
		RxWithRefill("select svcbr_id as \"sb\",prescription_id as \"rxId\", refill_no as \"refill\" from (select rx.svcbr_id,rx.prescription_id, rx.refill_no from thot.prescriptions_table rx where 1 =1 %s"
				+" and  rx.creation_date > (sysdate - %s) order by dbms_random.random) where rownum < 2"),
		TransferedRxWithRefill("select svcbr_id as \"sb\",prescription_id as \"rxId\", refill_no as \"refill\" from (select rx.svcbr_id,rx.prescription_id, rx.refill_no from thot.prescriptions_table rx, rxh_custom.mi_patients_xref xref "
				+ " where 1 =1 %s and  rx.creation_date > (sysdate - 10) and rownum < 30 order by dbms_random.random) where rownum < 2"),
		IntegratedRxWithRefill("select svcbr_id as \"sb\",prescription_id as \"rxId\", refill_no as \"refill\" from (select rx.svcbr_id,rx.prescription_id, rx.refill_no"+
				" from rxh_custom.mi_prescription_xref xrx, thot.prescriptions_table rx where 1 = 1 and xrx.svcbr_id = rx.svcbr_id and xrx.prescription_id = rx.prescription_id"+
				" and  xrx.refill_no = rx.refill_no %s and rx.creation_date > (sysdate - %s) order by dbms_random.random) where rownum < 2"),
		RxWithAncillary("select svcbr_id as \"sb\",prescription_id as \"rxId\", refill_no as \"refill\" from (select rx.svcbr_id,rx.prescription_id, rx.refill_no"+
				" from thot.prescriptions_table rx, ancillary_prescriptions ap"+
				" where 1 =1 %s and rx.svcbr_id = ap.svcbr_id and rx.prescription_id = ap.prescription_id and rx.refill_no = ap.refill_no"+
				" and  rx.creation_date > (sysdate - 10) and rownum < 30 order by dbms_random.random) where rownum < 2"),
		RxWithCaregiver("select svcbr_id as \"sb\",prescription_id as \"rxId\", refill_no as \"refill\" from (select rx.svcbr_id,rx.prescription_id, rx.refill_no"+
				" from thot.prescriptions_table rx,  caregiver_detail cg"+
				" where 1 =1 %s and rx.svcbr_id = cg.svcbr_id and rx.prescription_id = cg.prescription_id and rx.refill_no = cg.refill_no"+
				" and  rx.creation_date > (sysdate - 10) and rownum < 30 order by dbms_random.random) where rownum < 2"),
		GetAncillaryInventory("select inventory_id as \"inventoryId\", lot as \"lot\" from (select inventory_id, lot from thot.ancillary_prescriptions ap"+
				" where  ap.svcbr_id = %s and ap.prescription_id = %s and ap.refill_no = %s order by dbms_random.random) where rownum < 2"),
		GetCaregiverInventory("select inventory_id as \"inventoryId\", lot as \"lot\", tdrug_abbrev as \"abbrev\", dosage_unit as \"dUnit\", volume_unit as \"vUnit\" from (select cg.inventory_id, cg.lot, "
				+ "i.tdrug_abbrev, cd.dosage_unit, cd.volume_unit from thot.caregiver_detail cg, thot.caregiver_drugs cd, inventory i where cg.svcbr_id = cd.svcbr_id and cg.prescription_id = cd.prescription_id and "
				+ " cg.refill_no = cd.refill_no and cg.svcbr_id = %s and cg.prescription_id = %s and cg.refill_no = %s and i.id = cg.inventory_id order by dbms_random.random) where rownum < 2"),
		GetRlUserInfo("select to_char(xdate, 'yyyy-MM-dd') as \"date\", p.first ||' '|| p.last as \"name\" from rx_audit rx, thot.pharmacists p where rx.field_name = 'Lock'"+
				" and p.initials = rx.char_value and svcbr_id = %s and prescription_id = %s  %s and rownum = 1"),
		GetPlUserInfo("select to_char(xdate, 'yyyy-MM-dd') as \"date\", p.first ||' '|| p.last as \"name\" from rx_audit rx, thot.pharmacists p where rx.field_name = 'Profile Lock'"+
				" and p.initials = rx.char_value and svcbr_id = %s and prescription_id = %s %s and rownum = 1"),
		GetLlUserInfo("select to_char(xdate, 'yyyy-MM-dd') as \"date\", p.first ||' '|| p.last as \"name\" from rx_audit rx, thot.pharmacists p where rx.field_name = 'Disp'"+
				" and p.initials = rx.char_value and svcbr_id = %s and prescription_id = %s %s and rownum = 1"),
		GetRxDrugSubstituted("select rxd.svcbr_id as \"sb\", rxd.prescription_id as \"rxId\", rxd.refill_no \"refill\"from %s rxd where ws_owner.sds_util_pkg.get_drugs_substitutionType(rxd.drug_abbrev, rxd.drug_prescribed) "
				+ " is not null and rownum < 2 and rxd.creation_date > (sysdate - 600)"),
		GetSusbtitutionInfo("select ws_owner.sds_util_pkg.get_drugs_substitutionType(NVL(pd.drug_abbrev, cg.drug_abbrev), NVL(pd.drug_prescribed, cg.drug_prescribed)) AS \"subsType\""
				+ ",ws_owner.sds_util_pkg.get_substitutionUser(nvl(pd.drug_prescribed, cg.drug_prescribed), nvl(pd.substituted_by,cg.created_by)) AS \"subsUser\""
				+ ",to_char(ws_owner.sds_util_pkg.get_substitutionDateTime(nvl(pd.drug_prescribed, cg.drug_prescribed), nvl(pd.creation_date,cg.creation_date)),'YYYY-MM-DD') AS \"dateTime\""
				+ ",ws_owner.sds_util_pkg.get_substitutedItem(nvl(pd.drug_prescribed, cg.drug_prescribed), nvl(pd.drug_abbrev, cg.drug_abbrev)) AS \"subsItem\""
				+ ",nvl(pd.drug_prescribed, cg.drug_prescribed) as \"presItem\""
				+ "from thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd,thot.caregiver_drugs cg "
				+ "where rx.svcbr_id = rxv.svcbr_id and rx.prescription_id = rxv.prescription_id and rx.refill_no = rxv.refill_no and pd.svcbr_id(+) = rxv.svcbr_id "
				+ "and pd.prescription_id(+) = rxv.prescription_id and pd.refill_no(+) = rxv.refill_no and pd.line_id(+) = rxv.line_id and cg.svcbr_id(+) = rxv.svcbr_id "
				+ "and cg.prescription_id(+) = rxv.prescription_id and cg.refill_no(+) = rxv.refill_no and nvl(pd.drug_prescribed, cg.drug_prescribed) is not null and rx.svcbr_id = %s and rx.prescription_id = %s and rx.refill_no = %s"),
		GetProcessingUsers("select distinct decode(rx.field_name, 'Profile Lock', 'EntryTechnician', 'Lock', 'ProcessingPharmacist','Disp','VerifyingPharmacist') as \"userType\", p.first ||' '|| p.last as \"userName\","
				+ "to_char(rx.xdate, 'yyyy-MM-dd') as \"processingTime\" from thot.rx_audit rx ,thot.pharmacists p where rx.field_name in ('Profile Lock','Lock','Disp') and p.initials = rx.char_value and"
				+ " rx.char_value is not null and rx.svcbr_id = %s and rx.prescription_id = %s %s"),
		GetRxPrescribedItems("select distinct i.id as \"itemReference\", i.description as \"name\", i.ndc_no as \"ndc\", i.strength as \"strength\", i.strength_unit as \"strengthUnits\", rxv.qty as \"quantity\","
				+ " i.sale_unit as \"quantityUnits\", rx.no_days_shipment_last as \"daysSupply\", rx.no_days_shipment_last as \"cycleDays\", pd.dosage as \"dosageAmount\", pd.dosage_unit as \"dosageUnits\","
				+ " pd.frequency as \"doseFrequency\", 'Y' as \"specialtyIndicator\", rx.label_instruct as \"directions\", rx.special_instruct as \"note\", rx.daw_code as \"substitutions\", rx.md_daw_flag as"
				+ " \"prescriberDAW\", rx.pt_daw_flag as \"patientDAW\", decode(rx.refill_no, 0, 'Prescribed', 'Dispensed') as \"item\" ,decode(rxv.source_type,'nd','noncompounded_detail','cd','compounding_detail'"
				+ ",'cr','compounding_record','pc','prescription_container','cg','caregiver_detail','ap','ancillary_prescriptions') AS \"itemType\""
				+ " from thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd,thot.inventory i where rx.svcbr_id = rxv.svcbr_id(+)"
				+ " and rx.prescription_id = rxv.prescription_id(+) and rx.refill_no = rxv.refill_no(+) and pd.svcbr_id(+) = rxv.svcbr_id and pd.prescription_id(+) = rxv.prescription_id and pd.refill_no(+) = "
				+ " rxv.refill_no and pd.line_id(+) = rxv.line_id and rxv.inventory_id = i.id(+) and rx.svcbr_id = %s and rx.prescription_id = %s "
				+ " and rx.refill_no = 0 order by rx.refill_no, rx.prescription_id, rx.refill_no"),
		GetRxDispensedItems("select i.id as \"itemReference\", i.description as \"name\", i.ndc_no as \"ndc\", i.strength as \"strength\", i.strength_unit as \"strengthUnits\", rxv.qty as \"quantity\","
				+ " i.sale_unit as \"quantityUnits\", rx.no_days_shipment_last as \"daysSupply\", rx.no_days_shipment_last as \"cycleDays\", pd.dosage as \"dosageAmount\", pd.dosage_unit as \"dosageUnits\","
				+ " pd.frequency as \"doseFrequency\", 'Y' as \"specialtyIndicator\", rx.label_instruct as \"directions\", rx.special_instruct as \"note\", rx.daw_code as \"substitutions\", rx.md_daw_flag as"
				+ " \"prescriberDAW\", rx.pt_daw_flag as \"patientDAW\", decode(rx.refill_no, 0, 'Prescribed', 'Dispensed') as \"item\" ,decode(rxv.source_type"+
	                 " ,'nd','noncompounded_detail'"+
	                 " ,'cd','compounding_detail'"+
	                 " ,'cr','compounding_record'"+
	                 " ,'pc','prescription_container'"+
	                 " ,'cg','caregiver_detail'"+
	                 " ,'ap','ancillary_prescriptions') AS \"itemType\""
				+ " from thot.prescriptions_table rx,thot.prescription_items_v rxv,thot.prescription_drugs pd,thot.inventory i where rx.svcbr_id = rxv.svcbr_id"
				+ " and rx.prescription_id = rxv.prescription_id and rx.refill_no = rxv.refill_no and pd.svcbr_id(+) = rxv.svcbr_id and pd.prescription_id(+) = rxv.prescription_id and pd.refill_no(+) = "
				+ " rxv.refill_no and pd.line_id(+) = rxv.line_id and rxv.inventory_id = i.id(+) and rx.svcbr_id = %s and rx.prescription_id = %s "
				+ " %s order by rx.refill_no, rx.prescription_id, rx.refill_no"),
		GetRxUpdatableFields("select rx.prescription_id as \"rxNumber\", rx.svcbr_id as \"processingPharmacy\", to_char(rx.rx_written_date, 'YYYY-MM-DD') as \"writtenDate\"," 
				+" to_char(rx.refill_thru_date, 'YYYY-MM-DD') as \"refillThruDate\", to_char(rx.expiration_date, 'YYYY-MM-DD') as \"expirationDate\", rx.max_refills as \"fillsAllowed\","
				+" rx.rx_status as \"currentStatus\", rx.physician_id as \"prescriber\", rx.patient_id as \"patient\", rx.therapy_type as \"therapyID\", rx.order_taken_code as \"orderTaken\""
				+" from thot.prescriptions_table rx where 1 = 1 and rx.svcbr_id = %s and rx.prescription_id = %s and rx.refill_no = %s"),
		GetRxShipDate("select to_char(prescr_ship_date, 'YYYY-MM-DD')from thot.prescriptions_table where svcbr_id = %s and prescription_id = %s and refill_no = %s"),
		GetRxWrittenDate("select to_char(rx_written_date, 'YYYY-MM-DD')from thot.prescriptions_table where svcbr_id = %s and prescription_id = %s and refill_no = %s"),
		GetRxLotExpDate("select to_char(l.expiration_date, 'YYYY-MM-DD') from thot.prescription_items_v iv, lots l where 1=1 and iv.lot = l.lot and iv.inventory_id = "
				+ "l.inventory_id and svcbr_id = %s and prescription_id = %s and refill_no = %s order by l.expiration_date asc"),
		GetUpdateFillInfo("select null as \"localId\", rx.svcbr_id as \"processingPharmacy\", rx.svcbr_id as \"fillingPharmacy\",rx.refill_no as \"fillNumber\","
				+" to_char(rx.prescr_ship_date,'YYYY-MM-DD') as \"fillDate\", to_char(rx.prescr_ship_date,'YYYY-MM-DD') as \"shipDate\", to_char(rx.rx_written_date,'YYYY-MM-DD') as \"writtenDate\","
				+" to_char(rx.rx_start_date,'YYYY-MM-DD') as \"rx_start_date\", to_char(rx.rx_stop_date,'YYYY-MM-DD') as \"rx_stop_date\","
				+" rx.no_days_shipment_last as \"daysSupply\",rx.label_instruct as \"directions\", rx.next_delivery_note as \"note\","
				+" rx.daw_code as \"substitutions\", rx.md_daw_flag as \"prescriberDAW\", rx.pt_daw_flag as \"patientDAW\", rx.drug_route as \"drug_route\","
				+" rx.storage_type as \"storage_type\" from thot.prescriptions_table rx where 1= 1 and rx.svcbr_id = %s and rx.prescription_id = %s"
				+" and rx.refill_no = %s"),
		GetFillInfo("select rx.svcbr_id as \"processingPharmacy\", rx.svcbr_id as \"fillingPharmacy\",rx.refill_no as \"fillNumber\", to_char(rx.prescr_ship_date,'DD-MON-YY') as \"fillDate\","
				+ " to_char(rx.prescr_ship_date,'DD-MON-YY') as \"shipDate\",to_char(rx.rx_start_date,'DD-MON-YY') as \"rx_start_date\", to_char(rx.rx_stop_date,'DD-MON-YY') as \"rx_stop_date\","
				+ " rx.no_days_shipment_last as \"daysSupply\",rx.label_instruct as \"directions\", rx.next_delivery_note as \"note\", rx.daw_code as \"substitutions\", rx.md_daw_flag as \"prescriberDAW\", "
				+ " rx.pt_daw_flag as \"patientDAW\", rx.drug_route as \"drug_route\", rx.storage_type as \"storage_type\", 'Electronic' as \"order_taken_code\", 'Test' as \"notes\" from "
				+ " thot.prescriptions_table rx "
				+ " where 1= 1 and rx.svcbr_id = %s and rx.prescription_id = %s and rx.refill_no = %s"),
		GetUpdateFillBaseInfo("select svcbr_id as \"processingPharmacy\", prescription_id as \"rxNumber\", uniq_id as \"resourceId\" from prescription_drugs where 1= 1 and svcbr_id = %s and prescription_id = %s "
				+ " and refill_no = %s"),
		IsIntegrated("select ns_ord_invno from rxh_custom.mi_prescription_xref rx where rx.svcbr_id = %s and rx.prescription_id = %s %s "),
		GetInvalidFill0Rx("select max(id)+ round(dbms_random.value() * 10) + 1 as \"sb\", round(dbms_random.value() * 1000) + 1 as \"rxId\" ,'0' as \"refill\" from service_branches"),
		GetInvalidNotFill0Rx("select max(id)+ round(dbms_random.value() * 10) + 1 as \"sb\", round(dbms_random.value() * 1000) + 1 as \"rxId\" ,round(dbms_random.value() * 3) + 1 as \"refill\" from service_branches"),
		GetCaregiverDetails("select cg.svcbr_id as \"processingPharmacy\", cg.refill_no \"fillNumber\", cd.dosage as \"dosage\",cd.dosage_unit \"dosage_unit\", cd.drug_abbrev as  \"name\", cg.inventory_id as \"itemReference\", "
				+" cg.lot as \"lot\",cd.volume as \"volume\", cd.volume_unit as \"volumeUnit\", drug_route as \"drugRoute\", cg.quantity_per as \"quantityPer\", cd.freq as \"doseFrequency\", cg.quantity_to_ship as \"quantity\"," 
				+" cd.caregiver_labels_print as \"labelsPrintNumber\", cg.no_days as \"noDays\"  , cg.no_doses as \"noDoses\", 'Y' as \"specialtyIndicator\", 'cg' as \"itemType\", 'AUTOMATION_SUPU' as \"userName\", "
				+" i.strength as \"strength\", strength_unit as \"strengthUnits\", ndc_no as \"ndc\", i.sale_unit as \"quantityUnits\"from (select * from thot.caregiver_drugs where svcbr_id = %s and prescription_id = %s and "
				+" refill_no = %s order by creation_date desc)cd, (select * from thot.caregiver_detail where svcbr_id = %s and prescription_id = %s and refill_no = %s order by uniq_id desc) cg, thot.inventory i"
				+" where 1 = 1 and cg.inventory_id = i.id and cg.svcbr_id = cd.svcbr_id and cg.prescription_id  = cd.prescription_id and cg.refill_no = cd.refill_no and cd.drug_abbrev = i.tdrug_abbrev "),
		CaregiverExists("select cg.prescription_id, cd.prescription_id from thot.caregiver_drugs cd, thot.caregiver_detail cg where 1 = 1 and cg.svcbr_id = cd.svcbr_id and cg.prescription_id = cd.prescription_id "
				+ " and cg.refill_no = cd.refill_no and cg.svcbr_id = %s and cg.prescription_id = %s and cg.refill_no = %s and cg.inventory_id = %s and cg.lot = '%s'"),
		GetSupply("select svcbr_id as \"sb\",prescription_id as \"rxId\", refill_no as \"refill\", lot as \"lot\", inventory_id as \"inventoryId\", quantity_to_ship as \"qty\", uniq_id as \"uniqId\" from (select a.svcbr_id, a.prescription_id, a.refill_no, a.lot, a.quantity_to_ship, a.uniq_id, "
				+ " a.inventory_id from ancillary_prescriptions a, thot.prescriptions_table rx where 1=1 and rx.svcbr_id = a.svcbr_id and rx.prescription_id = a.prescription_id and rx.refill_no = a.refill_no and "
				+ " (select qoh from icsl_view where loc_id = svcbr_id and svcbr_id = a.svcbr_id and inventory_id = a.inventory_id  and lot = a.lot) > a.quantity_to_ship + 2"
				+ " and  rx.creation_date > (sysdate - 10) %s and rownum < 30 order by dbms_random.random) where rownum < 2"),
		IsPrescriptionRenewal("select case when (ws_owner.sds_util_pkg.Validate_rxRenewal(%s,%s,%s)) is not null then 'Y' else 'N' end \"renewal\" from dual "),
		GetPatientOldSb("select src.old_svcbr_id from (with renewal as (select * from thot.prescriptions_table rx where rx.patient_id = %s"
				+ " and (rx.no_days_shipment_last is not null and rx.no_days_shipment_last > 0) and rx.rx_status = 'PROFILE' and rx.profile_lock_initials IS NULL"
				+ " and rx.rx_written_date  >= trunc(add_months(sysdate,-6)) and rx.refill_thru_date > trunc(sysdate)) select rx1.svcbr_id old_svcbr_id"
				+ " , rx1.prescription_id old_prescription_id, rx1.refill_no old_refill_no, rn.svcbr_id renewal_svcbr_id, rn.prescription_id renewal_prescription_id"
				+ " , rn.refill_no renewal_refill_no, rn.patient_id, row_number() over (order by rx1.prescr_ship_date DESC) row_ordered from thot.prescriptions_table rx1,"
				+ " renewal rn where rx1.therapy_type = rn.therapy_type and rx1.patient_id = rn.patient_id and rx1.prescription_id <> rn.prescription_id"
				+ " and rx1.no_days_shipment_last = rn.no_days_shipment_last and (rx1.no_days_shipment_last is not null OR rx1.no_days_shipment_last >0) and" 
				+ " rx1.pharmacist_initials is not null) src where src.row_ordered = 1"),
		GetOldRenewalRx("select src.old_svcbr_id as \"sb\", src.old_prescription_id as \"rxId\", src.old_refill_no as \"refill\" from (with renewal as (select * from thot.prescriptions_table rx where rx.svcbr_id = %s"
				+ " and rx.prescription_id = %s and rx.refill_no = %s and (rx.no_days_shipment_last is not null and rx.no_days_shipment_last > 0) and rx.rx_status = 'PROFILE' and rx.profile_lock_initials is null and "
				+ " rx.rx_written_date  >= trunc(add_months (sysdate,-6)) and rx.refill_thru_date > trunc(sysdate)) select rx1.svcbr_id old_svcbr_id, rx1.prescription_id old_prescription_id, rx1.refill_no old_refill_no"
				+ " , rn.svcbr_id renewal_svcbr_id, rn.prescription_id renewal_prescription_id, rn.refill_no renewal_refill_no, row_number() over (order by rx1.prescr_ship_date desc) row_ordered from thot.prescriptions_table"
				+ " rx1, renewal rn where rx1.therapy_type = rn.therapy_type and rx1.patient_id = rn.patient_id and rx1.prescription_id <> rn.prescription_id and rx1.no_days_shipment_last = rn.no_days_shipment_last and "
				+ " (rx1.no_days_shipment_last is not null or rx1.no_days_shipment_last >0) and rx1.pharmacist_initials is not null)  src  WHERE src.row_ordered = 1"),
		GetRenewalAttributes("select to_char(rx.next_delivery_date, 'YYYY-MM-DD') as \"reminderDate\", rx.renewal_autofax as \"autoFax\" from thot.prescriptions_table rx where rx.svcbr_id = %sand rx.prescription_id = %s and "
				+ " rx.refill_no = %s"),
		GetRxImage("select document_id from thot.af_prescriptions_images where svcbr_id = %s and prescription_id = %s"),
		GetRxImagesNumber("select count(document_id) from thot.af_prescriptions_images where svcbr_id =%s and prescription_id = %s and refill_no =%s"),
		GetDirectRxInv("select svcbr_id as \"sb\",prescription_id as  \"rxId \", refill_no as  \"refill\" from (select pd.svcbr_id,pd.prescription_id,pd.refill_no from (select rx.patient_id, rx.svcbr_id,rx.prescription_id, rx.refill_no"
				+" from thot.prescriptions_table rx where 1=1  and rx.refill_no = 0 and rx.rx_status not in ('VOID','DC','PROFILE') and rx.technician_initials is null and rx.pharmacist_initials is null and rx.profile_lock_initials is null "
				+ " and rx.rxlock = 'N' and rx.pac_rx <> 'Y' and rx.est_delivery_date is not null and  rx.creation_date > (sysdate - 6) and rx.therapy_type = '%s' and %s not in (select inventory_id from thot.prescription_items_v "
				+ "where svcbr_id = rx.svcbr_id and prescription_id = rx.prescription_id and refill_no = rx.refill_no )) pd left join rxh_custom.mi_patients_xref pi on patient_id = pi.id where pi.id is null order by dbms_random.random) where rownum < 2"),
		GetNdcTherapyRelation("select * from (select attribute1 as \"therapyType\", attribute3 as \"ndc\", attribute4 as \"drugName\" from thot.ft_lookups where type = 'SDS_PRESCRIPTION_API' and code = 'NDC_THERAPY_MAPPING' order by dbms_random.random) where rownum < 2"),
		GetTransferToPrescription("select svcbr_id as \"sb\", prescription_id as \"rxId\", refill_no as \"refill\" from thot.prescriptions_table where copy_xfer_flag  = 'T' and svcbr_copied_from = %s and presc_copied_from = %s %s"),
		GetRxInvName("select i.description from thot.prescriptions_table rx, thot.prescription_items_v rxv, thot.prescription_drugs pd, thot.caregiver_drugs cg,thot.inventory i where rx.svcbr_id = rxv.svcbr_id and rx.prescription_id = rxv.prescription_id"
	            +" and rx.refill_no = rxv.refill_no and pd.svcbr_id(+) = rxv.svcbr_id and pd.prescription_id(+) = rxv.prescription_id and pd.refill_no(+) = rxv.refill_no and pd.line_id(+) = rxv.line_id and cg.svcbr_id(+) = rxv.svcbr_id and "
	            + " cg.prescription_id(+) = rxv.prescription_id and cg.refill_no(+) = rxv.refill_no and rxv.inventory_id = i.id(+) and rx.svcbr_id = %s and rx.prescription_id = %s %s order by rx.refill_no"),
	    
	    //SSPSS-1355 SET PSWITCH FLAG AS Y         
	    SETPSWITCHY("UPDATE thot.std_parameter SET pswitch = 'Y' WHERE parameter = 'SSPSS_1355_SWITCH'"),
	    SETPSWITCHN("UPDATE thot.std_parameter SET pswitch = 'N' WHERE parameter = 'SSPSS_1355_SWITCH'");
		
	    private final String query; 
	    private prescriptionSqlQueries(String q) {
	    	this.query = q;
	    }
	    public String toString() {
	        return query;
	    }
}
