package GlobalEnums;

public enum Path {
	
	Prescription("/v1/prescriptions/"),
;

	 private final String path;       

	    private Path(String path) {
	    	this.path = path;
	    }

	    public String toString() {
	        return path;
	    }
}
