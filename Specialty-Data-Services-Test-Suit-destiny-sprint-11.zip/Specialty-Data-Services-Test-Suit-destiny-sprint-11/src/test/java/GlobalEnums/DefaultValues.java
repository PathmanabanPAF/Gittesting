package GlobalEnums;

public enum DefaultValues {
	indexerFlag("N"),
	phoneType("OFFICE"),
	addressType("OFFICE"),
	CgDrug("thot.caregiver_drugs"),
	Drug("thot.prescription_drugs"),
	durationC("{\"code\": \"C\",\"name\": \"COPY FROM\",\"description\": \"Something to do with the duration date is created\"}"),
	durationS("{\"code\": \"S\",\"name\": \"System Date\",\"description\": \"Something to do with the duration date is created\"}"),
	durationR("{\"code\": \"R\",\"name\": \"FORWARD\",\"description\": \"Something to do with the duration date is created\"}"),
	hidC("{\"code\": \"C\",\"name\": \"COPY FROM\",\"description\": \"Something to do with the hid date is created\"}"),
	hidE("{\"code\": \"E\",\"name\": \"Exhaust Date\",\"description\": \"Something to do with the hid date is created\"}"),
	shipC("{\"code\": \"C\",\"name\": \"COPY FROM\",\"description\": \"Something to do with the ship date is created\"}"),
	shipS("{\"code\": \"S\",\"name\": \"System Date\",\"description\": \"Something to do with the ship date is created\"}"),
	exhaustC("{\"code\": \"C\",\"name\": \"COPY FROM\",\"description\": \"Something to do with the exhaust date is created\"}"),
	exhaustD("{\"code\": \"D\",\"name\": \"Duration End\",\"description\": \"Something to do with the exhaust date is created\"}"),
	nurseH("{\"code\": \"H\",\"name\": \"PER HOUR\",\"description\": \"Something to do with the way nurse charge for a visit\"}"),
	nurseV("{\"code\": \"V\",\"name\": \"PER VISIT\",\"description\": \"Something to do with the way nurse charge for a visit\"}"),
	isoDate31("{\"year\": 1000,\"month\": \"DECEMBER\",\"dayOfMonth\": 31,\"dayOfWeek\": \"WEDNESDAY\",\"dayOfYear\": 365,\"hour\": 0,"+
			"\"minute\": 0,\"second\": 0,\"nano\": 0,\"monthValue\": 12,\"chronology\":{\"calendarType\": \"iso8601\",\"id\": \"ISO\"}}"),
	isoDate1("{\"year\": 1000,\"month\": \"JANUARY\",\"dayOfMonth\": 1,\"dayOfWeek\": \"WEDNESDAY\",\"dayOfYear\": 1,\"hour\": 0,"+
			"\"minute\": 0,\"second\": 0,\"nano\": 0,\"monthValue\": 1,\"chronology\":{\"calendarType\": \"iso8601\",\"id\": \"ISO\"}}"),
	autoSequenceA("{\"code\": \"A\",\"name\": \"Active\",\"description\": \"Active\"}"),
	autoSequenceI("{\"code\": \"I\",\"name\": \"Inactive\",\"description\": \"Inactive\"}"),
	autoSequencenull("{\"code\": null,\"name\": null,\"description\": null}"),
	invoiceFormatP("{\"code\": \"P\",\"name\": \"Plain Paper\",\"description\": \"Plain Paper\"}"),
	invoiceFormatH("{\"code\": \"H\",\"name\": \"CMS - 1500\",\"description\": \"CMS - 1500\"}"),
	invoiceFormatE("{\"code\": \"E\",\"name\": \"Electronic\",\"description\": \"Electronic\"}"),
	invoiceFromatU("{\"code\": \"U\",\"name\": \"UB04\",\"description\": \"UB04\"}"),
	rxMatchDateS("{\"code\": \"S\",\"name\": \"Shipment Date\",\"description\": \"Shipment Date\"}"),
	rxMatchDateD("{\"code\": \"D\",\"name\": \"Duration Range\",\"description\": \"Duration Range\"}"),
	originCodenull("{\"code\": null,\"name\": null,\"description\": null}"),
	originCode0("{\"code\": \"0\",\"name\": \"Not Specified\",\"description\":\"\"}"),
	originCode1("{\"code\": \"1\",\"name\": \"Written\",\"description\": \"Written\"}"),
	originCode2("{\"code\": \"2\",\"name\": \"Telephone\",\"description\": \"Telephone\"}"),
	originCode3("{\"code\": \"3\",\"name\": \"Electronic\",\"description\": \"Electronic\"}"),
	originCode4("{\"code\": \"4\",\"name\": \"Fax\",\"description\": \"Fax\"}"),
	reversalProvidernull("{\"code\": null,\"name\": null,\"description\": null}"),
	statusA("{\"code\": \"A\",\"name\": \"Active\",\"description\": \"Active\"}"),
	statusI("{\"code\": \"I\",\"name\": \"Inactive\",\"description\": \"Inactive\"}"),
	group("{\"relativeId\": null,}"),
	addrState("{\"name\": null,\"description\":null }"),
	addrCountry("{\"name\": null,\"iso2code\": null,\"description\": null}"),
	addrStatus("{\"effectiveDate\": null,\"expirationDate\": null}"),
	phoneTypeHOME("{\"home\": true,\"work\": false,\"personal\": false,\"other\": false,\"customTags\": null}"),
	phoneTypeWORK("{\"home\": false,\"work\": true,\"personal\": false,\"other\": false,\"customTags\": null}"),
	phoneTypePERSONAL("{\"home\": false,\"work\": false,\"personal\": true,\"other\": false,\"customTags\": null}"),
	phoneTypeOTHER("{\"home\": false,\"work\": false,\"personal\": false,\"other\": true,\"customTags\": null}"),
	rxCreatedDefaultValues("{\"pmCheckedFlag\":\"N\",\"pos\":12,\"ancillaryPrescriptionsCount\":0,\"dcCheckedFlag\":\"N\",\"durResponseFlag\":\"N\",\"autoSrsFlag\":\"N\","+
			"\"timesPrinted\":0,\"tdCheckedFlag\":\"N\",\"employmentFlag\":\"N\",\"dvrPrintOk\":\"N\",\"caCheckedFlag\":\"N\",\"rxcmnCount\":0,\"rxPrintOk\":\"N\","+
			"\"diCheckedFlag\":\"N\",\"autoAccidentFlag\":\"N\",\"prCheckedFlag\":\"N\",\"refillFlag\":\"N\",\"rxauthCount\":0,\"rxCheckedFlag\":\"N\",\"peCheckedFlag\":\"N\","+
			"\"compoundingDetailCount\":0,\"labelPrintOk\":\"N\",\"rx_dme_count\":0,\"webLock\":\"N\",\"otherAccidentFlag\":\"N\","+
			"\"dzCheckedFlag\":\"N\",\"completed_flag\":\"N\",\"caregiverDetailCount\":0,\"noncompoundedDetailCount\":0}"),
	ProcessigUserEmpty("[{\"userType\": null,\"userName\": null,\"processingTime\": null}]"),
	StatusHistoryEmpty("[{\"localId\": null,\"value\": null,\"timestamp\": null,\"comments\": null}]"),
	SubstitutionTT("Brand to Brand"),
	selectRefill(", refill_no as \"refill\""),
	Not0Filter(" and rx.refill_no <> 0 "),
	Transfered(" and rx.copy_xfer_flag  = 'T' and rx.svcbr_id <> rx.svcbr_copied_from"),
	NotTransfered(" and rx.copy_xfer_flag  <> 'T' and not exists (select * from thot.prescriptions_table where copy_xfer_flag  = 'T' and svcbr_copied_from = rx.svcbr_id "
			+" and presc_copied_from = rx.prescription_id and refill_copied_from = rx.refill_no)"),
	TransferedfromanIntegratedone("and rx.patient_id  in (select id from rxh_custom.mi_patients_xref ip where ip.id = rx.patient_id) and rx.copy_xfer_flag  = 'T'"
			+ " and rx.svcbr_id <> rx.svcbr_copied_from "),
	TransferedfromaDirectone("and rx.patient_id not in (select id from rxh_custom.mi_patients_xref ip where ip.id = rx.patient_id) and rx.copy_xfer_flag  = 'T'"
			+ " and rx.svcbr_id <> rx.svcbr_copied_from "),
	RL(" and rx.technician_initials is not null and rx.pharmacist_initials is null and rx.profile_lock_initials is null and rx.rx_status not in ('VOID','DC')"),
	LL(" and rx.technician_initials is not null and rx.pharmacist_initials is not null and rx.profile_lock_initials is null and rx.rx_status not in ('VOID','DC')"),
	PL(" and rx.technician_initials is null and rx.pharmacist_initials is null and rx.profile_lock_initials is not null and rx.rx_status = 'PROFILE'"),
	RLPL("and rx.technician_initials is not null and rx.pharmacist_initials is null and rx.profile_lock_initials is not null and rx.rx_status not in ('VOID','DC')"),
	Fill0RL(" and rx.refill_no = 0 and rx.technician_initials is not null and rx.pharmacist_initials is null and rx.profile_lock_initials is null"
			+ " and rx.rx_status not in ('VOID','DC')"),
	Fill0LL(" and rx.refill_no = 0 and rx.technician_initials is not null and rx.pharmacist_initials is not null and rx.profile_lock_initials is "
			+ " null and rx.rx_status not in ('VOID','DC')"),
	Fill0PL(" and rx.refill_no = 0 and rx.technician_initials is null and rx.pharmacist_initials is null and rx.profile_lock_initials is not null "
			+ "and rx.rx_status = 'PROFILE'"),
	NotFill0RL(" and rx.refill_no <> 0 and rx.technician_initials is not null and rx.pharmacist_initials is null and rx.profile_lock_initials is null"
			+ " and rx.rx_status not in ('VOID','DC')"),
	NotFill0LL(" and rx.refill_no <> 0 and rx.technician_initials is not null and rx.pharmacist_initials is not null and rx.profile_lock_initials is "
			+ " null and rx.rx_status not in ('VOID','DC')"),
	NotFill0PL(" and rx.refill_no <> 0 and rx.technician_initials is null and rx.pharmacist_initials is null and rx.profile_lock_initials is not null "
			+ "and rx.rx_status = 'PROFILE'"),
	withoutLocks(" and rx.technician_initials is null and rx.pharmacist_initials is null and rx.profile_lock_initials is null"),
	Fill0("and rx.technician_initials is null and rx.pharmacist_initials is null and rx.refill_no = 0 and rx.rx_status not in  ('DC','VOID')"),
	Fill0Void(" and rx.refill_no = 0 and rx.rx_status = 'VOID' and rx.rxlock = 'N'"),
	DC(" and rx.rx_status = 'DC' and rx.rxlock = 'N'"),
	Void(" and rx.rx_status = 'VOID' and rx.rxlock = 'N'"),
	Fill0DC(" and rx.refill_no = 0 and rx.rx_status = 'DC' and rx.rxlock = 'N' "),
	NotFill0(" and rx.technician_initials is null and rx.pharmacist_initials is null and rx.refill_no <> 0 and rx.rx_status not in  ('DC','VOID')"),
	NotFill0Void(" and rx.refill_no <> 0 and rx.rx_status = 'VOID' and rx.rxlock = 'N'"),
	NotFill0DC(" and rx.refill_no <> 0 and rx.rx_status = 'DC' "),
	Fill0Updatable(" and rx.refill_no = 0 and rx.rx_status not in ('VOID','DC','PROFILE') and rx.technician_initials is null "
			+ " and rx.pharmacist_initials is null and rx.profile_lock_initials is null and rx.prescr_ship_date is not null "
			+ " and rx.order_taken_code is not null and rx.rxlock = 'N' and rx.refill_thru_date > sysdate"),
	NotFill0Updatable(" and rx.refill_no <> 0 and rx.rx_status not in ('VOID','DC','PROFILE') and rx.technician_initials is null "
			+ " and rx.pharmacist_initials is null and rx.profile_lock_initials is null and rx.prescr_ship_date is not null "
			+ " and rx.order_taken_code is not null and rx.rxlock = 'N' and rx.refill_thru_date > sysdate"),
	Fill0Pending(" and rx.refill_no = 0 and rx.rx_status = 'PENDING' and rx.technician_initials is null "
			+ " and rx.pharmacist_initials is null and rx.profile_lock_initials is null and rx.prescr_ship_date is not null "
			+ " and rx.order_taken_code is not null and rx.rxlock = 'N' and rx.refill_thru_date > sysdate"),
	Updatable(" and rx.rx_status not in ('VOID','DC','PROFILE') and rx.technician_initials is null "
			+ " and rx.pharmacist_initials is null and rx.profile_lock_initials is null and rx.prescr_ship_date is not null "
			+ " and rx.next_delivery_note is not null and rx.refill_thru_date > sysdate"),
	withOrderEntryTask("and (select max(creation_date) from thot.wq_tasks where workqueue_id = (select workqueue_id from "
			+ "thot.ft_workqueues where name = 'ORDER_ENTRY') and creation_date <= rx.creation_date and svcbr_id  = rx.svcbr_id "
			+ "and prescription_id = rx.prescription_id and refill_no = rx.refill_no) <> rx.creation_date"),
	withoutOrderEntryTask("and (select max(creation_date) from thot.wq_tasks where workqueue_id = (select workqueue_id from "
			+ "thot.ft_workqueues where name = 'ORDER_ENTRY') and creation_date <= rx.creation_date and svcbr_id  = rx.svcbr_id "
			+ "and prescription_id = rx.prescription_id and refill_no = rx.refill_no) is null"),
	UsableFill0(" and rx.refill_no = 0 and rx.rx_status not in ('VOID','DC','PROFILE') and rx.technician_initials is null "
			+ " and rx.pharmacist_initials is null  and rx.rxlock = 'N' and rx.pac_rx <> 'Y'"
			+ "and rx.est_delivery_date is not null"),
	Fill0AbleToAddInventory(" and rx.refill_no = 0 and rx.rx_status not in ('VOID','DC','PROFILE') and rx.technician_initials is null "
			+ " and rx.pharmacist_initials is null  and rx.rxlock = 'N' and rx.pac_rx <> 'Y'"
			+ "and rx.est_delivery_date is not null and (select count(iv.inventory_id) from icsl_view iv where iv.status = 'A' "
			+ "and iv.available_qty > 0 and svcbr_id = rx.svcbr_id and description like '%'||(select substr(therapy_descr, 1, 5) "
			+ "from therapy_types where therapy_type = rx.therapy_type)||'%' and loc_id = rx.it_sb_loc_id and loc_type = rx.it_sb_loc_type"
			+ " and inventory_id not in (select inventory_id from thot.prescription_items_v where svcbr_id = rx.svcbr_id and "
			+ "prescription_id = rx.prescription_id and refill_no = rx.refill_no))>0"),
	UsableNotFill0(" and rx.refill_no <> 0 and rx.rx_status not in ('VOID','DC','PROFILE') and rx.technician_initials is null "
			+ " and rx.pharmacist_initials is null  and rx.rxlock = 'N' and rx.pac_rx <> 'Y' "
			+ " and to_char(rx.est_delivery_date,'yyyy-MM-dd')not in ('1000-01-01') and rx.est_delivery_date is not null"),
			
	UsableWithInventory(" and rx.rx_status not in ('VOID','DC','PROFILE') and rx.technician_initials is null "
			+ " and rx.pharmacist_initials is null  and rx.rxlock = 'N' and rx.pac_rx <> 'Y'"
			+ "and rx.est_delivery_date is not null and (select count(inventory_id) from thot.prescription_items_v where "
			+ "svcbr_id = rx.svcbr_id and prescription_id = rx.prescription_id and refill_no = rx.refill_no )= 1"),
	Renewals("and (ws_owner.sds_util_pkg.Validate_rxRenewal(rx.svcbr_id, rx.prescription_id, rx.refill_no)) is not null"),
	NotRenewals("and (ws_owner.sds_util_pkg.Validate_rxRenewal(rx.svcbr_id, rx.prescription_id, rx.refill_no)) is null"),
	PacError(" and rx.rx_status not in ('VOID','DC') and rx.pharmacist_initials is null and rx.pac_rx_status in ('Rejected','Canceled',"
			+ "'Not Transmitted','Transmission Error')"),
	ReadyToRefill("and rx.rx_status not in ('VOID','DC') and rx.technician_initials is not null and rx.pharmacist_initials is not null "
			+ "and rx.rxlock = 'Y' and rx.pac_rx <> 'Y' and rx.est_delivery_date is not null "
			+"and (select count(task_id) from wq_tasks "
			+ "where workqueue_id = 1 and svcbr_id = rx.svcbr_id and prescription_id = rx.prescription_id and refill_no = rx.refill_no )>0"
			+ "and "),
	abletogetaRx("and exists(select patient_id from thot.patient_measurement where patient_id = p.id)"
			+" and exists(select patient_id from thot.patient_physician where patient_id = p.id and active_flag = 'A')"
			+" and exists(select patient_id from thot.patient_therapies pt where pt.patient_id = p.id and pt.stop_date is null and pt.stop_reason is null "
			+ "and exists (select * from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API' and ftl.code = 'NDC_THERAPY_MAPPING' and ftl.attribute1 = pt.therapy_type))"),
	withmultipleDocumentIds("and exists(select patient_id from thot.patient_measurement where patient_id = p.id)"
			+" and exists(select patient_id from thot.patient_physician where patient_id = p.id and active_flag = 'A')"
			+" and exists(select patient_id from thot.patient_therapies pt where pt.patient_id = p.id and pt.stop_date is null and pt.stop_reason is null "
			+ " and exists (select * from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API' and ftl.code = 'NDC_THERAPY_MAPPING' and ftl.attribute1 = pt.therapy_type))"
			+ " and (select count (document_id) from  doc_owner.ims_documents where patient_id = p.id) >1"),
	withoneDocumentId("and exists(select patient_id from thot.patient_measurement where patient_id = p.id)"
			+" and exists(select patient_id from thot.patient_physician where patient_id = p.id and active_flag = 'A')"
			+" and exists(select patient_id from thot.patient_therapies pt where pt.patient_id = p.id and pt.stop_date is null and pt.stop_reason is null "
			+ " and exists (select * from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API' and ftl.code = 'NDC_THERAPY_MAPPING' and ftl.attribute1 = pt.therapy_type))"
			+ " and (select count (document_id) from  doc_owner.ims_documents where patient_id = p.id) = 1"),
	withnoDocumentId("and exists(select patient_id from thot.patient_measurement where patient_id = p.id)"
			+" and exists(select patient_id from thot.patient_physician where patient_id = p.id and active_flag = 'A')"
			+" and exists(select patient_id from thot.patient_therapies pt where pt.patient_id = p.id and pt.stop_date is null and pt.stop_reason is null "
			+ " and exists (select * from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API' and ftl.code = 'NDC_THERAPY_MAPPING' and ftl.attribute1 = pt.therapy_type))"
			+ " and (select count (document_id) from  doc_owner.ims_documents where patient_id = p.id) = 0"),
	nevermeasured("and not exists(select patient_id from thot.patient_measurement where patient_id = p.id)"
			+" and exists(select patient_id from thot.patient_physician where patient_id = p.id and active_flag = 'A')"
			+" and exists(select pt.patient_id from thot.patient_therapies pt where patient_id = p.id and pt.stop_date is null and pt.stop_reason is null "
			+" and exists (select * from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API' and ftl.code = 'NDC_THERAPY_MAPPING' and ftl.attribute1 = pt.therapy_type))"),
	abletogetarenewalRx("and exists(select patient_id from thot.patient_measurement where patient_id = p.id)"
			+" and exists(select patient_id from thot.patient_physician where patient_id = p.id and active_flag = 'A')"
			+" and exists(select patient_id from thot.patient_therapies pt where pt.patient_id = p.id and pt.stop_date is null and pt.stop_reason is null "
			+ "and exists (select * from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API' and ftl.code = 'NDC_THERAPY_MAPPING' and ftl.attribute1 = pt.therapy_type))"
			+" and exists( select  src.patient_id from ( with renewal AS (select * from thot.prescriptions_table rx"
			+" where (rx.no_days_shipment_last is not  null and rx.no_days_shipment_last > 0) and rx.rx_status = 'PROFILE'" 
			+" and rx.profile_lock_initials is null and rx.rx_written_date  >= trunc(add_months(sysdate,-6))" 
			+" and rx.refill_thru_date > trunc(sysdate)) select rx1.svcbr_id old_svcbr_id, rx1.prescription_id" 
			+" old_prescription_id, rx1.refill_no old_refill_no, rn.svcbr_id renewal_svcbr_id, rn.prescription_id" 
			+" renewal_prescription_id, rn.refill_no renewal_refill_no, rn.patient_id, row_number() over (order by" 
			+" rx1.prescr_ship_date desc) row_ordered from thot.prescriptions_table rx1, renewal rn"
			+" where rx1.therapy_type = rn.therapy_type and rx1.patient_id = rn.patient_id and rx1.prescription_id <>" 
			+" rn.prescription_id and rx1.no_days_shipment_last = rn.no_days_shipment_last and (rx1.no_days_shipment_last is not null"
			+" or rx1.no_days_shipment_last >0 )and rx1.pharmacist_initials is not  null)src where p.id = src.patient_id)"),
	notabletogetarenewalRx("and exists(select patient_id from thot.patient_measurement where patient_id = p.id)"
			+" and exists(select patient_id from thot.patient_physician where patient_id = p.id and active_flag = 'A')"
			+" and exists(select patient_id from thot.patient_therapies pt where pt.patient_id = p.id and pt.stop_date is null and pt.stop_reason is null "
			+ "and exists (select * from thot.ft_lookups ftl where ftl.type = 'SDS_PRESCRIPTION_API' and ftl.code = 'NDC_THERAPY_MAPPING' and ftl.attribute1 = pt.therapy_type))"
			+" and not exists( select  src.patient_id from ( with renewal AS (select * from thot.prescriptions_table rx"
			+" where (rx.no_days_shipment_last is not  null and rx.no_days_shipment_last > 0) and rx.rx_status = 'PROFILE'" 
			+" and rx.profile_lock_initials is null and rx.rx_written_date  >= trunc(add_months(sysdate,-6))" 
			+" and rx.refill_thru_date > trunc(sysdate)) select rx1.svcbr_id old_svcbr_id, rx1.prescription_id" 
			+" old_prescription_id, rx1.refill_no old_refill_no, rn.svcbr_id renewal_svcbr_id, rn.prescription_id" 
			+" renewal_prescription_id, rn.refill_no renewal_refill_no, rn.patient_id, row_number() over (order by" 
			+" rx1.prescr_ship_date desc) row_ordered from thot.prescriptions_table rx1, renewal rn"
			+" where rx1.therapy_type = rn.therapy_type and rx1.patient_id = rn.patient_id and rx1.prescription_id <>" 
			+" rn.prescription_id and rx1.no_days_shipment_last = rn.no_days_shipment_last and (rx1.no_days_shipment_last is not null"
			+" or rx1.no_days_shipment_last >0 )and rx1.pharmacist_initials is not  null)src where p.id = src.patient_id)");
	
	    private final String value;       

	    private DefaultValues(String rs) {
	    	this.value = rs;
	    }
//	    public String getResponseMessage() {
//	        return responseMessage;
//	    }
	    
	    public String toString() {
	        return value;
	    }
}
