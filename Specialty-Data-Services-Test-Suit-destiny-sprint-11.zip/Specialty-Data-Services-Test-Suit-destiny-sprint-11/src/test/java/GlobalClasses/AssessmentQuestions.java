package GlobalClasses;

public class AssessmentQuestions {
	public static final String MED_ON_HAND = "Ask how many doses patient has remaining?  (ask only if patient has been receiving medication from another source)";
}
