package GlobalClasses;

public class WSCredentials {
	
	public static String[] webServicesCredentials(String ws,String env) {
		if(env.equals("UAT")){
			if(ws.equals("PaymentMethods")){
				String[] credentials = {"https://paymentmethods-1-uat.apps.ch3pcf01.express-scripts.com","application/json","Authorization,Basic Q1JNRXZudFB1Ymxpc2hlcl9xYTpDUk0zdm50UHVibDE1aDNyKg=="};
				return credentials;
			}else if(ws.equals("CRMEventPublisher")){
				String[] credentials = {"https://crmeventpublisher-1-uat.apps.ch3pcf01.express-scripts.com","application/json","Authorization,Basic VUNSTTAxOldlbGNvbWUx"};
				return credentials;
			}else if(ws.equals("GetRxSummary")){
				String[] credentials = {"https://trcws-qa.express-scripts.com","application/xml","Authorization,Basic UUNSTTAxOldlbGNvbWUx"};
				return credentials;
			}else if(ws.equals("Manufacturer")){
				String[] credentials = {"https://manufacturer-api-1-qa-candidate.apps.ch3pcf01.express-scripts.com","application/json","Authorization,Basic VUNSTTAxOldlbGNvbWUx"};
				return credentials;
			}else if(ws.equals("TherapyType")){
				String[] credentials = {"https://www-frontendservice-therapy-api-qa.apps.ch3pcf01.express-scripts.com","application/json","Authorization,Basic VUNSTTAxOldlbGNvbWUx"};
				return credentials;
			}else if(ws.equals("Payer")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json", ""};
				return credentials;
			}else if(ws.equals("ClinicalTherapy")){
				String[] credentials = {"https://therapy-record-api-1-qa.apps.ch3pcf01.express-scripts.com","application/json",""};
				return credentials;
			}else if(ws.equals("MedicalCondition")){
				String[] credentials = {"https://medical-condition-api-1-qa.apps.ch3pcf01.express-scripts.com","application/json",""};
				return credentials;
			}else if(ws.equals("GetSpecialtyPatientContactInfo")){
				String[] credentials = {"https://trcws-prod.express-scripts.com","application/xml","Authorization,Basic SVZSUFJPRDo1dGdiNnlobg=="};
				return credentials;
			}
			else{
				String[] credentials = {"Invalid URL","Content-Type: null","Authorization: null"};
				System.out.println("The Web Service you are trying to use doesn't exists");
				return credentials;
			}
		}else if(env.equals("TEST")){

			if(ws.equals("SubmitOrder")){
				String[] credentials = {"https://soaqa.medco.com:11056","application/xml","Authorization,Basic UUNSTTAxOldlbGNvbWUx"};
				return credentials;
			}else if(ws.equals("TRC")){
				String[] credentials = {"https://trc-api-1-qa-candidate.apps.ch3pcf01.express-scripts.com","application/json","Authorization,Basic VUNSTTAxOldlbGNvbWUx"};
				return credentials;
			}else if(ws.equals("Payer")){
				String[] credentials = {"https://payor-api-1-dev.apps.ch3pcf01.express-scripts.com","application/json","Authorization,Basic VUNSTTAxOldlbGNvbWUx"};
				return credentials;
			}else if(ws.equals("Prescription")){
				String[] credentials = {"https://prescriptions-1-qa.apps.ch3pcf01.express-scripts.com","application/json","Authorization,Basic VUNSTTAxOldlbGNvbWUx"};
				return credentials;
			}else if(ws.equals("PaymentMethods")){
				String[] credentials = {"https://paymentmethods-1-qa.apps.ch3pcf01.express-scripts.com","application/json","Authorization,Basic Q1JNRXZudFB1Ymxpc2hlcl9xYTpDUk0zdm50UHVibDE1aDNyKg=="};
				return credentials;
			}else if(ws.equals("SubmitOrder")){
				String[] credentials = {"https://soaqa.medco.com:11056","application/xml","Authorization,Basic SVZSUUE6M2VkYzRyZnY="};
				return credentials;
			}else if(ws.equals("CRMEventPublisher")){
				String[] credentials = {"https://crmeventpublisher-1-qa.apps.ch3pcf01.express-scripts.com","application/json","Authorization,Basic UUNSTTAxOldlbGNvbWUx"};
				return credentials;
			}else if(ws.equals("GetSpecialtyPatientContactInfo")){
				String[] credentials = {"https://trcws-qa.express-scripts.com","application/xml","Authorization,Basic UUNSTTAxOldlbGNvbWUx"};
				return credentials;
			}else if(ws.equals("EntityPaymentMethods")){
				String[] credentials = {"https://payment-1-qa.apps.ch3pcf01.express-scripts.com","application/json","Authorization,Basic Q1JNRXZudFB1Ymxpc2hlcl9xYTpDUk0zdm50UHVibDE1aDNyKg=="};
				return credentials;
			}
			{
			String[] credentials = {"Invalid URL","Content-Type: null","Authorization: null"};
			System.out.println("The Web Service you are trying to use doesn't exists");
			return credentials;
			}
		}
		String[] credentials = {"Invalid Environment","Content-Type: null","Authorization: null"};
		System.out.println("The Environment you are trying to use doesn't exists");
		return credentials;
	}

}
