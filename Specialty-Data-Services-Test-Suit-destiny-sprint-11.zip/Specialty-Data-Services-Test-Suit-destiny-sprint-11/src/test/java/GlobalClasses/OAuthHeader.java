package GlobalClasses;

import com.express_scripts.inf.security.oauth.spring.OAuthConsumerSupportImpl;
import com.express_scripts.inf.security.oauth.spring.OAuthConsumerTemplate;
import com.express_scripts.inf.security.oauth.spring.OAuthSignatureMethodFactoryImpl;
import org.springframework.http.HttpRequest;
import org.springframework.security.oauth.common.signature.SharedConsumerSecretImpl;
import org.springframework.security.oauth.consumer.BaseProtectedResourceDetails;
import org.springframework.security.oauth.consumer.OAuthConsumerSupport;
import org.springframework.security.oauth.consumer.ProtectedResourceDetails;
import org.springframework.security.oauth.consumer.ProtectedResourceDetailsService;
import org.springframework.security.oauth.consumer.net.DefaultOAuthURLStreamHandlerFactory;

import java.net.URI;

public class OAuthHeader {

    private OAuthConsumerTemplate oAuthConsumerTemplate;

    private OAuthHeader(){}

    public OAuthHeader(String oauthConsumerRequestTokenURL, String oauthConsumerAccessTokenURL, String oauthConsumerConsumerKey, String oauthConsumerConsumerSecret) {
        oAuthConsumerTemplate = new OAuthConsumerTemplate();
        oAuthConsumerTemplate.setProtectedResourceDetails(buildProtectedResourceDetails(oauthConsumerRequestTokenURL, oauthConsumerAccessTokenURL, oauthConsumerConsumerKey, oauthConsumerConsumerSecret));
        oAuthConsumerTemplate.setOauthConsumerSupport(buildOAuthConsumerSupport(oauthConsumerRequestTokenURL, oauthConsumerAccessTokenURL, oauthConsumerConsumerKey, oauthConsumerConsumerSecret));
        oAuthConsumerTemplate.init();
    }


     private String getAuthHeader(HttpRequest httpRequest) {
        return oAuthConsumerTemplate.createAuthorizationHeader(httpRequest.getMethod().toString(), httpRequest.getURI(), null);
    }
    public String getAuthHeader(String method, URI uri)
    {	
        String header = oAuthConsumerTemplate.createAuthorizationHeader(method, uri, null);
        
         return header;

    }
    private ProtectedResourceDetails buildProtectedResourceDetails(String oauthConsumerRequestTokenURL, String oauthConsumerAccessTokenURL, String oauthConsumerConsumerKey, String oauthConsumerConsumerSecret) {
        BaseProtectedResourceDetails baseProtectedResourceDetails = new BaseProtectedResourceDetails();

        baseProtectedResourceDetails.setConsumerKey(oauthConsumerConsumerKey);
        baseProtectedResourceDetails.setSharedSecret(new SharedConsumerSecretImpl(oauthConsumerConsumerSecret));
        baseProtectedResourceDetails.setSignatureMethod("HMAC-SHA256");
        baseProtectedResourceDetails.setRequestTokenURL(oauthConsumerRequestTokenURL);
        baseProtectedResourceDetails.setAccessTokenURL(oauthConsumerAccessTokenURL);
        baseProtectedResourceDetails.setUse10a(false);

        return baseProtectedResourceDetails;
    }

    private OAuthConsumerSupport buildOAuthConsumerSupport(final String oauthConsumerRequestTokenURL, final String oauthConsumerAccessTokenURL, final String oauthConsumerConsumerKey, final String oauthConsumerConsumerSecret) {
        OAuthConsumerSupportImpl coreOAuthConsumerSupport = new OAuthConsumerSupportImpl();

        coreOAuthConsumerSupport.setSignatureFactory(new OAuthSignatureMethodFactoryImpl());
        coreOAuthConsumerSupport.setStreamHandlerFactory(new DefaultOAuthURLStreamHandlerFactory());
        coreOAuthConsumerSupport.setProtectedResourceDetailsService(new ProtectedResourceDetailsService() {

            public ProtectedResourceDetails loadProtectedResourceDetailsById(String id) throws IllegalArgumentException {
                return buildProtectedResourceDetails(oauthConsumerRequestTokenURL, oauthConsumerAccessTokenURL, oauthConsumerConsumerKey, oauthConsumerConsumerSecret);
            }
        });

        return coreOAuthConsumerSupport;
    }
}
