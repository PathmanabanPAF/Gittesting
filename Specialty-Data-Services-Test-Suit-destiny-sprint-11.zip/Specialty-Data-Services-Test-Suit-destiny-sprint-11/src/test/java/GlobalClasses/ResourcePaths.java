package GlobalClasses;


public class ResourcePaths {
	public static final String ORDER_ASM_REQ= "/Resources/order_assessment.xml";
	public static final String MANUFACTURER_REQ = "/Resources/manufacturer.json";
	public static final String RX_INF = "src/test/java/Resources/prescription.json";
	public static final String COMPLETE_RX_INF = "src/test/java/Resources/complete_prescription.json";
	public static final String FILL_INF = "src/test/java/Resources/fill.json";
	public static final String NON_COMP_INF = "src/test/java/Resources/non_compound_item.json";
	public static final String INV_ITEM = "src/test/java/Resources/invitem.json";
	public static final String ORDER_REQ = "/Resources/order.xml";
	public static final String SUBMIT_SPECIALTY_ORDER = "src/test/java/Resources/submitspecialtyorder.xml";
	public static final String COPAY_ASST_REQ = "/Resources/copayassistance.json";
	public static final String INSURANCE_UPDATE = "src/test/java/Resources/insurance_update.json";
	public static final String THERAPY_UPDATE = "src/test/java/Resources/therapy_update.json";
	public static final String PHYSICIAN_UPDATE = "src/test/java/Resources/physician_update.json";
	public static final String COPAY = "src/test/java/Resources/copayassistance.json";
	public static final String GET_SPECIALTY_PATIENT_CONTACT_INFO = "src/test/java/Resources/getspecialtypatientcontactinfo.xml";
	public static final String PAYMENT_METHODS_POST = "src/test/java/Resources/payment_methods_post.json";
	public static final String TRC_INF = "src/test/java/Resources/trc.json";
	public static final String TRC_AOM_TT_INF = "src/test/java/Resources/trc_aom_tt.json";
	public static final String TRC_AOM_P_INF = "src/test/java/Resources/trc_aom_p.json";
	public static final String TRC_TT_INF = "src/test/java/Resources/trc_tt.json";
	public static final String SUPPLY_INF = "src/test/java/Resources/supply.json";
	public static final String CAREGIVER_INF = "src/test/java/Resources/caregiver.json";
	public static final String Order_API = "src/test/java/Resources/Orderapi.json";
	public static final String Order_API_Invalid = "src/test/java/Resources/Orderapi_invalid.json";
	public static final String Payment_API_TC1 = "src/test/java/Resources/TC1_PaymentAPI_ErrorCodes.json";
	public static final String Payment_API_TC2 = "src/test/java/Resources/TC2_PaymentAPI_ErrorCodes.json";
	public static final String Payment_API_TC3 = "src/test/java/Resources/TC3_PaymentAPI_ErrorCodes.json";
	public static final String Payment_API_V3_TC1 = "src/test/java/Resources/TC1_PaymentAPI_V3.json";
	public static final String Payment_API_V3_TC2 = "src/test/java/Resources/TC2_PaymentAPI_V3.json";
	public static final String Payment_API_V3_TC3 = "src/test/java/Resources/TC3_PaymentAPI_V3.json";
	public static final String Assessment_API = "src/test/java/Resources/Assessmentapi.json";
	public static final String Prescription_API_Renewal_Autofax_Tc1 = "src/test/java/Resources/TC1_RenewalAutoFax.json";
	public static final String Prescription_API_Renewal_Autofax_Tc2 = "src/test/java/Resources/TC2_RenewalAutoFax.json";
	public static final String Prescription_API_Renewal_Autofax_Tc3 = "src/test/java/Resources/TC3_RenewalAutoFax.json";
	public static final String Prescription_UpdatePhysician_TC1 = "src/test/java/Resources/TC1_SSPDT_2345.json";
	public static final String Prescription_UpdatePhysician_TC2 = "src/test/java/Resources/TC2_SSPDT_2345.json";
	public static final String Prescription_UpdatePhysician_TC3 = "src/test/java/Resources/TC3_SSPDT_2345.json";
	public static final String Prescription_UpdatePhysician_TC4 = "src/test/java/Resources/TC4_SSPDT_2345.json";
	public static final String Prescription_new = "src/test/java/Resources/prescription_new.json";
	public static final String Prescription_fill = "src/test/java/Resources/prescription_fill.json";
	public static final String prescription_prescribed_item = "src/test/java/Resources/prescription_prescribed_item.json";
	public static final String prescription_singlecall = "src/test/java/Resources/prescription_singlecall.json";
	public static final String Prescription_API_Renewal_Autofax_SSPDT2338_Tc1 = "src/test/java/Resources/TC1_SSPDT2338_RenewalAutoFax.json";
	public static final String Prescription_API_Renewal_Autofax_SSPDT2338_Tc2 = "src/test/java/Resources/TC2_SSPDT2338_RenewalAutoFax.json";
	public static final String Prescription_API_Renewal_Autofax_SSPDT2338_Tc3 = "src/test/java/Resources/TC3_SSPDT2338_RenewalAutoFax.json";
	public static final String Prescription_API_TC1_Active_Inventory = "src/test/java/Resources/TC1_Active_Inventory.json";
	public static final String Prescription_API_TC2_Active_Inventory = "src/test/java/Resources/TC2_Active_Inventory.json";
	//SSPSS-1850
	public static final String AutoResolve_PostDUR_Tc1 = "src/test/java/Resources/TC1_PostDUR_1850.json";
	public static final String AutoResolve_PostDUR_Tc2 = "src/test/java/Resources/TC2_PostDUR_1850.json";
	public static final String AutoResolve_PostDUR_Tc3 = "src/test/java/Resources/TC3_PostDUR_1850.json";
	//SSPSS-1927
	public static final String AutoResolve_PostDUR_Testc1 = "src/test/java/Resources/TC1_PostDUR_1927.json";
	public static final String AutoResolve_PostDUR_Testc2 = "src/test/java/Resources/TC2_PostDUR_1927.json";
	public static final String AutoResolve_PostDUR_Testc3 = "src/test/java/Resources/TC3_PostDUR_1927.json";
	public static final String AutoResolve_PostDUR_Testc4 = "src/test/java/Resources/TC4_PostDUR_1927.json";
	public static final String AutoResolve_PostDUR_Testc5 = "src/test/java/Resources/TC5_PostDUR_1927.json";
	//SSPSS 1991
	public static final String GetRxSummary_TC1 = "src/test/java/Resources/TC1_GetOrderSummary_SSPSS_1991.xml";
	public static final String GetRxSummary_TC2 = "src/test/java/Resources/TC2_GetOrderSummary_SSPSS_1991.xml";
	public static final String GetRxSummary_TC3 = "src/test/java/Resources/TC3_GetOrderSummary_SSPSS_1991.xml";
	
}
