package GlobalClasses; 

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Driver;
import java.util.Iterator;

public class JsonTools {
	private static JSONObject temp = new JSONObject();
	private static String returnValue;
	//private static String[] keys;
	private static String lastKey;
	
	public static JSONObject readJsonFile(String filePath){
		JSONObject jsonObj = new JSONObject();
//		InputStream inputStream = JsonTools.class.getResourceAsStream (filePath);
		try {
			File file = new File(filePath);
		    InputStream inputStream = new FileInputStream(file);
			String json = IOUtils.toString(inputStream, "UTF-8");	
			jsonObj = new JSONObject(json);
		} catch (IOException | JSONException e) {
			System.out.println("Could not read Json file");
			e.printStackTrace();
		}
		return  jsonObj;
	}

	public static String findKeys(JSONObject js, String keyt) throws JSONException {
		Iterator<?> iter = js.keys();
	    while(iter.hasNext()){
	    	String key = (String)iter.next();
	    	
	    	if (key.equals(keyt)) {
	    		if (js.optJSONObject(key) instanceof JSONObject){
	    			returnValue = js.getJSONObject(key).toString();
				}else if (js.optJSONArray(key) instanceof JSONArray) {
					JSONArray jsArray = js.getJSONArray(key);
					returnValue = jsArray.toString();
				}else{
					returnValue = js.getString(key);
				}
	    		break;
		    }
	    	else if (js.optJSONObject(key) instanceof JSONObject){
	    		temp = js.getJSONObject(key);
				 findKeys(temp, keyt);
			}else if (js.optJSONArray(key) instanceof JSONArray) {
	    		JSONArray jsArray = js.getJSONArray(key);
	    		for(int i = 0; i < jsArray.length(); i++)
	    		{
	    			if (jsArray.optJSONObject(i) instanceof JSONObject){
	    				temp = jsArray.getJSONObject(i);
	    				findKeys(temp, keyt);
	    			}
	    		}
		    }
	    }
	    return returnValue;
	    }

	public static String findKeysPath(JSONObject js, String keypath) throws JSONException {
		Iterator<?> iter = js.keys();
		String keyt = keypath.split("\\.")[1];
	    while(iter.hasNext()){
	    	String key = (String)iter.next();
	    	
	    	if (key.equals(keyt)&& lastKey.equals(keypath.split("\\.")[0])) {
	    		if (js.optJSONObject(key) instanceof JSONObject){
	    			returnValue = js.getJSONObject(key).toString();
				}else if (js.optJSONArray(key) instanceof JSONArray) {
					JSONArray jsArray = js.getJSONArray(key);
					returnValue = jsArray.toString();
				}else{
					returnValue = js.getString(key);
				}
	    		break;
		    }
	    	else if (js.optJSONObject(key) instanceof JSONObject){
	    		temp = js.getJSONObject(key);
	    		lastKey = key;
				 findKeys(temp, keyt);
			}else if (js.optJSONArray(key) instanceof JSONArray) {
	    		JSONArray jsArray = js.getJSONArray(key);
	    		for(int i = 0; i < jsArray.length(); i++)
	    		{
	    			if (jsArray.optJSONObject(i) instanceof JSONObject){
	    				temp = jsArray.getJSONObject(i);
	    				lastKey = key;
	    				findKeys(temp, keyt);
	    			}
	    		}
		    }
	    }
	    return returnValue;
	}
	public static boolean hasKey(JSONObject js, String keyt) throws JSONException {
		Iterator<?> iter = js.keys();
		boolean hasKey = false;
	    while(iter.hasNext()){
	    	String key = (String)iter.next();
	    	
	    	if (key.equals(keyt)) {
	    		hasKey = true;
	    		break;
		    }
	    	else if (js.optJSONObject(key) instanceof JSONObject){
	    		temp = js.getJSONObject(key);
				 hasKey(temp, keyt);
			}else if (js.optJSONArray(key) instanceof JSONArray) {
	    		JSONArray jsArray = js.getJSONArray(key);
	    		for(int i = 0; i < jsArray.length(); i++)
	    		{
	    			if (jsArray.optJSONObject(i) instanceof JSONObject){
	    				temp = jsArray.getJSONObject(i);
	    				hasKey(temp, keyt);
	    			}
	    		}
		    }
	    }
	    return hasKey;
	    }
	
	public static JSONObject updateKeys(JSONObject js, String keyt, Object newValue) throws JSONException {
		Iterator<?> iter = js.keys();
	    while(iter.hasNext()){
	    	String key = (String)iter.next();
	    	if (key.equals(keyt)) {
	    		if(newValue.equals("null")){
	    			js.put(key,JSONObject.NULL);
	    		}else{
	    			js.put(key,newValue);
	    		}
	    		break;
		    }else if (js.optJSONObject(key) instanceof JSONObject){
	    		temp = js.getJSONObject(key);
				updateKeys(temp, keyt, newValue);
			}
	    	else if (js.optJSONArray(key) instanceof JSONArray) {
	    		JSONArray jsArray = js.getJSONArray(key);
	    		for(int i = 0; i < jsArray.length(); i++)
	    		{
	    			if (jsArray.optJSONObject(i) instanceof JSONObject){
	    				temp = jsArray.getJSONObject(i);
	    				updateKeys(temp, keyt, newValue);
	    			}
	    		}
		    }
	    }
		return js;
	   }

	public static JSONObject deleteKey(JSONObject js, String keyt) throws JSONException {
		Iterator<?> iter = js.keys();
	    while(iter.hasNext()){
	    	String key = (String)iter.next();
	    	if (js.optJSONObject(key) instanceof JSONObject){
	    		temp = js.getJSONObject(key);
				deleteKey(temp, keyt);
			}
	    	else if (js.optJSONArray(key) instanceof JSONArray) {
	    		JSONArray jsArray = js.getJSONArray(key);
	    		for(int i = 0; i < jsArray.length(); i++)
	    		{
	    			if (jsArray.optJSONObject(i) instanceof JSONObject){
	    				temp = jsArray.getJSONObject(i);
	    				deleteKey(temp, keyt);
	    			}
	    		}
		    }
	    	else if (key.equals(keyt)) {
	    		iter.remove();
	    		js.remove(key);
	    		break;
		    }
	    }
		return js;
	   }

	public static JSONObject updateKeysPath(JSONObject js, String keypath, Object newValue) throws JSONException {
		String keyt = keypath.split("\\.")[1];
		Iterator<?> iter = js.keys();
	    while(iter.hasNext()){
	    	String key = (String)iter.next();
	    	if (js.optJSONObject(key) instanceof JSONObject){
	    		temp = js.getJSONObject(key);
	    		lastKey = key;
				updateKeysPath(temp, keypath, newValue);
				
			}
	    	else if (js.optJSONArray(key) instanceof JSONArray) {
	    		JSONArray jsArray = js.getJSONArray(key);
	    		for(int i = 0; i < jsArray.length(); i++)
	    		{
	    			if (jsArray.optJSONObject(i) instanceof JSONObject){
	    				temp = jsArray.getJSONObject(i);
	    				lastKey = key;
	    				updateKeysPath(temp, keypath, newValue);
	    			}
	    		}
		    }
	    	else if (key.equals(keyt) && lastKey.equals(keypath.split("\\.")[0])) { 
	    		if(newValue.equals("null")){
	    			js.put(key,JSONObject.NULL);
	    		}else{
	    			js.put(key,newValue);
	    		}
	    		break;
	    	}
	    }
		return js;
	   }
	
	public static String orderJson(String orderString, JSONObject js) throws JSONException{
		Iterator<?> iter = js.keys();
		String ordered = "{";
		int i = 0;
		String[] orderKeys =  orderString.split("\\.");
	    while(iter.hasNext()){
	    	String keyt = (String)iter.next();
	    	String key = orderKeys[i];
	    	if (js.optJSONObject(key)instanceof JSONObject){
	    		ordered = ordered+"\""+key+"\":"+js.getJSONObject(key).toString();
	    	}else{
	    		ordered = ordered+"\""+key+"\":"+js.getJSONArray(key).toString();
	    	}
	    	if(i<orderKeys.length-1) ordered = ordered + ",";
	    	i++;
	    }
	    ordered = ordered + "}";
		return ordered;
	}
	public static JSONObject leaveSingleKey(JSONObject js) throws JSONException {
		Iterator<?> iter = js.keys();
		int i = 1;
	    while(iter.hasNext()){
	    	String key = (String)iter.next();
	    	if(i > 1) iter.remove();
	    	i++;
	    }
		return js;
	}
	public static JSONArray leaveSingleObject(JSONArray js) throws JSONException {
		for (int i = 0; i <= js.length(); i++) {
			if(i > 0) js.remove(i);
		}
		return js;
	}
	public static JSONArray deleteUser(JSONArray js, String user) throws JSONException {
		for (int i = 0; i < js.length(); i++) {
			JSONObject temp = js.getJSONObject(i);
			if(temp.getString("userType").equals(user)) js.remove(i);
		}
		return js;
	}
}
