package GlobalClasses;

public class WSOauthCredentials {
	public static String[] webServicesOauthCredentials(String ws,String env) {
		if(env.equals("UAT")){
			if(ws.equals("Payer")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json","https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens","https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens","1e72920f-8bb0-6e60-85b5-6a90448fa3f2","2HeOn9Mo/xNOAwiFvDUSVq/naB4="};
				return credentials;
			}else{
				String[] credentials = {"Invalid URL","Content-Type: null","Authorization: null"};
				System.out.println("The Web Service you are trying to use doesn't exists");
				return credentials;
			}
		}else if(env.equals("TEST")){
			if(ws.equals("TRC")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json","https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens","https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens","1e72abb5-b0de-6ef3-a652-922004261108","43lZ6u9Tj3CmJhxZKlLR3pUdBu0="};
				return credentials;
			}else if(ws.equals("Prescription")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json","https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens","https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens","1e7874ef-a754-6efe-a152-9afdee480e30","iFC/usS1q1zxY/p/luJOjTS9XN0="};
				return credentials;
			}else if(ws.equals("DrugAPI")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json","https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens","https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens","1e719706-b2d1-6ef1-a8db-3230d780904b","aE7q9mcFGaGBDjJ3mInItTTKGZs="};
				return credentials;
			}else if(ws.equals("DURAPI")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json","https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens","https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens","1e8006c9-53fb-6bcc-8116-8eed0da1969e","4yIl8CIlShEERXjvhyjO/Mo8qxI="};
				return credentials;
			}else if(ws.equals("InvoiceAPI")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json","https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens","https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens","1e7c620c-23fb-6f46-af56-caea9478387f","Ok+8mzqm7O3DgX//g+H7NHivsVs="};
				return credentials;
			}else if(ws.equals("OrderAPI")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json","https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens","https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens","1e7a854c-d9e1-6cd2-b014-f2e2755c4e8b","9PAxLsO4W34keVU310/FpLczvXg="};
				return credentials;
			}else if(ws.equals("AssessmentAPI")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json","https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens","https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens","1e7ba5dc-4ce2-6acc-bd31-bee3b2025792","o0boR7ktkRR2f3G2MWyyZ+XKuWs="};
				return credentials;
			}else if(ws.equals("PaymentAPI")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json","https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens","https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens","1e755fde-e00d-6c9a-a9c0-a6a917648d15","Zb2PoDnTMTGZv8WCwXp38beRJng="};
				return credentials;
			}else if(ws.equals("PaymentAPIV3")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json","https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens","https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens","1e75ab48-b309-67d4-a9c0-a6a917648d15","z73vYiA87ZLb+fTQ8TRiUdbseJs="};
				return credentials;
			}else if(ws.equals("Manufacturer")){
				String[] credentials = {"https://api-qa.express-scripts.io","application/json","https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens","https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens","1e747d99-e640-665d-8e62-ced7c5d20e17","+a8w3fZMfHgF27h7tp3jOWjU5QE="};
				return credentials;
			}
			
		}else if(env.equals("DEV")){
			if(ws.equals("Prescription")){
				String[] credentials = {"https://api-dev.express-scripts.io","application/json","https://api-dev.express-scripts.io/v1/auth/oauth/requestTokens","https://api-dev.express-scripts.io/v1/auth/oauth/accessTokens","1e78758f-4c78-6e06-8d72-9aaaa32f6ed0","c2cCeSYxz8ae39UrP00362bi+S0="};
				return credentials;
			}else{
				String[] credentials = {"Invalid URL","Content-Type: null","Authorization: null"};
				System.out.println("The Web Service you are trying to use doesn't exists");
				return credentials;
			}
		}else{
			String[] credentials = {"Invalid URL","Content-Type: null","Authorization: null"};
			System.out.println("The Web Service you are trying to use doesn't exists");
			return credentials;
		}
		String[] credentials = {"Invalid Environment","Content-Type: null","Authorization: null"};
		System.out.println("The Environment you are trying to use doesn't exists");
		return credentials;
	}

}


