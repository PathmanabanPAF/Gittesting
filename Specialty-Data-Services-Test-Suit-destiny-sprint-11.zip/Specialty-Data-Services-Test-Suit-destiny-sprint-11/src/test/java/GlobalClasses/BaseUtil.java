package GlobalClasses;
import java.util.Map;
import org.json.JSONObject;
import org.json.JSONArray;
import org.springframework.http.ResponseEntity;

import com.jayway.restassured.response.Response;

public class BaseUtil {
	public String environment;
	public String requestBody,responseBody;
	public Response response;
	public ResponseEntity<String> oaResponse;
	public ApiTools serviceApi;
	public ApiToolsV2 oauthServiceApi;
	public Map<String, String> prescription;
	public JSONArray params;
	public String sb, rxId, refill;
	public String therapyType,invId, lot, oldInvId;
	public String patientId;
	public JSONObject requestBodyJson;
	public JSONArray requestBodyArray;
}
