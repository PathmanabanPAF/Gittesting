package GlobalClasses;

public class OauthAuthorization {
	public String oauthConsumerRequestTokenURL;
    public String oauthConsumerAccessTokenURL;
    public String oauthConsumerConsumerKey;
    public String oauthConsumerConsumerSecret;
	
	public OauthAuthorization(String oauthConsumerRequestTokenURL, String oauthConsumerAccessTokenURL,
			String oauthConsumerConsumerKey,String oauthConsumerConsumerSecret) {
		this.oauthConsumerRequestTokenURL=oauthConsumerRequestTokenURL;
	    this.oauthConsumerAccessTokenURL =oauthConsumerAccessTokenURL;
	    this.oauthConsumerConsumerKey=oauthConsumerConsumerKey;
	    this.oauthConsumerConsumerSecret=oauthConsumerConsumerSecret;
	}
	
}
