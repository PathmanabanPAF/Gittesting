package GlobalClasses;

//import static org.junit.Assert.assertFalse;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
//import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.MediaType;


import org.springframework.http.ResponseEntity;





//import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;


public class MiscTools {
		
	/**
	 * Used to convert a Doc String parameter with table format to Map (key, value)  
	 * @param mapString
	 * @return resultMap
	 */
	public static Map<String, String> toMap(String mapString){
		mapString = mapString.replaceAll("\\A\\||\\|\\z|\\s+", "");
		String[] table = mapString.split("\\|\\|");
		String[] headers = table[0].split("\\|");
		String[] values = table[1].split("\\|");

		Map<String, String> resultMap = new HashMap<String, String>();
		int i = 0;
		for (String key : headers)
			resultMap.put(key, values[i++]);
		return resultMap;
	}
	
	/**
	 * Used to convert a Doc String parameter with table format to String Array
	 * @param arrayString
	 * @return resultArray
	 */
	public static String[] toList(String arrayString){
		arrayString = arrayString.replaceAll("\\A\\||\\|\\z|\\s+", "");
		String[] table = arrayString.split("\\|\\|");
		String[] values = table[1].split("\\|");
		
		List<String> resultList = new ArrayList<String>();
		for (String value : values)
			resultList.add(value);
			
		String[] resultArray = new String[resultList.size()];
		resultArray = resultList.toArray(resultArray);
		
		return resultArray;
	}
	
	/**
	 * Used to execute a query with a single value as result
	 * @param env
	 * @param query
	 * @return result
	 * @throws SQLException
	 */
	public static String executeSingleSelect(String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		String result = new String();
		try{
			ResultSet rs = db.ExecuteSelect(query);
			if(rs.next()){
		        //rs.next();
		        result = rs.getString(1);
			}
	      }catch(SQLException e){
	    	System.out.println("Something went wrong while executing Select statement");
	    	System.out.println(e.getMessage());
	    	System.out.println(e.getErrorCode()+e.getErrorCode());
	        e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
		return result;
	}
	
	/**
	 * Used to execute an Update query
	 * @param env
	 * @param query
	 * @throws SQLException
	 */
	public static void executeUpdate(String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		try{
			
			db.ExecuteUpdate(query);
	      }catch(SQLException e){
	    	System.out.println("Something went wrong while executing Update statement");  
	        e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
	}
	
	public static void executeUpdate_commit(String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		try{
			
			db.ExecuteUpdate(query);
			db.connection.commit();
	      }catch(SQLException e){
	    	System.out.println("Something went wrong while executing Update statement");  
	        e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
	}
	/**
	 * Used to execute an Insert query
	 * @param env
	 * @param query
	 * @throws SQLException
	 */
	public static void executeInsert(String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		try{
			
			db.ExecuteInsert(query);
	      }catch(SQLException e){
	    	System.out.println("Something went wrong while executing Insert statement");  
	        e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
	}
	
	/**
	 * Used to execute a query with a row as result, row will be returned as a map
	 * @param env
	 * @param query
	 * @return resultSelect
	 * @throws SQLException
	 */
	public static Map<String, String> executeSingleRowSelect (String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		Map<String, String> resultSelect = new HashMap<String, String>();   
		try{
			ResultSet rs = db.ExecuteSelect(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			while (rs.next()) {
				for (int i = 1; i <= columnCount; i++) {
					resultSelect.put(rsmd.getColumnName(i),rs.getString(i) );  
				}
			}
	      }catch(SQLException e){
	    	if (e.getErrorCode() != 942){
	    		System.out.println("Something went wrong while executing Select statement: "+e.getMessage());
	    	}
	    	e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
		return resultSelect;
	}	
	
	/**
	 * Used to generate a random string
	 * @param lenght
	 * @return 
	 */
	public static String getRandomString(int lenght){	
	    StringBuffer sb = new StringBuffer();
	    for (int x = 0; x < lenght; x++)
	    {
	      sb.append((char)((int)(Math.random()*26)+97));
	    }
	    return sb.toString();
	}
	
	public static String getNumericRandomString(int lenght){	
	    StringBuffer sb = new StringBuffer();
	    for (int x = 0; x < lenght; x++)
	    {
	      sb.append((char)((int)(Math.random()*10)+48));
	    }
	    return sb.toString();
	}
	
	public static String getAlphaNumericRandomString(int lenght){
		String DATA = "0123456789abcdefghijklmnopqrstuvwxyz";
		Random RANDOM = new Random();
		StringBuffer sb = new StringBuffer();
	    for (int x = 0; x < lenght; x++) {
	    	sb.append(DATA.charAt(RANDOM.nextInt(DATA.length())));
		}
		return sb.toString();
	}
	public static int getRandomInt(int min,int max){

//		Random rand = new Random();
//		return rand.nextInt(max) + min;
		return ThreadLocalRandom.current().nextInt(min, max + 1);
	}
	/**
	 * Used to convert a string to camel case
	 * @param string
	 * @return
	 */
	public static String toCamelCase(String string){
		String[] words = string.toLowerCase().split("\\s+");
		for( int i = 1; i <= words.length - 1; i++){
		     words[i] = WordUtils.capitalize(words[i]);
		}
		return StringUtils.join(words, "");
	}
	
	public static String getTodayDate(){
		Date today = Calendar.getInstance().getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
	    return formatter.format(today);
	}
	
	public static String getTodayDateMonthName(){
		Date today = Calendar.getInstance().getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
	    return formatter.format(today);
	}
	public static String getTodayDate(String format){
		Date today = Calendar.getInstance().getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat(format);
	    return formatter.format(today);
	}
	public static String getTomorrowDate(){
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, 1);
	    Date tomorrow = calendar.getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
	    return formatter.format(tomorrow);
	}

	public static String getTomorrowDateMonthName(){
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, 1);
	    Date tomorrow = calendar.getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
	    return formatter.format(tomorrow);
	}
	
	public static String getMonthDateMonthName(){
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, 29);
	    Date tomorrow = calendar.getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
	    return formatter.format(tomorrow);
	}
	
	public static String getTwoMonthDateMonthName(){
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, 2);
	    Date tomorrow = calendar.getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
	    return formatter.format(tomorrow);
	}
	
	public static String getPastMonthDateMonthName(){
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR,-30);
	    Date tomorrow = calendar.getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
	    return formatter.format(tomorrow);
	}

	public static String getDateMonthName(int days){
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR,days);
	    Date tomorrow = calendar.getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
	    return formatter.format(tomorrow);
	}
	
	public static String addDaysToToday(int days, String format){
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR,days);
	    Date tomorrow = calendar.getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat(format);
	    return formatter.format(tomorrow);
	}
	
	public static String addDaysToDate(String stringDate, int days){
		Date tomorrow = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		    Date date = null;
			date = sdf.parse(stringDate);
			Calendar calendar = Calendar.getInstance();
		    calendar.setTime(date);
			calendar.add(Calendar.DAY_OF_YEAR,days);
		    tomorrow = calendar.getTime();
		    
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	    return formatter.format(tomorrow);
	}
	
	public static String changeFormatDate(String stringDate, String oldFormat, String newFormat) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat(oldFormat);
		Date date = sdf.parse(stringDate);
		sdf.applyPattern(newFormat);
		return sdf.format(date);
	}

	public static void printIdented(String string){
		System.out.println();
		System.out.printf("\t"+string);
		System.out.println();
	}
	
	/**
	 *  Used to execute a query with a multiple rows as result, rows will be returned as a map
	 * @param env
	 * @param query
	 * @return
	 * @throws SQLException
	 */
	public static List<Map<String, String>> executeMultipleRowSelect (String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		Map<String, String> resultSelect; 
		List<Map<String, String>> recordList = new ArrayList<Map<String, String>>();	 
		try{
			ResultSet rs = db.ExecuteSelect(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount(); 
			while (rs.next()) {
				resultSelect = new HashMap<String, String>();
				for (int i = 1; i <= columnCount; i++) {
				    resultSelect.put(rsmd.getColumnName(i),rs.getString(i) );
				}			 
			    recordList.add(resultSelect);
			}
	      }catch(SQLException e){
	    	System.out.println("Something went wrong while executing Select statement");  
	        e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
		return recordList;
	}
	
	/**
	 *  Used to execute a query with a row as result, row will be returned as a json object
	 * @param env
	 * @param query
	 * @return
	 * @throws SQLException
	 */
	public static JSONObject executeSingleSelectJson(String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		JSONObject resultSelect = new JSONObject();   
		try{
			ResultSet rs = db.ExecuteSelect(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount(); 
	        if(rs.next()){
				for (int i = 1; i <= columnCount; i++) {
					rs.getString(i);
					if (rs.wasNull()) {
						resultSelect.put(rsmd.getColumnName(i),JSONObject.NULL);
					}else if (rsmd.getColumnClassName(i).equals("java.lang.String")){
						resultSelect.put(rsmd.getColumnName(i),rs.getString(i));
					}else if (rsmd.getColumnClassName(i).equals("java.sql.Timestamp")){
						resultSelect.put(rsmd.getColumnName(i),rs.getString(i));
					}else if (rsmd.getColumnClassName(i).equals("java.math.BigDecimal")){
						resultSelect.put(rsmd.getColumnName(i),rs.getDouble(i));
					}else{
						resultSelect.put(rsmd.getColumnName(i),rs.getInt(i));
					}
				}
			}	
			
	      }catch(SQLException | JSONException e){
	    	System.out.println("Something went wrong while executing Select statement");  
	        System.out.println(e.getMessage());
	    	e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
		return resultSelect;
	}	
	
	/**
	 *  Used to execute a query with a row as result, row will be returned as a json and string flag values are change to bool
	 * @param env
	 * @param query
	 * @return
	 * @throws SQLException
	 */
	public static JSONObject executeSingleSelectJsonB (String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		JSONObject resultSelect = new JSONObject();   
		try{
			ResultSet rs = db.ExecuteSelect(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount(); 
	        rs.next();
			for (int i = 1; i <= columnCount; i++) {
				rs.getString(i);
				if (rs.wasNull()) {
					resultSelect.put(rsmd.getColumnName(i),JSONObject.NULL);
				}else if (rsmd.getColumnClassName(i).equals("java.lang.String")){
					if(rs.getString(i).equals("Y")){
						resultSelect.put(rsmd.getColumnName(i),true);
					} else if(rs.getString(i).equals("N")){
						resultSelect.put(rsmd.getColumnName(i),false);
					} else {
						resultSelect.put(rsmd.getColumnName(i),rs.getString(i));
					}
				}else{
					resultSelect.put(rsmd.getColumnName(i),rs.getInt(i));
				}
			}	
	      }catch(SQLException | JSONException e){
	    	System.out.println("Something went wrong while executing Select statement"); 
	    	System.out.println(e);
	        e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
		return resultSelect;
	}	
	
	public static List<JSONObject> executeMultipleRowSelectJson (String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		JSONObject resultSelect; 
		List<JSONObject> recordList = new ArrayList<JSONObject>();	 
		try{
			ResultSet rs = db.ExecuteSelect(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount(); 
			while (rs.next()) {
				resultSelect = new JSONObject();
				for (int i = 1; i <= columnCount; i++) {
					rs.getString(i);
					if (rs.wasNull()) {
						resultSelect.put(rsmd.getColumnName(i),JSONObject.NULL);
					}else if (rsmd.getColumnClassName(i).equals("java.lang.String")){
						resultSelect.put(rsmd.getColumnName(i),rs.getString(i));
					}else if (rsmd.getColumnClassName(i).equals("java.sql.Timestamp")){
						resultSelect.put(rsmd.getColumnName(i), rs.getTimestamp(i).toString());
					}else if (rsmd.getColumnClassName(i).equals("java.math.BigDecimal")){
						resultSelect.put(rsmd.getColumnName(i), rs.getBigDecimal(i));
					}
					else{
						resultSelect.put(rsmd.getColumnName(i),rs.getInt(i));
					}
				}
				//System.out.println(resultSelect);
			    recordList.add(resultSelect);
			}
	      }catch(SQLException | JSONException e){
	    	System.out.println("Something went wrong while executing Select statement");  
	        e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
		return recordList;
	}
	public static JSONArray executeMultipleRowSelectArray (String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		JSONObject resultSelect; 
		JSONArray recordList = new JSONArray();	 
		try{
			ResultSet rs = db.ExecuteSelect(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount(); 
			while (rs.next()) {
				resultSelect = new JSONObject();
				for (int i = 1; i <= columnCount; i++) {
					rs.getString(i);
					if (rs.wasNull()) {
						resultSelect.put(rsmd.getColumnName(i),JSONObject.NULL);
					}else if (rsmd.getColumnClassName(i).equals("java.lang.String")){
						resultSelect.put(rsmd.getColumnName(i),rs.getString(i));
					}else if (rsmd.getColumnClassName(i).equals("java.sql.Timestamp")){
						resultSelect.put(rsmd.getColumnName(i), rs.getTimestamp(i).toString());
					}else{
						resultSelect.put(rsmd.getColumnName(i),rs.getInt(i));
					}
				}
				//System.out.println(resultSelect);
			    recordList.put(resultSelect);
			}
	      }catch(SQLException | JSONException e){
	    	System.out.println("Something went wrong while executing Select statement");  
	        e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
		return recordList;
	}
	
	public static JSONArray executeSingleSelectArray (String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		JSONArray recordList = new JSONArray();	 
		try{
			ResultSet rs = db.ExecuteSelect(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount(); 
			while (rs.next()) {
				for (int i = 1; i <= columnCount; i++) {
					rs.getString(i);
					if (rs.wasNull()) {
						recordList.put(JSONObject.NULL);
					}else if (rsmd.getColumnClassName(i).equals("java.lang.String")){
						recordList.put(rs.getString(i));
					}else if (rsmd.getColumnClassName(i).equals("java.sql.Timestamp")){
						recordList.put(rs.getTimestamp(i).toString());
					}else{
						recordList.put(rs.getInt(i));
					}
				}
			}
	      }catch(SQLException e){
	    	System.out.println("Something went wrong while executing Select statement");  
	        e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
		return recordList;
	}
	public static String getAssessmentAnswer(String env, String assessmentID, String question) throws SQLException{
		String query = "select sai.item_response from adm.dm_session_assessment_items sai join adm.dm_admin_items dai"+
				" on sai.item_id = dai.item_id where sai.session_assessment_id = "+assessmentID+" and dai.description = '"+ 
				question+"'";
		return executeSingleSelect(env, query);
	}
	
	public static String getLastAssessment(String env, String patientId) throws SQLException{
		String query = "select session_assessment_id  from  (select session_assessment_id"+
			" from adm.dm_session_assessments sa"+
			" join adm.dm_sessions s on sa.session_id = s.session_id"+
			" where s.patient_id ="+patientId+ 
			" order by sa.session_assessment_id desc) where rownum < 2";
		return executeSingleSelect(env, query);
	}
	
	
	public static Map<String, String> getCriteriaPrescription(String criteriaString, String env) {
		String[] criteria  = MiscTools.toList(criteriaString);
		String query = SqlQueries.valueOf(StringUtils.join(criteria, "")).toString();
		Map<String, String> prescription = null;
		try {
			prescription = executeSingleRowSelect(env, query);
			if (criteria.length > 2){
				if(StringUtils.join(criteria,"",1,3).equals("RefillY")||StringUtils.join(criteria,"",1,3).equals("RenewalY")){
					String patientId = prescription.get("patient_id");
					String reassessmentQuery= SqlQueries.ReassessmentTask.toString();
					String taskId = executeSingleSelect(env, reassessmentQuery);
					String assignTaskQuery = "update wq_tasks set patient_id ="+patientId+" where task_id ="+taskId;
					executeUpdate(env, assignTaskQuery);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return prescription ;
	}
	
	public static JSONArray getDateIso8601Format(String stringDate){
		JSONArray arrayDate = null;
		try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			    Date date = null;
				date = sdf.parse(stringDate);
			    Calendar cal = Calendar.getInstance();
			    cal.setTime(date);
			    
			    int year = cal.get(Calendar.YEAR);
			    int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
			    int hour = cal.get(Calendar.HOUR_OF_DAY);
			    int minute = cal.get(Calendar.MINUTE);
			    int second = cal.get(Calendar.SECOND);
			    int monthValue = cal.get(Calendar.MONTH)+1;
			    arrayDate = new JSONArray();
			    arrayDate.put(year);
			    arrayDate.put(monthValue);
			    arrayDate.put(dayOfMonth);
			    arrayDate.put(hour);
			    arrayDate.put(minute);
			    if(second > 0){
			    	arrayDate.put(second);
			    }
			    
		} catch (ParseException e) {
			System.out.println("Something went wrong parsing ISO format date");
			e.printStackTrace();
		}
		return  arrayDate;
	}
	public static String changeDateFormat(String stringDate){
		String newFormatDate = "";
		try {
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
			    Date date = null;
				date = sdf.parse(stringDate);
			    Calendar cal = Calendar.getInstance();
			    cal.setTime(date);

			    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
			    newFormatDate = sdf2.format(cal.getTime());

		} catch (ParseException e) {
			System.out.println("Something went wrong parsing ISO format date");
			e.printStackTrace();
		}
		return newFormatDate;
	}
	public static String chageDateFormat2(String stringDate){
		String newFormatDate = "";
		if(stringDate == "null"){
			newFormatDate = stringDate;
		}else{
			
			try {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				    Date date = null;
					date = sdf.parse(stringDate);
				    Calendar cal = Calendar.getInstance();
				    cal.setTime(date);
	
				    SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MMM-yy");
				    newFormatDate = sdf2.format(cal.getTime());
	
			} catch (ParseException e) {
				System.out.println("Something went wrong parsing ISO format date");
				e.printStackTrace();
			}
		}
		return newFormatDate;
	}
	
	public static String chageDateFormat3(String stringDate){
		String newFormatDate = "";
		try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			    Date date = null;
				date = sdf.parse(stringDate);
			    Calendar cal = Calendar.getInstance();
			    cal.setTime(date);

			    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
			    newFormatDate = sdf2.format(cal.getTime());

		} catch (ParseException e) {
			System.out.println("Something went wrong parsing ISO format date");
			e.printStackTrace();
		}
		return newFormatDate;
	}
	
	public static JSONObject prescrionsArrayToJson(JSONArray array){
		String rxNumber;
		JSONObject json = new JSONObject();
		JSONObject temp;
		for (int i = 0; i<array.length(); i++){
			try {
				temp = array.getJSONObject(i);
				rxNumber = temp.getJSONObject("prescription").getString("rxNumber").replaceAll("\\.0", "");
				json.put(rxNumber,temp);
			} catch (JSONException e) {
				System.out.println("Something went wrong converting prescriptions array to JSON");
				e.printStackTrace();
			}
		}
		return json;
	}
	public static JSONArray prescrionsArrayAddKey2(JSONArray array){
		JSONObject temp;
		for (int i = 0; i<array.length(); i++){
			try {
				temp = array.getJSONObject(i);
				temp.put("rxNumber", temp.getJSONObject("prescription").getString("rxNumber").replaceAll("\\.0", ""));
				array.put(i, temp);
			} catch (JSONException e) {
				System.out.println("Something went wrong converting prescriptions array to JSON");
				e.printStackTrace();
			}
		}
		return array;
	}
	
	public static Map<String, JSONObject> prescrionsArrayAddKey(JSONArray array){
		JSONObject temp;
		Map<String, JSONObject> rxMap = new HashMap<String, JSONObject>();
		for (int i = 0; i<array.length(); i++){
			try {
				temp = array.getJSONObject(i);
				rxMap.put(temp.getJSONObject("prescription").getString("rxNumber").replaceAll("\\.0", ""),temp);
			} catch (JSONException e) {
				System.out.println("");
				e.printStackTrace();
			}
		}
		return rxMap;
	}
	public static JSONArray orderJsonArray(JSONArray jsonArray){
		JSONArray sortedJsonArray = new JSONArray();
		List<JSONObject> jsonList = new ArrayList<JSONObject>();
		
	    try {
	    	for (int i = 0; i < jsonArray.length(); i++) {
	    		jsonList.add(jsonArray.getJSONObject(i));
	    	}
	    	Collections.sort( jsonList, new Comparator<JSONObject>() {
	    	    public int compare(JSONObject a, JSONObject b) {
	    	        String valA = new String();
	    	        String valB = new String();

	    	        try {
	    	            valA = (String) a.getString("rxNumber");
	    	            valB = (String) b.getString("rxNumber");
	    	        } 
	    	        catch (JSONException e) {
	    	            //do something
	    	        }

	    	        return valA.compareTo(valB);
	    	    }
	    	});
	    	
	    	for (int i = 0; i < jsonArray.length(); i++) {
	    	    sortedJsonArray.put(jsonList.get(i));
	    	}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return sortedJsonArray;
	}
	
	public static void deliveryDaysSetup(Map<String, String> prescription,String env){
		String fromQuery = "select svcbr_id, prescription_id, refill_no from rxh_custom.mi_prescription_xref where svcbr_id = "+prescription.get("sb")+
				" and prescription_id = "+prescription.get("rx")+" and refill_no ="+prescription.get("refill");
		try {
			Map<String, String> prescriptionDirectOrIntegrated = MiscTools.executeSingleRowSelect(env, fromQuery);
			if(prescriptionDirectOrIntegrated.isEmpty()){
				verifyDirectPrescriptionDates(prescription, env);
			}else{
				verifyIntegratedPrescriptionDates(prescription, env);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void verifyDirectPrescriptionDates( Map<String, String> prescription,String env){
		String statusQuery = " select rx_status from prescriptions where svcbr_id = "+prescription.get("sb")+" and prescription_id = "+
				prescription.get("rx")+"and refill_no= "+prescription.get("refill");
		String query = "select svcbr_id, prescription_id, refill_no from thot.delivery_ship_dates where svcbr_id = "+prescription.get("sb")+
				" and prescription_id = "+prescription.get("rx")+" and refill_no ="+prescription.get("refill"); 
		String idQuery = "select max(id)+1 from thot.delivery_ship_dates";
		String id;
		try {
			Map<String, String> prescriptionDeliveryDates = MiscTools.executeSingleRowSelect(env, query);
			
			id= executeSingleSelect(env, idQuery);
			if(prescriptionDeliveryDates.isEmpty()){
				query =	"insert into thot.delivery_ship_dates (id,patient_id, svcbr_id, prescription_id, refill_no, delivery_date, ship_date,"
					+ "check_date, override_reason, calendar_flag) values ("+id+","+prescription.get("patient_id")+","+prescription.get("sb")
					+ ","+prescription.get("rx")+","+prescription.get("refill")+",SYSDATE , SYSDATE , 'N', null, null )";
				executeInsert(env, query);
			}
			if(executeSingleSelect(env, statusQuery).equals("ACTIVE")){
				id= executeSingleSelect(env, idQuery);
				prescription.put("refill", Integer.toString(Integer.parseInt(prescription.get("refill")) + 1));
				query = "select svcbr_id, prescription_id, refill_no from thot.delivery_ship_dates where svcbr_id = "+prescription.get("sb")+
						" and prescription_id = "+prescription.get("rx")+" and refill_no ="+prescription.get("refill"); 
				prescriptionDeliveryDates = MiscTools.executeSingleRowSelect(env, query);
				query =	"insert into thot.delivery_ship_dates (id,patient_id, svcbr_id, prescription_id, refill_no, delivery_date, ship_date,"
						+ "check_date, override_reason, calendar_flag) values ("+id+","+prescription.get("patient_id")+","+prescription.get("sb")
						+ ","+prescription.get("rx")+","+prescription.get("refill")+",SYSDATE , SYSDATE , 'N', null, null )";
				if(prescriptionDeliveryDates.isEmpty()){
					System.out.println(query+"<-");
					executeInsert(env, query);
				}
				prescription.put("refill", Integer.toString(Integer.parseInt(prescription.get("refill")) - 1));
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}
	public static void verifyIntegratedPrescriptionDates( Map<String, String> prescription,String env){
			String statusQuery = " select rx_status from prescriptions where svcbr_id = "+prescription.get("sb")+" and prescription_id = "+
					prescription.get("rx")+"and refill_no= "+prescription.get("refill");
			
			String query = "select svcbr_id, prescription_id, refill_no from thot.shc_integrated_dely_ship_dates where svcbr_id = "+prescription.get("sb")+
					" and prescription_id = "+prescription.get("rx")+" and refill_no ="+prescription.get("refill"); 
			System.out.println(query);
			try {
				Map<String, String> prescriptionDeliveryDates = MiscTools.executeSingleRowSelect(env, query);
				System.out.println(prescriptionDeliveryDates);
				if(prescriptionDeliveryDates.isEmpty()){
					query =	"insert into thot.shc_integrated_dely_ship_dates (svcbr_id, prescription_id, refill_no, delivery_date_1, ship_date_1,"
						+ "is_integrated_date, override_reason) values ("+prescription.get("sb")+ ","+prescription.get("rx")+","
						+ prescription.get("refill")+",SYSDATE , SYSDATE , 'N', null)";
					System.out.println(query + "llalala");
					executeInsert(env, query);
				}
				
				
				if(executeSingleSelect(env, statusQuery).equals("ACTIVE")){
					prescription.put("refill", Integer.toString(Integer.parseInt(prescription.get("refill")) + 1));
					query = "select svcbr_id, prescription_id, refill_no from thot.shc_integrated_dely_ship_dates where svcbr_id = "+prescription.get("sb")+
							" and prescription_id = "+prescription.get("rx")+" and refill_no ="+prescription.get("refill"); 
					prescriptionDeliveryDates = MiscTools.executeSingleRowSelect(env, query);
					System.out.println(prescriptionDeliveryDates);
					if(prescriptionDeliveryDates.isEmpty()){
						query =	"insert into thot.shc_integrated_dely_ship_dates (svcbr_id, prescription_id, refill_no, delivery_date_1, ship_date_1,"
								+ "is_integrated_date, override_reason) values ("+prescription.get("sb")+ ","+prescription.get("rx")+","
								+ prescription.get("refill")+",SYSDATE , SYSDATE , 'N', null)";
						System.out.println(query);
						executeInsert(env, query);
					}
					prescription.put("refill", Integer.toString(Integer.parseInt(prescription.get("refill")) - 1));
				}
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
			
	}
	public static boolean findDuplicate( JSONArray jsonArray,String key){
		for(int j = 0; j< jsonArray.length(); j++){
			try {
				if(jsonArray.getString(j).equals(key)){
					return true;
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
  public static String getOauthHeader(OauthAuthorization authorization, String httpMethod,String requestUrl) throws UnsupportedEncodingException {
	  OAuthHeader oAuthHeader= new OAuthHeader(authorization.oauthConsumerRequestTokenURL 
          , authorization.oauthConsumerAccessTokenURL
          , authorization.oauthConsumerConsumerKey
          , authorization.oauthConsumerConsumerSecret);
	 
	  String auth = oAuthHeader.getAuthHeader(httpMethod, URI.create(requestUrl));
   return auth;
  }
  
  public static JSONObject updateCreateRxRequestWithPatient(String patientId, JSONObject requestBodyJson, String env){
		String physicianId,therapyType, ndc, orderTaken;
		int fillsAllowed;
		try {
			//sb = executeSingleSelect(env, String.format(SqlQueries.GetPatientSb.toString(), patientId));
			//requestBodyJson.put("processingPharmacy", Integer.parseInt(sb));
			ndc = executeSingleSelect(env, String.format(SqlQueries.GetNdcFromPatientTherapy.toString(), patientId));
			physicianId = executeSingleSelect(env, String.format(SqlQueries.GetPhysicianFromPatient.toString(), patientId));
			
			fillsAllowed = getRandomInt(1, 5);

			requestBodyJson.put("legacyPatientID", Integer.parseInt(patientId));
			requestBodyJson.put("fillsAllowed",  fillsAllowed);	
			requestBodyJson.put("writtenDate", MiscTools.addDaysToToday(0, "yyyy-MM-dd"));
			requestBodyJson.put("refillThruDate",MiscTools.addDaysToToday(30, "yyyy-MM-dd"));
			requestBodyJson.put("expirationDate", MiscTools.addDaysToToday(60, "yyyy-MM-dd"));
			requestBodyJson.put("ndc", ndc);
			//requestBodyJson.put("prescriber", Integer.parseInt(physicianId));
			
			//orderTaken = executeSingleSelect(env,SqlQueries.GetOrderTaken.toString());
			//requestBodyJson.put("orderTaken",  orderTaken);
			JSONObject rxOriginCode = executeSingleSelectJson(env, SqlQueries.GetRxOrignCode.toString());
			requestBodyJson.put("rxOriginCode", rxOriginCode);
			JSONObject prescriberInfo = executeSingleSelectJson(env, String.format(SqlQueries.GetPrescriberInfo.toString(), physicianId));
			prescriberInfo.put("legacyPrescriberId", JSONObject.NULL);
			prescriberInfo.put("npiId", JSONObject.NULL);
			prescriberInfo.put("zip", JSONObject.NULL);
			prescriberInfo.put("addLine1", JSONObject.NULL);
			prescriberInfo.put( "addLine2", JSONObject.NULL);
			prescriberInfo.put("state", JSONObject.NULL);
			prescriberInfo.put("city", JSONObject.NULL);
			prescriberInfo.put( "phone", JSONObject.NULL);
			prescriberInfo.put("fax", JSONObject.NULL);

			requestBodyJson.put("practitioner", prescriberInfo);
			
			
		} catch (SQLException | JSONException e) {
			e.printStackTrace();
		}
		
	  return requestBodyJson;
  }
//  public static JSONObject updateCreateRxRequestWithPatient(String patientId, JSONObject requestBodyJson, String env){
//		String physicianId,therapyType, ndc;
//		try {
//			therapyType = executeSingleSelect(env, String.format(SqlQueries.GetTTFromPatient.toString(), patientId));
//			System.out.println(String.format(SqlQueries.GetTTFromPatient.toString(), patientId));
//			//ndc = executeSingleSelect(env, String.format(SqlQueries.GetNdcFromPatientTherapy.toString(), patientId));
//			physicianId = executeSingleSelect(env, String.format(SqlQueries.GetPhysicianFromPatient.toString(), patientId));
//			//sb = executeSingleSelect(env, String.format(SqlQueries.GetPatientSb.toString(), patientId));
//			//requestBodyJson.put("processingPharmacy", Integer.parseInt(sb));
//			String orderTaken = executeSingleSelect(env,SqlQueries.GetOrderTaken.toString());
//			requestBodyJson.put("orderTaken",  orderTaken);
//			System.out.println("patientId----->"+patientId);
//			requestBodyJson.put("patient", Integer.parseInt(patientId));
//			//requestBodyJson.put("therapyID", JSONObject.NULL);
//			System.out.println(therapyType);
//			requestBodyJson.put("therapyID", therapyType);
//			//requestBodyJson.put("ndc", ndc);
//			requestBodyJson.put("writtenDate", MiscTools.addDaysToToday(0, "yyyy-MM-dd"));
//			requestBodyJson.put("refillThruDate",MiscTools.addDaysToToday(30, "yyyy-MM-dd"));
//			requestBodyJson.put("expirationDate", MiscTools.addDaysToToday(60, "yyyy-MM-dd"));
//			
//			requestBodyJson.put("prescriber", Integer.parseInt(physicianId));
//		} catch (SQLException | JSONException e) {
//			e.printStackTrace();
//		}
//		
//	  return requestBodyJson;
//  }
  
  public static JSONObject updateSingleCallPrescriptionRequest(String patientId, JSONObject requestBodyJson, String env){
		String physicianId,therapyType, sb, ndcphysicianId, ndc, orderTaken;
		int fillsAllowed;
		try {
			 requestBodyJson.sortedKeys();
			 
			JSONObject prescriptionRequest = requestBodyJson.getJSONObject("prescription");

			ndc = executeSingleSelect(env, String.format(SqlQueries.GetNdcFromPatientTherapy.toString(), patientId));
			physicianId = executeSingleSelect(env, String.format(SqlQueries.GetPhysicianFromPatient.toString(), patientId));
			fillsAllowed = getRandomInt(1, 5);
			
			
			prescriptionRequest.put("legacyPatientID", Integer.parseInt(patientId));
			prescriptionRequest.put("fillsAllowed",  fillsAllowed);
			prescriptionRequest.put("writtenDate", MiscTools.addDaysToToday(0, "yyyy-MM-dd"));
			//prescriptionRequest.put("refillThruDate",MiscTools.addDaysToToday(30, "yyyy-MM-dd"));
			prescriptionRequest.put("expirationDate", MiscTools.addDaysToToday(60, "yyyy-MM-dd"));
			prescriptionRequest.put("ndc", ndc);

			JSONObject rxOriginCode = executeSingleSelectJson(env, SqlQueries.GetRxOrignCode.toString());
			prescriptionRequest.put("rxOriginCode", rxOriginCode);
			
			JSONObject prescriberInfo = executeSingleSelectJson(env, String.format(SqlQueries.GetPrescriberInfo.toString(), physicianId));
			prescriberInfo.put("legacyPrescriberId", JSONObject.NULL);
			prescriberInfo.put("npiId", JSONObject.NULL);
			prescriberInfo.put("zip", JSONObject.NULL);
			prescriberInfo.put("addLine1", JSONObject.NULL);
			prescriberInfo.put( "addLine2", JSONObject.NULL);
			prescriberInfo.put("state", JSONObject.NULL);
			prescriberInfo.put("city", JSONObject.NULL);
			prescriberInfo.put( "phone", JSONObject.NULL);
			prescriberInfo.put("fax", JSONObject.NULL);

			prescriptionRequest.put("practitioner", prescriberInfo);
		
			JSONObject fillItemRequest = requestBodyJson.getJSONObject("fillRx");
			fillItemRequest.put("fillingPharmacy", 555);
			fillItemRequest.put("fillNumber", 0);
			fillItemRequest.put("rx_start_date",addDaysToToday(0, "yyyy-MM-dd"));
			fillItemRequest.put("rx_stop_date", addDaysToToday(30, "yyyy-MM-dd"));
			fillItemRequest.put("fillDate",addDaysToToday(0, "yyyy-MM-dd"));
			fillItemRequest.put("shipDate",addDaysToToday(0, "yyyy-MM-dd"));
			fillItemRequest.put("note",getRandomString(5));
			fillItemRequest.put("notes",getRandomString(5));
			JSONArray itemsRequestArray = requestBodyJson.getJSONArray("prescribedItems");
			JSONObject inventoryItem = itemsRequestArray.getJSONObject(0);

			inventoryItem.put("processingPharmacy", 555);
			inventoryItem.put("fillNumber",0);
			
			String rxDrug = executeSingleSelect(env,String.format(SqlQueries.GetRxDrugFromNdc.toString(),ndc ));
			String dosageUnit = executeSingleSelect(env, String.format(SqlQueries.GetInvUnit.toString(),rxDrug));
			String drugRoute = executeSingleSelect(env,SqlQueries.GetDrugRoute.toString());
			Map<String, String> invDetails =  MiscTools.executeSingleRowSelect(env, String.format(SqlQueries.GetInvDetails.toString(), ndc,"555"));
//			System.out.println(String.format(SqlQueries.GetInvDetails.toString(),ndc,"555"));
//			System.out.println(invDetails);
//			System.out.println();
			String lot =  invDetails.get("lot"),qtyUnits= invDetails.get("quantityUnits"),
			strength = invDetails.get("strength"),strengthUnits = invDetails.get("strengthUnits");
			
			inventoryItem.put("ndc", ndc);
			inventoryItem.put("drugRoute", drugRoute);
			int dosage = getRandomInt(1,3);
			inventoryItem.put("dosage", dosage);
			inventoryItem.put("dosage_unit", dosageUnit);
			inventoryItem.put("quantityUnits", qtyUnits);
			inventoryItem.put("quantity", getRandomInt(1,3));
			inventoryItem.put("name", rxDrug);
			inventoryItem.put("lot", lot);
			inventoryItem.put("strength",strength);
			inventoryItem.put("strengthUnits", strengthUnits);
			inventoryItem.put("quantityUnits", qtyUnits);

			requestBodyJson.put("prescription",prescriptionRequest);
			requestBodyJson.put("fillRx",fillItemRequest);
			requestBodyJson.put("prescribedItems",itemsRequestArray);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	  return requestBodyJson;
  }
  public static String updateFillRxRequestWithPrescription(Map<String, String> prescription, JSONObject requestBodyJson){
		String sb, refill;
		sb = prescription.get("sb"); refill = prescription.get("refill");
		try {
			requestBodyJson.put("fillingPharmacy", Integer.parseInt(sb));
			//requestBodyJson.put("processingPharmacy", Integer.parseInt(sb));
			requestBodyJson.put("fillNumber", Integer.parseInt(refill));
			requestBodyJson.put("rx_start_date", addDaysToToday(0, "yyyy-MM-dd"));
			requestBodyJson.put("rx_stop_date", addDaysToToday(30, "yyyy-MM-dd"));
			requestBodyJson.put("fillDate", addDaysToToday(0, "yyyy-MM-dd"));
			requestBodyJson.put("shipDate", addDaysToToday(0, "yyyy-MM-dd"));
			requestBodyJson.put("notes",getRandomString(5));
			requestBodyJson.put("comments",getRandomString(7));

		} catch (JSONException e) {
			e.printStackTrace();
		}
	  return requestBodyJson.toString();
  }
  public static String getMsgFromRes(String responseBody){
	  String message = ""; 
	  try {
		JSONObject response = new JSONObject(responseBody);
		
		if(response.has("statusMessage")){
			message = response.getString("statusMessage");
		}else {
			message = response.getString("message");
		}
		
	} catch (JSONException e) {
		e.printStackTrace();
	}
	  return message;
  }
  
  public static String getErrorFromRes(String responseBody) throws JSONException{
	  String error = "";
	  JSONObject response;
	  try {
		JSONArray responseArray = new JSONArray(responseBody);
		 response= responseArray.getJSONObject(0);
		
	} catch (JSONException e) {
		response =  new JSONObject(responseBody);
	}
	  error = response.getString("x_errors");
	  return error;
  }
 
  public static String getErrorFromRes(String responseBody, String path) throws JSONException{
	  String error = "";
	  JSONObject response;
	  try {
		JSONArray responseArray = new JSONArray(responseBody);
		 response= responseArray.getJSONObject(0);
		
	} catch (JSONException e) {
		response =  new JSONObject(responseBody);
	}
	  error = JsonTools.findKeysPath(response, "fillItemResponse.x_errors");

	  return error;
  }
 
//  public static String getMsgFromRes(String responseBody, String key){
//	  String message = ""; 
//	  try {
//		JSONObject response = new JSONObject(responseBody);
//		message = response.getString(key);
//	} catch (JSONException e) {
//		e.printStackTrace();
//	}
//	  return message;
//  }
  public static String updateFillRxRequestWithInvalidTherapy(JSONObject requestBodyJson, String env){
		try {
			JSONArray itemsRequestArray = requestBodyJson.getJSONArray("itemRequest");
			for (int i = 0; i < itemsRequestArray.length(); i++){
				JSONObject itemRequest =  itemsRequestArray.getJSONObject(i);
				String drugAbbrev = itemRequest.getString("name");
				String invalidDrugAbbrev = drugAbbrev;
				do {
					invalidDrugAbbrev = (drugAbbrev.substring(0, drugAbbrev.length() - 1) + getRandomString(1)).toUpperCase();
				} while(invalidDrugAbbrev.equals(drugAbbrev));
				itemRequest.put("name", invalidDrugAbbrev);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	  return requestBodyJson.toString();
  }
  
  public static String updateFillRxRequestWithInvalidInvRx(Map<String, String> prescription,JSONObject requestBodyJson, String env){
	String sb, invalidRxId, invalidSb;
	  try {
			JSONArray itemsRequestArray = requestBodyJson.getJSONArray("itemRequest");
			for (int i = 0; i < itemsRequestArray.length(); i++){
				JSONObject itemRequest =  itemsRequestArray.getJSONObject(i);
				sb = itemRequest.getString("processingPharmacy");
				invalidSb = Integer.toString(Integer.parseInt(sb) + 1 + (int)(Math.random() * 10));
				invalidRxId = Integer.toString(1000 + (int)(Math.random() * 10000)); 
				
				itemRequest.put("processingPharmacy",invalidSb);
				itemRequest.put("rxNumber",invalidRxId);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	  return requestBodyJson.toString();
}
  public static String updateFillRxRequestWithInvalidStorage(JSONObject requestBodyJson, String env){
		try {
			 String invalidStorageType = getRandomString(3).toUpperCase();
			 requestBodyJson.put("storageType", invalidStorageType);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	  return requestBodyJson.toString();
  }
 
  public static JSONObject getRxValuesDefaulted(String sb, String rxId, String refill,String env){
	  String query = String.format(SqlQueries.GetRxDefaults.toString(),sb, rxId, refill);
	  JSONObject defaultValues = new JSONObject();
	  try {
		  defaultValues = executeSingleSelectJson(env,query);
	  } catch (SQLException e) {
		  e.printStackTrace();
	  }	
	  return defaultValues;
  }
  
  public static String updateRequestNotFilled(JSONObject requestBodyJson){

	  try {
		  requestBodyJson.put("fillDate","null");
		  requestBodyJson.put("shipDate","null");
		  requestBodyJson.put("daysSupply",JSONObject.NULL);
		  requestBodyJson.put("technicianInitials","");
		  requestBodyJson.put("directions",JSONObject.NULL);
		  requestBodyJson.put("note",JSONObject.NULL);
		  requestBodyJson.put("substitutions","0");
		  requestBodyJson.put("prescriberDAW",JSONObject.NULL);
		  requestBodyJson.put("patientDAW",JSONObject.NULL);
		  requestBodyJson.put("drug_route","OTHER");
		  requestBodyJson.put("storageType",JSONObject.NULL);
		  requestBodyJson.put("rx_start_date","null");
		  requestBodyJson.put("rx_stop_date","null");
		  requestBodyJson.put("order_taken_code",JSONObject.NULL);
	} catch (JSONException e) {
		e.printStackTrace();
	}
	  return  requestBodyJson.toString();
  }
  
  public static String addTherapyFilter(String therapyType, String env) {
	  String therapyFilter = "";
	  
	  try {
		 String result = executeSingleSelectTherapy(env,String.format(SqlQueries.TherapyTypeExists.toString(), therapyType));
		if(result.equals(therapyType)){
			therapyFilter = therapyType == ""? "":"and rx.therapy_type = '"+therapyType+"'";
		  }
	} catch (SQLException e) {
		System.out.println(e.getMessage());
		e.printStackTrace();
	}
	return therapyFilter;
  }
  
  public static String addRefillFilter(String refill) {
	return refill == ""? "":"and rx.refill_no = "+refill;
  }
  public static String concatenateParams(String api, JSONArray params){
	if(params.length() > 0){
		try {
			api = api.replaceAll("/$", "");
			api = api + "?";
			for(int i = 0; i < params.length(); i++){
				if(i != 0)api = api+"&";
				api = api + params.get(i);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
	}
	return api;
  }
  
	public static String executeSingleSelectTherapy(String env, String query) throws SQLException{
		DBConnection  db = new DBConnection(env);
		String result = new String();
		try{
			ResultSet rs = db.ExecuteSelect(query);
			if(rs.next()){
	        //rs.next();
	        result = rs.getString(1);
			}
	      }catch(SQLException e){
	        e.getStackTrace();
	      }finally{
	        db.Close();
	      } 
		return result;
	}
	
	public static String getNonExistentTrc(String env){
		String trcId = "", empty = null;
		try {
			do{
				trcId = getRandomString(2).toUpperCase();
				empty = executeSingleSelect(env, String.format(SqlQueries.TrcIdExists.toString(), trcId));
			}while(empty.isEmpty() == false);
		} catch (SQLException e) {
			System.out.println("Something went wrong  getting non existent trc");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		return trcId;
	}

	public static String getNonExistentTherapyType(String env){
		String therapyType = "", empty = null;
		try {
			do{
				therapyType = getRandomString(4).toUpperCase();
				empty = executeSingleSelect(env, String.format(SqlQueries.TherapyTypeExists.toString(), therapyType));
			}while(empty.isEmpty() == false);
		} catch (SQLException e) {
			System.out.println("Something went wrong  getting non existent trc");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		return therapyType;
	}

	public static String getNonExistentCity(String env) throws SQLException{
		String city = "", empty = null;
		do{
			city = getRandomString(7).toUpperCase();
			empty = executeSingleSelect(env, String.format(SqlQueries.CityExists.toString(), city));
		}while(empty.isEmpty() == false);
		return city ;
	}

	public static String getNonExistentDrugRoute(String env) throws SQLException{
		String drugRoute = "", empty = null;
		do{
			drugRoute = getRandomString(7).toUpperCase();
			empty = executeSingleSelect(env, String.format(SqlQueries.DrugRouteExists.toString(), drugRoute));
		}while(empty.isEmpty() == false);
		return drugRoute;
	}

	public static String getNonExistentTrcPg(String trcGroup,String env) throws SQLException{
		String trcPg = "", empty = null;
		do{
			trcPg = Integer.toString(getRandomInt(1, 50));
			empty = executeSingleSelect(env, String.format(SqlQueries.TrcPgExists.toString(), trcGroup, trcPg));
		}while(empty.isEmpty() == false);
		return trcPg;
	}

	public static String getNonExistentStorageType(String env) throws SQLException{
		String storageType = "", empty = null;
		do{
			storageType = getRandomString(3).toUpperCase();
			empty = executeSingleSelect(env, String.format(SqlQueries.StorageTypeExists.toString(), storageType));
		}while(empty.isEmpty() == false);
		return storageType;
	}
	
	public static String getInvalidEligible(){
		String eligible;
		do{
			eligible = getRandomString(1).toUpperCase();
		}while(eligible.equals("Y") || eligible.equals("N"));
		
		return eligible;
	}
	public static String getNonExistentValue(String env, int length, String query ) throws SQLException{
		String nonExistentValue = "", empty = null;
		do{
			nonExistentValue = getRandomString(length).toUpperCase();
			empty = executeSingleSelect(env, String.format(query, nonExistentValue));
		}while(empty.isEmpty() == false);
		return nonExistentValue;
	}

	public static String getNonExistentNdc(String env) throws SQLException{
		String nonExistentValue = "", empty = null;
		do{
			nonExistentValue = getNumericRandomString(4)+"-"+getNumericRandomString(4)+"-"+getNumericRandomString(2);
			String query = String.format(SqlQueries.NdcExists.toString(), nonExistentValue);
			empty = executeSingleSelect(env, String.format(query, nonExistentValue));
		}while(empty.isEmpty() == false);
		return nonExistentValue;
	}
	
	public static JSONObject refreshTrcRequest(String trcId, JSONObject trcInfo, String env){
		try {
			trcInfo.put("trcId", trcId);
			trcInfo.put("trcDescription", "AUTO "+getRandomString(4).toUpperCase());
			String city = executeSingleSelect(env, String.format(SqlQueries.GetCity.toString(),""));
			trcInfo.put("city", city);
			trcInfo.put("phoneNumber",getNumericRandomString(3)+"-"+getNumericRandomString(3)+"-"+getNumericRandomString(4));
		} catch (JSONException | SQLException e) {
			System.out.println("Something went wrong refreshing trc request");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return trcInfo;
	}
	public static JSONObject refreshTrcAomTTRequest(JSONObject trcAomInfo, String env){
		try {
			String therapyType = executeSingleSelect(env,SqlQueries.GetTTNotAddedToTrcAom.toString());
			trcAomInfo.put("therapyType", therapyType);
			Random random = new Random();
			String eligible = random.nextBoolean() == true ?"Y":"N";
			
			trcAomInfo.put("eligible", eligible);
		} catch (JSONException | SQLException e) {
			System.out.println("Something went wrong refreshing trc request");
			System.out.println(e.getMessage());e.printStackTrace();
		}
		return trcAomInfo;
	}
	
	public static JSONObject refreshTrcAomPRequest(String trcGroup, String trcCode, JSONObject trcAomInfo, String env){
		try {
			trcAomInfo.put("trcCode", trcCode);
			String trcPg = getNonExistentTrcPg(trcGroup, env);
			trcAomInfo.put("trcPg", trcPg);
			trcAomInfo.put("trcPhone",getNumericRandomString(3)+"-"+getNumericRandomString(3)+"-"+getNumericRandomString(4));
			
		} catch (JSONException | SQLException e) {
			System.out.println("Something went wrong refreshing trc request");
			System.out.println(e.getMessage());e.printStackTrace();
		}
		return trcAomInfo;
	}

	public static JSONArray getTTFromRequest(JSONArray request){
		JSONArray therapyTypes = new JSONArray();
			try {
				for (int i = 0; i < request.length(); i++){
					therapyTypes.put(request.getJSONObject(i).get("therapyType"));
				}
			} catch (JSONException e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		return therapyTypes;
	}

	public static JSONObject getNewTrcValues(String trcId, JSONObject trcInfo, String env){
		try {
			if(!trcInfo.has("trcId")){
				trcInfo.put("trcId", trcId);
			}
			trcInfo.put("trcDescription", "AUTO "+getRandomString(4).toUpperCase());
			String cityFilter = trcInfo.optString("city").equals("")? "":"where city <> '"+trcInfo.optString("city")+"'";
			String city = executeSingleSelect(env, String.format(SqlQueries.GetCity.toString(),cityFilter));
			trcInfo.put("city", city);
			trcInfo.put("phoneNumber",getNumericRandomString(3)+"-"+getNumericRandomString(3)+"-"+getNumericRandomString(4));
			int callFrom = getRandomInt(0,23);
			trcInfo.put("callFrom", callFrom);
			trcInfo.put("callTo", getRandomInt(callFrom,24));
			trcInfo.put("userName", "thot");
		} catch (JSONException | SQLException e) {
			System.out.println("Something went wrong refreshing trc request");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return trcInfo;
	}
	public static JSONObject getNewRxValues(JSONObject prescriptionInfo, String env){
		try {
			String temp = prescriptionInfo.getString("orderTaken");
			temp = executeSingleSelect(env,String.format(SqlQueries.GetOrderTakenDifferentThan.toString(),temp));
			prescriptionInfo.put("orderTaken", temp);
			int numericTemp = prescriptionInfo.getInt("fillsAllowed");
			prescriptionInfo.put("fillsAllowed",numericTemp+getRandomInt(1, 5));
			temp = prescriptionInfo.getString("currentStatus");
			if(temp.equals("ACTIVE")) {
				temp = "HOLD";
			}else if(!temp.equals("PROFILE")){
				temp = executeSingleSelect(env,String.format(SqlQueries.GetStatusDifferentThan.toString(),temp));
				prescriptionInfo.put("currentStatus", temp);
			}
			numericTemp = getRandomInt(1,3)*-1; 
			temp = prescriptionInfo.getString("writtenDate");
			prescriptionInfo.put("writtenDate", addDaysToDate(temp,numericTemp));
			temp = prescriptionInfo.getString("refillThruDate");
			prescriptionInfo.put("refillThruDate", addDaysToDate(temp, numericTemp));
			//temp = prescriptionInfo.getString("expirationDate");
			prescriptionInfo.put("expirationDate", addDaysToDate(temp, numericTemp));
			temp = prescriptionInfo.getString("patient");
			temp = executeSingleSelect(env,String.format(SqlQueries.GetPatientWithTTNotIn.toString(),temp));
			prescriptionInfo.put("patient", Integer.parseInt(temp));
			String temp2 =  executeSingleSelect(env,String.format(SqlQueries.GetPatientPrescribers.toString(),temp));
			prescriptionInfo.put("prescriber",Integer.parseInt(temp2));
			temp2 =  executeSingleSelect(env,String.format(SqlQueries.GetPatientsTT.toString(),temp));
			prescriptionInfo.put("therapyID", temp2);
		} catch (SQLException | JSONException e) {
			System.out.println(e.getMessage());e.printStackTrace();
		}
		System.out.println(prescriptionInfo);
		return prescriptionInfo;
	}
	public static String getPrescriberNotInPatient(String patientId, String env){
		JSONArray prescribersArray = new JSONArray();
		JSONArray prescriberIdsArray = new JSONArray();
		String prescriber = "";
		String query = String.format(SqlQueries.GetPatientPrescribers.toString(), patientId);
		try {
			prescribersArray = MiscTools.executeMultipleRowSelectArray(env, query);
			for (int i = 0; i < prescribersArray.length(); i++){
				prescriberIdsArray.put(prescribersArray.getJSONObject(i).get("prescriber"));
			}
			query = String.format(SqlQueries.GetPrescriberIdNotIn.toString(),prescriberIdsArray.join("','"));
			prescriber = MiscTools.executeSingleSelect(env, query);
		} catch (SQLException | JSONException e) {
			e.printStackTrace();System.out.println("Cannot obtain prescriber Id: "+e.getMessage());
		}
		return prescriber;
	}
	
	public static String getTTNotInPatient(String patientId, String env){
		JSONArray therapyTypesArray = new JSONArray();
		JSONArray therapyTypeIdsArray = new JSONArray();
		String therapyType = "";
		String query = String.format(SqlQueries.GetPatientTherapies.toString(), patientId);
		try {
			therapyTypesArray = MiscTools.executeMultipleRowSelectArray(env, query);
			for (int i = 0; i < therapyTypesArray.length(); i++){
				therapyTypeIdsArray.put(therapyTypesArray.getJSONObject(i).get("therapyType"));
			}
			query = String.format(SqlQueries.GetTherapyTypeNotIn.toString(),therapyTypeIdsArray.join(",")).replaceAll("\"", "");
			System.out.println(query);
			therapyType = MiscTools.executeSingleSelect(env, query);
		} catch (SQLException | JSONException e) {
			e.printStackTrace();System.out.println(e.getMessage());
		}
		//System.out.println(therapyType);
		return therapyType;
	}

	public static Map<String, String> getCaregiverInventoryNotAdded(String sb, String rxId,String refill, String env) throws SQLException{
		Map<String, String> inventory;
		String empty = null, invId, lot;
		do{
			inventory = MiscTools.executeSingleRowSelect(env, String.format(SqlQueries.GetCgInventory2.toString(), sb,rxId,sb));
			invId = inventory.get("inventoryId");
			lot =  inventory.get("lot");
			empty = executeSingleSelect(env, String.format(SqlQueries.CaregiverWithInvExists.toString(),sb, rxId, refill, invId, lot ));
		}while(empty.isEmpty() == false);
		return inventory;
	}
	
	public static Map<String, String> getNonCompInv(String sb, String rxId,String refill, String env) throws SQLException{
		Map<String, String> inventory;
		String empty = null, invId, lot;
		String locType, locId, therapy;
		//do{
		Map<String, String> 
		location = MiscTools.executeSingleRowSelect(env, String.format(SqlQueries.GetRxLocAndTherapy.toString(), sb,rxId,refill));
		locType = location.get("locType");
		locId = location.get("locId");
		therapy = location.get("therapy");
		System.out.println(String.format(SqlQueries.GetNonCompInventory2.toString(),sb,locType,locId,therapy));
		inventory = MiscTools.executeSingleRowSelect(env, String.format(SqlQueries.GetNonCompInventory.toString(),therapy,sb,locType,locId));
			
//		invId = inventory.get("inventoryId");
//		lot =  inventory.get("lot");
//			empty = executeSingleSelect(env, String.format(SqlQueries.NonCompInvAdded.toString(),sb, rxId, refill, invId, lot ));
//		}while(empty.isEmpty() == false);
//		
		System.out.println(inventory);
		return inventory;
	}
	
	public static Map<String, String> getNonCompInv(String sb, String therapy, String env) throws SQLException{
		Map<String, String> inventory;
		//do{
		String ther = MiscTools.executeSingleSelect(env, String.format(SqlQueries.GetTherapyLike.toString(), therapy));
		System.out.println(ther);
		System.out.println( String.format(SqlQueries.GetNonCompInventory.toString(),therapy,sb,sb,"S"));
		inventory = MiscTools.executeSingleRowSelect(env, String.format(SqlQueries.GetNonCompInventory.toString(),ther,sb,"S",sb));
			
//		invId = inventory.get("inventoryId");
//		lot =  inventory.get("lot");
//			empty = executeSingleSelect(env, String.format(SqlQueries.NonCompInvAdded.toString(),sb, rxId, refill, invId, lot ));
//		}while(empty.isEmpty() == false);
//		
		System.out.println(inventory);
		return inventory;
	}

	public static Map<String, String> getSupplyInventoryNotAdded(String sb, String rxId,String refill, String env) throws SQLException{
		Map<String, String> inventory;
		String empty = null, invId, lot;
		do{
			inventory = MiscTools.executeSingleRowSelect(env, String.format(SqlQueries.GetSupplyInventory.toString(), sb));
			invId = inventory.get("inventoryId");
			lot =  inventory.get("lot");
			empty = executeSingleSelect(env, String.format(SqlQueries.SupplyWithInvExists.toString(),sb, rxId, refill, invId, lot ));
		}while(empty.isEmpty() == false);
		return inventory;
	}

	public static JSONObject updateCreateSupplyRequestWithRx(Map<String, String> prescription, JSONObject supplyInfo, String env){
		String sb = prescription.get("sb"),rxId = prescription.get("rxId"),refill = prescription.get("refill"), invId, lot;
		Map<String, String> inventory;
		System.out.println(prescription);
		try {
			supplyInfo.put("processingPharmacy",Integer.parseInt(sb));
			supplyInfo.put("rxNumber",Integer.parseInt(rxId));
			supplyInfo.put("fillNumber",Integer.parseInt(refill));
			inventory = getSupplyInventoryNotAdded(sb,rxId,refill,env);
			invId = inventory.get("inventoryId");
			lot =  inventory.get("lot");
			supplyInfo.put("itemReference", Integer.parseInt(invId));
			supplyInfo.put("lot", lot);
		} catch (JSONException | SQLException e) {
			System.out.println("Something went wrong refreshing supply request");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return supplyInfo;
	}
	
	public static JSONObject supplyRequestUpdate(Map<String, String> prescription, JSONObject supplyInfo, String env){
		String sb = prescription.get("sb"),rxId = prescription.get("rxId"),refill = prescription.get("refill"),
				invId = prescription.get("inventoryId"), lot = prescription.get("lot"), qty = prescription.get("qty"),
				uniqId = prescription.get("uniqId");
		try {
			supplyInfo.put("processingPharmacy",Integer.parseInt(sb));
			supplyInfo.put("rxNumber",Integer.parseInt(rxId));
			supplyInfo.put("fillNumber",Integer.parseInt(refill));
			supplyInfo.put("itemReference", Integer.parseInt(invId));
			supplyInfo.put("lot", lot);
			supplyInfo.put("quantityPer", 1);
			supplyInfo.put("noDays", 1);
			supplyInfo.put("uniqueId", uniqId);
			supplyInfo.put("quantity", Integer.parseInt(qty)+1);
		} catch (JSONException e) {
			System.out.println("Something went wrong refreshing supply request");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return supplyInfo;
	}
	
	public static JSONObject updateCreateCgRequestWithRx(Map<String, String> prescription, JSONObject caregiverInfo, String env){
		String sb = prescription.get("sb"),rxId = prescription.get("rxId"),refill = prescription.get("refill"), invId, lot, rxDrug, strength, strengthUnits, ndc, qtyUnits;
		Map<String, String> inventory;
		try {
			caregiverInfo.put("processingPharmacy",Integer.parseInt(sb));
			caregiverInfo.put("rxNumber",Integer.parseInt(rxId));
			caregiverInfo.put("fillNumber",Integer.parseInt(refill));
//			System.out.println(String.format(SqlQueries.GetCgInventory2.toString(), sb,rxId, sb));
//			inventory = MiscTools.executeSingleRowSelect(env, String.format(SqlQueries.GetCgInventory.toString(), sb,rxId, sb));
			inventory = getCaregiverInventoryNotAdded(sb,rxId,refill,env);
			//inventory = MiscTools.executeSingleRowSelect(env, String.format(SqlQueries.GetCgInventory2.toString(), sb,rxId, sb));
			rxDrug = inventory.get("rxDrug");invId = inventory.get("inventoryId");lot =  inventory.get("lot");qtyUnits= inventory.get("quantityUnits");
			strength = inventory.get("strength");strengthUnits = inventory.get("strengthUnits");ndc = inventory.get("ndc");
			String dosageUnit = executeSingleSelect(env, String.format(SqlQueries.GetInvUnit.toString(),rxDrug));
			String drugRoute = executeSingleSelect(env,SqlQueries.GetDrugRoute.toString());
			caregiverInfo.put("drugRoute", drugRoute);
			int dosage = getRandomInt(1,3);
			caregiverInfo.put("dosage", dosage);
			caregiverInfo.put("volume", dosage);
			caregiverInfo.put("dosage_unit", dosageUnit);
			caregiverInfo.put("quantityUnits", qtyUnits);
			caregiverInfo.put("volumeUnit", dosageUnit);
			caregiverInfo.put("quantity", getRandomInt(1,3));
			caregiverInfo.put("itemReference", Integer.parseInt(invId));
			caregiverInfo.put("name", rxDrug);
			caregiverInfo.put("lot", lot);
			caregiverInfo.put("strength", strength == null?JSONObject.NULL: Double.parseDouble(strength));
			caregiverInfo.put("strengthUnits", strengthUnits == null?JSONObject.NULL:strengthUnits);
			caregiverInfo.put("ndc", ndc);
			String freqUnit = executeSingleSelect(env, SqlQueries.GetFreqUnit.toString());
			caregiverInfo.put(freqUnit,getRandomInt(1,3));
			caregiverInfo.put("labelsPrintNumber", getRandomInt(1,3));
			String frequency = executeSingleSelect(env,SqlQueries.GetFrequency.toString());
			caregiverInfo.put("doseFrequency", frequency);
		} catch (JSONException | SQLException e) {
			System.out.println("Something went wrong refreshing supply request");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return caregiverInfo;
	}

	public static JSONObject updateInvItemRequest(Map<String, String> prescription, JSONObject itemInfo, String env, String by){
		String sb = prescription.get("sb"),rxId = prescription.get("rxId"),refill = prescription.get("refill"), invId, lot, rxDrug, strength, strengthUnits, ndc, qtyUnits;
		Map<String, String> inventory;
		try {
			itemInfo.put("processingPharmacy",Integer.parseInt(sb));
			itemInfo.put("fillNumber",Integer.parseInt(refill));
			
			
			inventory = getNonCompInv(sb,rxId,refill,env);
			rxDrug = inventory.get("rxDrug");invId = inventory.get("inventoryId");lot =  inventory.get("lot");qtyUnits= inventory.get("quantityUnits");
			strength = inventory.get("strength");strengthUnits = inventory.get("strengthUnits");ndc = inventory.get("ndc");
			String dosageUnit = executeSingleSelect(env, String.format(SqlQueries.GetInvUnit.toString(),rxDrug));
			String drugRoute = executeSingleSelect(env,SqlQueries.GetDrugRoute.toString());
			itemInfo.put("drugRoute", drugRoute);
			int dosage = getRandomInt(1,3);
			itemInfo.put("dosage", dosage);
			itemInfo.put("dosage_unit", dosageUnit);
			itemInfo.put("quantityUnits", qtyUnits);
			itemInfo.put("quantity", getRandomInt(1,3));
			itemInfo.put("name", rxDrug);
			if(by.equals("Ndc")){itemInfo.put("ndc", ndc);}else{itemInfo.put("itemReference", invId);}
			//itemInfo.put("lot", lot);
			itemInfo.put("strength", strength == null?JSONObject.NULL: Double.parseDouble(strength));
			itemInfo.put("strengthUnits", strengthUnits == null?JSONObject.NULL:strengthUnits);
			itemInfo.put("labelsPrintNumber", getRandomInt(1,3));

		} catch (JSONException | SQLException e) {
			System.out.println("Something went wrong refreshing supply request");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return itemInfo;
	}

	public static int getMaxRefill(String sb,String rxId,String env){
		String refill = "";
		try {
			refill = executeSingleSelect(env, String.format(SqlQueries.GetMaxRefill.toString(), sb, rxId));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Integer.parseInt(refill);
	}
	public static MediaType getContentType(String contentType){
		MediaType mediaType = null;
		if(contentType.equals("application/json")){
			mediaType = MediaType.APPLICATION_JSON;
		}
		return mediaType;
	}
	public static JSONObject getNewFillValues(Map<String, String> prescription, String env){
		String sb = prescription.get("sb"), rxId = prescription.get("rxId"), refill = prescription.get("refill");
		JSONObject fill = new JSONObject();
		try {
			String query = String.format(prescriptionSqlQueries.GetUpdateFillBaseInfo.toString(),sb,rxId,refill);
			fill =  MiscTools.executeSingleSelectJson(env, query);
			query = String.format(prescriptionSqlQueries.GetUpdateFillInfo.toString(),sb,rxId,refill);
			JSONObject fillValues =  MiscTools.executeSingleSelectJson(env, query);
			if (fillValues.get("shipDate").equals("1000-01-01")){
				fillValues.put("shipDate", addDaysToDate(fillValues.getString("writtenDate"), -1)); //getTodayDate("yyyy-MM-dd"));
				fillValues.put("fillDate", addDaysToDate(fillValues.getString("writtenDate"), -1));//getTodayDate("yyyy-MM-dd"));
				fillValues.put("rx_start_date", addDaysToDate(fillValues.getString("writtenDate"), -1));//getTodayDate("yyyy-MM-dd"));
			}
			//fillValues.put("notes", getRandomString(5));
			System.out.println(fillValues);
			fillValues.remove("writtenDate");
			fill.put("fill", fillValues);
			fill.put("processingUsers", new JSONObject());
		} catch (JSONException | SQLException e) {
			e.printStackTrace();
		}
		return fill;
	}

	public static JSONObject getRxUpdatableFields(Map<String, String> prescription, String env) throws SQLException{
		String sb = prescription.get("sb"), rxId = prescription.get("rxId"), refill = prescription.get("refill");
		String query = String.format(prescriptionSqlQueries.GetRxUpdatableFields.toString(),sb,rxId,refill);
		return MiscTools.executeSingleSelectJson(env, query);
	}
	
	public static String getRxPostApiPathFromFill(String rxId, String refill){
		String apiPath;
		if(Integer.parseInt(refill) == 0){
			apiPath = String.format(ApiPaths.PRESCRIBED_ITEMS,rxId);
		}else{
			apiPath = String.format(ApiPaths.DISPENSED_ITEMS,rxId,refill);
		}
		
		return apiPath;
	}

	public static String getRxPutApiPathFromFill(String rxId, String refill, String itemReference){
		String apiPath;
		if(Integer.parseInt(refill) == 0){
			apiPath = String.format(ApiPaths.PRESCRIBED_ITEMS,rxId);
		}else{
			apiPath = String.format(ApiPaths.DISPENSED_ITEMS,rxId,refill);
		}
		
		return apiPath+itemReference;
	}
	
	public static String getOldRxApiPathFromFill(String refill){
		String apiPath;
		if(Integer.parseInt(refill) == 0){
			apiPath = ApiPaths.OLD_PRESCRIBED_ITEMS;
		}else{
			apiPath = ApiPaths.OLD_DISPENSED_ITEMS;
		}
		
		return apiPath;
	}
	
	public static String getOldRxPutApiPathFromFill(Map<String, String> prescription, String itemReference, String itemType, String lot){
		String apiPath;
		String sb = prescription.get("sb"), rxId = prescription.get("rxId"), refill = prescription.get("refill");
		if(Integer.parseInt(refill) == 0){
			apiPath = String.format("/v1/prescriptions/%s/%s/prescribedItems/%s/%s/%s",rxId,sb,itemReference, itemType, lot);
		}else{
			apiPath = String.format("/v1/prescriptions/fills/%s/%s/%s/dispensedItems/%s/%s/%s",rxId,sb,refill,itemReference, itemType, lot);
		}
		return apiPath+itemReference;
	}
	
	public static JSONObject putInvalidPhoneFormat(JSONObject requestBodyJson ) throws JSONException{
		if(requestBodyJson.has("trcPhone")){
			requestBodyJson.put("trcPhone",MiscTools.getNumericRandomString(3)+"-"+MiscTools.getNumericRandomString(3));
		}else{
			requestBodyJson.put("phoneNumber",MiscTools.getNumericRandomString(3)+"-"+MiscTools.getNumericRandomString(3));
		}
		return requestBodyJson;
	}
	public static JSONArray removeFromRequest(String field, JSONArray requestBodyArray) throws JSONException{
		JSONObject temp;	
		for (int i = 0; i<requestBodyArray.length(); i++){
			temp = requestBodyArray.getJSONObject(i);
			temp = JsonTools.deleteKey(temp, field);
			//if(temp.has(field))temp.remove(field);
		}
		return requestBodyArray;
	}
	
	public static boolean prescriptionGuidExists(String legacySb, String legacyRxId, String responseBody) throws JSONException{
		JSONArray arrayResponseBody = new JSONArray(responseBody); 
		JSONObject jsonResponseBody = arrayResponseBody.getJSONObject(0);
		String sb = jsonResponseBody.getString("legacyFulfillmentPhcyId");
		String rxId = jsonResponseBody.getString("legacyRxId");
		String rxGuid = jsonResponseBody.getString("rxId");
		if (legacySb.equals(sb) && legacyRxId.equals(rxId) && rxGuid != "" ){
			return true;
		}else{
			return false;
		}
	}
	
	public static boolean isJsonValid(String jsonString){
		try {
			new JSONObject(jsonString);
		} catch (JSONException ex) {      
			return false;
		}
		return true;
	}
	
	public static boolean isJsonArrayValid(String jsonString){
		try {
			new JSONArray(jsonString);
		} catch (JSONException ex) {      
			return false;
		}
		return true;
	}
	public static String getPersonGuid(String rxId, String env){
		String apiPath = ApiPaths.PRESCRIPTION_MySQL+rxId;
		ApiToolsV2 oauthServiceApi = new ApiToolsV2("Prescription", env);
		ResponseEntity<String> oaResponse = oauthServiceApi.retrive(apiPath);
		String responseBody = oaResponse.getBody();
		String personGuid = "";
		try {
			JSONArray responseBodyArray = new JSONArray(responseBody);
			JSONObject responseBodyJson = responseBodyArray.getJSONObject(0);
			if(responseBodyJson.has("personGUID")){
				personGuid = responseBodyJson.getString("personGUID");
			}else{
				personGuid = "";
			}
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return personGuid;
	}
	public static boolean responseHasKey(String key, String responseBody) throws JSONException{
		JSONObject jsonResponse;
		if(isJsonArrayValid(responseBody)){
			JSONArray arrayResponse = new JSONArray(responseBody);
			jsonResponse = arrayResponse.getJSONObject(0);
		}else{
			jsonResponse = new JSONObject(responseBody);
		}
		return JsonTools.hasKey(jsonResponse, key);
	}
	public static JSONObject getInvalidByRxOriginCode(String field, String env) throws Exception {
		JSONObject rxOriginCode = MiscTools.executeSingleSelectJson(env, SqlQueries.GetRxOrignCode.toString());
		if(field.equals("name")){
			rxOriginCode.put("name", MiscTools.getRandomString(6));
		}else{
			rxOriginCode.put("code", MiscTools.getRandomInt(6, 10));
		}
		return rxOriginCode;
	}
	public static JSONObject getNotMachingRxOriginCode(String env) throws Exception {
		JSONObject rxOriginCode = MiscTools.executeSingleSelectJson(env, SqlQueries.GetRxOrignCode.toString());
		String code = rxOriginCode.getString("code");
		String query = String.format(SqlQueries.GetRxOriginCodeNotMatchingName.toString(),code);
		String name  =  MiscTools.executeSingleSelect(env, query);
		rxOriginCode.put("name", name);
		return rxOriginCode;
	}
	public static String getExpectedSb(String sb, String patientId, String env) throws Exception {
		String expectedSb = "";
		if(sb.equals("")||sb.equals("null")) {
			String query = String.format(prescriptionSqlQueries.GetPatientOldSb.toString(),patientId);
			expectedSb = executeSingleSelect(env, query);
			if(expectedSb.equals(""))expectedSb = "555"; 
		}else{
			expectedSb = sb;
		}
		
		return expectedSb;
	}
}
