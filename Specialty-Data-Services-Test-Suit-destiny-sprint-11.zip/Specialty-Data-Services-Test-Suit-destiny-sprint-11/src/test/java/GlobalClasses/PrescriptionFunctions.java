package GlobalClasses;

//import org.json.JSONArray;
//import org.json.JSONException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;

public class PrescriptionFunctions {
	private static String query;
	
	public static JSONObject rxRenewalInformation(String sb, String rxId, String refill,String env) throws Exception{
		JSONObject renewalInformation = new JSONObject();
		String renewalIndicator;
		Map<String, String> oldPrescription, attributes;
		query = String.format(prescriptionSqlQueries.IsPrescriptionRenewal.toString(),sb,rxId,refill);
		renewalIndicator = MiscTools.executeSingleSelect(env, query);
		renewalInformation.put("renewalIndicator",renewalIndicator);
		query = String.format(prescriptionSqlQueries.GetOldRenewalRx.toString(),sb,rxId,refill);
		oldPrescription = MiscTools.executeSingleRowSelect(env, query);
		if(oldPrescription.isEmpty()){
			renewalInformation.put("priorProcessingPharmacy",JSONObject.NULL);
			renewalInformation.put("priorRxNumber",JSONObject.NULL);
			renewalInformation.put("priorFillNumber",JSONObject.NULL);
		}else{
			renewalInformation.put("priorProcessingPharmacy", oldPrescription.get("sb"));
			renewalInformation.put("priorRxNumber", oldPrescription.get("rxId"));
			renewalInformation.put("priorFillNumber", oldPrescription.get("refill"));
		}
		query = String.format(prescriptionSqlQueries.GetRenewalAttributes.toString(),sb,rxId,refill);
		attributes = MiscTools.executeSingleRowSelect(env, query);
		renewalInformation.put("renewalReminderDate", attributes.get("reminderDate")==null?JSONObject.NULL: attributes.get("reminderDate"));
		renewalInformation.put("autoRenewIndicator", attributes.get("autoFax")==null?JSONObject.NULL: attributes.get("autoFax"));

		return renewalInformation;
	}
	
	public static Object getRxTransferInformation(Map<String, String> transferInformation, Map<String, String> rx, Map<String, String> transferToRx, String env) throws Exception{
		String sb = rx.get("sb"), rxId =rx.get("rxId"),refill = rx.get("refill");
		String tSb = transferInformation.get("tSb"), tRxId = transferInformation.get("tRxId"),tRefill = transferInformation.get("tRefill");
		String tDate = transferInformation.get("creationDate"), tFlag = transferInformation.get("transferFlag"), tUser = transferInformation.get("transferUser");

		if ((tFlag.equals("T") && tSb != sb && tSb != "null")||(!transferToRx.isEmpty())){
			JSONObject transferInfo =  new JSONObject();
			transferInfo.put("transferFromPharmacy", tSb.equals("null")?JSONObject.NULL:Integer.parseInt(tSb));
			transferInfo.put("transferFromRx",tRxId.equals("null")?JSONObject.NULL:Integer.parseInt(tRxId));
			transferInfo.put("transferFromFill",tRefill.equals("null")?JSONObject.NULL:Integer.parseInt(tRefill));
			 if(transferToRx.isEmpty()){
				 transferInfo.put("transferToPharmacy",JSONObject.NULL);
				 transferInfo.put("transferToRx",JSONObject.NULL);
				 transferInfo.put("transferToFill",JSONObject.NULL);
			 }else{
				 transferInfo.put("transferToPharmacy",Integer.parseInt(transferToRx.get("sb")));
				 transferInfo.put("transferToRx",Integer.parseInt(transferToRx.get("rxId")));
				 transferInfo.put("transferToFill",Integer.parseInt(transferToRx.get("refill")));
			 }
			if(tFlag.equals("T")){
				transferInfo.put("transferDate",tDate);
				transferInfo.put("transferUser",tUser);
			}else{
				transferInfo.put("transferDate",JSONObject.NULL);
				transferInfo.put("transferUser",JSONObject.NULL);
			}
			return transferInfo;
		}else {
			return JSONObject.NULL;
		}
		}
	public static Object getRxReceivedDate(String sb,String rxId,String refill, String env) throws SQLException{
		String query, receivedDate = "";
		query = String.format(prescriptionSqlQueries.IsIntegrated.toString(),sb, rxId,refill);
		String invno = MiscTools.executeSingleSelect(env,query);
		if(invno.isEmpty()){
			query = String.format(SqlQueries.GetDirectReceivedDate.toString(),sb, rxId,refill);
			receivedDate = MiscTools.executeSingleSelect(env,query);
		}else{
			query = String.format(SqlQueries.GetIntegratedReceivedDate.toString(),sb, rxId,refill);
			receivedDate = MiscTools.executeSingleSelect(env,query);
		}
		if(receivedDate == null){return JSONObject.NULL;}else{ return receivedDate;}	
	}

	public static JSONArray getRxImage(String sb, String rxId, String env) throws Exception{
		JSONArray images = new JSONArray();
		JSONObject documentIdJson = new JSONObject(); 
		query = String.format(prescriptionSqlQueries.GetRxImage.toString(),sb, rxId);
		System.out.println(query);
		String documentId = MiscTools.executeSingleSelect(env,query);
		documentIdJson.put("documentReference",documentId.equals("")?JSONObject.NULL:documentId);
		images.put(documentIdJson);
		return images;
	}

	public static JSONArray getRxPrescribedItems(String sb, String rxId, String env) throws Exception{
		JSONArray itemsArray = new JSONArray();
		List<JSONObject> items = MiscTools.executeMultipleRowSelectJson(env, String.format(prescriptionSqlQueries.GetRxPrescribedItems.toString(),sb,rxId));
		for( int i = 0; i < items.size(); i++){
			JSONObject temp = items.get(i);
			temp.put("dosageAmount", temp.getString("dosageAmount").equals("null")?JSONObject.NULL:temp.getString("dosageAmount"));
			temp.put("itemReference", temp.getString("itemReference").equals("null")?JSONObject.NULL:temp.getString("itemReference"));
			temp.put("quantity",temp.getString("quantity").equals("null")?JSONObject.NULL:temp.getString("quantity"));
			String strength = temp.getString("strength"); String dosageAmount = temp.getString("dosageAmount");
			strength = strength.replaceAll("0\\.", "."); dosageAmount = dosageAmount.replaceAll("0\\.", ".");
			temp.put("dosageAmount",  dosageAmount.equals("null")?JSONObject.NULL: dosageAmount);
			temp.put("strength",  strength.equals("null")?JSONObject.NULL: strength);
			itemsArray.put(temp);
		}
		return itemsArray;
	}
	
	public static JSONObject getRxAutoRefillIndicator(Object autoRefillIndicatorFlag) throws JSONException{
		 JSONObject autoRefillIndicator = new JSONObject();
		 autoRefillIndicator.put("earliestRefillEnrollmentDate",JSONObject.NULL);
		 autoRefillIndicator.put("autoRefillEligibleIndicator",JSONObject.NULL);
		 autoRefillIndicator.put("autoRefillIndicator", autoRefillIndicatorFlag);
		 autoRefillIndicator.put("latestRefillEnrollmentDate",JSONObject.NULL);
		 
		 return autoRefillIndicator;
	}

	public static Object getSubstitution(String sb, String rxId, String refill,String env) throws Exception{
		 JSONObject susbtitution = new JSONObject();
		 query =  String.format(prescriptionSqlQueries.GetSusbtitutionInfo.toString(),sb,rxId,refill);
		 
		 Map<String, String> subsDetails =  MiscTools.executeSingleRowSelect(env,query);
		 if(subsDetails.isEmpty()){
			 return JSONObject.NULL;
		 }else{
			 String user = subsDetails.get("subsUser");
			 susbtitution.put("substitutionType",subsDetails.get("subsType"));
			 susbtitution.put("substitutedUser",user==null?JSONObject.NULL:user);
			 susbtitution.put("prescribedItem",subsDetails.get("presItem"));
			 susbtitution.put("substitutedItem",subsDetails.get("subsItem"));
			 susbtitution.put("dateTime",subsDetails.get("dateTime"));
			 return susbtitution;
		 }
		
	}

	public static Object getRxSourceChanel(String sourceName, String rxOriginCode) throws JSONException{
		if (sourceName.equals("null")){
			return JSONObject.NULL; 
		 }else{
			JSONObject sourceChanel = new JSONObject();
			sourceChanel.put("sourceName",sourceName);
			sourceChanel.put("rxOriginCode", rxOriginCode.equals("null")?JSONObject.NULL:rxOriginCode);
			return sourceChanel;
		 }
	}
	public static JSONArray getRxFills(String sb, String rxId, String refillFilter, String env) throws Exception{
	    String query = String.format(prescriptionSqlQueries.GetRxFillsWithoutRange.toString(),sb,rxId,refillFilter);
	    List<JSONObject> fills = MiscTools.executeMultipleRowSelectJson(env, query);
	    JSONArray fillsArray = new JSONArray();
	    JSONObject fill = new JSONObject();
	    for( int j = 0; j < fills.size(); j++){
	    	fill = fills.get(j);
	    	fill.put("processingPharmacy", fill.getString("processingPharmacy"));
	    	fill.put("fillingPharmacy", fill.getString("fillingPharmacy"));
	    	fill.put("provisionalFillIndicator", false);
	    	if (fill.get("scheduledFillDate") == null && fill.get("fillReminderDate")== null){
	    		fill.put("scheduledFills", JSONObject.NULL);
			}else{
				fill.put("scheduledFills", getFillScheduledFills(fill.get("scheduledFillDate"), fill.get("fillReminderDate")));
			}
	    	fill.remove("scheduledFillDate");
	    	fill.remove("fillReminderDate");
	    	fill.put("processingUsers", getFillProcessingUsers(sb,rxId,refillFilter,env));
	    	
			fill.put("dispensedItems", getFillDispensedItems(sb, rxId, fill.getString("fillNumber"), refillFilter, env) );

			fill.put("statusHistory",getFillStatusHistory(fill.get("timestamp"), fill.get("comments"))); 

			fill.remove("timestamp");
			fill.remove("comments");

			fill.put("orderScheduling", getFillOrderScheduling(fill.get("needByDate"),fill.get("needByDateReasonCode"), fill.get("scheduledAddressReference"),
					 fill.get("needByDateConfirmation")));
			fill.remove("needByDateReasonCode");
			fill.remove("scheduledAddressReference");
			fill.remove("needByDateConfirmation");
			fill.remove("needByDate");
	    	
	    	fillsArray.put(fill);
	    }
	    //System.out.println(fillsArray);
	    return fillsArray;
	}

	public static JSONArray getFillScheduledFills(Object scheduledFillDate, Object fillReminderDate ) throws JSONException{
		JSONArray scheduledFills = new JSONArray(); 
		JSONObject scheduledFill= new JSONObject();
		scheduledFill.put("fillReference",JSONObject.NULL);
		scheduledFill.put("latestFillDate",JSONObject.NULL);
		scheduledFill.put("earliestFillDate",JSONObject.NULL);
		scheduledFill.put("scheduledFillDate", scheduledFillDate);
		scheduledFill.put("fillReminderDate",fillReminderDate);
		scheduledFills.put( scheduledFill);
		return  scheduledFills;
	}

	public static JSONArray getFillDispensedItems(String sb, String rxId, String refill, String refillFilter,String env) throws Exception{
		JSONArray itemsArray = new JSONArray();
		String prescribedItemsFilter;
		if(!refill.equals("0")){
			if(refillFilter.equals("")){
				prescribedItemsFilter = DefaultValues.Not0Filter.toString();
			}else{
				prescribedItemsFilter = refillFilter;
			}	
			List<JSONObject> items = MiscTools.executeMultipleRowSelectJson(env, String.format(prescriptionSqlQueries.GetRxDispensedItems.toString(),sb,rxId,prescribedItemsFilter));
			System.out.println(items.size());
			for( int i = 0; i < items.size(); i++){
				JSONObject temp = items.get(i);
				String dosageAmount = temp.getString("dosageAmount");
				temp.put("dosageAmount", dosageAmount.equals("null")?JSONObject.NULL:dosageAmount.replaceAll("0\\.", "."));
				String itemReference = temp.getString("itemReference");
				temp.put("itemReference", itemReference.equals("null")?JSONObject.NULL:itemReference);
				temp.put("quantity",temp.getString("quantity"));
				String strength = temp.getString("strength");
				temp.put("strength", strength.equals("null")?JSONObject.NULL:strength.replaceAll("0\\.", "."));
				itemsArray.put(temp);
			}	
		}
		return itemsArray;
	}

	public static JSONArray getFillStatusHistory(Object timestamp, Object comments ) throws JSONException{
		JSONArray statusHistorys = new JSONArray(); 
		JSONObject statusHistory= new JSONObject();
		statusHistory.put("timestamp", timestamp );
		statusHistory.put("value",JSONObject.NULL);
		statusHistory.put("localId",JSONObject.NULL);
		statusHistory.put("comments",comments);
		statusHistorys.put( statusHistory);
		if(statusHistorys.length() == 0) { System.out.println("entro");statusHistorys = new JSONArray(DefaultValues.StatusHistoryEmpty.toString());}
		return  statusHistorys;
	}

	public static JSONArray getFillOrderScheduling(Object needByDate, Object needByDateReasonCode, Object scheduledAddressReference,Object needByDateConfirmation) throws JSONException{
		JSONArray orderSchedulings = new JSONArray(); 
		JSONObject orderScheduling= new JSONObject();
		orderScheduling.put("needByDateReasonCode", needByDateReasonCode);
		orderScheduling.put("scheduledAddressReference", scheduledAddressReference);
		orderScheduling.put("needByDateConfirmation",needByDateConfirmation);
		orderScheduling.put("needByDate", needByDate);
		orderSchedulings.put(orderScheduling);
		return  orderSchedulings;
	}

	public static JSONArray getFillProcessingUsers(String sb, String rxId, String refillFilter, String env) throws Exception{
		String query = String.format(prescriptionSqlQueries.GetProcessingUsers.toString(),sb,rxId,refillFilter);
		JSONArray processingUsers = MiscTools.executeMultipleRowSelectArray(env, query);
		if(processingUsers.length()==0) processingUsers = new JSONArray(DefaultValues.ProcessigUserEmpty.toString());
		//if(processingUsers.length()==2) processingUsers = JsonTools.deleteUser(processingUsers,"ProcessingPharmacist");
		return processingUsers;
	}

	public static JSONObject cleanPrescriptionInfo(JSONObject prescription){
		prescription.remove("autoRefillIndicator");
		prescription.remove("creationDate");
		prescription.remove("transferFlag");
		prescription.remove("cProcessingPharmacy");
		prescription.remove("cRxNumber");
	    prescription.remove("cFillNumber");
	    prescription.remove("transferUser");
	    prescription.remove("rxOriginCode");
	    prescription.remove("sourceName");

		return prescription;
	}
}
