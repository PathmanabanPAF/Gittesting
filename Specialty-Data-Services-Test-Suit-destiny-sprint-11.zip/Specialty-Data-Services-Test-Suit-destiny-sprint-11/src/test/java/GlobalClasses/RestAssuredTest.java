//package GlobalClasses;
//import io.restassured.RestAssured;
//import io.restassured.authentication.OAuthSignature;
//import io.restassured.http.Header;
//import io.restassured.response.Response;
//
//import org.junit.Before;
//import org.junit.Test;
//import org.springframework.http.HttpMethod;
//
//import java.io.UnsupportedEncodingException;
//import java.net.URI;
//
//import static io.restassured.RestAssured.given;
//import static org.hamcrest.Matchers.equalTo;
//
//public class RestAssuredTest {
//
//    public String contentType, signature, token;
//    public String gatewayUri;
//    private static Header header;
//    private static Response response;
//    private static API payerapi;
//    public OAuthHeader oAuthHeader;
//
//    @Before
//    public void setup(){
//        SSLCertificateValidation.disable();
//        RestAssured.useRelaxedHTTPSValidation();
//        RestAssured.baseURI = "";
//
//        this.contentType = "application/json";
//
//        this.gatewayUri = RestAssured.baseURI;
//        payerapi = new API(
//        		"https://api-qa.express-scripts.io/v1/auth/oauth/requestTokens",
//            "https://api-qa.express-scripts.io/v1/auth/oauth/accessTokens",
//            "1e72920f-8bb0-6e60-85b5-6a90448fa3f2",
//                "2HeOn9Mo/xNOAwiFvDUSVq/naB4=");
//         
//        try {
//            this.header = new Header("Authorization",MiscTools.getOauthHeader(payerapi));
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        }
//
//    }
//
//
//    @Test
//    public void pocTest(){
//        SSLCertificateValidation.disable();
//
//        get("https://api-qa.express-scripts.io/v1/payers/1578").
//                then().
//                assertThat().
//                body("id", equalTo("1578"));
//    }
//    private String getOauthHeader( API payerAPI) throws UnsupportedEncodingException {
//        oAuthHeader= new OAuthHeader(payerAPI.oauthConsumerRequestTokenURL
//                , payerAPI.oauthConsumerAccessTokenURL
//                , payerAPI.oauthConsumerConsumerKey
//                , payerAPI.oauthConsumerConsumerSecret);
//        String auth = oAuthHeader.getAuthHeader(HttpMethod.GET.toString(), URI.create(RestAssured.baseURI));
//        String[] words = auth.split("\\,");
//        String[] signatureA = words[2].split("\\=");
//        String[] tokenA = words[5].split("\\=");
//    
//        signature = signatureA[1].replace("\"","");
//        token = tokenA[1].replace("\"","");
//        System.out.println(auth);
//         return auth;
//     
//        }
//
//    public Response get(String apiPath) {
////    	auth().oauth("1e72920f-8bb0-6e60-85b5-6a90448fa3f2",
////                "2HeOn9Mo/xNOAwiFvDUSVq/naB4=",token, signature).
////        header("Authorization","oauth_signature_method=\"HMAC-SHA256\"").
//    		
//        response = given().
//        		header(header).
//                contentType(contentType).
//                when().
//                get(apiPath);
//        System.out.println(response.getBody());
//        return response;
//    }
//
//
//
//}
