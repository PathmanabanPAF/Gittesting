package GlobalClasses;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import GlobalEnums.DefaultValues;
import GlobalEnums.SqlQueries;
import GlobalEnums.prescriptionSqlQueries;

public class GetResponses {
	
	/**
	 * Used to build a json with values from db to compare with a manufacturer get response
	 * @param id
	 * @param env
	 * @return
	 */
	public static String createManufacturerRespose(String id, String env){
		String manufacturerQuery = "select id as \"id\", name as \"name\",comments as \"manufacturerComment\","+
				" invoicer as \"invoicerId\", marketing_id as \"marketingId\","+
				" pricing_Id as \"pricingId\",indexer_flag as \"indexerFlag\","+
				" active as \"active\" from manufacturers where id = "+ id;
		String phoneQuery = "select phone_seq as \"phoneSeq\",phone_type as \"phoneType\","+
				" phonea||'-'||phoneb||'-'||phonec as \"phoneNumber\","+
				" phone_ext as \"phoneExtension\" ,phone_comment as \"phoneComment\""+
				" from thot.phones where name_type ='F' and name_id = "+id;
		String addressQuery = "select name as \"addressName\",address_type as \"addressType\",attn as \"attention\","+
				" addr1 as \"addressLine1\",addr2 as \"addressLine2\",city as \"city\",state as \"state\","+
				" zip as \"zipCode\",country as \"country\",comments as \"addressComment\""+
				" from thot.addresses where name_type='F' and name_id ="+id;
		String emptyPhones =  "[{\"phoneSeq\": null,\"phoneType\": null,\"phoneNumber\": \"--\",\"phoneExtension\": null,\"phoneComment\": null}]";
		String emptyAddress = "[{\"addressComment\": null,\"zipCode\": null,\"state\": null,\"addressType\": null,\"addressLine2\": null,\"attention\": null,"+
				"\"addressLine1\": null,\"country\": null,\"city\": null,\"addressName\": null}]";
		JSONObject ManufacturerInfo = null;
		try {
			ManufacturerInfo = MiscTools.executeSingleSelectJson(env, manufacturerQuery );
			List<Map<String, String>> addressList = MiscTools.executeMultipleRowSelect(env, addressQuery);
			JSONArray addressListJsonArray;
			if(addressList.isEmpty()){	
				addressListJsonArray = new JSONArray(emptyAddress);
			}else{
				addressListJsonArray = new JSONArray(addressList);
			}
			List<Map<String, String>> phoneList = MiscTools.executeMultipleRowSelect(env, phoneQuery);
			JSONArray phoneListJsonArray = null;
			if(phoneList.isEmpty()){	
				phoneListJsonArray = new JSONArray(emptyPhones);
			}else{
				phoneListJsonArray = new JSONArray(phoneList);
			}
			ManufacturerInfo.put("address", addressListJsonArray);
			ManufacturerInfo.put("phone", phoneListJsonArray);
			
		} catch (SQLException | JSONException e) {
			e.printStackTrace();
		}
		
		return ManufacturerInfo.toString();		
	}
	
	public static String manufacturerRequestToResponse(String requestBody, String manufacturerId){
		JSONObject responseJson = null;
		try {
			responseJson = new JSONObject(requestBody);
			responseJson.put("id", Integer.parseInt(manufacturerId));
			String comments = responseJson.getString("manufacturerComments");
			responseJson.remove("manufacturerComments");
			responseJson.put("manufacturerComment", comments);
			responseJson.put("active", "Y");
			responseJson.remove("userName");
			if(responseJson.getString("indexerFlag").equals(JSONObject.NULL)){
				responseJson.put("indexerFlag", "N");
			}
			Iterator<?> iter = responseJson.keys();
		    while(iter.hasNext()){
		    	String key = (String)iter.next();	
		    	if (responseJson.get(key).equals(JSONObject.NULL)){
		    		responseJson.put(key, "N");
		    	}
		    }
		    
			//JSONArray jsonArrayAddresses = new JSONArray(responseJson.getJSONArray("addressPostRequest").toString());		
			JSONArray jsonArrayAddresses = new JSONArray(JsonTools.findKeys(responseJson, "addressPostRequest"));
			
			for(int i = 0; i <  jsonArrayAddresses.length(); i++){
				jsonArrayAddresses.getJSONObject(i).remove("userName");
				jsonArrayAddresses.getJSONObject(i).remove("nameType");
				jsonArrayAddresses.getJSONObject(i).remove("addressSeq");
				comments = jsonArrayAddresses.getJSONObject(i).getString("addressComments");
				jsonArrayAddresses.getJSONObject(i).remove("addressComments");
				jsonArrayAddresses.getJSONObject(i).put("addressComment",comments);
				iter = jsonArrayAddresses.getJSONObject(i).keys();
				if(jsonArrayAddresses.getJSONObject(i).getString("addressType").equals("")){
					jsonArrayAddresses.getJSONObject(i).put("addressType", "OFFICE");
				}
				while(iter.hasNext()){
					String key = (String)iter.next();
				    if (jsonArrayAddresses.getJSONObject(i).getString(key).equals("")) {
				    	jsonArrayAddresses.getJSONObject(i).put(key, JSONObject.NULL);
				    }
				}
			} 

			JSONArray jsonArrayPhones = responseJson.getJSONArray("phonePostRequest");			
			for(int i = 0; i < jsonArrayPhones.length(); i++){
				jsonArrayPhones.getJSONObject(i).remove("nameType");
				jsonArrayPhones.getJSONObject(i).remove("nameId");
				jsonArrayPhones.getJSONObject(i).remove("addrSeq");
				jsonArrayPhones.getJSONObject(i).remove("userName");
				if(jsonArrayPhones.getJSONObject(i).getString("phoneType").equals("")){
					jsonArrayPhones.getJSONObject(i).put("phoneType", "OFFICE");
				}
				iter = jsonArrayPhones.getJSONObject(i).keys();
			    while(iter.hasNext()){
			    	String key = (String)iter.next();	
			    	if (jsonArrayPhones.getJSONObject(i).getString(key).equals("")) {
			    		jsonArrayPhones.getJSONObject(i).put(key, JSONObject.NULL);
			    	}
			    }
			}
			
			responseJson.remove("addressPostRequest");
			responseJson.put("address",jsonArrayAddresses);
			responseJson.remove("phonePostRequest");
			responseJson.put("phone",jsonArrayPhones);

		} catch (JSONException e) {
			e.printStackTrace();
		}
		return responseJson.toString();
	}
	
	public static JSONObject trcRequestToResponse(String requestBody){
		JSONObject responseJson =  null;
		try {
			responseJson = new JSONObject(requestBody);
			responseJson.remove("userName");
			if(responseJson.getString("callFrom").equals("")) responseJson.put("callFrom", JSONObject.NULL);
			if(responseJson.getString("callTo").equals("")) responseJson.put("callTo", JSONObject.NULL);
		} catch (JSONException e) {
			e.printStackTrace();
			System.out.println("Exception converting trc request to response");
			System.out.println(e.getMessage());
		}
		return responseJson;
	}
	
	/**
	 * Used to build a json with values from db to compare with a therapy type get response
	 * @param therapyType
	 * @param env
	 * @return
	 */
	public static String createTherapyTypeRespose(String therapyType, String env){
		String therapyTypeQuery = "select therapy_type as \"therapyType\",therapy_descr as \"description\",therapy_class as \"therapyClass\","+
				" rx_hid_days_default as \"hid\", therapy_code as \"therapyCode\",rx_flag as \"prescriptionFlag\","+
				" ncpdp_flag as \"ncpdpFlag\",ansi837_flag as \"ansi837Flag\",exhaust_date_flag as \"exhaustDateFlag\","+
				" days_supply as \"daysSupply\",duration_flag as \"durationFlag\",altern_formula as \"alternFormula\","+
				" rt_flag as \"pharmacyRoutingFlag\",nv_flag as \"nurseVisitFlag\",nv_visit_sell_price as \"nurseVisitVisitPrice\","+
				" nv_hour_sell_price as \"nurseVisitHourPrice\",discard_after as \"discardAfter\",fu_days as \"followUpDays\","+
				" effective_date as \"effectiveDate\",reason_required as \"reasonRequired\",oncology_auth_flag as \"oncologyAuthFlag\","+
				" dsa_default_years as \"dsaDefaultYears\",delay_ord_sched_flag as \"delayOssFlag\",rfl_next_fill_date as \"nextFillDateFlag\","+
				" block_update_rx_dates_flag as \"blockUpdateRxDateFlag\",signature_required as \"signatureRequired\","+
				" rx_ship_po_box_flag as \"prescriptionShipPoBoxFlag\", allow_lot_prior_srs as \"allowLotPriorSrs\""+
				" from therapy_types where therapy_type='"+therapyType+"'";
		String defaultsQuery = "select exhaust_date_default as \"exhaustDate\", ship_date_default as \"shipDate\","+
				" duration_date_default as \"durationDate\", hid_date_default as \"hidDate\", nv_auth_units_flag as \"nurseVisitAuthUnitsFlag\""+
				" from therapy_types where therapy_type = '"+therapyType+"'";
		
		JSONObject therapyTypeInfo = null;
		JSONObject defaults = null;
		try {
			therapyTypeInfo = MiscTools.executeSingleSelectJsonB(env, therapyTypeQuery);
			Map<String, String> defaultsFlags = MiscTools.executeSingleRowSelect(env, defaultsQuery);
			defaults = new JSONObject(DefaultValues.valueOf("duration"+defaultsFlags.get("durationDate")).toString());
			therapyTypeInfo.put("durationDate", defaults);
			defaults = new JSONObject(DefaultValues.valueOf("exhaust"+defaultsFlags.get("exhaustDate")).toString());
			therapyTypeInfo.put("exhaustDate", defaults);
			defaults = new JSONObject(DefaultValues.valueOf("ship"+defaultsFlags.get("shipDate")).toString());
			therapyTypeInfo.put("shipDate", defaults);
			defaults = new JSONObject(DefaultValues.valueOf("hid"+defaultsFlags.get("hidDate")).toString());
			therapyTypeInfo.put("hidDate", defaults);
			defaults = new JSONObject(DefaultValues.valueOf("nurse"+defaultsFlags.get("nurseVisitAuthUnitsFlag")).toString());
			therapyTypeInfo.put("nurseVisitAuthUnitsFlag", defaults);
			therapyTypeInfo.put("uuid", JSONObject.NULL);
		} catch (SQLException | JSONException e) {
			e.printStackTrace();
		}
		return therapyTypeInfo.toString();
	}
	
	public static JSONObject createTrcByIdRespose(String trcId, String env){
		//trc_id as \"trcId\", -----> remove trc from request
		String trcQuery = "select trc_value as \"trcDescription\", city as \"city\", phone_number as \"phoneNumber\","+
				"call_from as \"callFrom\", call_to as \"callTo\" from  pt_trc_phones_hdr where trc_id='"+trcId+"'";
		JSONObject trcInfo = null;
		try {
			trcInfo = MiscTools.executeSingleSelectJson(env, trcQuery );
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return trcInfo;
	}
	
	public static JSONObject createTrcByTTRespose(String trcId, String env){
		String trcQuery = "select therapy_type as \"therapyType\" from PT_TRC_PHONES_DTL where trc_id = '"+trcId+"'";
		JSONObject trcInfo = new JSONObject();
		
		try {
			trcInfo.put("trcId", trcId);
			List<Map<String, String>> TherapyTypeMap = MiscTools.executeMultipleRowSelect(env, trcQuery);
			List<String> TherapyTypeList = new ArrayList<String>();
			for(int i = 0; i < TherapyTypeMap.size(); i++){
				TherapyTypeList.add(TherapyTypeMap.get(i).get("therapyType"));
			}
			trcInfo.put("therapyTypes", TherapyTypeList);
		} catch (SQLException | JSONException e) {
			
			e.printStackTrace();
		}
		return trcInfo;
	}

	public static JSONArray createPrescriptionRespose( Map<String, String> rx, String env){
		String sb = rx.get("sb"), rxId =rx.get("rxId"),refill = rx.get("refill");
		String refillFilter;
		if(refill == null){
			refillFilter = "";
			refill = "";
		}else{
			refillFilter = MiscTools.addRefillFilter(refill);
		}
		List<JSONObject> finalPrescriptionList = new ArrayList<JSONObject>();
		JSONArray prescriptionListJsonArray = null;
		
		try {
			String aux;
			JSONObject temp, tempAux;
			JSONObject prescription = MiscTools.executeSingleSelectJson(env, String.format(prescriptionSqlQueries.GetPrescriptionInfoWithoutRange.toString(),sb,rxId,refillFilter));
			//System.out.println();
			if(prescription.getString("writtenDate") != "null"){
				prescription.put("writtenDate",MiscTools.chageDateFormat3(prescription.getString("writtenDate")));
			}
			
			if(prescription.getString("expirationDate") != "null"){
				prescription.put("expirationDate",MiscTools.chageDateFormat3(prescription.getString("expirationDate")));
			}
			
			
			JSONArray itemsArray = new JSONArray();
			List<JSONObject> items;
			if(refill.equals("0") || refillFilter.equals("")){			
				items = MiscTools.executeMultipleRowSelectJson(env, String.format(prescriptionSqlQueries.GetRxPrescribedItems.toString(),sb,rxId));
				for( int i = 0; i < items.size(); i++){
					temp = items.get(i);
					temp.put("dosageAmount", temp.getString("dosageAmount").equals("null")?JSONObject.NULL:temp.getString("dosageAmount"));
					temp.put("itemReference", temp.getString("itemReference").equals("null")?JSONObject.NULL:temp.getString("itemReference"));
					temp.put("quantity",temp.getString("quantity").equals("null")?JSONObject.NULL:temp.getString("quantity"));
					temp.put("strength", temp.getString("strength").equals("null")?JSONObject.NULL:temp.getString("strength"));
					itemsArray.put(temp);
				}	
			}
			prescription.put("prescribedItems",itemsArray);
			
			itemsArray = new JSONArray();
			String prescribedItemsFilter;
			if(!refill.equals("0")){
				if(refillFilter.equals("")){
					prescribedItemsFilter = DefaultValues.Not0Filter.toString();
				}else{
					prescribedItemsFilter = refillFilter;
				}	
				items = MiscTools.executeMultipleRowSelectJson(env, String.format(prescriptionSqlQueries.GetRxDispensedItems.toString(),sb,rxId,prescribedItemsFilter));
				for( int i = 0; i < items.size(); i++){
					temp = items.get(i);
					temp.put("dosageAmount", temp.getString("dosageAmount").equals("null")?JSONObject.NULL:temp.getString("dosageAmount"));
					temp.put("itemReference", temp.getString("itemReference").equals("null")?JSONObject.NULL:temp.getString("itemReference"));
					temp.put("quantity",temp.getString("quantity").equals("null")?JSONObject.NULL:temp.getString("quantity"));
					temp.put("strength", temp.getString("strength").equals("null")?JSONObject.NULL:temp.getString("strength"));
					itemsArray.put(temp);
				}	
			}
			
			prescription.put("dispensedItems",itemsArray);
			prescription.put("renewal",PrescriptionFunctions.rxRenewalInformation(sb, rxId, refill, env));
			prescription.put("processingUsers",JSONObject.NULL);
			 aux = prescription.getString("timestamp");
			 if(aux.equals("null")){
				 prescription.put("statusHistory", JSONObject.NULL);
			 }else{
				 temp = new JSONObject();
				 temp.put("timestamp", aux == "null"?JSONObject.NULL:MiscTools.chageDateFormat3(aux));
				 temp.put("value",JSONObject.NULL);
				 temp.put("localId",JSONObject.NULL);
				 temp.put("comments",prescription.get("comments"));
				
				 prescription.put("statusHistory", temp);
			 }
			 prescription.remove("timestamp");
			 prescription.remove("comments");

			 if (prescription.getString("sourceName").equals("null")){
				 prescription.put("sourceChannel", JSONObject.NULL); 
			 }else{
				 temp= new JSONObject();
				 temp.put("sourceName",prescription.get("sourceName"));
				 temp.put("rxOriginCode",prescription.get("rxOriginCode"));
				 prescription.put("sourceChannel", temp); 
			 }
			 
			 prescription.remove("sourceName");
			 prescription.remove("rxOriginCode");
			 
			 temp= new JSONObject();
			 temp.put("needByDateReasonCode",prescription.get("needByDateReasonCode"));
			 temp.put("scheduledAddressReference",prescription.get("scheduledAddressReference"));
			 temp.put("needByDateConfirmation",prescription.get("needByDateConfirmation"));
			 aux = prescription.getString("needByDate");
			 temp.put("needByDate", aux == "null"?JSONObject.NULL:MiscTools.chageDateFormat3(aux));
			 prescription.put("orderScheduling", temp);
			 prescription.remove("needByDateReasonCode");
			 prescription.remove("scheduledAddressReference");
			 prescription.remove("needByDateConfirmation");
			 prescription.remove("needByDate");
			 
			 temp= new JSONObject();
			 temp.put("earliestRefillEnrollmentDate",JSONObject.NULL);
			 temp.put("autoRefillEligibleIndicator",JSONObject.NULL);
			 temp.put("autoRefillIndicator",prescription.get("autoRefillIndicator"));
			 temp.put("latestRefillEnrollmentDate",JSONObject.NULL);
			 prescription.put("fillSchedule", temp);
			 prescription.remove("autoRefillIndicator");
			 
			 aux = prescription.getString("scheduledFillDate");
			 String aux2 = prescription.getString("fillReminderDate");
			 if (aux == "null"&&aux2 == "null"){
				 prescription.put("scheduledFills", JSONObject.NULL);
			 
			 }else{
				 temp= new JSONObject();
				 temp.put("fillReference",JSONObject.NULL);
				 temp.put("latestFillDate",JSONObject.NULL);
				 temp.put("earliestFillDate",JSONObject.NULL);
				 temp.put("scheduledFillDate", aux == "null"?JSONObject.NULL:MiscTools.chageDateFormat3(aux));
				 temp.put("fillReminderDate", aux2 == "null"?JSONObject.NULL:MiscTools.chageDateFormat3(aux2));
				 prescription.put("scheduledFills", temp);
			 }
			 prescription.remove("fillReminderDate");
			 prescription.remove("scheduledFillDate");
			 
			 String creationDate = prescription.getString("creationDate");
			 prescription.remove("creationDate");
			 aux = prescription.getString("transferFlag");
			 if (aux.equals("T") && prescription.get("cProcessingPharmacy") != sb){
				 temp= new JSONObject();
				 temp.put("transferFromPharmacy",prescription.get("cProcessingPharmacy"));
				 temp.put("transferFromRx",prescription.get("cRxNumber"));
				 temp.put("transferFromFill",prescription.get("cFillNumber"));
				 temp.put("transferToPharmacy",JSONObject.NULL);
				 temp.put("transferToRx",JSONObject.NULL);
				 temp.put("transferToFill",JSONObject.NULL);
				 temp.put("transferDate",MiscTools.changeDateFormat(creationDate));
				 temp.put("transferUser",prescription.get("transferUser"));
				 prescription.put("transfer", temp);
			 }else{
				 prescription.put("transfer", JSONObject.NULL);
			 }
			 prescription.remove("transferFlag");
			 prescription.remove("cProcessingPharmacy");
			 prescription.remove("cRxNumber");
		     prescription.remove("cFillNumber");
		     prescription.remove("tranferUser");
		     //System.out.println(prescription.get("transfer"));
		     JSONArray tempArray;
		     tempArray = MiscTools.executeMultipleRowSelectArray(env, String.format(prescriptionSqlQueries.GetProcessingUsers.toString(),sb,rxId,refillFilter));
		     prescription.put("processingUsers", tempArray);
		     //String drugPrescribed = prescription.getString("drugPrescribed");
//		     String drugAbbrev = prescription.getString("drugAbbrev");
		     //String substitutedUser = prescription.getString("substitutedUser");
		     //System.out.println("this---->"+drugPrescribed +","+drugAbbrev +","+substitutedUser);
//		     if(!drugPrescribed.equals("null") && !substitutedUser.equals("null")){
//		    	 temp = new JSONObject();
//		    	 tempAux = MiscTools.executeSingleSelectJson(env, String.format(prescriptionSqlQueries.GetSusbtitutionInfo.toString(), sb, rxId, refill));
//		    	 temp.put("substitutionType", DefaultValues.valueOf("Substitution"+tempAux.getString("substitutionType")).toString());
//		    	 temp.put("substitutedUser", tempAux.getString("substitutedUser"));
//		    	 temp.put("prescribedItem", tempAux.getString("prescribedItem"));
//		    	 temp.put("substitutedItem", tempAux.getString("substitutedItem"));
//		    	 temp.put("dateTime", tempAux.getString("dateTime"));
//		    	 prescription.put("substitution", temp);
//		     }else{
//		    	 prescription.put("substitution", JSONObject.NULL);
//		     }
		    
		     prescription.remove("drugPrescribed");
		     prescription.remove("drugAbbrev");
		     prescription.remove("substitutedUser");
			 String query = String.format(prescriptionSqlQueries.GetRxFillsWithoutRange.toString(),sb,rxId,refillFilter);
			    List<JSONObject> fills = MiscTools.executeMultipleRowSelectJson(env, query);
			    JSONArray fillsArray = new JSONArray();
			    JSONObject fill = new JSONObject();
			    for( int j = 0; j < fills.size(); j++){
			    	fill = fills.get(j);
			    	fill.put("fillingPharmacy",fill.getString("fillingPharmacy"));
			    	fill.put("processingPharmacy",fill.getString("processingPharmacy")); 
					 fill.put("shipdate", fill.getString("shipdate"));
					 fill.put("fillDate", fill.getString("fillDate"));
			    	fill.put("provisionalFillIndicator", false);
			    	fillsArray.put(fill);
			    }
			    prescription.put("fills", fillsArray);
			    prescription.put("rxDateReceived", PrescriptionFunctions.getRxReceivedDate(sb, rxId, refill, env));
			    finalPrescriptionList.add(prescription);
			prescriptionListJsonArray = new JSONArray(finalPrescriptionList);
		} catch ( Exception e) {
			System.out.println("Something went wrong creating prescription response --->" + e.getMessage());
			e.printStackTrace();
		}
		return prescriptionListJsonArray;
	}
	
	public static JSONArray newCreatePrescriptionRespose( Map<String, String> rx, String env) throws JSONException{
		String sb = rx.get("sb"), rxId =rx.get("rxId"),refill = rx.get("refill");
		String refillFilter, refillCopiedFrom;
		if(refill == null){
			refillFilter = "";
			refillCopiedFrom = "";
			refill = "";
		}else{
			refillFilter = MiscTools.addRefillFilter(refill);
			refillCopiedFrom = refill == ""? "":"and refill_copied_from = "+refill;
		}
		JSONArray prescriptionListJsonArray = new JSONArray();
		JSONObject prescriptions = new JSONObject();
		JSONObject prescription = new JSONObject();
		try {
			prescription = MiscTools.executeSingleSelectJson(env, String.format(prescriptionSqlQueries.GetPrescriptionInfoWithoutRange2.toString(),sb,rxId,refillFilter));
			JSONArray itemsArray = new JSONArray();
			if(refill.equals("0") || refillFilter.equals("")) itemsArray = PrescriptionFunctions.getRxPrescribedItems(sb, rxId, env);
			prescription.put("prescribedItems",itemsArray);
			//prescription.put("name", itemsArray.length()==0?JSONObject.NULL:itemsArray.getJSONObject(0).get("name"));
			String patient = prescription.getString("patient");
			
			Map<String, String> transferInformation = new HashMap<String, String>();
			transferInformation.put("creationDate", prescription.getString("creationDate"));
			transferInformation.put("transferFlag", prescription.getString("transferFlag"));
			transferInformation.put("transferUser", prescription.getString("transferUser"));
			transferInformation.put("tSb", prescription.getString("cProcessingPharmacy").replaceAll("\\.0", ""));
			transferInformation.put("tRxId", prescription.getString("cRxNumber").replaceAll("\\.0", ""));
			transferInformation.put("tRefill", prescription.getString("cFillNumber").replaceAll("\\.0", ""));
			String query = String.format(prescriptionSqlQueries.GetTransferToPrescription.toString(),sb, rxId, refillCopiedFrom);
			Map<String, String> transferToRx = MiscTools.executeSingleRowSelect(env, query);
			prescription.put("transfer",PrescriptionFunctions.getRxTransferInformation(transferInformation, rx, transferToRx,env));
			prescription.put("sourceChannel", PrescriptionFunctions.getRxSourceChanel(prescription.getString("sourceName"),prescription.getString("rxOriginCode")));
			JSONArray fillsArray = PrescriptionFunctions.getRxFills(sb, rxId, refillFilter, env);
			prescription.put("fills", fillsArray );
			
			query = String.format(prescriptionSqlQueries.GetRxInvName.toString(), sb, rxId, refillFilter);
			String name = MiscTools.executeSingleSelect(env, query);
			System.out.println(query);
			//prescription.put("name", itemsArray.length()==0?fillsArray.getJSONObject(0).getJSONArray("dispensedItems").getJSONObject(0).get("name"):itemsArray.getJSONObject(0).get("name"));
			if(name == null) name = "";
			prescription.put("name", name.equals("")?JSONObject.NULL:name);
			prescription.put("fillSchedule", PrescriptionFunctions.getRxAutoRefillIndicator(prescription.get("autoRefillIndicator")));
			prescription.put("rxDateReceived", PrescriptionFunctions.getRxReceivedDate(sb, rxId, refillFilter, env));
			prescription.put("images",PrescriptionFunctions.getRxImage(sb, rxId, env));
			if(refill.equals("")){
				query = String.format(SqlQueries.GetMaxRefill.toString(),sb,rxId);
				refill = MiscTools.executeSingleSelect(env, query); 
			}
			prescription.put("renewal",PrescriptionFunctions.rxRenewalInformation(sb, rxId, refill, env));
			prescription.put("substitution",PrescriptionFunctions.getSubstitution(sb,rxId,refill, env));
			prescription = PrescriptionFunctions.cleanPrescriptionInfo(prescription);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		prescriptions.put("prescription",  prescription);
		prescriptionListJsonArray.put(prescriptions);
		//System.out.println(prescriptionListJsonArray);
		return prescriptionListJsonArray;
	}
	public static JSONArray createPrescriptionRespose(String patientId, String startDate, String stopDate,String therapyFilter,String env){
		String prescriptionQuery = String.format(prescriptionSqlQueries.GetDistinctPatientPrescriptions.toString(),patientId, startDate, stopDate, therapyFilter);
		System.out.println(prescriptionQuery);
		List<Map<String, String>> prescriptionList = null;
		//List<JSONObject> finalPrescriptionList = new ArrayList<JSONObject>();
		//JSONObject temp;
		JSONArray arrayTemp;
		JSONArray prescriptionListJsonArray = new JSONArray();
		
		try {
			System.out.println("empezo la lista");
			prescriptionList = MiscTools.executeMultipleRowSelect(env, prescriptionQuery);
			System.out.println(prescriptionList);
			for(int i = 0; i < prescriptionList.size(); i++){
				arrayTemp = newCreatePrescriptionRespose( prescriptionList.get(i), env);
				prescriptionListJsonArray.put(arrayTemp.getJSONObject(0));
			}
		} catch (Exception e) {
			System.out.println("Something went wrong creating prescription response");
			e.printStackTrace();
		}
		System.out.println("salio create respone");
		//System.out.println(prescriptionListJsonArray);
		return prescriptionListJsonArray;
	}
	public static JSONObject createPayorResposeById(String payorId, String env){
		String payorQuery =String.format(SqlQueries.ClaimCenterQuery.toString(), payorId );
				
		String payorBillingQuery = String.format(SqlQueries.ClaimCenterBilling.toString(), payorId );
		String payorPlanQuery = String.format(SqlQueries.ClaimCenterPlan.toString(), payorId );
		JSONObject payorInfo = new JSONObject();
		JSONObject billingInfo = new JSONObject();
		JSONObject planInfo = new JSONObject();
		try {
			payorInfo = MiscTools.executeSingleSelectJsonB(env, payorQuery);
			billingInfo = MiscTools.executeSingleSelectJsonB(env, payorBillingQuery);
			planInfo = MiscTools.executeSingleSelectJsonB(env, payorPlanQuery);
			payorInfo.put("resourceId", JSONObject.NULL);
			JSONObject defaults = new JSONObject(DefaultValues.valueOf("status"+payorInfo.getString("status")).toString());
			payorInfo.put("status", defaults);	
			defaults = new JSONObject(DefaultValues.group.toString());
			defaults.put("name", payorInfo.get("group"));
			payorInfo.put("group", defaults);
			billingInfo.put("relativeId", JSONObject.NULL);
			billingInfo.put("name", JSONObject.NULL);
			defaults = new JSONObject(DefaultValues.valueOf("autoSequence"+billingInfo.getString("autoSequence")).toString());
			billingInfo.put("autoSequence", defaults);	
			if(billingInfo.getString("deliverySignatureRequired").equals("null")){
				billingInfo.put("deliverySignatureRequired", false);
			}
			defaults = new JSONObject(DefaultValues.valueOf("invoiceFormat"+billingInfo.getString("invoiceFormat")).toString());
			billingInfo.put("invoiceFormat", defaults);		
			defaults = new JSONObject(DefaultValues.valueOf("rxMatchDate"+billingInfo.getString("prescriptionMatchDate")).toString());
			billingInfo.put("prescriptionMatchDate", defaults);	
			defaults = new JSONObject(DefaultValues.valueOf("originCode"+billingInfo.getString("ncpdpOriginCode")).toString());
			billingInfo.put("ncpdpOriginCode", defaults);
			defaults = new JSONObject(DefaultValues.valueOf("reversalProvider"+billingInfo.getString("ncpdpReversalProvider")).toString());
			billingInfo.put("ncpdpReversalProvider", defaults);
			if(billingInfo.getString("ReportPrescriberDataFlag").equals("null")){
				billingInfo.put("ncpdpReportPrescriberDataFlag",false);
			}else{
				billingInfo.put("ncpdpReportPrescriberDataFlag", billingInfo.getBoolean("ReportPrescriberDataFlag"));
			}
			billingInfo.remove("ReportPrescriberDataFlag");
			if(billingInfo.getString("ReportPrescriberFirstNameFlag").equals("null")){
				billingInfo.put("ncpdpReportPrescriberFirstNameFlag", false);
			}else{
				billingInfo.put("ncpdpReportPrescriberFirstNameFlag", billingInfo.getBoolean("ReportPrescriberFirstNameFlag"));
			}
			billingInfo.remove("ReportPrescriberFirstNameFlag");
			if(billingInfo.getString("ReportPrescriberAddressFlag").equals("null")){
				billingInfo.put("ncpdpReportPrescriberAddressFlag",false);
			}else{
				billingInfo.put("ncpdpReportPrescriberAddressFlag", billingInfo.getBoolean("ReportPrescriberAddressFlag"));
			}
			billingInfo.remove("ReportPrescriberAddressFlag");
			if(billingInfo.getString("ServiceProviderIdQualifier").equals("null")){
				billingInfo.put("ncpdpServiceProviderIdQualifier", JSONObject.NULL);
			}else{
				billingInfo.put("ncpdpServiceProviderIdQualifier", billingInfo.getString("ServiceProviderIdQualifier"));
			}
			billingInfo.remove("ServiceProviderIdQualifier");
			if(billingInfo.getString("ncpdpProviderFlag").equals("null")){
				billingInfo.put("ncpdpProviderFlag", false);
			}
			if(billingInfo.getString("ncpdpReversalCOB").equals("null")){
				billingInfo.put("ncpdpReversalCOB", false);
			}
			if(billingInfo.getString("ncpdpReversalDUR").equals("null")){
				billingInfo.put("ncpdpReversalDUR", false);
			}
			if(billingInfo.getString("ncpdpReversalBin").equals("null")){
				billingInfo.put("ncpdpReversalBin", false);
			}
			planInfo.put("relativeId", JSONObject.NULL);
			
			payorInfo.put("billing", billingInfo);
			payorInfo.put("plan", planInfo);
			
			String payorAddressesQuery = String.format(SqlQueries.ClaimCenterAddresses.toString(), payorId );
			List<Map<String, String>> addressList = MiscTools.executeMultipleRowSelect(env, payorAddressesQuery);
			List<Map<String, String>> addressList2 = MiscTools.executeMultipleRowSelect(env, payorAddressesQuery);
			for(int i = 0; i < addressList.size(); i++){
				addressList.get(i).remove("attn");
				addressList.get(i).remove("addr1");
				addressList.get(i).remove("addr2");
			}

			JSONObject address;
			List<JSONObject>newAddressJsonArray = new ArrayList<JSONObject>();
			String postalCode;
			for(int i = 0; i < addressList.size(); i++){
				postalCode = addressList.get(i).get("postalCode");
				address = new JSONObject(addressList.get(i));
				address.put("relativeId",JSONObject.NULL);
				address.put("officeSuite",JSONObject.NULL);
				address.put("apartmentNumber",JSONObject.NULL);
				address.put("postOfficeBoxNumber",JSONObject.NULL);
				if(address.getString("postalCode").equals("null")){
					address.put("postalCode", JSONObject.NULL);
				}else{
					address.put("postalCode", address.getString("postalCode"));
				}
				
				JSONArray streetJsonArray = new JSONArray();
				streetJsonArray.put(addressList2.get(i).get("addr1"));
				streetJsonArray.put(addressList2.get(i).get("addr2"));
				streetJsonArray.put(addressList2.get(i).get("attn"));

				address.put("streetAddress", streetJsonArray);
				address.remove("addr1");
				address.remove("addr2");
				address.remove("attn");
				defaults = new JSONObject(DefaultValues.addrState.toString());
				defaults.put("code", address.get("state"));
				address.put("state", defaults);
				defaults = new JSONObject(DefaultValues.addrCountry.toString());
				defaults.put("iso3code", address.get("country"));
				address.put("country", defaults);
				defaults = new JSONObject(DefaultValues.addrStatus.toString());
				defaults.put("value", address.get("status"));
				address.put("status", defaults);
				newAddressJsonArray.add(address);
			}
			payorInfo.put("postalAddresses",new JSONArray(newAddressJsonArray.toString()));

			String payorPhonesQuery = String.format(SqlQueries.ClaimCenterPhones.toString(), payorId );
			List<Map<String, String>> phoneList = MiscTools.executeMultipleRowSelect(env, payorPhonesQuery);
			JSONArray phoneListJsonArray;
			if(phoneList.isEmpty()){	
				phoneListJsonArray = new JSONArray("[]");
			}else{
				phoneListJsonArray = new JSONArray(phoneList);
			}
			JSONObject phone;
			String phoneType;
			JSONArray newPhoneJsonArray = new JSONArray();
			for(int i = 0; i < phoneListJsonArray.length(); i++){
				phone = new JSONObject(phoneListJsonArray.getString(i));
				if(phone.get("number").equals("--")){
					phone.put("number", JSONObject.NULL);
				}
				phone.put("relativeId",JSONObject.NULL);
				phone.put("countryCallingCode",JSONObject.NULL);
				phone.put("capabilities",JSONObject.NULL);
				if(phone.getString("extension").equals("null")){
					phone.put("extension", JSONObject.NULL);
				}else{
					phone.put("extension", phone.getString("extension"));
				}
				phoneType = phone.getString("classifications");
				if(phoneType.equals("HOME")||phoneType.equals("WORK")||phoneType.equals("PERSONAL")){
					defaults = new JSONObject(DefaultValues.valueOf("phoneType"+phoneType).toString());
				}else{
					defaults = new JSONObject(DefaultValues.phoneTypeOTHER.toString());
					String payorCustomTagsQuery = String.format(SqlQueries.ClaimCenterCustomTags.toString(),phone.get("phoneSeq"), payorId );
					String customTags = MiscTools.executeSingleSelect(env, payorCustomTagsQuery);
					String[] tags = customTags.split("\\-");
					JSONArray tagsJsonArray = new JSONArray();
					for(int j = 0; j< tags.length; j++){
						if(MiscTools.findDuplicate(tagsJsonArray, tags[j]) == false){
							tagsJsonArray.put(tags[j]);
						}
					}
					defaults.put("customTags", tagsJsonArray);
				}
				phone.remove("phoneSeq");
				phone.put("classifications", defaults);
				newPhoneJsonArray.put(phone);
			}
			payorInfo.put("phoneNumbers",newPhoneJsonArray);
		} catch (SQLException | JSONException e) {
			e.printStackTrace();
		}
		
		return payorInfo;
	}

	public static JSONArray createPayorResposeByName(String payorName, String env){
		JSONArray payorsInfo = new JSONArray();
		String payorId;
		JSONObject payor;
		try {
			payorName = payorName.replaceAll("\\'+", "''");
			String payorIdsQuery = String.format(SqlQueries.ClaimCenterIdsByName.toString(), payorName );
			List<Map<String, String>> payorIds = MiscTools.executeMultipleRowSelect(env,payorIdsQuery);
			for(int i = 0; i < payorIds.size(); i++){
				payorId = payorIds.get(i).get("id");
				payor = createPayorResposeById(payorId,env);
				payorsInfo.put(payor);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return payorsInfo;	
	}
	
	public static JSONObject createMedicalConditionResponse(String patientId, String env){
		JSONObject medicalConditionInfo = new JSONObject();
		String medicalConditionQuery =  String.format(SqlQueries.GetMedicalCondition.toString(),patientId);
		
		try {
			//medicalConditionInfo.put("patientId", patientId); <-- It shouldn't only temp
			medicalConditionInfo.put("patientId", JSONObject.NULL);
			medicalConditionInfo.put("resourceId", JSONObject.NULL);
			List<Map<String, String>> medicalConditionList = MiscTools.executeMultipleRowSelect(env,medicalConditionQuery);
			JSONArray medicalConsitionJsonArray = new JSONArray();
			JSONObject medicalCondition = null;
			for(int i = 0; i < medicalConditionList.size(); i++){
				medicalCondition = new JSONObject();
				medicalCondition.put("severity",JSONObject.NULL);
				medicalCondition.put("status",JSONObject.NULL);
				medicalCondition.put("conditionCode",medicalConditionList.get(i).get("conditionCode"));
				medicalCondition.put("codingSystem",medicalConditionList.get(i).get("codingSystem"));
				medicalCondition.put("description",medicalConditionList.get(i).get("description"));
				medicalCondition.put("onsetDate",medicalConditionList.get(i).get("onsetDate") == null?JSONObject.NULL:medicalConditionList.get(i).get("onsetDate"));
				medicalCondition.put("abatementDate",medicalConditionList.get(i).get("abatementDate") == null?JSONObject.NULL:medicalConditionList.get(i).get("abatementDate"));
				medicalConsitionJsonArray.put(medicalCondition);
			}
			medicalConditionInfo.put("medicalConditions", medicalConsitionJsonArray);
		} catch (SQLException | JSONException e) {
			e.printStackTrace();
		}
		
		return medicalConditionInfo;
	}
	
	public static JSONObject createClinicalTherapyResponse(String patientId, String env){
		JSONObject clinicalTherapyInfo = new JSONObject();
		String clinicalTherapyQuery =  String.format(SqlQueries.GetClinicalTherapy.toString(),patientId);
		
		try {
			//clinicalTherapyInfo.put("patientId", patientId);--> Has values in DB, but they arrive null
			clinicalTherapyInfo.put("patientId", JSONObject.NULL);
			clinicalTherapyInfo.put("resourceId", JSONObject.NULL);
			List<Map<String, String>> clinicalTherapyList = MiscTools.executeMultipleRowSelect(env,clinicalTherapyQuery);
			JSONArray clinicalTherapyJsonArray = new JSONArray();
			JSONObject clinicalTherapy = null;
			for(int i = 0; i < clinicalTherapyList.size(); i++){
				clinicalTherapy = new JSONObject();
				//clinicalTherapyInfo.put("therapy", therapy); --> Has values in DB, but they arrive null
				clinicalTherapy.put("therapy",JSONObject.NULL);
				clinicalTherapy.put("drugIds",JSONObject.NULL);
				clinicalTherapy.put("endDate",clinicalTherapyList.get(i).get("endDate") == null?JSONObject.NULL:clinicalTherapyList.get(i).get("endDate"));
				clinicalTherapy.put("startDate",clinicalTherapyList.get(i).get("startDate"));
				clinicalTherapy.put("status",clinicalTherapyList.get(i).get("status"));
				clinicalTherapy.put("stopReason",clinicalTherapyList.get(i).get("stopReason") == null?JSONObject.NULL:clinicalTherapyList.get(i).get("stopReason"));
				clinicalTherapyJsonArray.put(clinicalTherapy);
			}
			clinicalTherapyInfo.put("therapyRecords",clinicalTherapyJsonArray);
		} catch (SQLException | JSONException e) {
			e.printStackTrace();
		}
		
		return clinicalTherapyInfo;
	}
	
	public static JSONObject createTrcAomByTherapyTypeResponse(String therapyType, String env){
		JSONObject trcAomInfo = new JSONObject();
		String trcAomQuery =  String.format(SqlQueries.GetTrcAomByTherapyType.toString(),therapyType);
		
		try {
			trcAomInfo = MiscTools.executeSingleSelectJson(env, trcAomQuery);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return trcAomInfo;
	}
	
	public static JSONArray createTrcAomPhonesResponse(String trcGroup, String env){
		JSONArray trcAomPhonesJsonArray = new JSONArray();
		String clinicalTrcAomPhones =  String.format(SqlQueries.TrcAomPhones.toString(),trcGroup);
		
		try {
			List<Map<String, String>> trcAomPhonesList = MiscTools.executeMultipleRowSelect(env,clinicalTrcAomPhones);
			
			JSONObject  trcAomPhone = new JSONObject();
			for(int i = 0; i < trcAomPhonesList.size(); i++){
				 trcAomPhone = new JSONObject(trcAomPhonesList.get(i));
				 trcAomPhonesJsonArray.put(trcAomPhone);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return trcAomPhonesJsonArray;
	}
	
	public static JSONObject fullPrescriptionRequestToResponse(String requestBody, String prescriptionId, String env){
		JSONObject fullPrescription = new JSONObject();
		try {
			JSONObject requestBodyJson = new JSONObject(requestBody);
			JSONObject rx = requestBodyJson.getJSONObject("prescription");
			fullPrescription.put("prescription", prescriptionRequestToResponse(rx.toString(), prescriptionId, env));
			fullPrescription.put("fillRx", requestBodyJson.getJSONObject("fillRx"));
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return fullPrescription;
	}
	public static JSONObject prescriptionRequestToResponse(String requestBody, String prescriptionId, String env){
		JSONObject prescription = null;
		try {
			prescription = new JSONObject(requestBody);
			String requestSb = prescription.getString("processingPharmacy");
			String patientId = prescription.getString("legacyPatientID");
		    String expectedSb = MiscTools.getExpectedSb(requestSb,patientId,env);
		    prescription.put("processingPharmacy", expectedSb);
			prescription.put("currentStatus",prescription.getString("currentStatus").toUpperCase());
			prescription.put("rxNumber", Integer.parseInt(prescriptionId));
			prescription.put("fillNumber", 0);
			String date = prescription.getString("writtenDate");
			prescription.put("writtenDate",date);
			date = prescription.getString("expirationDate");
			prescription.put("expirationDate",date.equals("null")||date.equals("")?JSONObject.NULL:date);
			date = date.equals("null")||date.equals("")? MiscTools.addDaysToToday(365, "yyyy-MM-dd"):date;
			prescription.put("refillThruDate",date);
			String status = prescription.getString("currentStatus");
			if(status.equals("NULL")) prescription.put("currentStatus", "PROFILE");
			prescription.remove("ndc");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return prescription;
		
	}
	
	
	public static JSONObject fullPrescriptionInfo(String sb, String rxId, String refill, String env){
		JSONObject fullPrescriptionInfo = new JSONObject();
		try {
			fullPrescriptionInfo.put("prescription", prescriptionInfoJsonFormat(rxId, sb, env));
			fullPrescriptionInfo.put("fillRx", fillInfoJsonFormat(rxId, sb, refill, env));
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return fullPrescriptionInfo;
	}
	public static JSONObject prescriptionInfoJsonFormat(String rxId, String sb, String env) throws JSONException{
		JSONObject jsonPrescriptionInfo = null;
		try {
			String query = String.format(SqlQueries.CreateRx.toString(),sb,rxId);
			jsonPrescriptionInfo = MiscTools.executeSingleSelectJson(env, query);
			//String patientId = jsonPrescriptionInfo.getString("legacyPatientID");
			query = String.format(SqlQueries.GetPhysicianFromRx.toString(),sb,rxId);
			String physicianId = MiscTools.executeSingleSelect(env, query);
			
			query = String.format(SqlQueries.GetRxOrignCodeFrom.toString(),jsonPrescriptionInfo.getString("orderTaken"));
			JSONObject rxOriginCode = MiscTools.executeSingleSelectJson(env,query );
			jsonPrescriptionInfo.put("rxOriginCode", rxOriginCode);
			jsonPrescriptionInfo.put("personGUID", MiscTools.getPersonGuid(rxId,env));
			jsonPrescriptionInfo.remove("orderTaken");
			query = String.format(prescriptionSqlQueries.GetRxImage.toString(),sb,rxId);
			JSONArray docIds = MiscTools.executeSingleSelectArray(env, query);
			jsonPrescriptionInfo.put("documentReferences", docIds);
			query = String.format(SqlQueries.GetPrescriberInfo.toString(), physicianId);
			JSONObject prescriberInfo = MiscTools.executeSingleSelectJson(env, query);
			prescriberInfo.put("legacyPrescriberId", JSONObject.NULL);
			prescriberInfo.put("npiId", JSONObject.NULL);
			prescriberInfo.put("zip", JSONObject.NULL);
			prescriberInfo.put("addLine1", JSONObject.NULL);
			prescriberInfo.put( "addLine2", JSONObject.NULL);
			prescriberInfo.put("state", JSONObject.NULL);
			prescriberInfo.put("city", JSONObject.NULL);
			prescriberInfo.put( "phone", JSONObject.NULL);
			prescriberInfo.put("fax", JSONObject.NULL);

			jsonPrescriptionInfo.put("practitioner", prescriberInfo);

		} catch ( SQLException e) {
			e.printStackTrace();
		}
		return jsonPrescriptionInfo;
	}
	
	
	public static JSONObject fillInfoJsonFormat(String rxId, String sb,String refill, String env){
		JSONObject jsonFillInfo = null;
		try {
				String query = String.format(SqlQueries.GetFillRequestStruct.toString(),sb,rxId,refill);
				System.out.println(query);
				jsonFillInfo = MiscTools.executeSingleSelectJson(env, query);
				String initials= jsonFillInfo.getString("technicianInitials");
				jsonFillInfo.put("technicianInitials", initials == "null"? "":initials);
		} catch ( SQLException | JSONException e) {
			e.printStackTrace();
		}
		return jsonFillInfo;
	}
}
