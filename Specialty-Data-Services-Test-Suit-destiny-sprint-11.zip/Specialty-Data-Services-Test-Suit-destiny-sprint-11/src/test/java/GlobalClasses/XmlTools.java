package GlobalClasses;

import org.apache.commons.io.IOUtils;
import org.w3c.dom.Node;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.*;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XmlTools {
	
	public static String readXmlFile(String filePath){
		String xml = "";
		 InputStream inputStream = JsonTools.class.getResourceAsStream (filePath);
		 try {
			xml = IOUtils.toString(inputStream, "UTF-8");
		} catch (IOException e) {
			System.out.println("Could not read xml file");
			e.printStackTrace();
		}
		 return xml;
	}
	
	public static String readXmlFileComplete(String filePath){
		String xml = "";
		try {
			 File file = new File(filePath);
		     InputStream inputStream = new FileInputStream(file);
		     xml = IOUtils.toString(inputStream, "UTF-8");
		} catch (IOException e) {
			System.out.println("Could not read xml file");
			e.printStackTrace();
		}
		 return xml;
	}
	
	public static String getXmlNodeValue(String xml, String nodeId){
		XPath xpath = XPathFactory.newInstance().newXPath();
		InputSource inputSource = new InputSource(	new StringReader(xml));
		String nodeValue = "";
		try {
			nodeValue = xpath.evaluate("//"+nodeId, inputSource);
		} catch (XPathExpressionException e) {
			System.out.println("Something went wrong");
			e.printStackTrace();
		}
		return nodeValue;
	}

	public static String updateXmlNodeValue(String xml, String nodeId, String newValue){
		String newXml = xml;
		InputSource inputSource = new InputSource(new StringReader(xml)); 
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder;
		try {
			docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(inputSource);
	        
	        XPath xpath = XPathFactory.newInstance().newXPath();
	        Node node = (Node) xpath.compile("//"+nodeId).evaluate(doc, XPathConstants.NODE);
			node.setTextContent(newValue);
	        Transformer transformer = TransformerFactory.newInstance().newTransformer();

	        DOMSource domSource = new DOMSource(doc);
	        StreamResult sr = new StreamResult();
	        OutputStream out = new ByteArrayOutputStream();

	        sr.setOutputStream(out);
			transformer.transform(domSource, sr);
		    newXml = sr.getOutputStream().toString();

		} catch (ParserConfigurationException | TransformerFactoryConfigurationError |
				SAXException | IOException | XPathExpressionException |  TransformerException e1) {
			System.out.println("Xml was not updated");
			e1.printStackTrace();
		}
		return newXml;
	}	

}
