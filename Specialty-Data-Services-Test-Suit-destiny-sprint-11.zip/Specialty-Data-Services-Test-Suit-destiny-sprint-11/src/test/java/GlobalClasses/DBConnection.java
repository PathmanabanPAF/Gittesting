package GlobalClasses;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import GlobalClasses.DBConnection;

public class DBConnection {
	public Statement statement;
	public Connection connection;
	public DBConnection db;
	
	/**
	 * Singleton Class Constructor
	 * @param env
	 */
	public DBConnection(String env){
		final String driver = "oracle.jdbc.driver.OracleDriver";
		final String user = "EI1378";
		final String pass = "Es172694**";
		String url;
		try{
			Class.forName(driver).newInstance();
			url = GetURLServerConection(env);
			this.connection = (Connection)DriverManager.getConnection(url,user,pass);
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Failed to make connection!");
		}
	}

	public synchronized  DBConnection getConnection (String env){
		if(db == null){
			db = new  DBConnection(env);
		}
		return db;	
	}
	
	/**
	 * Execute a statement SQL Select
	 * @param query
	 * @return The value in resultQuery variable
	 * @throws SQLException
	 */
	public ResultSet ExecuteSelect (String query)throws SQLException{
		statement = connection.createStatement();
		ResultSet resultQuery = statement.executeQuery(query);
		return resultQuery;
	}
	
	/**
	 * Execute a statement SQL Update
	 * @param query
	 * @throws SQLException
	 */
	public void ExecuteUpdate (String query)throws SQLException{
		statement = connection.createStatement();
		statement.executeUpdate(query);
		connection.commit();
	}
	
	/**
	 * Execute a statement SQL Insert
	 * @param query
	 * @return
	 * @throws SQLException
	 */
	public void ExecuteInsert (String query)throws SQLException{
		statement = connection.createStatement();
		statement.executeUpdate(query);
		connection.commit();
	}
	/**
	 * Execute a statement SQL Delete
	 * @param query
	 * @throws SQLException
	 */
	public void ExecuteDelete (String query)throws SQLException{
		statement = connection.createStatement();
		statement.executeUpdate(query);
		connection.commit();
	}
	/**
	 * Close connection
	 * @throws SQLException
	 */
	public void Close()throws SQLException{
		try{
			if(connection != null){
				connection.close();
			}
			if(statement != null){
				statement.close();
			}	
		}catch(Exception e){
				e.getMessage();
			}
			
			
		}
		
	
	/**
	 * The function receive the parameter and return the URL to connect specific data base 
	 * url example //jdbc:oracle:thin:@hostname:port Number:databaseName
	 * @param env
	 * @return
	 */
	public static String GetURLServerConection(String env){
		String url = null;
		switch(env) {
		case "ETRN": 
			url = "jdbc:oracle:thin:@//mp1-qracb-scan.express-scripts.com:1521/TA_RXHOME";
			break;
		case "PREP": 
			url = "jdbc:oracle:thin:@//mp1-dracb-scan-1.medco.com:1521/UDB063R";
			break;
		case "UAT": 
			url = "jdbc:oracle:thin:@//mp1-qracb-scan.express-scripts.com:1521/UA_RXHOME";
			break;
		case "TEST": 
			url = "jdbc:oracle:thin:@ldap://oraclenames.express-scripts.com:389/QARXHSUSR,cn=OracleContext,dc=eusovd,dc=com";
			//"jdbc:oracle:thin:@mp1q3r12915.express-scripts.com:1521:QDB062R1";//
			break;
		case "INT": 
			url = "jdbc:oracle:thin:@//mp1-dracb-scan-1.medco.com:1521/IA_WKSTNS";
			break;
		case "DEV": 
			url = "jdbc:oracle:thin:@ldap://oraclenames.express-scripts.com:389/DAFPRXHSUSR,cn=OracleContext,dc=eusovd,dc=com";
			break;
		}
		return url;
	}
	
}

