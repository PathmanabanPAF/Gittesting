package GlobalClasses; 

import static com.jayway.restassured.RestAssured.given;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;

public class ApiTools {
	//public String hostName;
	public String contentType;
	private static Header header;
	private static Response response;
	
	/**
	 * ApiTool contructor
	 * @param hostName
	 * @param contentType
	 * @param authorization
	 */
	public ApiTools(String hostName, String contentType, String authorization) {
		//this.hostName   = hostName;
		this.contentType = contentType;
		String[] arrayAuthorization = authorization.split("\\,");
		header = new Header( arrayAuthorization[0], arrayAuthorization.length > 1?arrayAuthorization[1]:null );
		RestAssured.baseURI = hostName;
	}
	
	/**
	 * Executes a POST request 
	 * @param apiPath
	 * @param requestBody
	 * @return response
	 */
	public Response create(String apiPath, String requestBody) {
    	response = given().
    			contentType(contentType).
    			header(header).
    			body(requestBody).
    			when().
    			post(apiPath);	
	   return response;
	}
	
	/**
	 * Executes a GET Request
	 * @param apiPath
	 * @return response
	 */
	public Response retrive(String apiPath) {
	 	response = given().
	 			contentType(contentType).
	 	    	header(header).
	 	        when().
	 	        get(apiPath);
	   return response;
	}
	
	/**
	 * Executes a GET Request with url Encoding not Enabled
	 * @param apiPath
	 * @return response
	 */
	public Response retriveEncodingFalse(String apiPath) {
	 	response = given().
	 			urlEncodingEnabled(false).
	 			contentType(contentType).
	 			header(header).
	 			when().
	 			get(apiPath);
	   return response;
	}
	/**
	 * Executes a PUT Request
	 * @param apiPath
	 * @param requestBody
	 * @return response
	 */
	public Response update(String apiPath, String requestBody) {
    	response = given().
	    	contentType("application/json").
	    	header(header).
	    	body(requestBody).
	        when().
	        put(apiPath);
		return response;
	}
	
	/**
	 * Executes a DELETE Request
	 * @param apiPath
	 * @param requestBody
	 * @return respose
	 */
	public Response delete(String apiPath, String requestBody) {
		response = given().
	    	contentType("application/json").
	    	header(header).
	    	body(requestBody).
	        when().
	        delete(apiPath);
		return response;
	}
}
