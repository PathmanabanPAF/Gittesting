package GlobalClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.UnreachableBrowserException;

public class BrowserDriver {

	private static WebDriver mDriver;
	
	public synchronized static WebDriver getCurrentDriver() {
	    if (mDriver==null) {
	    	mDriver = new FirefoxDriver(new FirefoxProfile());
	    }
	    return mDriver;
	}
	 
	public void close() {
	    try {
	        getCurrentDriver().quit();
	        mDriver = null;
	    } catch (UnreachableBrowserException e) {
	    	System.out.println("cannot close browser: unreachable browser");
	    }
	}
	
	public void loadPage(String url){
    	getCurrentDriver().get(url);
	}
	
}
