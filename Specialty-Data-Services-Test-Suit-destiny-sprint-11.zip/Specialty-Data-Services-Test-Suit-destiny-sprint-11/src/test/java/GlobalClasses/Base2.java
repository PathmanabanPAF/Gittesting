package GlobalClasses;

public class Base2 {
	public String lala;
}
