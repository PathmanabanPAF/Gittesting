package GlobalClasses;

import java.io.UnsupportedEncodingException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

public class ApiToolsV2 {
	
	public String hostName;
	public ResponseEntity<String> response;
	public HttpHeaders headers;
	public MediaType contentType;
	public RestTemplate restTemplate;
	public OauthAuthorization authorization;
	public String authorized;
	
	public ApiToolsV2(String service, String env) {
		String[] credentials = WSOauthCredentials.webServicesOauthCredentials(service,env);
		this.hostName = credentials[0];
		this.contentType = MiscTools.getContentType(credentials[1]);
		authorization = new OauthAuthorization(credentials[2],credentials[3],credentials[4], credentials[5]);
		restTemplate = new RestTemplate();
		restTemplate.setErrorHandler(new CustomResponseErrorHandler());
		//headers = new HttpHeaders();
		setAuthorized("Y");
	}
	
	public ResponseEntity<String> retrive(String apiPath) {
		SSLCertificateValidation.disable();
		try {
			if(this.authorized.equals("Y")){
				headers = new HttpHeaders();
				headers.add("Authorization",MiscTools.getOauthHeader(authorization,HttpMethod.GET.toString(),hostName+apiPath));
			}
			HttpEntity<String> request = new HttpEntity<String>(headers);
			response = restTemplate.exchange(hostName+apiPath, HttpMethod.GET, request, String.class);
		}catch( Exception ex){
			response = new ResponseEntity<String>( ((HttpStatusCodeException) ex).getResponseBodyAsString(), ((HttpStatusCodeException) ex).getStatusCode());
		}
	   return response;
	}

	public ResponseEntity<String> create(String apiPath, String requestBody) {
		SSLCertificateValidation.disable();
		try {
			headers = new HttpHeaders();
			headers.add("Authorization",MiscTools.getOauthHeader(authorization,HttpMethod.POST.toString(),hostName+apiPath));
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request = new HttpEntity<String>(requestBody,headers);
			response = restTemplate.exchange(hostName+apiPath, HttpMethod.POST, request, String.class);
		}catch(HttpClientErrorException | UnsupportedEncodingException  ex){
			response = new ResponseEntity<String>( ((HttpStatusCodeException) ex).getResponseBodyAsString(), ((HttpStatusCodeException) ex).getStatusCode());
		}
		System.out.println("Response message:"+response);
	   return response;
	   
	}

	public ResponseEntity<String> update(String apiPath, String requestBody) {
		SSLCertificateValidation.disable();
		try {
			headers = new HttpHeaders();
			headers.add("Authorization",MiscTools.getOauthHeader(authorization,HttpMethod.PUT.toString(),hostName+apiPath));
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request = new HttpEntity<String>(requestBody,headers);
			response = restTemplate.exchange(hostName+apiPath, HttpMethod.PUT, request, String.class);
		}catch(HttpClientErrorException | UnsupportedEncodingException  ex){
			response = new ResponseEntity<String>( ((HttpStatusCodeException) ex).getResponseBodyAsString(), ((HttpStatusCodeException) ex).getStatusCode());
		}
	   return response;
	}

	public void setAuthorized(String authorized){
		this.authorized = authorized;
	}
}
