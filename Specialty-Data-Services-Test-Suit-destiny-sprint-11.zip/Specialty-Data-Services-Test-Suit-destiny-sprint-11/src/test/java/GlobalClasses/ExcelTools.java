//package GlobalClasses;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.util.Iterator;
//
//import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//
////public class ExcelTools 
//{
//
//	
//	/**
//	 * loadExceltoVector: This method get the Information of the excel and return it as a String[][]
//	 * @param TeamName: Name of the team owner of the excel file belong 
//	 * @param sheet: Name of the sheet to load
//	 * @return a String[][] With the information inside the sheet
//	 * @throws IOException
//	 */
//	public String[][] loadExceltoVector(String TeamName, String sheet) throws IOException
//	{
//		
//        int rows =0;
//        int columns =0;
//
//		FileInputStream inputStream = new FileInputStream(new File(getExcelPath(TeamName)));
//        Workbook workbook = new XSSFWorkbook(inputStream);
//        Sheet firstSheet = workbook.getSheet(sheet);
//        
//        Iterator<Row> iterator = firstSheet.iterator();
//        Iterator<Row> iterator2 = firstSheet.iterator();
//        Iterator<Row> iterator3 = firstSheet.iterator();
//        rows = getLengthOfColum(iterator2);
//        columns = getLenghtOfRow(iterator3);
//        System.out.println("rows: "+rows+ " columns: "+columns);
//        String[][] tags = new String[rows][columns];
//        tags = GetDataFromCell(iterator,rows,columns);
//        
//        workbook.close();
//        inputStream.close();
//        return tags;
//	}
//
//	/**
//	 * getExcelPath: return the path of the Excel file
//	 * @param TeamName: Name of the team owner of the excel file belong
//	 * @return: Path of the Excel File
//	 */
//	public String getExcelPath(String TeamName)
//	{
//		String excelPath = null;
//		switch(TeamName.toUpperCase())
//		{
//		case "SPARTAN":
//			excelPath ="C:/esi/WSSpecialtyDataServices/Specialty-Data-Services-Test-Suit/SpartanUS.xlsx";
//			break;
//		case "ARMAGEDDON":
//			excelPath ="C:/esi/WSSpecialtyDataServices/Specialty-Data-Services-Test-Suit/ArmageddonUS.xlsx";
//			break;
//		case "NIGHT WATCH":
//			excelPath ="C:/esi/WSSpecialtyDataServices/Specialty-Data-Services-Test-Suit/NightWatchUS.xlsx";
//			break;
//		case "DESTINY":
//			excelPath ="C:/esi/WSSpecialtyDataServices/Specialty-Data-Services-Test-Suit/DestinyUS.xlsx";
//			break;
//		}
//		return excelPath;
//	}
//	
//	/**
//	 * getLengthOfColum: This method return the length of the first column of the sheet. skips the first row (tags)
//	 * @param iterator: Sheet as a Iterator Object
//	 * @return: Length of the Column
//	 */
//	public int getLengthOfColum( Iterator<Row> iterator)
//	{
//		int rows= 0;
//		while (iterator.hasNext()) 
//		{
//			Row nextRow = iterator.next();
//			if (nextRow.getRowNum() == 0){nextRow = iterator.next();}
//			rows++;	
//		}
//		return rows;
//	}
//	
//	/**
//	 * getLenghtOfRow: This method return the length of the second row of the sheet. skips the first row (tags)
//	 * @param iterator: Sheet as a Iterator Object
//	 * @return: Length of the row
//	 */
//	public int getLenghtOfRow(Iterator<Row> iterator)
//	{
//		
//		int columns =0;
//        
//        Row nextRow = iterator.next();
//        Iterator<Cell> cellIterator = nextRow.cellIterator();
//        cellIterator = nextRow.cellIterator();
//            
//        while (cellIterator.hasNext()) 
//        {
//        	Cell cell = cellIterator.next();
//            columns++;
//        }
//		return columns;
//	}
//	
//	/**
//	 * GetDataFromCell: This method get the information of the Cells an return it as a string[][]
//	 * @param iterator: Sheet as a Iterator Object 
//	 * @param row: Length of the Row
//	 * @param column: Length of the Column
//	 * @return: The method return a String[][] with the data of the sheet
//	 */
//	public String[][] GetDataFromCell(Iterator<Row> iterator, int row, int column)
//	{
//		String[][] tags = new String[row][column];
//		while (iterator.hasNext()) 
//        {
//        	int j=0;
//            Row nextRow = iterator.next();
//            Iterator<Cell> cellIterator = nextRow.cellIterator();
//            
//            if (nextRow.getRowNum() == 0)
//            {
//            	nextRow = iterator.next();
//            	cellIterator = nextRow.cellIterator();
//            }
//            
//            while (cellIterator.hasNext()) 
//            {
//                Cell cell= cellIterator.next();
//               
//                switch (cell.getCellType()) 
//                {
//                    case Cell.CELL_TYPE_STRING:
//                    	tags[cell.getRowIndex()-1][j] = cell.getStringCellValue();
//                    	break;
//                    case Cell.CELL_TYPE_BOOLEAN:
//                    	tags[cell.getRowIndex()-1][j] = String.valueOf(cell.getBooleanCellValue());
//                    	break;
//                    case Cell.CELL_TYPE_NUMERIC:
//                    	tags[cell.getRowIndex()-1][j] = String.valueOf(cell.getNumericCellValue());
//                    	break;
//                }
//                j++;    
//            }
//        }
//		return tags;
//	}
//	
//}
